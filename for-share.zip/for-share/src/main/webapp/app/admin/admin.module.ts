import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ParseLinks } from 'ng-jhipster';
import { SmartiTrackerService } from './../shared/tracker/tracker.service';

import { SmartiSharedModule } from '../shared';

import {
    adminState,
    AuditsComponent,
    LogsComponent,
    SmartiMetricsMonitoringModalComponent,
    SmartiMetricsMonitoringComponent,
    SmartiHealthModalComponent,
    SmartiHealthCheckComponent,
    SmartiConfigurationComponent,
    SmartiDocsComponent,
    AuditsService,
    SmartiConfigurationService,
    SmartiHealthService,
    SmartiMetricsService,
    SmartiTrackerComponent,
    LogsService,
} from './';


@NgModule({
    imports: [
        SmartiSharedModule,
        RouterModule.forRoot(adminState, { useHash: true })
    ],
    declarations: [
        AuditsComponent,
        LogsComponent,
        SmartiConfigurationComponent,
        SmartiHealthCheckComponent,
        SmartiHealthModalComponent,
        SmartiDocsComponent,
        SmartiTrackerComponent,
        SmartiMetricsMonitoringComponent,
        SmartiMetricsMonitoringModalComponent
    ],
    entryComponents: [
        SmartiHealthModalComponent,
        SmartiMetricsMonitoringModalComponent,
    ],
    providers: [
        AuditsService,
        SmartiConfigurationService,
        SmartiHealthService,
        SmartiMetricsService,
        LogsService,
        SmartiTrackerService,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartiAdminModule {}
