import { Route } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { SmartiConfigurationComponent } from './configuration.component';

export const configurationRoute: Route = {
  path: 'smarti-configuration',
  component: SmartiConfigurationComponent,
  data: {
    pageTitle: 'Configuration'
  }
};
