import { Route } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { SmartiDocsComponent } from './docs.component';

export const docsRoute: Route = {
  path: 'docs',
  component: SmartiDocsComponent,
  data: {
    pageTitle: 'API'
  }
};
