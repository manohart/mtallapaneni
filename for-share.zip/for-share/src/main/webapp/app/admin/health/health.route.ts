import { Route } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { SmartiHealthCheckComponent } from './health.component';

export const healthRoute: Route = {
  path: 'smarti-health',
  component: SmartiHealthCheckComponent,
  data: {
    pageTitle: 'Health Checks'
  }
};
