import { Route } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { SmartiMetricsMonitoringComponent } from './metrics.component';

export const metricsRoute: Route = {
  path: 'smarti-metrics',
  component: SmartiMetricsMonitoringComponent,
  data: {
    pageTitle: 'Application Metrics'
  }
};
