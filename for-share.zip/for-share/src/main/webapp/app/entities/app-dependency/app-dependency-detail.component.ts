import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AppDependency } from './app-dependency.model';
import { AppDependencyService } from './app-dependency.service';

@Component({
    selector: 'smarti-app-dependency-detail',
    templateUrl: './app-dependency-detail.component.html'
})
export class AppDependencyDetailComponent implements OnInit, OnDestroy {

    appDependency: AppDependency;
    private subscription: any;

    constructor(
        private appDependencyService: AppDependencyService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.appDependencyService.find(id).subscribe(appDependency => {
            this.appDependency = appDependency;
        });
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
