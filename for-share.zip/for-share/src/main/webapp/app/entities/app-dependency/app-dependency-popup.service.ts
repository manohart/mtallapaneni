import { Injectable, Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { AppDependency } from './app-dependency.model';
import { AppDependencyService } from './app-dependency.service';
@Injectable()
export class AppDependencyPopupService {
    private isOpen = false;
    constructor (
        private datePipe: DatePipe,
        private modalService: NgbModal,
        private router: Router,
        private appDependencyService: AppDependencyService

    ) {}

    open (component: Component, id?: number | any): NgbModalRef {
        if (this.isOpen) {
            return;
        }
        this.isOpen = true;

        if (id) {
            this.appDependencyService.find(id).subscribe(appDependency => {
                appDependency.updatedDate = this.datePipe
                    .transform(appDependency.updatedDate, 'yyyy-MM-ddThh:mm');
                this.appDependencyModalRef(component, appDependency);
            });
        } else {
            return this.appDependencyModalRef(component, new AppDependency());
        }
    }

    appDependencyModalRef(component: Component, appDependency: AppDependency): NgbModalRef {
        let modalRef = this.modalService.open(component, { size: 'lg', backdrop: 'static'});
        modalRef.componentInstance.appDependency = appDependency;
        modalRef.result.then(result => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        }, (reason) => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        });
        return modalRef;
    }
}
