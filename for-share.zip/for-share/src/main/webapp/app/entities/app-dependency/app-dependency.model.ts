import { Application } from '../application';
export class AppDependency {
    constructor(
        public id?: number,
        public isActive?: boolean,
        public updatedDate?: any,
        public application?: Application,
        public dependOn?: Application,
    ) {
        this.isActive = false;
    }
}
