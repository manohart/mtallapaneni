import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, CanActivate } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { PaginationUtil } from 'ng-jhipster';

import { AppDependencyComponent } from './app-dependency.component';
import { AppDependencyDetailComponent } from './app-dependency-detail.component';
import { AppDependencyPopupComponent } from './app-dependency-dialog.component';
import { AppDependencyDeletePopupComponent } from './app-dependency-delete-dialog.component';

import { Principal } from '../../shared';

@Injectable()
export class AppDependencyResolvePagingParams implements Resolve<any> {

  constructor(private paginationUtil: PaginationUtil) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
      let page = route.queryParams['page'] ? route.queryParams['page'] : '1';
      let sort = route.queryParams['sort'] ? route.queryParams['sort'] : 'id,asc';
      return {
          page: this.paginationUtil.parsePage(page),
          predicate: this.paginationUtil.parsePredicate(sort),
          ascending: this.paginationUtil.parseAscending(sort)
    };
  }
}

export const appDependencyRoute: Routes = [
  {
    path: 'app-dependency',
    component: AppDependencyComponent,
    resolve: {
      'pagingParams': AppDependencyResolvePagingParams
    },
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'AppDependencies'
    }
  }, {
    path: 'app-dependency/:id',
    component: AppDependencyDetailComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'AppDependencies'
    }
  }
];

export const appDependencyPopupRoute: Routes = [
  {
    path: 'app-dependency-new',
    component: AppDependencyPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'AppDependencies'
    },
    outlet: 'popup'
  },
  {
    path: 'app-dependency/:id/edit',
    component: AppDependencyPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'AppDependencies'
    },
    outlet: 'popup'
  },
  {
    path: 'app-dependency/:id/delete',
    component: AppDependencyDeletePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'AppDependencies'
    },
    outlet: 'popup'
  }
];
