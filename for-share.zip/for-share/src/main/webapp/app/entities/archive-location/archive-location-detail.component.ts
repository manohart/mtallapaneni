import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ArchiveLocation } from './archive-location.model';
import { ArchiveLocationService } from './archive-location.service';

@Component({
    selector: 'smarti-archive-location-detail',
    templateUrl: './archive-location-detail.component.html'
})
export class ArchiveLocationDetailComponent implements OnInit, OnDestroy {

    archiveLocation: ArchiveLocation;
    private subscription: any;

    constructor(
        private archiveLocationService: ArchiveLocationService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.archiveLocationService.find(id).subscribe(archiveLocation => {
            this.archiveLocation = archiveLocation;
        });
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
