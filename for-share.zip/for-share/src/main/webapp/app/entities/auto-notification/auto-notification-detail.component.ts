import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AutoNotification } from './auto-notification.model';
import { AutoNotificationService } from './auto-notification.service';

@Component({
    selector: 'smarti-auto-notification-detail',
    templateUrl: './auto-notification-detail.component.html'
})
export class AutoNotificationDetailComponent implements OnInit, OnDestroy {

    autoNotification: AutoNotification;
    private subscription: any;

    constructor(
        private autoNotificationService: AutoNotificationService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.autoNotificationService.find(id).subscribe(autoNotification => {
            this.autoNotification = autoNotification;
        });
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
