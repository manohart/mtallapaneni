import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager, AlertService } from 'ng-jhipster';

import { AutoNotification } from './auto-notification.model';
import { AutoNotificationPopupService } from './auto-notification-popup.service';
import { AutoNotificationService } from './auto-notification.service';
import { NotificationRule, NotificationRuleService } from '../notification-rule';
import { LineOfBusiness, LineOfBusinessService } from '../line-of-business';
import { Application, ApplicationService } from '../application';

@Component({
    selector: 'smarti-auto-notification-dialog',
    templateUrl: './auto-notification-dialog.component.html'
})
export class AutoNotificationDialogComponent implements OnInit {

    autoNotification: AutoNotification;
    authorities: any[];
    isSaving: boolean;

    notificationrules: NotificationRule[];

    lineofbusinesses: LineOfBusiness[];

    applications: Application[];
    constructor(
        public activeModal: NgbActiveModal,
        private alertService: AlertService,
        private autoNotificationService: AutoNotificationService,
        private notificationRuleService: NotificationRuleService,
        private lineOfBusinessService: LineOfBusinessService,
        private applicationService: ApplicationService,
        private eventManager: EventManager
    ) {
    }

    ngOnInit() {
        this.isSaving = false;
        this.authorities = ['ROLE_USER', 'ROLE_ADMIN'];
        this.notificationRuleService.query().subscribe(
            (res: Response) => { this.notificationrules = res.json(); }, (res: Response) => this.onError(res.json()));
        this.lineOfBusinessService.query().subscribe(
            (res: Response) => { this.lineofbusinesses = res.json(); }, (res: Response) => this.onError(res.json()));
        this.applicationService.query().subscribe(
            (res: Response) => { this.applications = res.json(); }, (res: Response) => this.onError(res.json()));
    }
    clear () {
        this.activeModal.dismiss('cancel');
    }

    save () {
        this.isSaving = true;
        if (this.autoNotification.id !== undefined) {
            this.autoNotificationService.update(this.autoNotification)
                .subscribe((res: AutoNotification) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        } else {
            this.autoNotificationService.create(this.autoNotification)
                .subscribe((res: AutoNotification) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        }
    }

    private onSaveSuccess (result: AutoNotification) {
        this.eventManager.broadcast({ name: 'autoNotificationListModification', content: 'OK'});
        this.isSaving = false;
        this.activeModal.dismiss(result);
    }

    private onSaveError (error) {
        this.isSaving = false;
        this.onError(error);
    }

    private onError (error) {
        this.alertService.error(error.message, null, null);
    }

    trackNotificationRuleById(index: number, item: NotificationRule) {
        return item.id;
    }

    trackLineOfBusinessById(index: number, item: LineOfBusiness) {
        return item.id;
    }

    trackApplicationById(index: number, item: Application) {
        return item.id;
    }
}

@Component({
    selector: 'smarti-auto-notification-popup',
    template: ''
})
export class AutoNotificationPopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private autoNotificationPopupService: AutoNotificationPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            if ( params['id'] ) {
                this.modalRef = this.autoNotificationPopupService
                    .open(AutoNotificationDialogComponent, params['id']);
            } else {
                this.modalRef = this.autoNotificationPopupService
                    .open(AutoNotificationDialogComponent);
            }

        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
