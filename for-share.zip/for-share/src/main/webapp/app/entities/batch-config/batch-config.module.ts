import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SmartiSharedModule } from '../../shared';

import {
    BatchConfigService,
    BatchConfigPopupService,
    BatchConfigComponent,
    BatchConfigDetailComponent,
    BatchConfigDialogComponent,
    BatchConfigPopupComponent,
    BatchConfigDeletePopupComponent,
    BatchConfigDeleteDialogComponent,
    batchConfigRoute,
    batchConfigPopupRoute,
    BatchConfigResolvePagingParams,
} from './';

let ENTITY_STATES = [
    ...batchConfigRoute,
    ...batchConfigPopupRoute,
];

@NgModule({
    imports: [
        SmartiSharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [
        BatchConfigComponent,
        BatchConfigDetailComponent,
        BatchConfigDialogComponent,
        BatchConfigDeleteDialogComponent,
        BatchConfigPopupComponent,
        BatchConfigDeletePopupComponent,
    ],
    entryComponents: [
        BatchConfigComponent,
        BatchConfigDialogComponent,
        BatchConfigPopupComponent,
        BatchConfigDeleteDialogComponent,
        BatchConfigDeletePopupComponent,
    ],
    providers: [
        BatchConfigService,
        BatchConfigPopupService,
        BatchConfigResolvePagingParams,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartiBatchConfigModule {}
