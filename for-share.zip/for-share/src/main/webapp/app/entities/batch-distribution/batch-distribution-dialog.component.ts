import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager, AlertService } from 'ng-jhipster';

import { BatchDistribution } from './batch-distribution.model';
import { BatchDistributionPopupService } from './batch-distribution-popup.service';
import { BatchDistributionService } from './batch-distribution.service';
import { Distribution, DistributionService } from '../distribution';
import { Application, ApplicationService } from '../application';

@Component({
    selector: 'smarti-batch-distribution-dialog',
    templateUrl: './batch-distribution-dialog.component.html'
})
export class BatchDistributionDialogComponent implements OnInit {

    batchDistribution: BatchDistribution;
    authorities: any[];
    isSaving: boolean;

    distributions: Distribution[];

    applications: Application[];
    constructor(
        public activeModal: NgbActiveModal,
        private alertService: AlertService,
        private batchDistributionService: BatchDistributionService,
        private distributionService: DistributionService,
        private applicationService: ApplicationService,
        private eventManager: EventManager
    ) {
    }

    ngOnInit() {
        this.isSaving = false;
        this.authorities = ['ROLE_USER', 'ROLE_ADMIN'];
        this.distributionService.query().subscribe(
            (res: Response) => { this.distributions = res.json(); }, (res: Response) => this.onError(res.json()));
        this.applicationService.query().subscribe(
            (res: Response) => { this.applications = res.json(); }, (res: Response) => this.onError(res.json()));
    }
    clear () {
        this.activeModal.dismiss('cancel');
    }

    save () {
        this.isSaving = true;
        if (this.batchDistribution.id !== undefined) {
            this.batchDistributionService.update(this.batchDistribution)
                .subscribe((res: BatchDistribution) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        } else {
            this.batchDistributionService.create(this.batchDistribution)
                .subscribe((res: BatchDistribution) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        }
    }

    private onSaveSuccess (result: BatchDistribution) {
        this.eventManager.broadcast({ name: 'batchDistributionListModification', content: 'OK'});
        this.isSaving = false;
        this.activeModal.dismiss(result);
    }

    private onSaveError (error) {
        this.isSaving = false;
        this.onError(error);
    }

    private onError (error) {
        this.alertService.error(error.message, null, null);
    }

    trackDistributionById(index: number, item: Distribution) {
        return item.id;
    }

    trackApplicationById(index: number, item: Application) {
        return item.id;
    }
}

@Component({
    selector: 'smarti-batch-distribution-popup',
    template: ''
})
export class BatchDistributionPopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private batchDistributionPopupService: BatchDistributionPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            if ( params['id'] ) {
                this.modalRef = this.batchDistributionPopupService
                    .open(BatchDistributionDialogComponent, params['id']);
            } else {
                this.modalRef = this.batchDistributionPopupService
                    .open(BatchDistributionDialogComponent);
            }

        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
