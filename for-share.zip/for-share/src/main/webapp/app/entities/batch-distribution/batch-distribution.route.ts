import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, CanActivate } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { PaginationUtil } from 'ng-jhipster';

import { BatchDistributionComponent } from './batch-distribution.component';
import { BatchDistributionDetailComponent } from './batch-distribution-detail.component';
import { BatchDistributionPopupComponent } from './batch-distribution-dialog.component';
import { BatchDistributionDeletePopupComponent } from './batch-distribution-delete-dialog.component';

import { Principal } from '../../shared';

@Injectable()
export class BatchDistributionResolvePagingParams implements Resolve<any> {

  constructor(private paginationUtil: PaginationUtil) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
      let page = route.queryParams['page'] ? route.queryParams['page'] : '1';
      let sort = route.queryParams['sort'] ? route.queryParams['sort'] : 'id,asc';
      return {
          page: this.paginationUtil.parsePage(page),
          predicate: this.paginationUtil.parsePredicate(sort),
          ascending: this.paginationUtil.parseAscending(sort)
    };
  }
}

export const batchDistributionRoute: Routes = [
  {
    path: 'batch-distribution',
    component: BatchDistributionComponent,
    resolve: {
      'pagingParams': BatchDistributionResolvePagingParams
    },
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchDistributions'
    }
  }, {
    path: 'batch-distribution/:id',
    component: BatchDistributionDetailComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchDistributions'
    }
  }
];

export const batchDistributionPopupRoute: Routes = [
  {
    path: 'batch-distribution-new',
    component: BatchDistributionPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchDistributions'
    },
    outlet: 'popup'
  },
  {
    path: 'batch-distribution/:id/edit',
    component: BatchDistributionPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchDistributions'
    },
    outlet: 'popup'
  },
  {
    path: 'batch-distribution/:id/delete',
    component: BatchDistributionDeletePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchDistributions'
    },
    outlet: 'popup'
  }
];
