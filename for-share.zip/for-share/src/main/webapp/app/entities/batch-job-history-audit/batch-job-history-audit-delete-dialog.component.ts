import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager } from 'ng-jhipster';

import { BatchJobHistoryAudit } from './batch-job-history-audit.model';
import { BatchJobHistoryAuditPopupService } from './batch-job-history-audit-popup.service';
import { BatchJobHistoryAuditService } from './batch-job-history-audit.service';

@Component({
    selector: 'smarti-batch-job-history-audit-delete-dialog',
    templateUrl: './batch-job-history-audit-delete-dialog.component.html'
})
export class BatchJobHistoryAuditDeleteDialogComponent {

    batchJobHistoryAudit: BatchJobHistoryAudit;

    constructor(
        private batchJobHistoryAuditService: BatchJobHistoryAuditService,
        public activeModal: NgbActiveModal,
        private eventManager: EventManager
    ) {
    }

    clear () {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete (id: number) {
        this.batchJobHistoryAuditService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'batchJobHistoryAuditListModification',
                content: 'Deleted an batchJobHistoryAudit'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'smarti-batch-job-history-audit-delete-popup',
    template: ''
})
export class BatchJobHistoryAuditDeletePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private batchJobHistoryAuditPopupService: BatchJobHistoryAuditPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            this.modalRef = this.batchJobHistoryAuditPopupService
                .open(BatchJobHistoryAuditDeleteDialogComponent, params['id']);
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
