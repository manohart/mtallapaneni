import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataUtils } from 'ng-jhipster';
import { BatchJobHistoryAudit } from './batch-job-history-audit.model';
import { BatchJobHistoryAuditService } from './batch-job-history-audit.service';

@Component({
    selector: 'smarti-batch-job-history-audit-detail',
    templateUrl: './batch-job-history-audit-detail.component.html'
})
export class BatchJobHistoryAuditDetailComponent implements OnInit, OnDestroy {

    batchJobHistoryAudit: BatchJobHistoryAudit;
    private subscription: any;

    constructor(
        private dataUtils: DataUtils,
        private batchJobHistoryAuditService: BatchJobHistoryAuditService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.batchJobHistoryAuditService.find(id).subscribe(batchJobHistoryAudit => {
            this.batchJobHistoryAudit = batchJobHistoryAudit;
        });
    }
    byteSize(field) {
        return this.dataUtils.byteSize(field);
    }

    openFile(contentType, field) {
        return this.dataUtils.openFile(contentType, field);
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
