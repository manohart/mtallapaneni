import { Injectable, Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { BatchJobHistoryAudit } from './batch-job-history-audit.model';
import { BatchJobHistoryAuditService } from './batch-job-history-audit.service';
@Injectable()
export class BatchJobHistoryAuditPopupService {
    private isOpen = false;
    constructor (
        private datePipe: DatePipe,
        private modalService: NgbModal,
        private router: Router,
        private batchJobHistoryAuditService: BatchJobHistoryAuditService

    ) {}

    open (component: Component, id?: number | any): NgbModalRef {
        if (this.isOpen) {
            return;
        }
        this.isOpen = true;

        if (id) {
            this.batchJobHistoryAuditService.find(id).subscribe(batchJobHistoryAudit => {
                if (batchJobHistoryAudit.businessDate) {
                    batchJobHistoryAudit.businessDate = {
                        year: batchJobHistoryAudit.businessDate.getFullYear(),
                        month: batchJobHistoryAudit.businessDate.getMonth() + 1,
                        day: batchJobHistoryAudit.businessDate.getDate()
                    };
                }
                batchJobHistoryAudit.startTime = this.datePipe
                    .transform(batchJobHistoryAudit.startTime, 'yyyy-MM-ddThh:mm');
                batchJobHistoryAudit.endTime = this.datePipe
                    .transform(batchJobHistoryAudit.endTime, 'yyyy-MM-ddThh:mm');
                batchJobHistoryAudit.updatedDate = this.datePipe
                    .transform(batchJobHistoryAudit.updatedDate, 'yyyy-MM-ddThh:mm');
                this.batchJobHistoryAuditModalRef(component, batchJobHistoryAudit);
            });
        } else {
            return this.batchJobHistoryAuditModalRef(component, new BatchJobHistoryAudit());
        }
    }

    batchJobHistoryAuditModalRef(component: Component, batchJobHistoryAudit: BatchJobHistoryAudit): NgbModalRef {
        let modalRef = this.modalService.open(component, { size: 'lg', backdrop: 'static'});
        modalRef.componentInstance.batchJobHistoryAudit = batchJobHistoryAudit;
        modalRef.result.then(result => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        }, (reason) => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        });
        return modalRef;
    }
}
