
const enum BatchFailureRootCause {
    'UPSTREAM_DATA',
    'OWN_DATA',
    'PROGRAM_BUG',
    'APP_CONFIGURATION',
    'DATABASE_BOX',
    'APPLICATION_BOX',
    'UNKNOWN',
    'OTHER'

};
import { BatchJobHistory } from '../batch-job-history';
export class BatchJobHistoryAudit {
    constructor(
        public id?: number,
        public businessDate?: any,
        public initialStatus?: string,
        public finalStatus?: string,
        public currentStep?: string,
        public errorMessage?: any,
        public rootCauseCode?: BatchFailureRootCause,
        public rootCause?: any,
        public resolution?: any,
        public startTime?: any,
        public endTime?: any,
        public updatedDate?: any,
        public batchJob?: BatchJobHistory,
    ) {
    }
}
