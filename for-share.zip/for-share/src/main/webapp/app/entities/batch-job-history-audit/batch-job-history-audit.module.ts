import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SmartiSharedModule } from '../../shared';

import {
    BatchJobHistoryAuditService,
    BatchJobHistoryAuditPopupService,
    BatchJobHistoryAuditComponent,
    BatchJobHistoryAuditDetailComponent,
    BatchJobHistoryAuditDialogComponent,
    BatchJobHistoryAuditPopupComponent,
    BatchJobHistoryAuditDeletePopupComponent,
    BatchJobHistoryAuditDeleteDialogComponent,
    batchJobHistoryAuditRoute,
    batchJobHistoryAuditPopupRoute,
    BatchJobHistoryAuditResolvePagingParams,
} from './';

let ENTITY_STATES = [
    ...batchJobHistoryAuditRoute,
    ...batchJobHistoryAuditPopupRoute,
];

@NgModule({
    imports: [
        SmartiSharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [
        BatchJobHistoryAuditComponent,
        BatchJobHistoryAuditDetailComponent,
        BatchJobHistoryAuditDialogComponent,
        BatchJobHistoryAuditDeleteDialogComponent,
        BatchJobHistoryAuditPopupComponent,
        BatchJobHistoryAuditDeletePopupComponent,
    ],
    entryComponents: [
        BatchJobHistoryAuditComponent,
        BatchJobHistoryAuditDialogComponent,
        BatchJobHistoryAuditPopupComponent,
        BatchJobHistoryAuditDeleteDialogComponent,
        BatchJobHistoryAuditDeletePopupComponent,
    ],
    providers: [
        BatchJobHistoryAuditService,
        BatchJobHistoryAuditPopupService,
        BatchJobHistoryAuditResolvePagingParams,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartiBatchJobHistoryAuditModule {}
