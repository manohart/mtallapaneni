import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, CanActivate } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { PaginationUtil } from 'ng-jhipster';

import { BatchJobHistoryAuditComponent } from './batch-job-history-audit.component';
import { BatchJobHistoryAuditDetailComponent } from './batch-job-history-audit-detail.component';
import { BatchJobHistoryAuditPopupComponent } from './batch-job-history-audit-dialog.component';
import { BatchJobHistoryAuditDeletePopupComponent } from './batch-job-history-audit-delete-dialog.component';

import { Principal } from '../../shared';

@Injectable()
export class BatchJobHistoryAuditResolvePagingParams implements Resolve<any> {

  constructor(private paginationUtil: PaginationUtil) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
      let page = route.queryParams['page'] ? route.queryParams['page'] : '1';
      let sort = route.queryParams['sort'] ? route.queryParams['sort'] : 'id,asc';
      return {
          page: this.paginationUtil.parsePage(page),
          predicate: this.paginationUtil.parsePredicate(sort),
          ascending: this.paginationUtil.parseAscending(sort)
    };
  }
}

export const batchJobHistoryAuditRoute: Routes = [
  {
    path: 'batch-job-history-audit',
    component: BatchJobHistoryAuditComponent,
    resolve: {
      'pagingParams': BatchJobHistoryAuditResolvePagingParams
    },
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchJobHistoryAudits'
    }
  }, {
    path: 'batch-job-history-audit/:id',
    component: BatchJobHistoryAuditDetailComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchJobHistoryAudits'
    }
  }
];

export const batchJobHistoryAuditPopupRoute: Routes = [
  {
    path: 'batch-job-history-audit-new',
    component: BatchJobHistoryAuditPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchJobHistoryAudits'
    },
    outlet: 'popup'
  },
  {
    path: 'batch-job-history-audit/:id/edit',
    component: BatchJobHistoryAuditPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchJobHistoryAudits'
    },
    outlet: 'popup'
  },
  {
    path: 'batch-job-history-audit/:id/delete',
    component: BatchJobHistoryAuditDeletePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchJobHistoryAudits'
    },
    outlet: 'popup'
  }
];
