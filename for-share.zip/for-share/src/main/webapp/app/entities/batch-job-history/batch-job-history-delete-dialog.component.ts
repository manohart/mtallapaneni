import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager } from 'ng-jhipster';

import { BatchJobHistory } from './batch-job-history.model';
import { BatchJobHistoryPopupService } from './batch-job-history-popup.service';
import { BatchJobHistoryService } from './batch-job-history.service';

@Component({
    selector: 'smarti-batch-job-history-delete-dialog',
    templateUrl: './batch-job-history-delete-dialog.component.html'
})
export class BatchJobHistoryDeleteDialogComponent {

    batchJobHistory: BatchJobHistory;

    constructor(
        private batchJobHistoryService: BatchJobHistoryService,
        public activeModal: NgbActiveModal,
        private eventManager: EventManager
    ) {
    }

    clear () {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete (id: number) {
        this.batchJobHistoryService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'batchJobHistoryListModification',
                content: 'Deleted an batchJobHistory'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'smarti-batch-job-history-delete-popup',
    template: ''
})
export class BatchJobHistoryDeletePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private batchJobHistoryPopupService: BatchJobHistoryPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            this.modalRef = this.batchJobHistoryPopupService
                .open(BatchJobHistoryDeleteDialogComponent, params['id']);
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
