import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BatchJobHistory } from './batch-job-history.model';
import { BatchJobHistoryService } from './batch-job-history.service';

@Component({
    selector: 'smarti-batch-job-history-detail',
    templateUrl: './batch-job-history-detail.component.html'
})
export class BatchJobHistoryDetailComponent implements OnInit, OnDestroy {

    batchJobHistory: BatchJobHistory;
    private subscription: any;

    constructor(
        private batchJobHistoryService: BatchJobHistoryService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.batchJobHistoryService.find(id).subscribe(batchJobHistory => {
            this.batchJobHistory = batchJobHistory;
        });
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
