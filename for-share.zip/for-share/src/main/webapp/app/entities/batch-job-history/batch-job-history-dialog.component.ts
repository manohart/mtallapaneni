import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager, AlertService } from 'ng-jhipster';

import { BatchJobHistory } from './batch-job-history.model';
import { BatchJobHistoryPopupService } from './batch-job-history-popup.service';
import { BatchJobHistoryService } from './batch-job-history.service';
import { BatchJobIssue, BatchJobIssueService } from '../batch-job-issue';
import { BatchJob, BatchJobService } from '../batch-job';

@Component({
    selector: 'smarti-batch-job-history-dialog',
    templateUrl: './batch-job-history-dialog.component.html'
})
export class BatchJobHistoryDialogComponent implements OnInit {

    batchJobHistory: BatchJobHistory;
    authorities: any[];
    isSaving: boolean;

    batchjobissues: BatchJobIssue[];

    batchjobs: BatchJob[];
    constructor(
        public activeModal: NgbActiveModal,
        private alertService: AlertService,
        private batchJobHistoryService: BatchJobHistoryService,
        private batchJobIssueService: BatchJobIssueService,
        private batchJobService: BatchJobService,
        private eventManager: EventManager
    ) {
    }

    ngOnInit() {
        this.isSaving = false;
        this.authorities = ['ROLE_USER', 'ROLE_ADMIN'];
        this.batchJobIssueService.query().subscribe(
            (res: Response) => { this.batchjobissues = res.json(); }, (res: Response) => this.onError(res.json()));
        this.batchJobService.query().subscribe(
            (res: Response) => { this.batchjobs = res.json(); }, (res: Response) => this.onError(res.json()));
    }
    clear () {
        this.activeModal.dismiss('cancel');
    }

    save () {
        this.isSaving = true;
        if (this.batchJobHistory.id !== undefined) {
            this.batchJobHistoryService.update(this.batchJobHistory)
                .subscribe((res: BatchJobHistory) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        } else {
            this.batchJobHistoryService.create(this.batchJobHistory)
                .subscribe((res: BatchJobHistory) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        }
    }

    private onSaveSuccess (result: BatchJobHistory) {
        this.eventManager.broadcast({ name: 'batchJobHistoryListModification', content: 'OK'});
        this.isSaving = false;
        this.activeModal.dismiss(result);
    }

    private onSaveError (error) {
        this.isSaving = false;
        this.onError(error);
    }

    private onError (error) {
        this.alertService.error(error.message, null, null);
    }

    trackBatchJobIssueById(index: number, item: BatchJobIssue) {
        return item.id;
    }

    trackBatchJobById(index: number, item: BatchJob) {
        return item.id;
    }
}

@Component({
    selector: 'smarti-batch-job-history-popup',
    template: ''
})
export class BatchJobHistoryPopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private batchJobHistoryPopupService: BatchJobHistoryPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            if ( params['id'] ) {
                this.modalRef = this.batchJobHistoryPopupService
                    .open(BatchJobHistoryDialogComponent, params['id']);
            } else {
                this.modalRef = this.batchJobHistoryPopupService
                    .open(BatchJobHistoryDialogComponent);
            }

        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
