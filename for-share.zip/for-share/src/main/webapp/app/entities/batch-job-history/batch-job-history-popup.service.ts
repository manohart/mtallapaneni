import { Injectable, Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { BatchJobHistory } from './batch-job-history.model';
import { BatchJobHistoryService } from './batch-job-history.service';
@Injectable()
export class BatchJobHistoryPopupService {
    private isOpen = false;
    constructor (
        private datePipe: DatePipe,
        private modalService: NgbModal,
        private router: Router,
        private batchJobHistoryService: BatchJobHistoryService

    ) {}

    open (component: Component, id?: number | any): NgbModalRef {
        if (this.isOpen) {
            return;
        }
        this.isOpen = true;

        if (id) {
            this.batchJobHistoryService.find(id).subscribe(batchJobHistory => {
                if (batchJobHistory.businessDate) {
                    batchJobHistory.businessDate = {
                        year: batchJobHistory.businessDate.getFullYear(),
                        month: batchJobHistory.businessDate.getMonth() + 1,
                        day: batchJobHistory.businessDate.getDate()
                    };
                }
                batchJobHistory.startTime = this.datePipe
                    .transform(batchJobHistory.startTime, 'yyyy-MM-ddThh:mm');
                batchJobHistory.endTime = this.datePipe
                    .transform(batchJobHistory.endTime, 'yyyy-MM-ddThh:mm');
                this.batchJobHistoryModalRef(component, batchJobHistory);
            });
        } else {
            return this.batchJobHistoryModalRef(component, new BatchJobHistory());
        }
    }

    batchJobHistoryModalRef(component: Component, batchJobHistory: BatchJobHistory): NgbModalRef {
        let modalRef = this.modalService.open(component, { size: 'lg', backdrop: 'static'});
        modalRef.componentInstance.batchJobHistory = batchJobHistory;
        modalRef.result.then(result => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        }, (reason) => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        });
        return modalRef;
    }
}
