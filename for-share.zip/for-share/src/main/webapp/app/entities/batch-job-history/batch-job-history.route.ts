import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, CanActivate } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { PaginationUtil } from 'ng-jhipster';

import { BatchJobHistoryComponent } from './batch-job-history.component';
import { BatchJobHistoryDetailComponent } from './batch-job-history-detail.component';
import { BatchJobHistoryPopupComponent } from './batch-job-history-dialog.component';
import { BatchJobHistoryDeletePopupComponent } from './batch-job-history-delete-dialog.component';

import { Principal } from '../../shared';

@Injectable()
export class BatchJobHistoryResolvePagingParams implements Resolve<any> {

  constructor(private paginationUtil: PaginationUtil) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
      let page = route.queryParams['page'] ? route.queryParams['page'] : '1';
      let sort = route.queryParams['sort'] ? route.queryParams['sort'] : 'id,asc';
      return {
          page: this.paginationUtil.parsePage(page),
          predicate: this.paginationUtil.parsePredicate(sort),
          ascending: this.paginationUtil.parseAscending(sort)
    };
  }
}

export const batchJobHistoryRoute: Routes = [
  {
    path: 'batch-job-history',
    component: BatchJobHistoryComponent,
    resolve: {
      'pagingParams': BatchJobHistoryResolvePagingParams
    },
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchJobHistories'
    }
  }, {
    path: 'batch-job-history/:id',
    component: BatchJobHistoryDetailComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchJobHistories'
    }
  }
];

export const batchJobHistoryPopupRoute: Routes = [
  {
    path: 'batch-job-history-new',
    component: BatchJobHistoryPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchJobHistories'
    },
    outlet: 'popup'
  },
  {
    path: 'batch-job-history/:id/edit',
    component: BatchJobHistoryPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchJobHistories'
    },
    outlet: 'popup'
  },
  {
    path: 'batch-job-history/:id/delete',
    component: BatchJobHistoryDeletePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchJobHistories'
    },
    outlet: 'popup'
  }
];
