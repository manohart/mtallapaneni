import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataUtils } from 'ng-jhipster';
import { BatchJobIssue } from './batch-job-issue.model';
import { BatchJobIssueService } from './batch-job-issue.service';

@Component({
    selector: 'smarti-batch-job-issue-detail',
    templateUrl: './batch-job-issue-detail.component.html'
})
export class BatchJobIssueDetailComponent implements OnInit, OnDestroy {

    batchJobIssue: BatchJobIssue;
    private subscription: any;

    constructor(
        private dataUtils: DataUtils,
        private batchJobIssueService: BatchJobIssueService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.batchJobIssueService.find(id).subscribe(batchJobIssue => {
            this.batchJobIssue = batchJobIssue;
        });
    }
    byteSize(field) {
        return this.dataUtils.byteSize(field);
    }

    openFile(contentType, field) {
        return this.dataUtils.openFile(contentType, field);
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
