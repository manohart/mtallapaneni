import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager, AlertService, DataUtils } from 'ng-jhipster';

import { BatchJobIssue } from './batch-job-issue.model';
import { BatchJobIssuePopupService } from './batch-job-issue-popup.service';
import { BatchJobIssueService } from './batch-job-issue.service';
import { BatchJobHistory, BatchJobHistoryService } from '../batch-job-history';

@Component({
    selector: 'smarti-batch-job-issue-dialog',
    templateUrl: './batch-job-issue-dialog.component.html'
})
export class BatchJobIssueDialogComponent implements OnInit {

    batchJobIssue: BatchJobIssue;
    authorities: any[];
    isSaving: boolean;

    batchjobhistories: BatchJobHistory[];
    constructor(
        public activeModal: NgbActiveModal,
        private dataUtils: DataUtils,
        private alertService: AlertService,
        private batchJobIssueService: BatchJobIssueService,
        private batchJobHistoryService: BatchJobHistoryService,
        private eventManager: EventManager
    ) {
    }

    ngOnInit() {
        this.isSaving = false;
        this.authorities = ['ROLE_USER', 'ROLE_ADMIN'];
        this.batchJobHistoryService.query().subscribe(
            (res: Response) => { this.batchjobhistories = res.json(); }, (res: Response) => this.onError(res.json()));
    }
    byteSize(field) {
        return this.dataUtils.byteSize(field);
    }

    openFile(contentType, field) {
        return this.dataUtils.openFile(contentType, field);
    }

    setFileData($event, batchJobIssue, field, isImage) {
        if ($event.target.files && $event.target.files[0]) {
            let $file = $event.target.files[0];
            if (isImage && !/^image\//.test($file.type)) {
                return;
            }
            this.dataUtils.toBase64($file, (base64Data) => {
                batchJobIssue[field] = base64Data;
                batchJobIssue[`${field}ContentType`] = $file.type;
            });
        }
    }
    clear () {
        this.activeModal.dismiss('cancel');
    }

    save () {
        this.isSaving = true;
        if (this.batchJobIssue.id !== undefined) {
            this.batchJobIssueService.update(this.batchJobIssue)
                .subscribe((res: BatchJobIssue) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        } else {
            this.batchJobIssueService.create(this.batchJobIssue)
                .subscribe((res: BatchJobIssue) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        }
    }

    private onSaveSuccess (result: BatchJobIssue) {
        this.eventManager.broadcast({ name: 'batchJobIssueListModification', content: 'OK'});
        this.isSaving = false;
        this.activeModal.dismiss(result);
    }

    private onSaveError (error) {
        this.isSaving = false;
        this.onError(error);
    }

    private onError (error) {
        this.alertService.error(error.message, null, null);
    }

    trackBatchJobHistoryById(index: number, item: BatchJobHistory) {
        return item.id;
    }
}

@Component({
    selector: 'smarti-batch-job-issue-popup',
    template: ''
})
export class BatchJobIssuePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private batchJobIssuePopupService: BatchJobIssuePopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            if ( params['id'] ) {
                this.modalRef = this.batchJobIssuePopupService
                    .open(BatchJobIssueDialogComponent, params['id']);
            } else {
                this.modalRef = this.batchJobIssuePopupService
                    .open(BatchJobIssueDialogComponent);
            }

        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
