import { Injectable, Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { BatchJobIssue } from './batch-job-issue.model';
import { BatchJobIssueService } from './batch-job-issue.service';
@Injectable()
export class BatchJobIssuePopupService {
    private isOpen = false;
    constructor (
        private datePipe: DatePipe,
        private modalService: NgbModal,
        private router: Router,
        private batchJobIssueService: BatchJobIssueService

    ) {}

    open (component: Component, id?: number | any): NgbModalRef {
        if (this.isOpen) {
            return;
        }
        this.isOpen = true;

        if (id) {
            this.batchJobIssueService.find(id).subscribe(batchJobIssue => {
                if (batchJobIssue.businessDate) {
                    batchJobIssue.businessDate = {
                        year: batchJobIssue.businessDate.getFullYear(),
                        month: batchJobIssue.businessDate.getMonth() + 1,
                        day: batchJobIssue.businessDate.getDate()
                    };
                }
                batchJobIssue.startTime = this.datePipe
                    .transform(batchJobIssue.startTime, 'yyyy-MM-ddThh:mm');
                batchJobIssue.endTime = this.datePipe
                    .transform(batchJobIssue.endTime, 'yyyy-MM-ddThh:mm');
                batchJobIssue.updatedDate = this.datePipe
                    .transform(batchJobIssue.updatedDate, 'yyyy-MM-ddThh:mm');
                this.batchJobIssueModalRef(component, batchJobIssue);
            });
        } else {
            return this.batchJobIssueModalRef(component, new BatchJobIssue());
        }
    }

    batchJobIssueModalRef(component: Component, batchJobIssue: BatchJobIssue): NgbModalRef {
        let modalRef = this.modalService.open(component, { size: 'lg', backdrop: 'static'});
        modalRef.componentInstance.batchJobIssue = batchJobIssue;
        modalRef.result.then(result => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        }, (reason) => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        });
        return modalRef;
    }
}
