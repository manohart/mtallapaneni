import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SmartiSharedModule } from '../../shared';

import {
    BatchJobIssueService,
    BatchJobIssuePopupService,
    BatchJobIssueComponent,
    BatchJobIssueDetailComponent,
    BatchJobIssueDialogComponent,
    BatchJobIssuePopupComponent,
    BatchJobIssueDeletePopupComponent,
    BatchJobIssueDeleteDialogComponent,
    batchJobIssueRoute,
    batchJobIssuePopupRoute,
    BatchJobIssueResolvePagingParams,
} from './';

let ENTITY_STATES = [
    ...batchJobIssueRoute,
    ...batchJobIssuePopupRoute,
];

@NgModule({
    imports: [
        SmartiSharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [
        BatchJobIssueComponent,
        BatchJobIssueDetailComponent,
        BatchJobIssueDialogComponent,
        BatchJobIssueDeleteDialogComponent,
        BatchJobIssuePopupComponent,
        BatchJobIssueDeletePopupComponent,
    ],
    entryComponents: [
        BatchJobIssueComponent,
        BatchJobIssueDialogComponent,
        BatchJobIssuePopupComponent,
        BatchJobIssueDeleteDialogComponent,
        BatchJobIssueDeletePopupComponent,
    ],
    providers: [
        BatchJobIssueService,
        BatchJobIssuePopupService,
        BatchJobIssueResolvePagingParams,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartiBatchJobIssueModule {}
