import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BatchJob } from './batch-job.model';
import { BatchJobService } from './batch-job.service';

@Component({
    selector: 'smarti-batch-job-detail',
    templateUrl: './batch-job-detail.component.html'
})
export class BatchJobDetailComponent implements OnInit, OnDestroy {

    batchJob: BatchJob;
    private subscription: any;

    constructor(
        private batchJobService: BatchJobService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.batchJobService.find(id).subscribe(batchJob => {
            this.batchJob = batchJob;
        });
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
