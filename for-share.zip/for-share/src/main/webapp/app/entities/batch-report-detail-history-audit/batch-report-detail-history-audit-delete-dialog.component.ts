import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager } from 'ng-jhipster';

import { BatchReportDetailHistoryAudit } from './batch-report-detail-history-audit.model';
import { BatchReportDetailHistoryAuditPopupService } from './batch-report-detail-history-audit-popup.service';
import { BatchReportDetailHistoryAuditService } from './batch-report-detail-history-audit.service';

@Component({
    selector: 'smarti-batch-report-detail-history-audit-delete-dialog',
    templateUrl: './batch-report-detail-history-audit-delete-dialog.component.html'
})
export class BatchReportDetailHistoryAuditDeleteDialogComponent {

    batchReportDetailHistoryAudit: BatchReportDetailHistoryAudit;

    constructor(
        private batchReportDetailHistoryAuditService: BatchReportDetailHistoryAuditService,
        public activeModal: NgbActiveModal,
        private eventManager: EventManager
    ) {
    }

    clear () {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete (id: number) {
        this.batchReportDetailHistoryAuditService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'batchReportDetailHistoryAuditListModification',
                content: 'Deleted an batchReportDetailHistoryAudit'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'smarti-batch-report-detail-history-audit-delete-popup',
    template: ''
})
export class BatchReportDetailHistoryAuditDeletePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private batchReportDetailHistoryAuditPopupService: BatchReportDetailHistoryAuditPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            this.modalRef = this.batchReportDetailHistoryAuditPopupService
                .open(BatchReportDetailHistoryAuditDeleteDialogComponent, params['id']);
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
