import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataUtils } from 'ng-jhipster';
import { BatchReportDetailHistoryAudit } from './batch-report-detail-history-audit.model';
import { BatchReportDetailHistoryAuditService } from './batch-report-detail-history-audit.service';

@Component({
    selector: 'smarti-batch-report-detail-history-audit-detail',
    templateUrl: './batch-report-detail-history-audit-detail.component.html'
})
export class BatchReportDetailHistoryAuditDetailComponent implements OnInit, OnDestroy {

    batchReportDetailHistoryAudit: BatchReportDetailHistoryAudit;
    private subscription: any;

    constructor(
        private dataUtils: DataUtils,
        private batchReportDetailHistoryAuditService: BatchReportDetailHistoryAuditService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.batchReportDetailHistoryAuditService.find(id).subscribe(batchReportDetailHistoryAudit => {
            this.batchReportDetailHistoryAudit = batchReportDetailHistoryAudit;
        });
    }
    byteSize(field) {
        return this.dataUtils.byteSize(field);
    }

    openFile(contentType, field) {
        return this.dataUtils.openFile(contentType, field);
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
