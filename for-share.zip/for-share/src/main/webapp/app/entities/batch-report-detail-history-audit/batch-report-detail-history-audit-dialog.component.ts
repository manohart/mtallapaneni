import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager, AlertService, DataUtils } from 'ng-jhipster';

import { BatchReportDetailHistoryAudit } from './batch-report-detail-history-audit.model';
import { BatchReportDetailHistoryAuditPopupService } from './batch-report-detail-history-audit-popup.service';
import { BatchReportDetailHistoryAuditService } from './batch-report-detail-history-audit.service';
import { BatchReportHistory, BatchReportHistoryService } from '../batch-report-history';

@Component({
    selector: 'smarti-batch-report-detail-history-audit-dialog',
    templateUrl: './batch-report-detail-history-audit-dialog.component.html'
})
export class BatchReportDetailHistoryAuditDialogComponent implements OnInit {

    batchReportDetailHistoryAudit: BatchReportDetailHistoryAudit;
    authorities: any[];
    isSaving: boolean;

    batchreporthistories: BatchReportHistory[];
    constructor(
        public activeModal: NgbActiveModal,
        private dataUtils: DataUtils,
        private alertService: AlertService,
        private batchReportDetailHistoryAuditService: BatchReportDetailHistoryAuditService,
        private batchReportHistoryService: BatchReportHistoryService,
        private eventManager: EventManager
    ) {
    }

    ngOnInit() {
        this.isSaving = false;
        this.authorities = ['ROLE_USER', 'ROLE_ADMIN'];
        this.batchReportHistoryService.query().subscribe(
            (res: Response) => { this.batchreporthistories = res.json(); }, (res: Response) => this.onError(res.json()));
    }
    byteSize(field) {
        return this.dataUtils.byteSize(field);
    }

    openFile(contentType, field) {
        return this.dataUtils.openFile(contentType, field);
    }

    setFileData($event, batchReportDetailHistoryAudit, field, isImage) {
        if ($event.target.files && $event.target.files[0]) {
            let $file = $event.target.files[0];
            if (isImage && !/^image\//.test($file.type)) {
                return;
            }
            this.dataUtils.toBase64($file, (base64Data) => {
                batchReportDetailHistoryAudit[field] = base64Data;
                batchReportDetailHistoryAudit[`${field}ContentType`] = $file.type;
            });
        }
    }
    clear () {
        this.activeModal.dismiss('cancel');
    }

    save () {
        this.isSaving = true;
        if (this.batchReportDetailHistoryAudit.id !== undefined) {
            this.batchReportDetailHistoryAuditService.update(this.batchReportDetailHistoryAudit)
                .subscribe((res: BatchReportDetailHistoryAudit) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        } else {
            this.batchReportDetailHistoryAuditService.create(this.batchReportDetailHistoryAudit)
                .subscribe((res: BatchReportDetailHistoryAudit) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        }
    }

    private onSaveSuccess (result: BatchReportDetailHistoryAudit) {
        this.eventManager.broadcast({ name: 'batchReportDetailHistoryAuditListModification', content: 'OK'});
        this.isSaving = false;
        this.activeModal.dismiss(result);
    }

    private onSaveError (error) {
        this.isSaving = false;
        this.onError(error);
    }

    private onError (error) {
        this.alertService.error(error.message, null, null);
    }

    trackBatchReportHistoryById(index: number, item: BatchReportHistory) {
        return item.id;
    }
}

@Component({
    selector: 'smarti-batch-report-detail-history-audit-popup',
    template: ''
})
export class BatchReportDetailHistoryAuditPopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private batchReportDetailHistoryAuditPopupService: BatchReportDetailHistoryAuditPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            if ( params['id'] ) {
                this.modalRef = this.batchReportDetailHistoryAuditPopupService
                    .open(BatchReportDetailHistoryAuditDialogComponent, params['id']);
            } else {
                this.modalRef = this.batchReportDetailHistoryAuditPopupService
                    .open(BatchReportDetailHistoryAuditDialogComponent);
            }

        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
