import { Injectable, Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { BatchReportDetailHistoryAudit } from './batch-report-detail-history-audit.model';
import { BatchReportDetailHistoryAuditService } from './batch-report-detail-history-audit.service';
@Injectable()
export class BatchReportDetailHistoryAuditPopupService {
    private isOpen = false;
    constructor (
        private datePipe: DatePipe,
        private modalService: NgbModal,
        private router: Router,
        private batchReportDetailHistoryAuditService: BatchReportDetailHistoryAuditService

    ) {}

    open (component: Component, id?: number | any): NgbModalRef {
        if (this.isOpen) {
            return;
        }
        this.isOpen = true;

        if (id) {
            this.batchReportDetailHistoryAuditService.find(id).subscribe(batchReportDetailHistoryAudit => {
                batchReportDetailHistoryAudit.updatedDate = this.datePipe
                    .transform(batchReportDetailHistoryAudit.updatedDate, 'yyyy-MM-ddThh:mm');
                this.batchReportDetailHistoryAuditModalRef(component, batchReportDetailHistoryAudit);
            });
        } else {
            return this.batchReportDetailHistoryAuditModalRef(component, new BatchReportDetailHistoryAudit());
        }
    }

    batchReportDetailHistoryAuditModalRef(component: Component, batchReportDetailHistoryAudit: BatchReportDetailHistoryAudit): NgbModalRef {
        let modalRef = this.modalService.open(component, { size: 'lg', backdrop: 'static'});
        modalRef.componentInstance.batchReportDetailHistoryAudit = batchReportDetailHistoryAudit;
        modalRef.result.then(result => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        }, (reason) => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        });
        return modalRef;
    }
}
