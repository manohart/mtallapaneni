import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SmartiSharedModule } from '../../shared';

import {
    BatchReportDetailHistoryAuditService,
    BatchReportDetailHistoryAuditPopupService,
    BatchReportDetailHistoryAuditComponent,
    BatchReportDetailHistoryAuditDetailComponent,
    BatchReportDetailHistoryAuditDialogComponent,
    BatchReportDetailHistoryAuditPopupComponent,
    BatchReportDetailHistoryAuditDeletePopupComponent,
    BatchReportDetailHistoryAuditDeleteDialogComponent,
    batchReportDetailHistoryAuditRoute,
    batchReportDetailHistoryAuditPopupRoute,
    BatchReportDetailHistoryAuditResolvePagingParams,
} from './';

let ENTITY_STATES = [
    ...batchReportDetailHistoryAuditRoute,
    ...batchReportDetailHistoryAuditPopupRoute,
];

@NgModule({
    imports: [
        SmartiSharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [
        BatchReportDetailHistoryAuditComponent,
        BatchReportDetailHistoryAuditDetailComponent,
        BatchReportDetailHistoryAuditDialogComponent,
        BatchReportDetailHistoryAuditDeleteDialogComponent,
        BatchReportDetailHistoryAuditPopupComponent,
        BatchReportDetailHistoryAuditDeletePopupComponent,
    ],
    entryComponents: [
        BatchReportDetailHistoryAuditComponent,
        BatchReportDetailHistoryAuditDialogComponent,
        BatchReportDetailHistoryAuditPopupComponent,
        BatchReportDetailHistoryAuditDeleteDialogComponent,
        BatchReportDetailHistoryAuditDeletePopupComponent,
    ],
    providers: [
        BatchReportDetailHistoryAuditService,
        BatchReportDetailHistoryAuditPopupService,
        BatchReportDetailHistoryAuditResolvePagingParams,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartiBatchReportDetailHistoryAuditModule {}
