import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, CanActivate } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { PaginationUtil } from 'ng-jhipster';

import { BatchReportDetailHistoryAuditComponent } from './batch-report-detail-history-audit.component';
import { BatchReportDetailHistoryAuditDetailComponent } from './batch-report-detail-history-audit-detail.component';
import { BatchReportDetailHistoryAuditPopupComponent } from './batch-report-detail-history-audit-dialog.component';
import { BatchReportDetailHistoryAuditDeletePopupComponent }
    from './batch-report-detail-history-audit-delete-dialog.component';

import { Principal } from '../../shared';

@Injectable()
export class BatchReportDetailHistoryAuditResolvePagingParams implements Resolve<any> {

  constructor(private paginationUtil: PaginationUtil) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
      let page = route.queryParams['page'] ? route.queryParams['page'] : '1';
      let sort = route.queryParams['sort'] ? route.queryParams['sort'] : 'id,asc';
      return {
          page: this.paginationUtil.parsePage(page),
          predicate: this.paginationUtil.parsePredicate(sort),
          ascending: this.paginationUtil.parseAscending(sort)
    };
  }
}

export const batchReportDetailHistoryAuditRoute: Routes = [
  {
    path: 'batch-report-detail-history-audit',
    component: BatchReportDetailHistoryAuditComponent,
    resolve: {
      'pagingParams': BatchReportDetailHistoryAuditResolvePagingParams
    },
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchReportDetailHistoryAudits'
    }
  }, {
    path: 'batch-report-detail-history-audit/:id',
    component: BatchReportDetailHistoryAuditDetailComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchReportDetailHistoryAudits'
    }
  }
];

export const batchReportDetailHistoryAuditPopupRoute: Routes = [
  {
    path: 'batch-report-detail-history-audit-new',
    component: BatchReportDetailHistoryAuditPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchReportDetailHistoryAudits'
    },
    outlet: 'popup'
  },
  {
    path: 'batch-report-detail-history-audit/:id/edit',
    component: BatchReportDetailHistoryAuditPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchReportDetailHistoryAudits'
    },
    outlet: 'popup'
  },
  {
    path: 'batch-report-detail-history-audit/:id/delete',
    component: BatchReportDetailHistoryAuditDeletePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchReportDetailHistoryAudits'
    },
    outlet: 'popup'
  }
];
