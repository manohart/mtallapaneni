import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BatchReportDetailHistory } from './batch-report-detail-history.model';
import { BatchReportDetailHistoryService } from './batch-report-detail-history.service';

@Component({
    selector: 'smarti-batch-report-detail-history-detail',
    templateUrl: './batch-report-detail-history-detail.component.html'
})
export class BatchReportDetailHistoryDetailComponent implements OnInit, OnDestroy {

    batchReportDetailHistory: BatchReportDetailHistory;
    private subscription: any;

    constructor(
        private batchReportDetailHistoryService: BatchReportDetailHistoryService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.batchReportDetailHistoryService.find(id).subscribe(batchReportDetailHistory => {
            this.batchReportDetailHistory = batchReportDetailHistory;
        });
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
