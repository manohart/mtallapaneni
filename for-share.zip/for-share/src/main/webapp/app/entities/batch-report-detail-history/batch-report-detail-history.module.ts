import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SmartiSharedModule } from '../../shared';

import {
    BatchReportDetailHistoryService,
    BatchReportDetailHistoryPopupService,
    BatchReportDetailHistoryComponent,
    BatchReportDetailHistoryDetailComponent,
    BatchReportDetailHistoryDialogComponent,
    BatchReportDetailHistoryPopupComponent,
    BatchReportDetailHistoryDeletePopupComponent,
    BatchReportDetailHistoryDeleteDialogComponent,
    batchReportDetailHistoryRoute,
    batchReportDetailHistoryPopupRoute,
    BatchReportDetailHistoryResolvePagingParams,
} from './';

let ENTITY_STATES = [
    ...batchReportDetailHistoryRoute,
    ...batchReportDetailHistoryPopupRoute,
];

@NgModule({
    imports: [
        SmartiSharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [
        BatchReportDetailHistoryComponent,
        BatchReportDetailHistoryDetailComponent,
        BatchReportDetailHistoryDialogComponent,
        BatchReportDetailHistoryDeleteDialogComponent,
        BatchReportDetailHistoryPopupComponent,
        BatchReportDetailHistoryDeletePopupComponent,
    ],
    entryComponents: [
        BatchReportDetailHistoryComponent,
        BatchReportDetailHistoryDialogComponent,
        BatchReportDetailHistoryPopupComponent,
        BatchReportDetailHistoryDeleteDialogComponent,
        BatchReportDetailHistoryDeletePopupComponent,
    ],
    providers: [
        BatchReportDetailHistoryService,
        BatchReportDetailHistoryPopupService,
        BatchReportDetailHistoryResolvePagingParams,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartiBatchReportDetailHistoryModule {}
