import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, CanActivate } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { PaginationUtil } from 'ng-jhipster';

import { BatchReportDetailHistoryComponent } from './batch-report-detail-history.component';
import { BatchReportDetailHistoryDetailComponent } from './batch-report-detail-history-detail.component';
import { BatchReportDetailHistoryPopupComponent } from './batch-report-detail-history-dialog.component';
import { BatchReportDetailHistoryDeletePopupComponent } from './batch-report-detail-history-delete-dialog.component';

import { Principal } from '../../shared';

@Injectable()
export class BatchReportDetailHistoryResolvePagingParams implements Resolve<any> {

  constructor(private paginationUtil: PaginationUtil) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
      let page = route.queryParams['page'] ? route.queryParams['page'] : '1';
      let sort = route.queryParams['sort'] ? route.queryParams['sort'] : 'id,asc';
      return {
          page: this.paginationUtil.parsePage(page),
          predicate: this.paginationUtil.parsePredicate(sort),
          ascending: this.paginationUtil.parseAscending(sort)
    };
  }
}

export const batchReportDetailHistoryRoute: Routes = [
  {
    path: 'batch-report-detail-history',
    component: BatchReportDetailHistoryComponent,
    resolve: {
      'pagingParams': BatchReportDetailHistoryResolvePagingParams
    },
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchReportDetailHistories'
    }
  }, {
    path: 'batch-report-detail-history/:id',
    component: BatchReportDetailHistoryDetailComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchReportDetailHistories'
    }
  }
];

export const batchReportDetailHistoryPopupRoute: Routes = [
  {
    path: 'batch-report-detail-history-new',
    component: BatchReportDetailHistoryPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchReportDetailHistories'
    },
    outlet: 'popup'
  },
  {
    path: 'batch-report-detail-history/:id/edit',
    component: BatchReportDetailHistoryPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchReportDetailHistories'
    },
    outlet: 'popup'
  },
  {
    path: 'batch-report-detail-history/:id/delete',
    component: BatchReportDetailHistoryDeletePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchReportDetailHistories'
    },
    outlet: 'popup'
  }
];
