
const enum ReportType {
    'HTML',
    'EXCEL',
    'PDF',
    'JSON',
    'CSV'

};
import { DataQualityCheck } from '../data-quality-check';
import { BatchReportHistory } from '../batch-report-history';
import { BatchJob } from '../batch-job';
export class BatchReport {
    constructor(
        public id?: number,
        public name?: string,
        public type?: ReportType,
        public description?: string,
        public isActive?: boolean,
        public updatedDate?: any,
        public dataQualityCheck?: DataQualityCheck,
        public generatedReport?: BatchReportHistory,
        public batchJob?: BatchJob,
    ) {
        this.isActive = false;
    }
}
