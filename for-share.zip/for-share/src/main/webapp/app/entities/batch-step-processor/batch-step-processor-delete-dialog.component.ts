import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager } from 'ng-jhipster';

import { BatchStepProcessor } from './batch-step-processor.model';
import { BatchStepProcessorPopupService } from './batch-step-processor-popup.service';
import { BatchStepProcessorService } from './batch-step-processor.service';

@Component({
    selector: 'smarti-batch-step-processor-delete-dialog',
    templateUrl: './batch-step-processor-delete-dialog.component.html'
})
export class BatchStepProcessorDeleteDialogComponent {

    batchStepProcessor: BatchStepProcessor;

    constructor(
        private batchStepProcessorService: BatchStepProcessorService,
        public activeModal: NgbActiveModal,
        private eventManager: EventManager
    ) {
    }

    clear () {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete (id: number) {
        this.batchStepProcessorService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'batchStepProcessorListModification',
                content: 'Deleted an batchStepProcessor'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'smarti-batch-step-processor-delete-popup',
    template: ''
})
export class BatchStepProcessorDeletePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private batchStepProcessorPopupService: BatchStepProcessorPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            this.modalRef = this.batchStepProcessorPopupService
                .open(BatchStepProcessorDeleteDialogComponent, params['id']);
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
