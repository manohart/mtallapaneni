import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataUtils } from 'ng-jhipster';
import { BatchStepProcessor } from './batch-step-processor.model';
import { BatchStepProcessorService } from './batch-step-processor.service';

@Component({
    selector: 'smarti-batch-step-processor-detail',
    templateUrl: './batch-step-processor-detail.component.html'
})
export class BatchStepProcessorDetailComponent implements OnInit, OnDestroy {

    batchStepProcessor: BatchStepProcessor;
    private subscription: any;

    constructor(
        private dataUtils: DataUtils,
        private batchStepProcessorService: BatchStepProcessorService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.batchStepProcessorService.find(id).subscribe(batchStepProcessor => {
            this.batchStepProcessor = batchStepProcessor;
        });
    }
    byteSize(field) {
        return this.dataUtils.byteSize(field);
    }

    openFile(contentType, field) {
        return this.dataUtils.openFile(contentType, field);
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
