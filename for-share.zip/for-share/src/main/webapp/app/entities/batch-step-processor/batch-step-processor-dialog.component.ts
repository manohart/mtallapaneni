import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager, AlertService, DataUtils } from 'ng-jhipster';

import { BatchStepProcessor } from './batch-step-processor.model';
import { BatchStepProcessorPopupService } from './batch-step-processor-popup.service';
import { BatchStepProcessorService } from './batch-step-processor.service';
import { BatchJob, BatchJobService } from '../batch-job';

@Component({
    selector: 'smarti-batch-step-processor-dialog',
    templateUrl: './batch-step-processor-dialog.component.html'
})
export class BatchStepProcessorDialogComponent implements OnInit {

    batchStepProcessor: BatchStepProcessor;
    authorities: any[];
    isSaving: boolean;

    batchjobs: BatchJob[];
    constructor(
        public activeModal: NgbActiveModal,
        private dataUtils: DataUtils,
        private alertService: AlertService,
        private batchStepProcessorService: BatchStepProcessorService,
        private batchJobService: BatchJobService,
        private eventManager: EventManager
    ) {
    }

    ngOnInit() {
        this.isSaving = false;
        this.authorities = ['ROLE_USER', 'ROLE_ADMIN'];
        this.batchJobService.query().subscribe(
            (res: Response) => { this.batchjobs = res.json(); }, (res: Response) => this.onError(res.json()));
    }
    byteSize(field) {
        return this.dataUtils.byteSize(field);
    }

    openFile(contentType, field) {
        return this.dataUtils.openFile(contentType, field);
    }

    setFileData($event, batchStepProcessor, field, isImage) {
        if ($event.target.files && $event.target.files[0]) {
            let $file = $event.target.files[0];
            if (isImage && !/^image\//.test($file.type)) {
                return;
            }
            this.dataUtils.toBase64($file, (base64Data) => {
                batchStepProcessor[field] = base64Data;
                batchStepProcessor[`${field}ContentType`] = $file.type;
            });
        }
    }
    clear () {
        this.activeModal.dismiss('cancel');
    }

    save () {
        this.isSaving = true;
        if (this.batchStepProcessor.id !== undefined) {
            this.batchStepProcessorService.update(this.batchStepProcessor)
                .subscribe((res: BatchStepProcessor) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        } else {
            this.batchStepProcessorService.create(this.batchStepProcessor)
                .subscribe((res: BatchStepProcessor) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        }
    }

    private onSaveSuccess (result: BatchStepProcessor) {
        this.eventManager.broadcast({ name: 'batchStepProcessorListModification', content: 'OK'});
        this.isSaving = false;
        this.activeModal.dismiss(result);
    }

    private onSaveError (error) {
        this.isSaving = false;
        this.onError(error);
    }

    private onError (error) {
        this.alertService.error(error.message, null, null);
    }

    trackBatchJobById(index: number, item: BatchJob) {
        return item.id;
    }
}

@Component({
    selector: 'smarti-batch-step-processor-popup',
    template: ''
})
export class BatchStepProcessorPopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private batchStepProcessorPopupService: BatchStepProcessorPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            if ( params['id'] ) {
                this.modalRef = this.batchStepProcessorPopupService
                    .open(BatchStepProcessorDialogComponent, params['id']);
            } else {
                this.modalRef = this.batchStepProcessorPopupService
                    .open(BatchStepProcessorDialogComponent);
            }

        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
