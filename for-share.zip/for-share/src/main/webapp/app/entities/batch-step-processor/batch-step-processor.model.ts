import { BatchJob } from '../batch-job';
export class BatchStepProcessor {
    constructor(
        public id?: number,
        public step?: number,
        public name?: string,
        public processor?: string,
        public description?: any,
        public troubleshooting?: any,
        public continueStepFailed?: boolean,
        public preCheck?: string,
        public postCheck?: string,
        public continueCheckFailed?: boolean,
        public isActive?: boolean,
        public updatedDate?: any,
        public batchJob?: BatchJob,
    ) {
        this.continueStepFailed = false;
        this.continueCheckFailed = false;
        this.isActive = false;
    }
}
