import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager } from 'ng-jhipster';

import { DataQualityCheckIssue } from './data-quality-check-issue.model';
import { DataQualityCheckIssuePopupService } from './data-quality-check-issue-popup.service';
import { DataQualityCheckIssueService } from './data-quality-check-issue.service';

@Component({
    selector: 'smarti-data-quality-check-issue-delete-dialog',
    templateUrl: './data-quality-check-issue-delete-dialog.component.html'
})
export class DataQualityCheckIssueDeleteDialogComponent {

    dataQualityCheckIssue: DataQualityCheckIssue;

    constructor(
        private dataQualityCheckIssueService: DataQualityCheckIssueService,
        public activeModal: NgbActiveModal,
        private eventManager: EventManager
    ) {
    }

    clear () {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete (id: number) {
        this.dataQualityCheckIssueService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'dataQualityCheckIssueListModification',
                content: 'Deleted an dataQualityCheckIssue'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'smarti-data-quality-check-issue-delete-popup',
    template: ''
})
export class DataQualityCheckIssueDeletePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private dataQualityCheckIssuePopupService: DataQualityCheckIssuePopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            this.modalRef = this.dataQualityCheckIssuePopupService
                .open(DataQualityCheckIssueDeleteDialogComponent, params['id']);
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
