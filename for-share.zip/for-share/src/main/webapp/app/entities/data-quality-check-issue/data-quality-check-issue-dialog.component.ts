import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager, AlertService, DataUtils } from 'ng-jhipster';

import { DataQualityCheckIssue } from './data-quality-check-issue.model';
import { DataQualityCheckIssuePopupService } from './data-quality-check-issue-popup.service';
import { DataQualityCheckIssueService } from './data-quality-check-issue.service';
import { BatchReportHistory, BatchReportHistoryService } from '../batch-report-history';

@Component({
    selector: 'smarti-data-quality-check-issue-dialog',
    templateUrl: './data-quality-check-issue-dialog.component.html'
})
export class DataQualityCheckIssueDialogComponent implements OnInit {

    dataQualityCheckIssue: DataQualityCheckIssue;
    authorities: any[];
    isSaving: boolean;

    batchreporthistories: BatchReportHistory[];
    constructor(
        public activeModal: NgbActiveModal,
        private dataUtils: DataUtils,
        private alertService: AlertService,
        private dataQualityCheckIssueService: DataQualityCheckIssueService,
        private batchReportHistoryService: BatchReportHistoryService,
        private eventManager: EventManager
    ) {
    }

    ngOnInit() {
        this.isSaving = false;
        this.authorities = ['ROLE_USER', 'ROLE_ADMIN'];
        this.batchReportHistoryService.query().subscribe(
            (res: Response) => { this.batchreporthistories = res.json(); }, (res: Response) => this.onError(res.json()));
    }
    byteSize(field) {
        return this.dataUtils.byteSize(field);
    }

    openFile(contentType, field) {
        return this.dataUtils.openFile(contentType, field);
    }

    setFileData($event, dataQualityCheckIssue, field, isImage) {
        if ($event.target.files && $event.target.files[0]) {
            let $file = $event.target.files[0];
            if (isImage && !/^image\//.test($file.type)) {
                return;
            }
            this.dataUtils.toBase64($file, (base64Data) => {
                dataQualityCheckIssue[field] = base64Data;
                dataQualityCheckIssue[`${field}ContentType`] = $file.type;
            });
        }
    }
    clear () {
        this.activeModal.dismiss('cancel');
    }

    save () {
        this.isSaving = true;
        if (this.dataQualityCheckIssue.id !== undefined) {
            this.dataQualityCheckIssueService.update(this.dataQualityCheckIssue)
                .subscribe((res: DataQualityCheckIssue) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        } else {
            this.dataQualityCheckIssueService.create(this.dataQualityCheckIssue)
                .subscribe((res: DataQualityCheckIssue) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        }
    }

    private onSaveSuccess (result: DataQualityCheckIssue) {
        this.eventManager.broadcast({ name: 'dataQualityCheckIssueListModification', content: 'OK'});
        this.isSaving = false;
        this.activeModal.dismiss(result);
    }

    private onSaveError (error) {
        this.isSaving = false;
        this.onError(error);
    }

    private onError (error) {
        this.alertService.error(error.message, null, null);
    }

    trackBatchReportHistoryById(index: number, item: BatchReportHistory) {
        return item.id;
    }
}

@Component({
    selector: 'smarti-data-quality-check-issue-popup',
    template: ''
})
export class DataQualityCheckIssuePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private dataQualityCheckIssuePopupService: DataQualityCheckIssuePopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            if ( params['id'] ) {
                this.modalRef = this.dataQualityCheckIssuePopupService
                    .open(DataQualityCheckIssueDialogComponent, params['id']);
            } else {
                this.modalRef = this.dataQualityCheckIssuePopupService
                    .open(DataQualityCheckIssueDialogComponent);
            }

        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
