import { Injectable, Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { DataQualityCheckIssue } from './data-quality-check-issue.model';
import { DataQualityCheckIssueService } from './data-quality-check-issue.service';
@Injectable()
export class DataQualityCheckIssuePopupService {
    private isOpen = false;
    constructor (
        private datePipe: DatePipe,
        private modalService: NgbModal,
        private router: Router,
        private dataQualityCheckIssueService: DataQualityCheckIssueService

    ) {}

    open (component: Component, id?: number | any): NgbModalRef {
        if (this.isOpen) {
            return;
        }
        this.isOpen = true;

        if (id) {
            this.dataQualityCheckIssueService.find(id).subscribe(dataQualityCheckIssue => {
                dataQualityCheckIssue.updatedDate = this.datePipe
                    .transform(dataQualityCheckIssue.updatedDate, 'yyyy-MM-ddThh:mm');
                this.dataQualityCheckIssueModalRef(component, dataQualityCheckIssue);
            });
        } else {
            return this.dataQualityCheckIssueModalRef(component, new DataQualityCheckIssue());
        }
    }

    dataQualityCheckIssueModalRef(component: Component, dataQualityCheckIssue: DataQualityCheckIssue): NgbModalRef {
        let modalRef = this.modalService.open(component, { size: 'lg', backdrop: 'static'});
        modalRef.componentInstance.dataQualityCheckIssue = dataQualityCheckIssue;
        modalRef.result.then(result => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        }, (reason) => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        });
        return modalRef;
    }
}
