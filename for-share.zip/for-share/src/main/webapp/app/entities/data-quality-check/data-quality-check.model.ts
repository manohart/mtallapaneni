
const enum DataCheckExpectation {
    'NONE',
    'ISSUE_IF_RECORDS_FOUND',
    'ISSUE_IF_NO_RECORDS_FOUND',
    'WARN_IF_RECORDS_FOUND',
    'WARN_IF_NO_RECORDS_FOUND',
    'GOOD_IF_NO_RECORDS_FOUND',
    'GOOD_IF_RECORDS_FOUND',
    'WARN_IF_LIMITED_ISSUES_FOUND'

};
import { BatchReportDetailHistory } from '../batch-report-detail-history';
import { WebService } from '../web-service';
import { BatchReport } from '../batch-report';
export class DataQualityCheck {
    constructor(
        public id?: number,
        public name?: string,
        public description?: string,
        public sqlQuery?: any,
        public resultColumns?: string,
        public groupColumns?: string,
        public expectation?: DataCheckExpectation,
        public reportIssuesOnly?: boolean,
        public sequence?: number,
        public isActive?: boolean,
        public updatedDate?: any,
        public history?: BatchReportDetailHistory,
        public executorService?: WebService,
        public batchReport?: BatchReport,
    ) {
        this.reportIssuesOnly = false;
        this.isActive = false;
    }
}
