import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SmartiSharedModule } from '../../shared';

import {
    DataQualityCheckService,
    DataQualityCheckPopupService,
    DataQualityCheckComponent,
    DataQualityCheckDetailComponent,
    DataQualityCheckDialogComponent,
    DataQualityCheckPopupComponent,
    DataQualityCheckDeletePopupComponent,
    DataQualityCheckDeleteDialogComponent,
    dataQualityCheckRoute,
    dataQualityCheckPopupRoute,
    DataQualityCheckResolvePagingParams,
} from './';

let ENTITY_STATES = [
    ...dataQualityCheckRoute,
    ...dataQualityCheckPopupRoute,
];

@NgModule({
    imports: [
        SmartiSharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [
        DataQualityCheckComponent,
        DataQualityCheckDetailComponent,
        DataQualityCheckDialogComponent,
        DataQualityCheckDeleteDialogComponent,
        DataQualityCheckPopupComponent,
        DataQualityCheckDeletePopupComponent,
    ],
    entryComponents: [
        DataQualityCheckComponent,
        DataQualityCheckDialogComponent,
        DataQualityCheckPopupComponent,
        DataQualityCheckDeleteDialogComponent,
        DataQualityCheckDeletePopupComponent,
    ],
    providers: [
        DataQualityCheckService,
        DataQualityCheckPopupService,
        DataQualityCheckResolvePagingParams,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartiDataQualityCheckModule {}
