import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, CanActivate } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { PaginationUtil } from 'ng-jhipster';

import { DataQualityCheckComponent } from './data-quality-check.component';
import { DataQualityCheckDetailComponent } from './data-quality-check-detail.component';
import { DataQualityCheckPopupComponent } from './data-quality-check-dialog.component';
import { DataQualityCheckDeletePopupComponent } from './data-quality-check-delete-dialog.component';

import { Principal } from '../../shared';

@Injectable()
export class DataQualityCheckResolvePagingParams implements Resolve<any> {

  constructor(private paginationUtil: PaginationUtil) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
      let page = route.queryParams['page'] ? route.queryParams['page'] : '1';
      let sort = route.queryParams['sort'] ? route.queryParams['sort'] : 'id,asc';
      return {
          page: this.paginationUtil.parsePage(page),
          predicate: this.paginationUtil.parsePredicate(sort),
          ascending: this.paginationUtil.parseAscending(sort)
    };
  }
}

export const dataQualityCheckRoute: Routes = [
  {
    path: 'data-quality-check',
    component: DataQualityCheckComponent,
    resolve: {
      'pagingParams': DataQualityCheckResolvePagingParams
    },
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'DataQualityChecks'
    }
  }, {
    path: 'data-quality-check/:id',
    component: DataQualityCheckDetailComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'DataQualityChecks'
    }
  }
];

export const dataQualityCheckPopupRoute: Routes = [
  {
    path: 'data-quality-check-new',
    component: DataQualityCheckPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'DataQualityChecks'
    },
    outlet: 'popup'
  },
  {
    path: 'data-quality-check/:id/edit',
    component: DataQualityCheckPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'DataQualityChecks'
    },
    outlet: 'popup'
  },
  {
    path: 'data-quality-check/:id/delete',
    component: DataQualityCheckDeletePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'DataQualityChecks'
    },
    outlet: 'popup'
  }
];
