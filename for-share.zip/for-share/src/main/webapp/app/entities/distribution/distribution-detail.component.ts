import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Distribution } from './distribution.model';
import { DistributionService } from './distribution.service';

@Component({
    selector: 'smarti-distribution-detail',
    templateUrl: './distribution-detail.component.html'
})
export class DistributionDetailComponent implements OnInit, OnDestroy {

    distribution: Distribution;
    private subscription: any;

    constructor(
        private distributionService: DistributionService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.distributionService.find(id).subscribe(distribution => {
            this.distribution = distribution;
        });
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
