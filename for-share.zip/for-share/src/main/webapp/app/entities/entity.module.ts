import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { SmartiBatchReportHistoryModule } from './batch-report-history/batch-report-history.module';
import { SmartiActiveBusinessDateModule } from './active-business-date/active-business-date.module';
import { SmartiApplicationModule } from './application/application.module';
import { SmartiArchiveLocationModule } from './archive-location/archive-location.module';
import { SmartiAutoNotificationModule } from './auto-notification/auto-notification.module';
import { SmartiBatchConfigModule } from './batch-config/batch-config.module';
import { SmartiBatchDistributionModule } from './batch-distribution/batch-distribution.module';
import { SmartiBatchJobModule } from './batch-job/batch-job.module';
import { SmartiBatchJobHistoryModule } from './batch-job-history/batch-job-history.module';
import { SmartiBatchJobHistoryAuditModule } from './batch-job-history-audit/batch-job-history-audit.module';
import { SmartiWebServiceModule } from './web-service/web-service.module';
import { SmartiBatchReportModule } from './batch-report/batch-report.module';
import { SmartiBatchReportDetailHistoryModule } from './batch-report-detail-history/batch-report-detail-history.module';
import { SmartiBatchReportDetailHistoryAuditModule } from './batch-report-detail-history-audit/batch-report-detail-history-audit.module';
import { SmartiAppDependencyModule } from './app-dependency/app-dependency.module';
import { SmartiBatchStepProcessorModule } from './batch-step-processor/batch-step-processor.module';
import { SmartiDataQualityCheckModule } from './data-quality-check/data-quality-check.module';
import { SmartiWebApplicationModule } from './web-application/web-application.module';
import { SmartiDistributionModule } from './distribution/distribution.module';
import { SmartiLineOfBusinessModule } from './line-of-business/line-of-business.module';
import { SmartiNotificationRuleModule } from './notification-rule/notification-rule.module';
import { SmartiProductModule } from './product/product.module';
import { SmartiServerModule } from './server/server.module';
import { SmartiSoftwareReleaseModule } from './software-release/software-release.module';
import { SmartiTeamModule } from './team/team.module';
import { SmartiTemplateModule } from './template/template.module';
import { SmartiWebServiceConsumerModule } from './web-service-consumer/web-service-consumer.module';
import { SmartiDataQualityCheckIssueModule } from './data-quality-check-issue/data-quality-check-issue.module';
import { SmartiBatchJobIssueModule } from './batch-job-issue/batch-job-issue.module';
/* jhipster-needle-add-entity-module-import - JHipster will add entity modules imports here */

@NgModule({
    imports: [
        SmartiBatchReportHistoryModule,
        SmartiActiveBusinessDateModule,
        SmartiApplicationModule,
        SmartiArchiveLocationModule,
        SmartiAutoNotificationModule,
        SmartiBatchConfigModule,
        SmartiBatchDistributionModule,
        SmartiBatchJobModule,
        SmartiBatchJobHistoryModule,
        SmartiBatchJobHistoryAuditModule,
        SmartiWebServiceModule,
        SmartiBatchReportModule,
        SmartiBatchReportDetailHistoryModule,
        SmartiBatchReportDetailHistoryAuditModule,
        SmartiAppDependencyModule,
        SmartiBatchStepProcessorModule,
        SmartiDataQualityCheckModule,
        SmartiWebApplicationModule,
        SmartiDistributionModule,
        SmartiLineOfBusinessModule,
        SmartiNotificationRuleModule,
        SmartiProductModule,
        SmartiServerModule,
        SmartiSoftwareReleaseModule,
        SmartiTeamModule,
        SmartiTemplateModule,
        SmartiWebServiceConsumerModule,
        SmartiDataQualityCheckIssueModule,
        SmartiBatchJobIssueModule,
        /* jhipster-needle-add-entity-module - JHipster will add entity modules here */
    ],
    declarations: [],
    entryComponents: [],
    providers: [],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartiEntityModule {}
