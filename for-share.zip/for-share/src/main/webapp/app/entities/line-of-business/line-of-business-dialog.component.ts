import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager, AlertService } from 'ng-jhipster';

import { LineOfBusiness } from './line-of-business.model';
import { LineOfBusinessPopupService } from './line-of-business-popup.service';
import { LineOfBusinessService } from './line-of-business.service';
import { Application, ApplicationService } from '../application';
import { ArchiveLocation, ArchiveLocationService } from '../archive-location';
import { AutoNotification, AutoNotificationService } from '../auto-notification';
import { Product, ProductService } from '../product';
import { Template, TemplateService } from '../template';
import { Team, TeamService } from '../team';

@Component({
    selector: 'smarti-line-of-business-dialog',
    templateUrl: './line-of-business-dialog.component.html'
})
export class LineOfBusinessDialogComponent implements OnInit {

    lineOfBusiness: LineOfBusiness;
    authorities: any[];
    isSaving: boolean;

    lineofbusinesses: LineOfBusiness[];

    applications: Application[];

    archivelocations: ArchiveLocation[];

    autonotifications: AutoNotification[];

    products: Product[];

    templates: Template[];

    teams: Team[];
    constructor(
        public activeModal: NgbActiveModal,
        private alertService: AlertService,
        private lineOfBusinessService: LineOfBusinessService,
        private applicationService: ApplicationService,
        private archiveLocationService: ArchiveLocationService,
        private autoNotificationService: AutoNotificationService,
        private productService: ProductService,
        private templateService: TemplateService,
        private teamService: TeamService,
        private eventManager: EventManager
    ) {
    }

    ngOnInit() {
        this.isSaving = false;
        this.authorities = ['ROLE_USER', 'ROLE_ADMIN'];
        this.lineOfBusinessService.query().subscribe(
            (res: Response) => { this.lineofbusinesses = res.json(); }, (res: Response) => this.onError(res.json()));
        this.applicationService.query().subscribe(
            (res: Response) => { this.applications = res.json(); }, (res: Response) => this.onError(res.json()));
        this.archiveLocationService.query().subscribe(
            (res: Response) => { this.archivelocations = res.json(); }, (res: Response) => this.onError(res.json()));
        this.autoNotificationService.query().subscribe(
            (res: Response) => { this.autonotifications = res.json(); }, (res: Response) => this.onError(res.json()));
        this.productService.query().subscribe(
            (res: Response) => { this.products = res.json(); }, (res: Response) => this.onError(res.json()));
        this.templateService.query().subscribe(
            (res: Response) => { this.templates = res.json(); }, (res: Response) => this.onError(res.json()));
        this.teamService.query().subscribe(
            (res: Response) => { this.teams = res.json(); }, (res: Response) => this.onError(res.json()));
    }
    clear () {
        this.activeModal.dismiss('cancel');
    }

    save () {
        this.isSaving = true;
        if (this.lineOfBusiness.id !== undefined) {
            this.lineOfBusinessService.update(this.lineOfBusiness)
                .subscribe((res: LineOfBusiness) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        } else {
            this.lineOfBusinessService.create(this.lineOfBusiness)
                .subscribe((res: LineOfBusiness) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        }
    }

    private onSaveSuccess (result: LineOfBusiness) {
        this.eventManager.broadcast({ name: 'lineOfBusinessListModification', content: 'OK'});
        this.isSaving = false;
        this.activeModal.dismiss(result);
    }

    private onSaveError (error) {
        this.isSaving = false;
        this.onError(error);
    }

    private onError (error) {
        this.alertService.error(error.message, null, null);
    }

    trackLineOfBusinessById(index: number, item: LineOfBusiness) {
        return item.id;
    }

    trackApplicationById(index: number, item: Application) {
        return item.id;
    }

    trackArchiveLocationById(index: number, item: ArchiveLocation) {
        return item.id;
    }

    trackAutoNotificationById(index: number, item: AutoNotification) {
        return item.id;
    }

    trackProductById(index: number, item: Product) {
        return item.id;
    }

    trackTemplateById(index: number, item: Template) {
        return item.id;
    }

    trackTeamById(index: number, item: Team) {
        return item.id;
    }
}

@Component({
    selector: 'smarti-line-of-business-popup',
    template: ''
})
export class LineOfBusinessPopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private lineOfBusinessPopupService: LineOfBusinessPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            if ( params['id'] ) {
                this.modalRef = this.lineOfBusinessPopupService
                    .open(LineOfBusinessDialogComponent, params['id']);
            } else {
                this.modalRef = this.lineOfBusinessPopupService
                    .open(LineOfBusinessDialogComponent);
            }

        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
