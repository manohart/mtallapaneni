import { Injectable, Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { NotificationRule } from './notification-rule.model';
import { NotificationRuleService } from './notification-rule.service';
@Injectable()
export class NotificationRulePopupService {
    private isOpen = false;
    constructor (
        private datePipe: DatePipe,
        private modalService: NgbModal,
        private router: Router,
        private notificationRuleService: NotificationRuleService

    ) {}

    open (component: Component, id?: number | any): NgbModalRef {
        if (this.isOpen) {
            return;
        }
        this.isOpen = true;

        if (id) {
            this.notificationRuleService.find(id).subscribe(notificationRule => {
                notificationRule.updatedDate = this.datePipe
                    .transform(notificationRule.updatedDate, 'yyyy-MM-ddThh:mm');
                this.notificationRuleModalRef(component, notificationRule);
            });
        } else {
            return this.notificationRuleModalRef(component, new NotificationRule());
        }
    }

    notificationRuleModalRef(component: Component, notificationRule: NotificationRule): NgbModalRef {
        let modalRef = this.modalService.open(component, { size: 'lg', backdrop: 'static'});
        modalRef.componentInstance.notificationRule = notificationRule;
        modalRef.result.then(result => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        }, (reason) => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        });
        return modalRef;
    }
}
