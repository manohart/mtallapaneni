import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SmartiSharedModule } from '../../shared';

import {
    NotificationRuleService,
    NotificationRulePopupService,
    NotificationRuleComponent,
    NotificationRuleDetailComponent,
    NotificationRuleDialogComponent,
    NotificationRulePopupComponent,
    NotificationRuleDeletePopupComponent,
    NotificationRuleDeleteDialogComponent,
    notificationRuleRoute,
    notificationRulePopupRoute,
    NotificationRuleResolvePagingParams,
} from './';

let ENTITY_STATES = [
    ...notificationRuleRoute,
    ...notificationRulePopupRoute,
];

@NgModule({
    imports: [
        SmartiSharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [
        NotificationRuleComponent,
        NotificationRuleDetailComponent,
        NotificationRuleDialogComponent,
        NotificationRuleDeleteDialogComponent,
        NotificationRulePopupComponent,
        NotificationRuleDeletePopupComponent,
    ],
    entryComponents: [
        NotificationRuleComponent,
        NotificationRuleDialogComponent,
        NotificationRulePopupComponent,
        NotificationRuleDeleteDialogComponent,
        NotificationRuleDeletePopupComponent,
    ],
    providers: [
        NotificationRuleService,
        NotificationRulePopupService,
        NotificationRuleResolvePagingParams,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartiNotificationRuleModule {}
