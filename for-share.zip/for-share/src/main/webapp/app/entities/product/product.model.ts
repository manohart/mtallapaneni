import { SoftwareRelease } from '../software-release';
import { Application } from '../application';
import { Team } from '../team';
import { LineOfBusiness } from '../line-of-business';
export class Product {
    constructor(
        public id?: number,
        public name?: string,
        public description?: any,
        public productId?: number,
        public codeRepoLink?: string,
        public trackerLink?: string,
        public ciLink?: string,
        public techonologyStack?: string,
        public isActive?: boolean,
        public updatedDate?: any,
        public release?: SoftwareRelease,
        public application?: Application,
        public techonology?: Team,
        public support?: Team,
        public business?: Team,
        public lob?: LineOfBusiness,
    ) {
        this.isActive = false;
    }
}
