
const enum ServerType {
    'APP',
    'DB',
    'BOTH'

};

const enum Environment {
    'DEV',
    'TEST',
    'UAT',
    'PROD',
    'RESEARCH',
    'DR'

};

const enum OsType {
    'WINDOWS',
    'LINUX',
    'SOLARIS',
    'MAC',
    'OTHERS'

};

const enum InfraCategory {
    'INVEST',
    'MAINTAIN',
    'DIVEST'

};
import { Application } from '../application';
import { LineOfBusiness } from '../line-of-business';
export class Server {
    constructor(
        public id?: number,
        public hostname?: string,
        public aliasName?: string,
        public description?: string,
        public type?: ServerType,
        public environment?: Environment,
        public osType?: OsType,
        public category?: InfraCategory,
        public isActive?: boolean,
        public updatedDate?: any,
        public appApp?: Application,
        public dbApp?: Application,
        public lob?: LineOfBusiness,
    ) {
        this.isActive = false;
    }
}
