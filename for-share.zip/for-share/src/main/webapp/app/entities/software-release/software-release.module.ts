import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SmartiSharedModule } from '../../shared';

import {
    SoftwareReleaseService,
    SoftwareReleasePopupService,
    SoftwareReleaseComponent,
    SoftwareReleaseDetailComponent,
    SoftwareReleaseDialogComponent,
    SoftwareReleasePopupComponent,
    SoftwareReleaseDeletePopupComponent,
    SoftwareReleaseDeleteDialogComponent,
    softwareReleaseRoute,
    softwareReleasePopupRoute,
    SoftwareReleaseResolvePagingParams,
} from './';

let ENTITY_STATES = [
    ...softwareReleaseRoute,
    ...softwareReleasePopupRoute,
];

@NgModule({
    imports: [
        SmartiSharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [
        SoftwareReleaseComponent,
        SoftwareReleaseDetailComponent,
        SoftwareReleaseDialogComponent,
        SoftwareReleaseDeleteDialogComponent,
        SoftwareReleasePopupComponent,
        SoftwareReleaseDeletePopupComponent,
    ],
    entryComponents: [
        SoftwareReleaseComponent,
        SoftwareReleaseDialogComponent,
        SoftwareReleasePopupComponent,
        SoftwareReleaseDeleteDialogComponent,
        SoftwareReleaseDeletePopupComponent,
    ],
    providers: [
        SoftwareReleaseService,
        SoftwareReleasePopupService,
        SoftwareReleaseResolvePagingParams,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartiSoftwareReleaseModule {}
