import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, CanActivate } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { PaginationUtil } from 'ng-jhipster';

import { SoftwareReleaseComponent } from './software-release.component';
import { SoftwareReleaseDetailComponent } from './software-release-detail.component';
import { SoftwareReleasePopupComponent } from './software-release-dialog.component';
import { SoftwareReleaseDeletePopupComponent } from './software-release-delete-dialog.component';

import { Principal } from '../../shared';

@Injectable()
export class SoftwareReleaseResolvePagingParams implements Resolve<any> {

  constructor(private paginationUtil: PaginationUtil) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
      let page = route.queryParams['page'] ? route.queryParams['page'] : '1';
      let sort = route.queryParams['sort'] ? route.queryParams['sort'] : 'id,asc';
      return {
          page: this.paginationUtil.parsePage(page),
          predicate: this.paginationUtil.parsePredicate(sort),
          ascending: this.paginationUtil.parseAscending(sort)
    };
  }
}

export const softwareReleaseRoute: Routes = [
  {
    path: 'software-release',
    component: SoftwareReleaseComponent,
    resolve: {
      'pagingParams': SoftwareReleaseResolvePagingParams
    },
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'SoftwareReleases'
    }
  }, {
    path: 'software-release/:id',
    component: SoftwareReleaseDetailComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'SoftwareReleases'
    }
  }
];

export const softwareReleasePopupRoute: Routes = [
  {
    path: 'software-release-new',
    component: SoftwareReleasePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'SoftwareReleases'
    },
    outlet: 'popup'
  },
  {
    path: 'software-release/:id/edit',
    component: SoftwareReleasePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'SoftwareReleases'
    },
    outlet: 'popup'
  },
  {
    path: 'software-release/:id/delete',
    component: SoftwareReleaseDeletePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'SoftwareReleases'
    },
    outlet: 'popup'
  }
];
