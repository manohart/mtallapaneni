import { LineOfBusiness } from '../line-of-business';
export class Team {
    constructor(
        public id?: number,
        public name?: string,
        public managerSid?: string,
        public leadSid?: string,
        public emailDl?: string,
        public cityCountry?: string,
        public isActive?: boolean,
        public updatedDate?: any,
        public lob?: LineOfBusiness,
    ) {
        this.isActive = false;
    }
}
