export * from './template.model';
export * from './template-popup.service';
export * from './template.service';
export * from './template-dialog.component';
export * from './template-delete-dialog.component';
export * from './template-detail.component';
export * from './template.component';
export * from './template.route';
