import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager } from 'ng-jhipster';

import { WebApplication } from './web-application.model';
import { WebApplicationPopupService } from './web-application-popup.service';
import { WebApplicationService } from './web-application.service';

@Component({
    selector: 'smarti-web-application-delete-dialog',
    templateUrl: './web-application-delete-dialog.component.html'
})
export class WebApplicationDeleteDialogComponent {

    webApplication: WebApplication;

    constructor(
        private webApplicationService: WebApplicationService,
        public activeModal: NgbActiveModal,
        private eventManager: EventManager
    ) {
    }

    clear () {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete (id: number) {
        this.webApplicationService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'webApplicationListModification',
                content: 'Deleted an webApplication'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'smarti-web-application-delete-popup',
    template: ''
})
export class WebApplicationDeletePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private webApplicationPopupService: WebApplicationPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            this.modalRef = this.webApplicationPopupService
                .open(WebApplicationDeleteDialogComponent, params['id']);
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
