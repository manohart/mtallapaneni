import { Injectable, Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { WebApplication } from './web-application.model';
import { WebApplicationService } from './web-application.service';
@Injectable()
export class WebApplicationPopupService {
    private isOpen = false;
    constructor (
        private datePipe: DatePipe,
        private modalService: NgbModal,
        private router: Router,
        private webApplicationService: WebApplicationService

    ) {}

    open (component: Component, id?: number | any): NgbModalRef {
        if (this.isOpen) {
            return;
        }
        this.isOpen = true;

        if (id) {
            this.webApplicationService.find(id).subscribe(webApplication => {
                webApplication.updatedDate = this.datePipe
                    .transform(webApplication.updatedDate, 'yyyy-MM-ddThh:mm');
                this.webApplicationModalRef(component, webApplication);
            });
        } else {
            return this.webApplicationModalRef(component, new WebApplication());
        }
    }

    webApplicationModalRef(component: Component, webApplication: WebApplication): NgbModalRef {
        let modalRef = this.modalService.open(component, { size: 'lg', backdrop: 'static'});
        modalRef.componentInstance.webApplication = webApplication;
        modalRef.result.then(result => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        }, (reason) => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        });
        return modalRef;
    }
}
