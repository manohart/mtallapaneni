import { Application } from '../application';
import { WebService } from '../web-service';
export class WebApplication {
    constructor(
        public id?: number,
        public hostPortContext?: string,
        public apiDoc?: string,
        public health?: string,
        public metrics?: string,
        public logs?: string,
        public container?: string,
        public isActive?: boolean,
        public updatedDate?: any,
        public application?: Application,
        public drApplication?: Application,
        public service?: WebService,
    ) {
        this.isActive = false;
    }
}
