import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SmartiSharedModule } from '../../shared';

import {
    WebApplicationService,
    WebApplicationPopupService,
    WebApplicationComponent,
    WebApplicationDetailComponent,
    WebApplicationDialogComponent,
    WebApplicationPopupComponent,
    WebApplicationDeletePopupComponent,
    WebApplicationDeleteDialogComponent,
    webApplicationRoute,
    webApplicationPopupRoute,
    WebApplicationResolvePagingParams,
} from './';

let ENTITY_STATES = [
    ...webApplicationRoute,
    ...webApplicationPopupRoute,
];

@NgModule({
    imports: [
        SmartiSharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [
        WebApplicationComponent,
        WebApplicationDetailComponent,
        WebApplicationDialogComponent,
        WebApplicationDeleteDialogComponent,
        WebApplicationPopupComponent,
        WebApplicationDeletePopupComponent,
    ],
    entryComponents: [
        WebApplicationComponent,
        WebApplicationDialogComponent,
        WebApplicationPopupComponent,
        WebApplicationDeleteDialogComponent,
        WebApplicationDeletePopupComponent,
    ],
    providers: [
        WebApplicationService,
        WebApplicationPopupService,
        WebApplicationResolvePagingParams,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartiWebApplicationModule {}
