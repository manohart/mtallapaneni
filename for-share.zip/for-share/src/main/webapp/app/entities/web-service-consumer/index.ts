export * from './web-service-consumer.model';
export * from './web-service-consumer-popup.service';
export * from './web-service-consumer.service';
export * from './web-service-consumer-dialog.component';
export * from './web-service-consumer-delete-dialog.component';
export * from './web-service-consumer-detail.component';
export * from './web-service-consumer.component';
export * from './web-service-consumer.route';
