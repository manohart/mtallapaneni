import { NgModule, Sanitizer } from '@angular/core';
import { Title } from '@angular/platform-browser';

import { AlertService } from 'ng-jhipster';

import {
    SmartiSharedLibsModule,
    SmartiAlertComponent,
    SmartiAlertErrorComponent
} from './';


export function alertServiceProvider(sanitizer: Sanitizer) {
    // set below to true to make alerts look like toast
    let isToast = false;
    return new AlertService(sanitizer, isToast);
}

@NgModule({
    imports: [
        SmartiSharedLibsModule
    ],
    declarations: [
        SmartiAlertComponent,
        SmartiAlertErrorComponent
    ],
    providers: [
        {
            provide: AlertService,
            useFactory: alertServiceProvider,
            deps: [Sanitizer]
        },
        Title
    ],
    exports: [
        SmartiSharedLibsModule,
        SmartiAlertComponent,
        SmartiAlertErrorComponent
    ]
})
export class SmartiSharedCommonModule {}
