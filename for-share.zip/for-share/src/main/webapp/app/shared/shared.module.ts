import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { DatePipe } from '@angular/common';

import { CookieService } from 'angular2-cookie/services/cookies.service';
import {
    SmartiSharedLibsModule,
    SmartiSharedCommonModule,
    CSRFService,
    AuthService,
    AuthServerProvider,
    AccountService,
    StateStorageService,
    LoginService,
    LoginModalService,
    Principal,
    SmartiTrackerService,
    HasAnyAuthorityDirective,
    SmartiLoginModalComponent
} from './';

@NgModule({
    imports: [
        SmartiSharedLibsModule,
        SmartiSharedCommonModule
    ],
    declarations: [
        SmartiLoginModalComponent,
        HasAnyAuthorityDirective
    ],
    providers: [
        CookieService,
        LoginService,
        LoginModalService,
        AccountService,
        StateStorageService,
        Principal,
        CSRFService,
        SmartiTrackerService,
        AuthServerProvider,
        AuthService,
        DatePipe
    ],
    entryComponents: [SmartiLoginModalComponent],
    exports: [
        SmartiSharedCommonModule,
        SmartiLoginModalComponent,
        HasAnyAuthorityDirective,
        DatePipe
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]

})
export class SmartiSharedModule {}
