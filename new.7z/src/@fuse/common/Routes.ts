export const UrlRoute = {
    apps: 'apps',
    calendar: 'calendar',
    dashboards: 'dashbaords',

    analytics: 'analytics',

    pages: 'pages',
    auth: 'auth',
    login: 'login',
    forgotPassword: 'forgot-password',
    profile: 'profile'
};