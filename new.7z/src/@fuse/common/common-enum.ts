export enum VendorRoleTypeEnum {
    Trial = 0,
    Subscription = 1,
    Basic = 2,
    Standard = 3,
    Premium = 4
}
