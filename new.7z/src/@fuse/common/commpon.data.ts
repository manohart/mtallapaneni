export const GlobalConstants = {

    LocalStorage: {
        UserData: 'UserData'
    }

};