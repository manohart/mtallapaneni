export const locale = {
    lang: 'tr',
    data: {
        'COMMON': {
        }
    }
};
