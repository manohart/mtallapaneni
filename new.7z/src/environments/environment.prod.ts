import { IConfig } from './iconfig';

export const environment = {
    production: true,
    hmr: false
};

export const CONFIG: IConfig = {
    'firebaseConfig': {
        apiKey: 'AIzaSyBvlBZqFoCGf_LEn2984zWucGj4cFq2D5A',
        authDomain: 'mainapp-9c872.firebaseapp.com',
        databaseURL: 'https://mainapp-9c872.firebaseio.com',
        projectId: 'mainapp-9c872',
        storageBucket: 'mainapp-9c872.appspot.com',
        messagingSenderId: '365674294653'
    }
};

