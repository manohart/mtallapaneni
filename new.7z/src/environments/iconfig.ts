import { FirebaseAppConfig } from 'angularfire2';

export interface IConfig {
  firebaseConfig: FirebaseAppConfig;
}
