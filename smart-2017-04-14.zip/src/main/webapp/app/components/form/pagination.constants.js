(function() {
    'use strict';

    angular
        .module('smartApp')
        .constant('paginationConstants', {
            'itemsPerPage': 20
        });
})();
