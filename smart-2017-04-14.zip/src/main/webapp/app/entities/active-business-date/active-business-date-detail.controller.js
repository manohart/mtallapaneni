(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('ActiveBusinessDateDetailController', ActiveBusinessDateDetailController);

    ActiveBusinessDateDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'ActiveBusinessDate'];

    function ActiveBusinessDateDetailController($scope, $rootScope, $stateParams, previousState, entity, ActiveBusinessDate) {
        var vm = this;

        vm.activeBusinessDate = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartApp:activeBusinessDateUpdate', function(event, result) {
            vm.activeBusinessDate = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
