(function() {
    'use strict';

    angular
        .module('smartApp')
        .factory('ActiveBusinessDateSearch', ActiveBusinessDateSearch);

    ActiveBusinessDateSearch.$inject = ['$resource'];

    function ActiveBusinessDateSearch($resource) {
        var resourceUrl =  'api/_search/active-business-dates/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
