(function() {
    'use strict';
    angular
        .module('smartApp')
        .factory('ActiveBusinessDate', ActiveBusinessDate);

    ActiveBusinessDate.$inject = ['$resource', 'DateUtils'];

    function ActiveBusinessDate ($resource, DateUtils) {
        var resourceUrl =  'api/active-business-dates/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true},
            'get': {
                method: 'GET',
                transformResponse: function (data) {
                    if (data) {
                        data = angular.fromJson(data);
                        data.calendarDate = DateUtils.convertLocalDateFromServer(data.calendarDate);
                        data.businessDate = DateUtils.convertLocalDateFromServer(data.businessDate);
                        data.previousBusinessDate = DateUtils.convertLocalDateFromServer(data.previousBusinessDate);
                        data.updatedDate = DateUtils.convertDateTimeFromServer(data.updatedDate);
                    }
                    return data;
                }
            },
            'update': {
                method: 'PUT',
                transformRequest: function (data) {
                    var copy = angular.copy(data);
                    copy.calendarDate = DateUtils.convertLocalDateToServer(copy.calendarDate);
                    copy.businessDate = DateUtils.convertLocalDateToServer(copy.businessDate);
                    copy.previousBusinessDate = DateUtils.convertLocalDateToServer(copy.previousBusinessDate);
                    return angular.toJson(copy);
                }
            },
            'save': {
                method: 'POST',
                transformRequest: function (data) {
                    var copy = angular.copy(data);
                    copy.calendarDate = DateUtils.convertLocalDateToServer(copy.calendarDate);
                    copy.businessDate = DateUtils.convertLocalDateToServer(copy.businessDate);
                    copy.previousBusinessDate = DateUtils.convertLocalDateToServer(copy.previousBusinessDate);
                    return angular.toJson(copy);
                }
            }
        });
    }
})();
