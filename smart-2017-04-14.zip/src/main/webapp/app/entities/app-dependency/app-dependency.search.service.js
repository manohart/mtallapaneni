(function() {
    'use strict';

    angular
        .module('smartApp')
        .factory('AppDependencySearch', AppDependencySearch);

    AppDependencySearch.$inject = ['$resource'];

    function AppDependencySearch($resource) {
        var resourceUrl =  'api/_search/app-dependencies/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
