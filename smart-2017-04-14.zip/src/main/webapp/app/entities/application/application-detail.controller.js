(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('ApplicationDetailController', ApplicationDetailController);

    ApplicationDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'Application', 'AutoNotification', 'AppDependency', 'BatchDistribution', 'LineOfBusiness', 'ProductModule', 'Server'];

    function ApplicationDetailController($scope, $rootScope, $stateParams, previousState, entity, Application, AutoNotification, AppDependency, BatchDistribution, LineOfBusiness, ProductModule, Server) {
        var vm = this;

        vm.application = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartApp:applicationUpdate', function(event, result) {
            vm.application = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
