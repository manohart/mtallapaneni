(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('ArchiveLocationDetailController', ArchiveLocationDetailController);

    ArchiveLocationDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'ArchiveLocation', 'LineOfBusiness'];

    function ArchiveLocationDetailController($scope, $rootScope, $stateParams, previousState, entity, ArchiveLocation, LineOfBusiness) {
        var vm = this;

        vm.archiveLocation = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartApp:archiveLocationUpdate', function(event, result) {
            vm.archiveLocation = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
