(function() {
    'use strict';

    angular
        .module('smartApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('archive-location', {
            parent: 'entity',
            url: '/archive-location?page&sort&search',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'ArchiveLocations'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/archive-location/archive-locations.html',
                    controller: 'ArchiveLocationController',
                    controllerAs: 'vm'
                }
            },
            params: {
                page: {
                    value: '1',
                    squash: true
                },
                sort: {
                    value: 'id,asc',
                    squash: true
                },
                search: null
            },
            resolve: {
                pagingParams: ['$stateParams', 'PaginationUtil', function ($stateParams, PaginationUtil) {
                    return {
                        page: PaginationUtil.parsePage($stateParams.page),
                        sort: $stateParams.sort,
                        predicate: PaginationUtil.parsePredicate($stateParams.sort),
                        ascending: PaginationUtil.parseAscending($stateParams.sort),
                        search: $stateParams.search
                    };
                }]
            }
        })
        .state('archive-location-detail', {
            parent: 'archive-location',
            url: '/archive-location/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'ArchiveLocation'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/archive-location/archive-location-detail.html',
                    controller: 'ArchiveLocationDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'ArchiveLocation', function($stateParams, ArchiveLocation) {
                    return ArchiveLocation.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'archive-location',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('archive-location-detail.edit', {
            parent: 'archive-location-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/archive-location/archive-location-dialog.html',
                    controller: 'ArchiveLocationDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['ArchiveLocation', function(ArchiveLocation) {
                            return ArchiveLocation.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('archive-location.new', {
            parent: 'archive-location',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/archive-location/archive-location-dialog.html',
                    controller: 'ArchiveLocationDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                code: null,
                                description: null,
                                path: null,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('archive-location', null, { reload: 'archive-location' });
                }, function() {
                    $state.go('archive-location');
                });
            }]
        })
        .state('archive-location.edit', {
            parent: 'archive-location',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/archive-location/archive-location-dialog.html',
                    controller: 'ArchiveLocationDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['ArchiveLocation', function(ArchiveLocation) {
                            return ArchiveLocation.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('archive-location', null, { reload: 'archive-location' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('archive-location.delete', {
            parent: 'archive-location',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/archive-location/archive-location-delete-dialog.html',
                    controller: 'ArchiveLocationDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['ArchiveLocation', function(ArchiveLocation) {
                            return ArchiveLocation.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('archive-location', null, { reload: 'archive-location' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
