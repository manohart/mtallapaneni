(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('AutoNotificationDetailController', AutoNotificationDetailController);

    AutoNotificationDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'AutoNotification', 'NotificationRule', 'LineOfBusiness', 'Application'];

    function AutoNotificationDetailController($scope, $rootScope, $stateParams, previousState, entity, AutoNotification, NotificationRule, LineOfBusiness, Application) {
        var vm = this;

        vm.autoNotification = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartApp:autoNotificationUpdate', function(event, result) {
            vm.autoNotification = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
