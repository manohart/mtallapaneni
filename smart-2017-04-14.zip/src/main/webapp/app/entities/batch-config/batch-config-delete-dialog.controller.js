(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('BatchConfigDeleteController',BatchConfigDeleteController);

    BatchConfigDeleteController.$inject = ['$uibModalInstance', 'entity', 'BatchConfig'];

    function BatchConfigDeleteController($uibModalInstance, entity, BatchConfig) {
        var vm = this;

        vm.batchConfig = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            BatchConfig.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
