(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('BatchConfigDetailController', BatchConfigDetailController);

    BatchConfigDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'BatchConfig', 'BatchJob'];

    function BatchConfigDetailController($scope, $rootScope, $stateParams, previousState, entity, BatchConfig, BatchJob) {
        var vm = this;

        vm.batchConfig = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartApp:batchConfigUpdate', function(event, result) {
            vm.batchConfig = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
