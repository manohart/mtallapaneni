(function() {
    'use strict';

    angular
        .module('smartApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('batch-config', {
            parent: 'entity',
            url: '/batch-config?page&sort&search',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'BatchConfigs'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/batch-config/batch-configs.html',
                    controller: 'BatchConfigController',
                    controllerAs: 'vm'
                }
            },
            params: {
                page: {
                    value: '1',
                    squash: true
                },
                sort: {
                    value: 'id,asc',
                    squash: true
                },
                search: null
            },
            resolve: {
                pagingParams: ['$stateParams', 'PaginationUtil', function ($stateParams, PaginationUtil) {
                    return {
                        page: PaginationUtil.parsePage($stateParams.page),
                        sort: $stateParams.sort,
                        predicate: PaginationUtil.parsePredicate($stateParams.sort),
                        ascending: PaginationUtil.parseAscending($stateParams.sort),
                        search: $stateParams.search
                    };
                }]
            }
        })
        .state('batch-config-detail', {
            parent: 'batch-config',
            url: '/batch-config/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'BatchConfig'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/batch-config/batch-config-detail.html',
                    controller: 'BatchConfigDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'BatchConfig', function($stateParams, BatchConfig) {
                    return BatchConfig.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'batch-config',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('batch-config-detail.edit', {
            parent: 'batch-config-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-config/batch-config-dialog.html',
                    controller: 'BatchConfigDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['BatchConfig', function(BatchConfig) {
                            return BatchConfig.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('batch-config.new', {
            parent: 'batch-config',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-config/batch-config-dialog.html',
                    controller: 'BatchConfigDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                code: null,
                                value: null,
                                jsonType: null,
                                active: null,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('batch-config', null, { reload: 'batch-config' });
                }, function() {
                    $state.go('batch-config');
                });
            }]
        })
        .state('batch-config.edit', {
            parent: 'batch-config',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-config/batch-config-dialog.html',
                    controller: 'BatchConfigDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['BatchConfig', function(BatchConfig) {
                            return BatchConfig.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('batch-config', null, { reload: 'batch-config' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('batch-config.delete', {
            parent: 'batch-config',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-config/batch-config-delete-dialog.html',
                    controller: 'BatchConfigDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['BatchConfig', function(BatchConfig) {
                            return BatchConfig.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('batch-config', null, { reload: 'batch-config' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
