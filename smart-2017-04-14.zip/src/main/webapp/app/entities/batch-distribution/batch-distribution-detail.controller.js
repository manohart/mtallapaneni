(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('BatchDistributionDetailController', BatchDistributionDetailController);

    BatchDistributionDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'BatchDistribution', 'Distribution', 'Application'];

    function BatchDistributionDetailController($scope, $rootScope, $stateParams, previousState, entity, BatchDistribution, Distribution, Application) {
        var vm = this;

        vm.batchDistribution = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartApp:batchDistributionUpdate', function(event, result) {
            vm.batchDistribution = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
