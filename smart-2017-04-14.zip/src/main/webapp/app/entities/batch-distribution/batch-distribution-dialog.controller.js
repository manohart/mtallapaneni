(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('BatchDistributionDialogController', BatchDistributionDialogController);

    BatchDistributionDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'entity', 'BatchDistribution', 'Distribution', 'Application'];

    function BatchDistributionDialogController ($timeout, $scope, $stateParams, $uibModalInstance, entity, BatchDistribution, Distribution, Application) {
        var vm = this;

        vm.batchDistribution = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.distributions = Distribution.query();
        vm.applications = Application.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.batchDistribution.id !== null) {
                BatchDistribution.update(vm.batchDistribution, onSaveSuccess, onSaveError);
            } else {
                BatchDistribution.save(vm.batchDistribution, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('smartApp:batchDistributionUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
