(function() {
    'use strict';

    angular
        .module('smartApp')
        .factory('BatchDistributionSearch', BatchDistributionSearch);

    BatchDistributionSearch.$inject = ['$resource'];

    function BatchDistributionSearch($resource) {
        var resourceUrl =  'api/_search/batch-distributions/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
