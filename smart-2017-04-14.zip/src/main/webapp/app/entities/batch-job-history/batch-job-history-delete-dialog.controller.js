(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('BatchJobHistoryDeleteController',BatchJobHistoryDeleteController);

    BatchJobHistoryDeleteController.$inject = ['$uibModalInstance', 'entity', 'BatchJobHistory'];

    function BatchJobHistoryDeleteController($uibModalInstance, entity, BatchJobHistory) {
        var vm = this;

        vm.batchJobHistory = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            BatchJobHistory.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
