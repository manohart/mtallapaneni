(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('BatchJobHistoryDetailController', BatchJobHistoryDetailController);

    BatchJobHistoryDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'BatchJobHistory', 'BatchJobIssue', 'BatchJob'];

    function BatchJobHistoryDetailController($scope, $rootScope, $stateParams, previousState, entity, BatchJobHistory, BatchJobIssue, BatchJob) {
        var vm = this;

        vm.batchJobHistory = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartApp:batchJobHistoryUpdate', function(event, result) {
            vm.batchJobHistory = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
