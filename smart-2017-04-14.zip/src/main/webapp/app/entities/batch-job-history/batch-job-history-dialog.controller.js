(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('BatchJobHistoryDialogController', BatchJobHistoryDialogController);

    BatchJobHistoryDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'entity', 'BatchJobHistory', 'BatchJobIssue', 'BatchJob'];

    function BatchJobHistoryDialogController ($timeout, $scope, $stateParams, $uibModalInstance, entity, BatchJobHistory, BatchJobIssue, BatchJob) {
        var vm = this;

        vm.batchJobHistory = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.batchjobissues = BatchJobIssue.query();
        vm.batchjobs = BatchJob.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.batchJobHistory.id !== null) {
                BatchJobHistory.update(vm.batchJobHistory, onSaveSuccess, onSaveError);
            } else {
                BatchJobHistory.save(vm.batchJobHistory, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('smartApp:batchJobHistoryUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.businessDate = false;
        vm.datePickerOpenStatus.startTime = false;
        vm.datePickerOpenStatus.endTime = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
