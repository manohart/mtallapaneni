(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('BatchJobIssueDeleteController',BatchJobIssueDeleteController);

    BatchJobIssueDeleteController.$inject = ['$uibModalInstance', 'entity', 'BatchJobIssue'];

    function BatchJobIssueDeleteController($uibModalInstance, entity, BatchJobIssue) {
        var vm = this;

        vm.batchJobIssue = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            BatchJobIssue.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
