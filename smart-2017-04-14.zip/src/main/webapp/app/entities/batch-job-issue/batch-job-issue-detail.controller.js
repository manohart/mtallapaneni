(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('BatchJobIssueDetailController', BatchJobIssueDetailController);

    BatchJobIssueDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'BatchJobIssue', 'BatchJobHistory'];

    function BatchJobIssueDetailController($scope, $rootScope, $stateParams, previousState, entity, BatchJobIssue, BatchJobHistory) {
        var vm = this;

        vm.batchJobIssue = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartApp:batchJobIssueUpdate', function(event, result) {
            vm.batchJobIssue = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
