(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('BatchJobIssueDialogController', BatchJobIssueDialogController);

    BatchJobIssueDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'entity', 'BatchJobIssue', 'BatchJobHistory'];

    function BatchJobIssueDialogController ($timeout, $scope, $stateParams, $uibModalInstance, entity, BatchJobIssue, BatchJobHistory) {
        var vm = this;

        vm.batchJobIssue = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.batchjobhistories = BatchJobHistory.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.batchJobIssue.id !== null) {
                BatchJobIssue.update(vm.batchJobIssue, onSaveSuccess, onSaveError);
            } else {
                BatchJobIssue.save(vm.batchJobIssue, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('smartApp:batchJobIssueUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.businessDate = false;
        vm.datePickerOpenStatus.startTime = false;
        vm.datePickerOpenStatus.endTime = false;
        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
