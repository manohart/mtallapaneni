(function() {
    'use strict';

    angular
        .module('smartApp')
        .factory('BatchJobIssueSearch', BatchJobIssueSearch);

    BatchJobIssueSearch.$inject = ['$resource'];

    function BatchJobIssueSearch($resource) {
        var resourceUrl =  'api/_search/batch-job-issues/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
