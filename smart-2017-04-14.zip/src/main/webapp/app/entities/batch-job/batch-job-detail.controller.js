(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('BatchJobDetailController', BatchJobDetailController);

    BatchJobDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'BatchJob', 'Application', 'BatchJobHistory', 'BatchReport', 'BatchConfig', 'BatchProcessor'];

    function BatchJobDetailController($scope, $rootScope, $stateParams, previousState, entity, BatchJob, Application, BatchJobHistory, BatchReport, BatchConfig, BatchProcessor) {
        var vm = this;

        vm.batchJob = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartApp:batchJobUpdate', function(event, result) {
            vm.batchJob = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
