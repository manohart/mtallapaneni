(function() {
    'use strict';

    angular
        .module('smartApp')
        .factory('BatchJobSearch', BatchJobSearch);

    BatchJobSearch.$inject = ['$resource'];

    function BatchJobSearch($resource) {
        var resourceUrl =  'api/_search/batch-jobs/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
