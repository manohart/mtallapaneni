(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('BatchProcessorDeleteController',BatchProcessorDeleteController);

    BatchProcessorDeleteController.$inject = ['$uibModalInstance', 'entity', 'BatchProcessor'];

    function BatchProcessorDeleteController($uibModalInstance, entity, BatchProcessor) {
        var vm = this;

        vm.batchProcessor = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            BatchProcessor.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
