(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('BatchProcessorDetailController', BatchProcessorDetailController);

    BatchProcessorDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'BatchProcessor', 'BatchJob'];

    function BatchProcessorDetailController($scope, $rootScope, $stateParams, previousState, entity, BatchProcessor, BatchJob) {
        var vm = this;

        vm.batchProcessor = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartApp:batchProcessorUpdate', function(event, result) {
            vm.batchProcessor = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
