(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('BatchProcessorDialogController', BatchProcessorDialogController);

    BatchProcessorDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'entity', 'BatchProcessor', 'BatchJob'];

    function BatchProcessorDialogController ($timeout, $scope, $stateParams, $uibModalInstance, entity, BatchProcessor, BatchJob) {
        var vm = this;

        vm.batchProcessor = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.batchjobs = BatchJob.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.batchProcessor.id !== null) {
                BatchProcessor.update(vm.batchProcessor, onSaveSuccess, onSaveError);
            } else {
                BatchProcessor.save(vm.batchProcessor, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('smartApp:batchProcessorUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
