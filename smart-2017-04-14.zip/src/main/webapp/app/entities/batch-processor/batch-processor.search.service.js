(function() {
    'use strict';

    angular
        .module('smartApp')
        .factory('BatchProcessorSearch', BatchProcessorSearch);

    BatchProcessorSearch.$inject = ['$resource'];

    function BatchProcessorSearch($resource) {
        var resourceUrl =  'api/_search/batch-processors/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
