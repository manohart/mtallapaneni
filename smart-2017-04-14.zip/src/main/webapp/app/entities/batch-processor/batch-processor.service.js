(function() {
    'use strict';
    angular
        .module('smartApp')
        .factory('BatchProcessor', BatchProcessor);

    BatchProcessor.$inject = ['$resource', 'DateUtils'];

    function BatchProcessor ($resource, DateUtils) {
        var resourceUrl =  'api/batch-processors/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true},
            'get': {
                method: 'GET',
                transformResponse: function (data) {
                    if (data) {
                        data = angular.fromJson(data);
                        data.updatedDate = DateUtils.convertDateTimeFromServer(data.updatedDate);
                    }
                    return data;
                }
            },
            'update': { method:'PUT' }
        });
    }
})();
