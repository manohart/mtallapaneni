(function() {
    'use strict';

    angular
        .module('smartApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('batch-processor', {
            parent: 'entity',
            url: '/batch-processor?page&sort&search',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'BatchProcessors'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/batch-processor/batch-processors.html',
                    controller: 'BatchProcessorController',
                    controllerAs: 'vm'
                }
            },
            params: {
                page: {
                    value: '1',
                    squash: true
                },
                sort: {
                    value: 'id,asc',
                    squash: true
                },
                search: null
            },
            resolve: {
                pagingParams: ['$stateParams', 'PaginationUtil', function ($stateParams, PaginationUtil) {
                    return {
                        page: PaginationUtil.parsePage($stateParams.page),
                        sort: $stateParams.sort,
                        predicate: PaginationUtil.parsePredicate($stateParams.sort),
                        ascending: PaginationUtil.parseAscending($stateParams.sort),
                        search: $stateParams.search
                    };
                }]
            }
        })
        .state('batch-processor-detail', {
            parent: 'batch-processor',
            url: '/batch-processor/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'BatchProcessor'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/batch-processor/batch-processor-detail.html',
                    controller: 'BatchProcessorDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'BatchProcessor', function($stateParams, BatchProcessor) {
                    return BatchProcessor.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'batch-processor',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('batch-processor-detail.edit', {
            parent: 'batch-processor-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-processor/batch-processor-dialog.html',
                    controller: 'BatchProcessorDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['BatchProcessor', function(BatchProcessor) {
                            return BatchProcessor.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('batch-processor.new', {
            parent: 'batch-processor',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-processor/batch-processor-dialog.html',
                    controller: 'BatchProcessorDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                code: null,
                                step: null,
                                processor: null,
                                description: null,
                                troubleshooting: null,
                                preCheckCode: null,
                                postCheckCode: null,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('batch-processor', null, { reload: 'batch-processor' });
                }, function() {
                    $state.go('batch-processor');
                });
            }]
        })
        .state('batch-processor.edit', {
            parent: 'batch-processor',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-processor/batch-processor-dialog.html',
                    controller: 'BatchProcessorDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['BatchProcessor', function(BatchProcessor) {
                            return BatchProcessor.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('batch-processor', null, { reload: 'batch-processor' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('batch-processor.delete', {
            parent: 'batch-processor',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-processor/batch-processor-delete-dialog.html',
                    controller: 'BatchProcessorDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['BatchProcessor', function(BatchProcessor) {
                            return BatchProcessor.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('batch-processor', null, { reload: 'batch-processor' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
