(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('BatchReportDetailHistoryDeleteController',BatchReportDetailHistoryDeleteController);

    BatchReportDetailHistoryDeleteController.$inject = ['$uibModalInstance', 'entity', 'BatchReportDetailHistory'];

    function BatchReportDetailHistoryDeleteController($uibModalInstance, entity, BatchReportDetailHistory) {
        var vm = this;

        vm.batchReportDetailHistory = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            BatchReportDetailHistory.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
