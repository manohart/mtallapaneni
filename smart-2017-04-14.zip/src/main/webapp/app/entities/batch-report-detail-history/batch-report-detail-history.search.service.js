(function() {
    'use strict';

    angular
        .module('smartApp')
        .factory('BatchReportDetailHistorySearch', BatchReportDetailHistorySearch);

    BatchReportDetailHistorySearch.$inject = ['$resource'];

    function BatchReportDetailHistorySearch($resource) {
        var resourceUrl =  'api/_search/batch-report-detail-histories/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
