(function() {
    'use strict';

    angular
        .module('smartApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('batch-report-detail-history', {
            parent: 'entity',
            url: '/batch-report-detail-history?page&sort&search',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'BatchReportDetailHistories'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/batch-report-detail-history/batch-report-detail-histories.html',
                    controller: 'BatchReportDetailHistoryController',
                    controllerAs: 'vm'
                }
            },
            params: {
                page: {
                    value: '1',
                    squash: true
                },
                sort: {
                    value: 'id,asc',
                    squash: true
                },
                search: null
            },
            resolve: {
                pagingParams: ['$stateParams', 'PaginationUtil', function ($stateParams, PaginationUtil) {
                    return {
                        page: PaginationUtil.parsePage($stateParams.page),
                        sort: $stateParams.sort,
                        predicate: PaginationUtil.parsePredicate($stateParams.sort),
                        ascending: PaginationUtil.parseAscending($stateParams.sort),
                        search: $stateParams.search
                    };
                }]
            }
        })
        .state('batch-report-detail-history-detail', {
            parent: 'batch-report-detail-history',
            url: '/batch-report-detail-history/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'BatchReportDetailHistory'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/batch-report-detail-history/batch-report-detail-history-detail.html',
                    controller: 'BatchReportDetailHistoryDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'BatchReportDetailHistory', function($stateParams, BatchReportDetailHistory) {
                    return BatchReportDetailHistory.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'batch-report-detail-history',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('batch-report-detail-history-detail.edit', {
            parent: 'batch-report-detail-history-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-report-detail-history/batch-report-detail-history-dialog.html',
                    controller: 'BatchReportDetailHistoryDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['BatchReportDetailHistory', function(BatchReportDetailHistory) {
                            return BatchReportDetailHistory.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('batch-report-detail-history.new', {
            parent: 'batch-report-detail-history',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-report-detail-history/batch-report-detail-history-dialog.html',
                    controller: 'BatchReportDetailHistoryDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                records: null,
                                issues: null,
                                status: null,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('batch-report-detail-history', null, { reload: 'batch-report-detail-history' });
                }, function() {
                    $state.go('batch-report-detail-history');
                });
            }]
        })
        .state('batch-report-detail-history.edit', {
            parent: 'batch-report-detail-history',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-report-detail-history/batch-report-detail-history-dialog.html',
                    controller: 'BatchReportDetailHistoryDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['BatchReportDetailHistory', function(BatchReportDetailHistory) {
                            return BatchReportDetailHistory.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('batch-report-detail-history', null, { reload: 'batch-report-detail-history' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('batch-report-detail-history.delete', {
            parent: 'batch-report-detail-history',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-report-detail-history/batch-report-detail-history-delete-dialog.html',
                    controller: 'BatchReportDetailHistoryDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['BatchReportDetailHistory', function(BatchReportDetailHistory) {
                            return BatchReportDetailHistory.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('batch-report-detail-history', null, { reload: 'batch-report-detail-history' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
