(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('BatchReportHistoryDetailController', BatchReportHistoryDetailController);

    BatchReportHistoryDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'BatchReportHistory', 'BatchReportDetailHistory', 'DataQualityCheckIssue', 'BatchReport'];

    function BatchReportHistoryDetailController($scope, $rootScope, $stateParams, previousState, entity, BatchReportHistory, BatchReportDetailHistory, DataQualityCheckIssue, BatchReport) {
        var vm = this;

        vm.batchReportHistory = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartApp:batchReportHistoryUpdate', function(event, result) {
            vm.batchReportHistory = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
