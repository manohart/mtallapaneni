(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('BatchReportHistoryDialogController', BatchReportHistoryDialogController);

    BatchReportHistoryDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'entity', 'BatchReportHistory', 'BatchReportDetailHistory', 'DataQualityCheckIssue', 'BatchReport'];

    function BatchReportHistoryDialogController ($timeout, $scope, $stateParams, $uibModalInstance, entity, BatchReportHistory, BatchReportDetailHistory, DataQualityCheckIssue, BatchReport) {
        var vm = this;

        vm.batchReportHistory = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.batchreportdetailhistories = BatchReportDetailHistory.query();
        vm.dataqualitycheckissues = DataQualityCheckIssue.query();
        vm.batchreports = BatchReport.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.batchReportHistory.id !== null) {
                BatchReportHistory.update(vm.batchReportHistory, onSaveSuccess, onSaveError);
            } else {
                BatchReportHistory.save(vm.batchReportHistory, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('smartApp:batchReportHistoryUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.businessDate = false;
        vm.datePickerOpenStatus.startTime = false;
        vm.datePickerOpenStatus.endTime = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
