(function() {
    'use strict';

    angular
        .module('smartApp')
        .factory('BatchReportHistorySearch', BatchReportHistorySearch);

    BatchReportHistorySearch.$inject = ['$resource'];

    function BatchReportHistorySearch($resource) {
        var resourceUrl =  'api/_search/batch-report-histories/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
