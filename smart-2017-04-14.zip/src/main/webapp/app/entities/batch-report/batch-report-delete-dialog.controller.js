(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('BatchReportDeleteController',BatchReportDeleteController);

    BatchReportDeleteController.$inject = ['$uibModalInstance', 'entity', 'BatchReport'];

    function BatchReportDeleteController($uibModalInstance, entity, BatchReport) {
        var vm = this;

        vm.batchReport = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            BatchReport.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
