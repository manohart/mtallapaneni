(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('BatchReportDialogController', BatchReportDialogController);

    BatchReportDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'entity', 'BatchReport', 'DataQualityCheck', 'BatchReportHistory', 'BatchJob'];

    function BatchReportDialogController ($timeout, $scope, $stateParams, $uibModalInstance, entity, BatchReport, DataQualityCheck, BatchReportHistory, BatchJob) {
        var vm = this;

        vm.batchReport = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.dataqualitychecks = DataQualityCheck.query();
        vm.batchreporthistories = BatchReportHistory.query();
        vm.batchjobs = BatchJob.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.batchReport.id !== null) {
                BatchReport.update(vm.batchReport, onSaveSuccess, onSaveError);
            } else {
                BatchReport.save(vm.batchReport, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('smartApp:batchReportUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
