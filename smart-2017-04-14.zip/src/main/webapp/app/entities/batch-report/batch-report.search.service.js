(function() {
    'use strict';

    angular
        .module('smartApp')
        .factory('BatchReportSearch', BatchReportSearch);

    BatchReportSearch.$inject = ['$resource'];

    function BatchReportSearch($resource) {
        var resourceUrl =  'api/_search/batch-reports/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
