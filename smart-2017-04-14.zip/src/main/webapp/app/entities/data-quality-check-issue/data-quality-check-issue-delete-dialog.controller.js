(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('DataQualityCheckIssueDeleteController',DataQualityCheckIssueDeleteController);

    DataQualityCheckIssueDeleteController.$inject = ['$uibModalInstance', 'entity', 'DataQualityCheckIssue'];

    function DataQualityCheckIssueDeleteController($uibModalInstance, entity, DataQualityCheckIssue) {
        var vm = this;

        vm.dataQualityCheckIssue = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            DataQualityCheckIssue.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
