(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('DataQualityCheckIssueDetailController', DataQualityCheckIssueDetailController);

    DataQualityCheckIssueDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'DataQualityCheckIssue', 'BatchReportHistory'];

    function DataQualityCheckIssueDetailController($scope, $rootScope, $stateParams, previousState, entity, DataQualityCheckIssue, BatchReportHistory) {
        var vm = this;

        vm.dataQualityCheckIssue = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartApp:dataQualityCheckIssueUpdate', function(event, result) {
            vm.dataQualityCheckIssue = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
