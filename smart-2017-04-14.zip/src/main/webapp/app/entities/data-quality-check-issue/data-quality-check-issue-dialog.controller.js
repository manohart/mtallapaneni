(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('DataQualityCheckIssueDialogController', DataQualityCheckIssueDialogController);

    DataQualityCheckIssueDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'entity', 'DataQualityCheckIssue', 'BatchReportHistory'];

    function DataQualityCheckIssueDialogController ($timeout, $scope, $stateParams, $uibModalInstance, entity, DataQualityCheckIssue, BatchReportHistory) {
        var vm = this;

        vm.dataQualityCheckIssue = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.batchreporthistories = BatchReportHistory.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.dataQualityCheckIssue.id !== null) {
                DataQualityCheckIssue.update(vm.dataQualityCheckIssue, onSaveSuccess, onSaveError);
            } else {
                DataQualityCheckIssue.save(vm.dataQualityCheckIssue, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('smartApp:dataQualityCheckIssueUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
