(function() {
    'use strict';
    angular
        .module('smartApp')
        .factory('DataQualityCheckIssue', DataQualityCheckIssue);

    DataQualityCheckIssue.$inject = ['$resource', 'DateUtils'];

    function DataQualityCheckIssue ($resource, DateUtils) {
        var resourceUrl =  'api/data-quality-check-issues/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true},
            'get': {
                method: 'GET',
                transformResponse: function (data) {
                    if (data) {
                        data = angular.fromJson(data);
                        data.updatedDate = DateUtils.convertDateTimeFromServer(data.updatedDate);
                    }
                    return data;
                }
            },
            'update': { method:'PUT' }
        });
    }
})();
