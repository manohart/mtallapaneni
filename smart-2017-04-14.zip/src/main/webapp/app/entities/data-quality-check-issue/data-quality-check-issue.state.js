(function() {
    'use strict';

    angular
        .module('smartApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('data-quality-check-issue', {
            parent: 'entity',
            url: '/data-quality-check-issue?page&sort&search',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'DataQualityCheckIssues'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/data-quality-check-issue/data-quality-check-issues.html',
                    controller: 'DataQualityCheckIssueController',
                    controllerAs: 'vm'
                }
            },
            params: {
                page: {
                    value: '1',
                    squash: true
                },
                sort: {
                    value: 'id,asc',
                    squash: true
                },
                search: null
            },
            resolve: {
                pagingParams: ['$stateParams', 'PaginationUtil', function ($stateParams, PaginationUtil) {
                    return {
                        page: PaginationUtil.parsePage($stateParams.page),
                        sort: $stateParams.sort,
                        predicate: PaginationUtil.parsePredicate($stateParams.sort),
                        ascending: PaginationUtil.parseAscending($stateParams.sort),
                        search: $stateParams.search
                    };
                }]
            }
        })
        .state('data-quality-check-issue-detail', {
            parent: 'data-quality-check-issue',
            url: '/data-quality-check-issue/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'DataQualityCheckIssue'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/data-quality-check-issue/data-quality-check-issue-detail.html',
                    controller: 'DataQualityCheckIssueDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'DataQualityCheckIssue', function($stateParams, DataQualityCheckIssue) {
                    return DataQualityCheckIssue.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'data-quality-check-issue',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('data-quality-check-issue-detail.edit', {
            parent: 'data-quality-check-issue-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/data-quality-check-issue/data-quality-check-issue-dialog.html',
                    controller: 'DataQualityCheckIssueDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['DataQualityCheckIssue', function(DataQualityCheckIssue) {
                            return DataQualityCheckIssue.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('data-quality-check-issue.new', {
            parent: 'data-quality-check-issue',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/data-quality-check-issue/data-quality-check-issue-dialog.html',
                    controller: 'DataQualityCheckIssueDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                records: null,
                                issues: null,
                                initialStatus: null,
                                rootCauseCode: null,
                                rootCause: null,
                                resolution: null,
                                finalStatus: null,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('data-quality-check-issue', null, { reload: 'data-quality-check-issue' });
                }, function() {
                    $state.go('data-quality-check-issue');
                });
            }]
        })
        .state('data-quality-check-issue.edit', {
            parent: 'data-quality-check-issue',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/data-quality-check-issue/data-quality-check-issue-dialog.html',
                    controller: 'DataQualityCheckIssueDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['DataQualityCheckIssue', function(DataQualityCheckIssue) {
                            return DataQualityCheckIssue.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('data-quality-check-issue', null, { reload: 'data-quality-check-issue' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('data-quality-check-issue.delete', {
            parent: 'data-quality-check-issue',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/data-quality-check-issue/data-quality-check-issue-delete-dialog.html',
                    controller: 'DataQualityCheckIssueDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['DataQualityCheckIssue', function(DataQualityCheckIssue) {
                            return DataQualityCheckIssue.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('data-quality-check-issue', null, { reload: 'data-quality-check-issue' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
