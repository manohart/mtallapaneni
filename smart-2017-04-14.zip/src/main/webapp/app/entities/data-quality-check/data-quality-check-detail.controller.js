(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('DataQualityCheckDetailController', DataQualityCheckDetailController);

    DataQualityCheckDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'DataQualityCheck', 'BatchReportDetailHistory', 'WebService', 'BatchReport'];

    function DataQualityCheckDetailController($scope, $rootScope, $stateParams, previousState, entity, DataQualityCheck, BatchReportDetailHistory, WebService, BatchReport) {
        var vm = this;

        vm.dataQualityCheck = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartApp:dataQualityCheckUpdate', function(event, result) {
            vm.dataQualityCheck = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
