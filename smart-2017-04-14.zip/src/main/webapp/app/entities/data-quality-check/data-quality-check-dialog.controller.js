(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('DataQualityCheckDialogController', DataQualityCheckDialogController);

    DataQualityCheckDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'entity', 'DataQualityCheck', 'BatchReportDetailHistory', 'WebService', 'BatchReport'];

    function DataQualityCheckDialogController ($timeout, $scope, $stateParams, $uibModalInstance, entity, DataQualityCheck, BatchReportDetailHistory, WebService, BatchReport) {
        var vm = this;

        vm.dataQualityCheck = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.batchreportdetailhistories = BatchReportDetailHistory.query();
        vm.webservices = WebService.query();
        vm.batchreports = BatchReport.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.dataQualityCheck.id !== null) {
                DataQualityCheck.update(vm.dataQualityCheck, onSaveSuccess, onSaveError);
            } else {
                DataQualityCheck.save(vm.dataQualityCheck, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('smartApp:dataQualityCheckUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
