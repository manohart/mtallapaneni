(function() {
    'use strict';

    angular
        .module('smartApp')
        .factory('DataQualityCheckSearch', DataQualityCheckSearch);

    DataQualityCheckSearch.$inject = ['$resource'];

    function DataQualityCheckSearch($resource) {
        var resourceUrl =  'api/_search/data-quality-checks/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
