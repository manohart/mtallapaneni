(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('DistributionDetailController', DistributionDetailController);

    DistributionDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'Distribution', 'LineOfBusiness'];

    function DistributionDetailController($scope, $rootScope, $stateParams, previousState, entity, Distribution, LineOfBusiness) {
        var vm = this;

        vm.distribution = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartApp:distributionUpdate', function(event, result) {
            vm.distribution = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
