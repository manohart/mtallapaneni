(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('HolidayCalendarDeleteController',HolidayCalendarDeleteController);

    HolidayCalendarDeleteController.$inject = ['$uibModalInstance', 'entity', 'HolidayCalendar'];

    function HolidayCalendarDeleteController($uibModalInstance, entity, HolidayCalendar) {
        var vm = this;

        vm.holidayCalendar = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            HolidayCalendar.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
