(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('HolidayCalendarDetailController', HolidayCalendarDetailController);

    HolidayCalendarDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'HolidayCalendar'];

    function HolidayCalendarDetailController($scope, $rootScope, $stateParams, previousState, entity, HolidayCalendar) {
        var vm = this;

        vm.holidayCalendar = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartApp:holidayCalendarUpdate', function(event, result) {
            vm.holidayCalendar = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
