(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('HolidayCalendarDialogController', HolidayCalendarDialogController);

    HolidayCalendarDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'entity', 'HolidayCalendar'];

    function HolidayCalendarDialogController ($timeout, $scope, $stateParams, $uibModalInstance, entity, HolidayCalendar) {
        var vm = this;

        vm.holidayCalendar = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.holidayCalendar.id !== null) {
                HolidayCalendar.update(vm.holidayCalendar, onSaveSuccess, onSaveError);
            } else {
                HolidayCalendar.save(vm.holidayCalendar, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('smartApp:holidayCalendarUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.calendarDate = false;
        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
