(function() {
    'use strict';

    angular
        .module('smartApp')
        .factory('HolidayCalendarSearch', HolidayCalendarSearch);

    HolidayCalendarSearch.$inject = ['$resource'];

    function HolidayCalendarSearch($resource) {
        var resourceUrl =  'api/_search/holiday-calendars/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
