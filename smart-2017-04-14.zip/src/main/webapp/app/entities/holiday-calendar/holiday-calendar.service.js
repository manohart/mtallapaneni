(function() {
    'use strict';
    angular
        .module('smartApp')
        .factory('HolidayCalendar', HolidayCalendar);

    HolidayCalendar.$inject = ['$resource', 'DateUtils'];

    function HolidayCalendar ($resource, DateUtils) {
        var resourceUrl =  'api/holiday-calendars/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true},
            'get': {
                method: 'GET',
                transformResponse: function (data) {
                    if (data) {
                        data = angular.fromJson(data);
                        data.calendarDate = DateUtils.convertLocalDateFromServer(data.calendarDate);
                        data.updatedDate = DateUtils.convertDateTimeFromServer(data.updatedDate);
                    }
                    return data;
                }
            },
            'update': {
                method: 'PUT',
                transformRequest: function (data) {
                    var copy = angular.copy(data);
                    copy.calendarDate = DateUtils.convertLocalDateToServer(copy.calendarDate);
                    return angular.toJson(copy);
                }
            },
            'save': {
                method: 'POST',
                transformRequest: function (data) {
                    var copy = angular.copy(data);
                    copy.calendarDate = DateUtils.convertLocalDateToServer(copy.calendarDate);
                    return angular.toJson(copy);
                }
            }
        });
    }
})();
