(function() {
    'use strict';

    angular
        .module('smartApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('holiday-calendar', {
            parent: 'entity',
            url: '/holiday-calendar?page&sort&search',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'HolidayCalendars'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/holiday-calendar/holiday-calendars.html',
                    controller: 'HolidayCalendarController',
                    controllerAs: 'vm'
                }
            },
            params: {
                page: {
                    value: '1',
                    squash: true
                },
                sort: {
                    value: 'id,asc',
                    squash: true
                },
                search: null
            },
            resolve: {
                pagingParams: ['$stateParams', 'PaginationUtil', function ($stateParams, PaginationUtil) {
                    return {
                        page: PaginationUtil.parsePage($stateParams.page),
                        sort: $stateParams.sort,
                        predicate: PaginationUtil.parsePredicate($stateParams.sort),
                        ascending: PaginationUtil.parseAscending($stateParams.sort),
                        search: $stateParams.search
                    };
                }]
            }
        })
        .state('holiday-calendar-detail', {
            parent: 'holiday-calendar',
            url: '/holiday-calendar/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'HolidayCalendar'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/holiday-calendar/holiday-calendar-detail.html',
                    controller: 'HolidayCalendarDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'HolidayCalendar', function($stateParams, HolidayCalendar) {
                    return HolidayCalendar.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'holiday-calendar',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('holiday-calendar-detail.edit', {
            parent: 'holiday-calendar-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/holiday-calendar/holiday-calendar-dialog.html',
                    controller: 'HolidayCalendarDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['HolidayCalendar', function(HolidayCalendar) {
                            return HolidayCalendar.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('holiday-calendar.new', {
            parent: 'holiday-calendar',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/holiday-calendar/holiday-calendar-dialog.html',
                    controller: 'HolidayCalendarDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                regionCode: null,
                                calendarDate: null,
                                description: null,
                                exchangeCode: null,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('holiday-calendar', null, { reload: 'holiday-calendar' });
                }, function() {
                    $state.go('holiday-calendar');
                });
            }]
        })
        .state('holiday-calendar.edit', {
            parent: 'holiday-calendar',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/holiday-calendar/holiday-calendar-dialog.html',
                    controller: 'HolidayCalendarDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['HolidayCalendar', function(HolidayCalendar) {
                            return HolidayCalendar.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('holiday-calendar', null, { reload: 'holiday-calendar' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('holiday-calendar.delete', {
            parent: 'holiday-calendar',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/holiday-calendar/holiday-calendar-delete-dialog.html',
                    controller: 'HolidayCalendarDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['HolidayCalendar', function(HolidayCalendar) {
                            return HolidayCalendar.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('holiday-calendar', null, { reload: 'holiday-calendar' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
