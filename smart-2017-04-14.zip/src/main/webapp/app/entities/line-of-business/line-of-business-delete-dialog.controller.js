(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('LineOfBusinessDeleteController',LineOfBusinessDeleteController);

    LineOfBusinessDeleteController.$inject = ['$uibModalInstance', 'entity', 'LineOfBusiness'];

    function LineOfBusinessDeleteController($uibModalInstance, entity, LineOfBusiness) {
        var vm = this;

        vm.lineOfBusiness = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            LineOfBusiness.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
