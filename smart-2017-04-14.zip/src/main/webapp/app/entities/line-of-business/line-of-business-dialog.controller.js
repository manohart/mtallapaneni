(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('LineOfBusinessDialogController', LineOfBusinessDialogController);

    LineOfBusinessDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'entity', 'LineOfBusiness', 'Application', 'ArchiveLocation', 'AutoNotification', 'Product', 'Template', 'Team'];

    function LineOfBusinessDialogController ($timeout, $scope, $stateParams, $uibModalInstance, entity, LineOfBusiness, Application, ArchiveLocation, AutoNotification, Product, Template, Team) {
        var vm = this;

        vm.lineOfBusiness = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.lineofbusinesses = LineOfBusiness.query();
        vm.applications = Application.query();
        vm.archivelocations = ArchiveLocation.query();
        vm.autonotifications = AutoNotification.query();
        vm.products = Product.query();
        vm.templates = Template.query();
        vm.teams = Team.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.lineOfBusiness.id !== null) {
                LineOfBusiness.update(vm.lineOfBusiness, onSaveSuccess, onSaveError);
            } else {
                LineOfBusiness.save(vm.lineOfBusiness, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('smartApp:lineOfBusinessUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
