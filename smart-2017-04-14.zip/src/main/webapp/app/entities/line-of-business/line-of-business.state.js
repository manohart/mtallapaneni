(function() {
    'use strict';

    angular
        .module('smartApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('line-of-business', {
            parent: 'entity',
            url: '/line-of-business?page&sort&search',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'LineOfBusinesses'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/line-of-business/line-of-businesses.html',
                    controller: 'LineOfBusinessController',
                    controllerAs: 'vm'
                }
            },
            params: {
                page: {
                    value: '1',
                    squash: true
                },
                sort: {
                    value: 'id,asc',
                    squash: true
                },
                search: null
            },
            resolve: {
                pagingParams: ['$stateParams', 'PaginationUtil', function ($stateParams, PaginationUtil) {
                    return {
                        page: PaginationUtil.parsePage($stateParams.page),
                        sort: $stateParams.sort,
                        predicate: PaginationUtil.parsePredicate($stateParams.sort),
                        ascending: PaginationUtil.parseAscending($stateParams.sort),
                        search: $stateParams.search
                    };
                }]
            }
        })
        .state('line-of-business-detail', {
            parent: 'line-of-business',
            url: '/line-of-business/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'LineOfBusiness'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/line-of-business/line-of-business-detail.html',
                    controller: 'LineOfBusinessDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'LineOfBusiness', function($stateParams, LineOfBusiness) {
                    return LineOfBusiness.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'line-of-business',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('line-of-business-detail.edit', {
            parent: 'line-of-business-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/line-of-business/line-of-business-dialog.html',
                    controller: 'LineOfBusinessDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['LineOfBusiness', function(LineOfBusiness) {
                            return LineOfBusiness.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('line-of-business.new', {
            parent: 'line-of-business',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/line-of-business/line-of-business-dialog.html',
                    controller: 'LineOfBusinessDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                code: null,
                                description: null,
                                ownerSid: null,
                                managerSid: null,
                                businessSponsorSid: null,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('line-of-business', null, { reload: 'line-of-business' });
                }, function() {
                    $state.go('line-of-business');
                });
            }]
        })
        .state('line-of-business.edit', {
            parent: 'line-of-business',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/line-of-business/line-of-business-dialog.html',
                    controller: 'LineOfBusinessDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['LineOfBusiness', function(LineOfBusiness) {
                            return LineOfBusiness.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('line-of-business', null, { reload: 'line-of-business' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('line-of-business.delete', {
            parent: 'line-of-business',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/line-of-business/line-of-business-delete-dialog.html',
                    controller: 'LineOfBusinessDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['LineOfBusiness', function(LineOfBusiness) {
                            return LineOfBusiness.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('line-of-business', null, { reload: 'line-of-business' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
