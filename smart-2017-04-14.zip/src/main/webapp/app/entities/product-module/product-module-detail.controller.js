(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('ProductModuleDetailController', ProductModuleDetailController);

    ProductModuleDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'ProductModule', 'Application', 'Product'];

    function ProductModuleDetailController($scope, $rootScope, $stateParams, previousState, entity, ProductModule, Application, Product) {
        var vm = this;

        vm.productModule = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartApp:productModuleUpdate', function(event, result) {
            vm.productModule = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
