(function() {
    'use strict';

    angular
        .module('smartApp')
        .factory('ProductModuleSearch', ProductModuleSearch);

    ProductModuleSearch.$inject = ['$resource'];

    function ProductModuleSearch($resource) {
        var resourceUrl =  'api/_search/product-modules/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
