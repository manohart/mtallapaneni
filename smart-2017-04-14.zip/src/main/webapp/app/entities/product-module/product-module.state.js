(function() {
    'use strict';

    angular
        .module('smartApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('product-module', {
            parent: 'entity',
            url: '/product-module?page&sort&search',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'ProductModules'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/product-module/product-modules.html',
                    controller: 'ProductModuleController',
                    controllerAs: 'vm'
                }
            },
            params: {
                page: {
                    value: '1',
                    squash: true
                },
                sort: {
                    value: 'id,asc',
                    squash: true
                },
                search: null
            },
            resolve: {
                pagingParams: ['$stateParams', 'PaginationUtil', function ($stateParams, PaginationUtil) {
                    return {
                        page: PaginationUtil.parsePage($stateParams.page),
                        sort: $stateParams.sort,
                        predicate: PaginationUtil.parsePredicate($stateParams.sort),
                        ascending: PaginationUtil.parseAscending($stateParams.sort),
                        search: $stateParams.search
                    };
                }]
            }
        })
        .state('product-module-detail', {
            parent: 'product-module',
            url: '/product-module/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'ProductModule'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/product-module/product-module-detail.html',
                    controller: 'ProductModuleDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'ProductModule', function($stateParams, ProductModule) {
                    return ProductModule.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'product-module',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('product-module-detail.edit', {
            parent: 'product-module-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/product-module/product-module-dialog.html',
                    controller: 'ProductModuleDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['ProductModule', function(ProductModule) {
                            return ProductModule.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('product-module.new', {
            parent: 'product-module',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/product-module/product-module-dialog.html',
                    controller: 'ProductModuleDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                code: null,
                                description: null,
                                sourceCode: null,
                                tracker: null,
                                ciLink: null,
                                techStack: null,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('product-module', null, { reload: 'product-module' });
                }, function() {
                    $state.go('product-module');
                });
            }]
        })
        .state('product-module.edit', {
            parent: 'product-module',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/product-module/product-module-dialog.html',
                    controller: 'ProductModuleDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['ProductModule', function(ProductModule) {
                            return ProductModule.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('product-module', null, { reload: 'product-module' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('product-module.delete', {
            parent: 'product-module',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/product-module/product-module-delete-dialog.html',
                    controller: 'ProductModuleDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['ProductModule', function(ProductModule) {
                            return ProductModule.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('product-module', null, { reload: 'product-module' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
