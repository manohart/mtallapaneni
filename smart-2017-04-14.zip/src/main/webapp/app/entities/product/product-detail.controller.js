(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('ProductDetailController', ProductDetailController);

    ProductDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'Product', 'ProductModule', 'SoftwareRelease', 'Team', 'LineOfBusiness'];

    function ProductDetailController($scope, $rootScope, $stateParams, previousState, entity, Product, ProductModule, SoftwareRelease, Team, LineOfBusiness) {
        var vm = this;

        vm.product = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartApp:productUpdate', function(event, result) {
            vm.product = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
