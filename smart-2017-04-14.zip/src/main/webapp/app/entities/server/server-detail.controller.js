(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('ServerDetailController', ServerDetailController);

    ServerDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'Server', 'Application', 'LineOfBusiness'];

    function ServerDetailController($scope, $rootScope, $stateParams, previousState, entity, Server, Application, LineOfBusiness) {
        var vm = this;

        vm.server = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartApp:serverUpdate', function(event, result) {
            vm.server = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
