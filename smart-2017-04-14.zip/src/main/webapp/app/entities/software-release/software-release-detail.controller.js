(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('SoftwareReleaseDetailController', SoftwareReleaseDetailController);

    SoftwareReleaseDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'SoftwareRelease', 'Product'];

    function SoftwareReleaseDetailController($scope, $rootScope, $stateParams, previousState, entity, SoftwareRelease, Product) {
        var vm = this;

        vm.softwareRelease = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartApp:softwareReleaseUpdate', function(event, result) {
            vm.softwareRelease = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
