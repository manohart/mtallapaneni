(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('SoftwareReleaseDialogController', SoftwareReleaseDialogController);

    SoftwareReleaseDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'entity', 'SoftwareRelease', 'Product'];

    function SoftwareReleaseDialogController ($timeout, $scope, $stateParams, $uibModalInstance, entity, SoftwareRelease, Product) {
        var vm = this;

        vm.softwareRelease = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.products = Product.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.softwareRelease.id !== null) {
                SoftwareRelease.update(vm.softwareRelease, onSaveSuccess, onSaveError);
            } else {
                SoftwareRelease.save(vm.softwareRelease, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('smartApp:softwareReleaseUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.releaseDate = false;
        vm.datePickerOpenStatus.plannedReleaseDate = false;
        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
