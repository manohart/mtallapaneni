(function() {
    'use strict';

    angular
        .module('smartApp')
        .factory('SoftwareReleaseSearch', SoftwareReleaseSearch);

    SoftwareReleaseSearch.$inject = ['$resource'];

    function SoftwareReleaseSearch($resource) {
        var resourceUrl =  'api/_search/software-releases/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
