(function() {
    'use strict';

    angular
        .module('smartApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('software-release', {
            parent: 'entity',
            url: '/software-release?page&sort&search',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'SoftwareReleases'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/software-release/software-releases.html',
                    controller: 'SoftwareReleaseController',
                    controllerAs: 'vm'
                }
            },
            params: {
                page: {
                    value: '1',
                    squash: true
                },
                sort: {
                    value: 'id,asc',
                    squash: true
                },
                search: null
            },
            resolve: {
                pagingParams: ['$stateParams', 'PaginationUtil', function ($stateParams, PaginationUtil) {
                    return {
                        page: PaginationUtil.parsePage($stateParams.page),
                        sort: $stateParams.sort,
                        predicate: PaginationUtil.parsePredicate($stateParams.sort),
                        ascending: PaginationUtil.parseAscending($stateParams.sort),
                        search: $stateParams.search
                    };
                }]
            }
        })
        .state('software-release-detail', {
            parent: 'software-release',
            url: '/software-release/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'SoftwareRelease'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/software-release/software-release-detail.html',
                    controller: 'SoftwareReleaseDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'SoftwareRelease', function($stateParams, SoftwareRelease) {
                    return SoftwareRelease.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'software-release',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('software-release-detail.edit', {
            parent: 'software-release-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/software-release/software-release-dialog.html',
                    controller: 'SoftwareReleaseDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['SoftwareRelease', function(SoftwareRelease) {
                            return SoftwareRelease.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('software-release.new', {
            parent: 'software-release',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/software-release/software-release-dialog.html',
                    controller: 'SoftwareReleaseDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                type: null,
                                releaseDate: null,
                                sprint: null,
                                version: null,
                                newFeatures: null,
                                enhancements: null,
                                bugFixes: null,
                                knownIssues: null,
                                releaseState: null,
                                plannedReleaseDate: null,
                                summary: null,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('software-release', null, { reload: 'software-release' });
                }, function() {
                    $state.go('software-release');
                });
            }]
        })
        .state('software-release.edit', {
            parent: 'software-release',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/software-release/software-release-dialog.html',
                    controller: 'SoftwareReleaseDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['SoftwareRelease', function(SoftwareRelease) {
                            return SoftwareRelease.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('software-release', null, { reload: 'software-release' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('software-release.delete', {
            parent: 'software-release',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/software-release/software-release-delete-dialog.html',
                    controller: 'SoftwareReleaseDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['SoftwareRelease', function(SoftwareRelease) {
                            return SoftwareRelease.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('software-release', null, { reload: 'software-release' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
