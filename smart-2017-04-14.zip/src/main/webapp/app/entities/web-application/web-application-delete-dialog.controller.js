(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('WebApplicationDeleteController',WebApplicationDeleteController);

    WebApplicationDeleteController.$inject = ['$uibModalInstance', 'entity', 'WebApplication'];

    function WebApplicationDeleteController($uibModalInstance, entity, WebApplication) {
        var vm = this;

        vm.webApplication = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            WebApplication.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
