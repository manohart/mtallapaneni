(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('WebApplicationDetailController', WebApplicationDetailController);

    WebApplicationDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'WebApplication', 'Application', 'WebService'];

    function WebApplicationDetailController($scope, $rootScope, $stateParams, previousState, entity, WebApplication, Application, WebService) {
        var vm = this;

        vm.webApplication = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartApp:webApplicationUpdate', function(event, result) {
            vm.webApplication = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
