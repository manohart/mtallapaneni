(function() {
    'use strict';

    angular
        .module('smartApp')
        .factory('WebApplicationSearch', WebApplicationSearch);

    WebApplicationSearch.$inject = ['$resource'];

    function WebApplicationSearch($resource) {
        var resourceUrl =  'api/_search/web-applications/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
