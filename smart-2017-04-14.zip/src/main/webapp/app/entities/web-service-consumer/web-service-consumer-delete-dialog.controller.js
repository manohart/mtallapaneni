(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('WebServiceConsumerDeleteController',WebServiceConsumerDeleteController);

    WebServiceConsumerDeleteController.$inject = ['$uibModalInstance', 'entity', 'WebServiceConsumer'];

    function WebServiceConsumerDeleteController($uibModalInstance, entity, WebServiceConsumer) {
        var vm = this;

        vm.webServiceConsumer = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            WebServiceConsumer.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
