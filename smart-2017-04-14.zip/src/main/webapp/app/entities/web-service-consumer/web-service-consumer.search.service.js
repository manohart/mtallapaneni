(function() {
    'use strict';

    angular
        .module('smartApp')
        .factory('WebServiceConsumerSearch', WebServiceConsumerSearch);

    WebServiceConsumerSearch.$inject = ['$resource'];

    function WebServiceConsumerSearch($resource) {
        var resourceUrl =  'api/_search/web-service-consumers/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
