(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('WebServiceDetailController', WebServiceDetailController);

    WebServiceDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'WebService', 'WebServiceConsumer', 'WebApplication'];

    function WebServiceDetailController($scope, $rootScope, $stateParams, previousState, entity, WebService, WebServiceConsumer, WebApplication) {
        var vm = this;

        vm.webService = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartApp:webServiceUpdate', function(event, result) {
            vm.webService = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
