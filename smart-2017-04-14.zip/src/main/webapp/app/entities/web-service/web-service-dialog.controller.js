(function() {
    'use strict';

    angular
        .module('smartApp')
        .controller('WebServiceDialogController', WebServiceDialogController);

    WebServiceDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'entity', 'WebService', 'WebServiceConsumer', 'WebApplication'];

    function WebServiceDialogController ($timeout, $scope, $stateParams, $uibModalInstance, entity, WebService, WebServiceConsumer, WebApplication) {
        var vm = this;

        vm.webService = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.webserviceconsumers = WebServiceConsumer.query();
        vm.webapplications = WebApplication.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.webService.id !== null) {
                WebService.update(vm.webService, onSaveSuccess, onSaveError);
            } else {
                WebService.save(vm.webService, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('smartApp:webServiceUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
