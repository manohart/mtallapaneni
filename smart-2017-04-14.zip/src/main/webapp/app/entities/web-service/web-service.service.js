(function() {
    'use strict';
    angular
        .module('smartApp')
        .factory('WebService', WebService);

    WebService.$inject = ['$resource', 'DateUtils'];

    function WebService ($resource, DateUtils) {
        var resourceUrl =  'api/web-services/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true},
            'get': {
                method: 'GET',
                transformResponse: function (data) {
                    if (data) {
                        data = angular.fromJson(data);
                        data.updatedDate = DateUtils.convertDateTimeFromServer(data.updatedDate);
                    }
                    return data;
                }
            },
            'update': { method:'PUT' }
        });
    }
})();
