(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('ActiveBusinessDateDetailController', ActiveBusinessDateDetailController);

    ActiveBusinessDateDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'ActiveBusinessDate'];

    function ActiveBusinessDateDetailController($scope, $rootScope, $stateParams, previousState, entity, ActiveBusinessDate) {
        var vm = this;

        vm.activeBusinessDate = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartIApp:activeBusinessDateUpdate', function(event, result) {
            vm.activeBusinessDate = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
