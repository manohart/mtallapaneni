(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('AppDependencyDialogController', AppDependencyDialogController);

    AppDependencyDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'entity', 'AppDependency', 'Application'];

    function AppDependencyDialogController ($timeout, $scope, $stateParams, $uibModalInstance, entity, AppDependency, Application) {
        var vm = this;

        vm.appDependency = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.applications = Application.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.appDependency.id !== null) {
                AppDependency.update(vm.appDependency, onSaveSuccess, onSaveError);
            } else {
                AppDependency.save(vm.appDependency, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('smartIApp:appDependencyUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
