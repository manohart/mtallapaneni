(function() {
    'use strict';

    angular
        .module('smartIApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('app-dependency', {
            parent: 'entity',
            url: '/app-dependency?page&sort&search',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'AppDependencies'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/app-dependency/app-dependencies.html',
                    controller: 'AppDependencyController',
                    controllerAs: 'vm'
                }
            },
            params: {
                page: {
                    value: '1',
                    squash: true
                },
                sort: {
                    value: 'id,asc',
                    squash: true
                },
                search: null
            },
            resolve: {
                pagingParams: ['$stateParams', 'PaginationUtil', function ($stateParams, PaginationUtil) {
                    return {
                        page: PaginationUtil.parsePage($stateParams.page),
                        sort: $stateParams.sort,
                        predicate: PaginationUtil.parsePredicate($stateParams.sort),
                        ascending: PaginationUtil.parseAscending($stateParams.sort),
                        search: $stateParams.search
                    };
                }]
            }
        })
        .state('app-dependency-detail', {
            parent: 'app-dependency',
            url: '/app-dependency/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'AppDependency'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/app-dependency/app-dependency-detail.html',
                    controller: 'AppDependencyDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'AppDependency', function($stateParams, AppDependency) {
                    return AppDependency.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'app-dependency',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('app-dependency-detail.edit', {
            parent: 'app-dependency-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/app-dependency/app-dependency-dialog.html',
                    controller: 'AppDependencyDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['AppDependency', function(AppDependency) {
                            return AppDependency.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('app-dependency.new', {
            parent: 'app-dependency',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/app-dependency/app-dependency-dialog.html',
                    controller: 'AppDependencyDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('app-dependency', null, { reload: 'app-dependency' });
                }, function() {
                    $state.go('app-dependency');
                });
            }]
        })
        .state('app-dependency.edit', {
            parent: 'app-dependency',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/app-dependency/app-dependency-dialog.html',
                    controller: 'AppDependencyDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['AppDependency', function(AppDependency) {
                            return AppDependency.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('app-dependency', null, { reload: 'app-dependency' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('app-dependency.delete', {
            parent: 'app-dependency',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/app-dependency/app-dependency-delete-dialog.html',
                    controller: 'AppDependencyDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['AppDependency', function(AppDependency) {
                            return AppDependency.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('app-dependency', null, { reload: 'app-dependency' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
