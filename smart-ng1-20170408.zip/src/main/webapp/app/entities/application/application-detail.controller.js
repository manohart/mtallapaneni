(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('ApplicationDetailController', ApplicationDetailController);

    ApplicationDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'DataUtils', 'entity', 'Application', 'AutoNotification', 'AppDependency', 'BatchDistribution', 'LineOfBusiness', 'ProductModule', 'Server'];

    function ApplicationDetailController($scope, $rootScope, $stateParams, previousState, DataUtils, entity, Application, AutoNotification, AppDependency, BatchDistribution, LineOfBusiness, ProductModule, Server) {
        var vm = this;

        vm.application = entity;
        vm.previousState = previousState.name;
        vm.byteSize = DataUtils.byteSize;
        vm.openFile = DataUtils.openFile;

        var unsubscribe = $rootScope.$on('smartIApp:applicationUpdate', function(event, result) {
            vm.application = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
