(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('AutoNotificationDeleteController',AutoNotificationDeleteController);

    AutoNotificationDeleteController.$inject = ['$uibModalInstance', 'entity', 'AutoNotification'];

    function AutoNotificationDeleteController($uibModalInstance, entity, AutoNotification) {
        var vm = this;

        vm.autoNotification = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            AutoNotification.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
