(function() {
    'use strict';

    angular
        .module('smartIApp')
        .factory('BatchConfigSearch', BatchConfigSearch);

    BatchConfigSearch.$inject = ['$resource'];

    function BatchConfigSearch($resource) {
        var resourceUrl =  'api/_search/batch-configs/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
