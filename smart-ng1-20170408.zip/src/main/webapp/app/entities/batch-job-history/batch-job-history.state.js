(function() {
    'use strict';

    angular
        .module('smartIApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('batch-job-history', {
            parent: 'entity',
            url: '/batch-job-history?page&sort&search',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'BatchJobHistories'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/batch-job-history/batch-job-histories.html',
                    controller: 'BatchJobHistoryController',
                    controllerAs: 'vm'
                }
            },
            params: {
                page: {
                    value: '1',
                    squash: true
                },
                sort: {
                    value: 'id,asc',
                    squash: true
                },
                search: null
            },
            resolve: {
                pagingParams: ['$stateParams', 'PaginationUtil', function ($stateParams, PaginationUtil) {
                    return {
                        page: PaginationUtil.parsePage($stateParams.page),
                        sort: $stateParams.sort,
                        predicate: PaginationUtil.parsePredicate($stateParams.sort),
                        ascending: PaginationUtil.parseAscending($stateParams.sort),
                        search: $stateParams.search
                    };
                }]
            }
        })
        .state('batch-job-history-detail', {
            parent: 'batch-job-history',
            url: '/batch-job-history/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'BatchJobHistory'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/batch-job-history/batch-job-history-detail.html',
                    controller: 'BatchJobHistoryDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'BatchJobHistory', function($stateParams, BatchJobHistory) {
                    return BatchJobHistory.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'batch-job-history',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('batch-job-history-detail.edit', {
            parent: 'batch-job-history-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-job-history/batch-job-history-dialog.html',
                    controller: 'BatchJobHistoryDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['BatchJobHistory', function(BatchJobHistory) {
                            return BatchJobHistory.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('batch-job-history.new', {
            parent: 'batch-job-history',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-job-history/batch-job-history-dialog.html',
                    controller: 'BatchJobHistoryDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                businessDate: null,
                                status: null,
                                currentStep: null,
                                startTime: null,
                                endTime: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('batch-job-history', null, { reload: 'batch-job-history' });
                }, function() {
                    $state.go('batch-job-history');
                });
            }]
        })
        .state('batch-job-history.edit', {
            parent: 'batch-job-history',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-job-history/batch-job-history-dialog.html',
                    controller: 'BatchJobHistoryDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['BatchJobHistory', function(BatchJobHistory) {
                            return BatchJobHistory.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('batch-job-history', null, { reload: 'batch-job-history' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('batch-job-history.delete', {
            parent: 'batch-job-history',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-job-history/batch-job-history-delete-dialog.html',
                    controller: 'BatchJobHistoryDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['BatchJobHistory', function(BatchJobHistory) {
                            return BatchJobHistory.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('batch-job-history', null, { reload: 'batch-job-history' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
