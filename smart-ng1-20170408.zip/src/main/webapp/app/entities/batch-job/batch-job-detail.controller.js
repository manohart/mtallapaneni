(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('BatchJobDetailController', BatchJobDetailController);

    BatchJobDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'BatchJob', 'Application', 'BatchJobHistory', 'BatchReport', 'BatchConfig', 'BatchStepProcessor'];

    function BatchJobDetailController($scope, $rootScope, $stateParams, previousState, entity, BatchJob, Application, BatchJobHistory, BatchReport, BatchConfig, BatchStepProcessor) {
        var vm = this;

        vm.batchJob = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartIApp:batchJobUpdate', function(event, result) {
            vm.batchJob = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
