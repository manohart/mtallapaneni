(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('BatchJobDialogController', BatchJobDialogController);

    BatchJobDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', '$q', 'entity', 'BatchJob', 'Application', 'BatchJobHistory', 'BatchReport', 'BatchConfig', 'BatchStepProcessor'];

    function BatchJobDialogController ($timeout, $scope, $stateParams, $uibModalInstance, $q, entity, BatchJob, Application, BatchJobHistory, BatchReport, BatchConfig, BatchStepProcessor) {
        var vm = this;

        vm.batchJob = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.applications = Application.query({filter: 'batchjob-is-null'});
        $q.all([vm.batchJob.$promise, vm.applications.$promise]).then(function() {
            if (!vm.batchJob.application || !vm.batchJob.application.id) {
                return $q.reject();
            }
            return Application.get({id : vm.batchJob.application.id}).$promise;
        }).then(function(application) {
            vm.applications.push(application);
        });
        vm.batchjobhistories = BatchJobHistory.query();
        vm.batchreports = BatchReport.query();
        vm.batchconfigs = BatchConfig.query();
        vm.batchstepprocessors = BatchStepProcessor.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.batchJob.id !== null) {
                BatchJob.update(vm.batchJob, onSaveSuccess, onSaveError);
            } else {
                BatchJob.save(vm.batchJob, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('smartIApp:batchJobUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
