(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('BatchReportDetailHistoryDetailController', BatchReportDetailHistoryDetailController);

    BatchReportDetailHistoryDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'BatchReportDetailHistory', 'BatchReportHistory', 'DataQualityCheck'];

    function BatchReportDetailHistoryDetailController($scope, $rootScope, $stateParams, previousState, entity, BatchReportDetailHistory, BatchReportHistory, DataQualityCheck) {
        var vm = this;

        vm.batchReportDetailHistory = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartIApp:batchReportDetailHistoryUpdate', function(event, result) {
            vm.batchReportDetailHistory = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
