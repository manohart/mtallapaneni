(function() {
    'use strict';

    angular
        .module('smartIApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('batch-report-history', {
            parent: 'entity',
            url: '/batch-report-history?page&sort&search',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'BatchReportHistories'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/batch-report-history/batch-report-histories.html',
                    controller: 'BatchReportHistoryController',
                    controllerAs: 'vm'
                }
            },
            params: {
                page: {
                    value: '1',
                    squash: true
                },
                sort: {
                    value: 'id,asc',
                    squash: true
                },
                search: null
            },
            resolve: {
                pagingParams: ['$stateParams', 'PaginationUtil', function ($stateParams, PaginationUtil) {
                    return {
                        page: PaginationUtil.parsePage($stateParams.page),
                        sort: $stateParams.sort,
                        predicate: PaginationUtil.parsePredicate($stateParams.sort),
                        ascending: PaginationUtil.parseAscending($stateParams.sort),
                        search: $stateParams.search
                    };
                }]
            }
        })
        .state('batch-report-history-detail', {
            parent: 'batch-report-history',
            url: '/batch-report-history/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'BatchReportHistory'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/batch-report-history/batch-report-history-detail.html',
                    controller: 'BatchReportHistoryDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'BatchReportHistory', function($stateParams, BatchReportHistory) {
                    return BatchReportHistory.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'batch-report-history',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('batch-report-history-detail.edit', {
            parent: 'batch-report-history-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-report-history/batch-report-history-dialog.html',
                    controller: 'BatchReportHistoryDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['BatchReportHistory', function(BatchReportHistory) {
                            return BatchReportHistory.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('batch-report-history.new', {
            parent: 'batch-report-history',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-report-history/batch-report-history-dialog.html',
                    controller: 'BatchReportHistoryDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                businessDate: null,
                                status: null,
                                startTime: null,
                                endTime: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('batch-report-history', null, { reload: 'batch-report-history' });
                }, function() {
                    $state.go('batch-report-history');
                });
            }]
        })
        .state('batch-report-history.edit', {
            parent: 'batch-report-history',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-report-history/batch-report-history-dialog.html',
                    controller: 'BatchReportHistoryDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['BatchReportHistory', function(BatchReportHistory) {
                            return BatchReportHistory.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('batch-report-history', null, { reload: 'batch-report-history' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('batch-report-history.delete', {
            parent: 'batch-report-history',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-report-history/batch-report-history-delete-dialog.html',
                    controller: 'BatchReportHistoryDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['BatchReportHistory', function(BatchReportHistory) {
                            return BatchReportHistory.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('batch-report-history', null, { reload: 'batch-report-history' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
