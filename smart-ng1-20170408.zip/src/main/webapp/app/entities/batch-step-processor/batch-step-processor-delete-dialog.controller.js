(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('BatchStepProcessorDeleteController',BatchStepProcessorDeleteController);

    BatchStepProcessorDeleteController.$inject = ['$uibModalInstance', 'entity', 'BatchStepProcessor'];

    function BatchStepProcessorDeleteController($uibModalInstance, entity, BatchStepProcessor) {
        var vm = this;

        vm.batchStepProcessor = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            BatchStepProcessor.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
