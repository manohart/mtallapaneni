(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('BatchStepProcessorDetailController', BatchStepProcessorDetailController);

    BatchStepProcessorDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'DataUtils', 'entity', 'BatchStepProcessor', 'BatchJob'];

    function BatchStepProcessorDetailController($scope, $rootScope, $stateParams, previousState, DataUtils, entity, BatchStepProcessor, BatchJob) {
        var vm = this;

        vm.batchStepProcessor = entity;
        vm.previousState = previousState.name;
        vm.byteSize = DataUtils.byteSize;
        vm.openFile = DataUtils.openFile;

        var unsubscribe = $rootScope.$on('smartIApp:batchStepProcessorUpdate', function(event, result) {
            vm.batchStepProcessor = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
