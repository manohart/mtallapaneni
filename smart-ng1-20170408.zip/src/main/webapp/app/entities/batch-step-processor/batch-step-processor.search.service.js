(function() {
    'use strict';

    angular
        .module('smartIApp')
        .factory('BatchStepProcessorSearch', BatchStepProcessorSearch);

    BatchStepProcessorSearch.$inject = ['$resource'];

    function BatchStepProcessorSearch($resource) {
        var resourceUrl =  'api/_search/batch-step-processors/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
