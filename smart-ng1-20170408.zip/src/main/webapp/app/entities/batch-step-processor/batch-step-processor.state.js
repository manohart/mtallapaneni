(function() {
    'use strict';

    angular
        .module('smartIApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('batch-step-processor', {
            parent: 'entity',
            url: '/batch-step-processor?page&sort&search',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'BatchStepProcessors'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/batch-step-processor/batch-step-processors.html',
                    controller: 'BatchStepProcessorController',
                    controllerAs: 'vm'
                }
            },
            params: {
                page: {
                    value: '1',
                    squash: true
                },
                sort: {
                    value: 'id,asc',
                    squash: true
                },
                search: null
            },
            resolve: {
                pagingParams: ['$stateParams', 'PaginationUtil', function ($stateParams, PaginationUtil) {
                    return {
                        page: PaginationUtil.parsePage($stateParams.page),
                        sort: $stateParams.sort,
                        predicate: PaginationUtil.parsePredicate($stateParams.sort),
                        ascending: PaginationUtil.parseAscending($stateParams.sort),
                        search: $stateParams.search
                    };
                }]
            }
        })
        .state('batch-step-processor-detail', {
            parent: 'batch-step-processor',
            url: '/batch-step-processor/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'BatchStepProcessor'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/batch-step-processor/batch-step-processor-detail.html',
                    controller: 'BatchStepProcessorDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'BatchStepProcessor', function($stateParams, BatchStepProcessor) {
                    return BatchStepProcessor.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'batch-step-processor',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('batch-step-processor-detail.edit', {
            parent: 'batch-step-processor-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-step-processor/batch-step-processor-dialog.html',
                    controller: 'BatchStepProcessorDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['BatchStepProcessor', function(BatchStepProcessor) {
                            return BatchStepProcessor.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('batch-step-processor.new', {
            parent: 'batch-step-processor',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-step-processor/batch-step-processor-dialog.html',
                    controller: 'BatchStepProcessorDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                stepNumber: null,
                                name: null,
                                processor: null,
                                description: null,
                                descriptionContentType: null,
                                troubleshooting: null,
                                troubleshootingContentType: null,
                                contIfFailed: null,
                                postCheckCode: null,
                                fail: null,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('batch-step-processor', null, { reload: 'batch-step-processor' });
                }, function() {
                    $state.go('batch-step-processor');
                });
            }]
        })
        .state('batch-step-processor.edit', {
            parent: 'batch-step-processor',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-step-processor/batch-step-processor-dialog.html',
                    controller: 'BatchStepProcessorDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['BatchStepProcessor', function(BatchStepProcessor) {
                            return BatchStepProcessor.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('batch-step-processor', null, { reload: 'batch-step-processor' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('batch-step-processor.delete', {
            parent: 'batch-step-processor',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-step-processor/batch-step-processor-delete-dialog.html',
                    controller: 'BatchStepProcessorDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['BatchStepProcessor', function(BatchStepProcessor) {
                            return BatchStepProcessor.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('batch-step-processor', null, { reload: 'batch-step-processor' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
