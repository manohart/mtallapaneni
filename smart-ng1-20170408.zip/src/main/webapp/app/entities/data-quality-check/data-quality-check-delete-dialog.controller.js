(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('DataQualityCheckDeleteController',DataQualityCheckDeleteController);

    DataQualityCheckDeleteController.$inject = ['$uibModalInstance', 'entity', 'DataQualityCheck'];

    function DataQualityCheckDeleteController($uibModalInstance, entity, DataQualityCheck) {
        var vm = this;

        vm.dataQualityCheck = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            DataQualityCheck.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
