(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('DataQualityCheckDetailController', DataQualityCheckDetailController);

    DataQualityCheckDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'DataUtils', 'entity', 'DataQualityCheck', 'BatchReportDetailHistory', 'WebService', 'BatchReport'];

    function DataQualityCheckDetailController($scope, $rootScope, $stateParams, previousState, DataUtils, entity, DataQualityCheck, BatchReportDetailHistory, WebService, BatchReport) {
        var vm = this;

        vm.dataQualityCheck = entity;
        vm.previousState = previousState.name;
        vm.byteSize = DataUtils.byteSize;
        vm.openFile = DataUtils.openFile;

        var unsubscribe = $rootScope.$on('smartIApp:dataQualityCheckUpdate', function(event, result) {
            vm.dataQualityCheck = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
