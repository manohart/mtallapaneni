(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('DistributionDeleteController',DistributionDeleteController);

    DistributionDeleteController.$inject = ['$uibModalInstance', 'entity', 'Distribution'];

    function DistributionDeleteController($uibModalInstance, entity, Distribution) {
        var vm = this;

        vm.distribution = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            Distribution.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
