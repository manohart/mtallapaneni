(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('DistributionDialogController', DistributionDialogController);

    DistributionDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'entity', 'Distribution', 'LineOfBusiness'];

    function DistributionDialogController ($timeout, $scope, $stateParams, $uibModalInstance, entity, Distribution, LineOfBusiness) {
        var vm = this;

        vm.distribution = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.lineofbusinesses = LineOfBusiness.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.distribution.id !== null) {
                Distribution.update(vm.distribution, onSaveSuccess, onSaveError);
            } else {
                Distribution.save(vm.distribution, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('smartIApp:distributionUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
