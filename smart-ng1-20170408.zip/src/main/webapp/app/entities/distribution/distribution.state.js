(function() {
    'use strict';

    angular
        .module('smartIApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('distribution', {
            parent: 'entity',
            url: '/distribution?page&sort&search',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'Distributions'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/distribution/distributions.html',
                    controller: 'DistributionController',
                    controllerAs: 'vm'
                }
            },
            params: {
                page: {
                    value: '1',
                    squash: true
                },
                sort: {
                    value: 'id,asc',
                    squash: true
                },
                search: null
            },
            resolve: {
                pagingParams: ['$stateParams', 'PaginationUtil', function ($stateParams, PaginationUtil) {
                    return {
                        page: PaginationUtil.parsePage($stateParams.page),
                        sort: $stateParams.sort,
                        predicate: PaginationUtil.parsePredicate($stateParams.sort),
                        ascending: PaginationUtil.parseAscending($stateParams.sort),
                        search: $stateParams.search
                    };
                }]
            }
        })
        .state('distribution-detail', {
            parent: 'distribution',
            url: '/distribution/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'Distribution'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/distribution/distribution-detail.html',
                    controller: 'DistributionDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'Distribution', function($stateParams, Distribution) {
                    return Distribution.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'distribution',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('distribution-detail.edit', {
            parent: 'distribution-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/distribution/distribution-dialog.html',
                    controller: 'DistributionDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['Distribution', function(Distribution) {
                            return Distribution.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('distribution.new', {
            parent: 'distribution',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/distribution/distribution-dialog.html',
                    controller: 'DistributionDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                name: null,
                                fromAddress: null,
                                toAddress: null,
                                ccAddress: null,
                                skipEmpty: false,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('distribution', null, { reload: 'distribution' });
                }, function() {
                    $state.go('distribution');
                });
            }]
        })
        .state('distribution.edit', {
            parent: 'distribution',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/distribution/distribution-dialog.html',
                    controller: 'DistributionDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['Distribution', function(Distribution) {
                            return Distribution.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('distribution', null, { reload: 'distribution' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('distribution.delete', {
            parent: 'distribution',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/distribution/distribution-delete-dialog.html',
                    controller: 'DistributionDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['Distribution', function(Distribution) {
                            return Distribution.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('distribution', null, { reload: 'distribution' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
