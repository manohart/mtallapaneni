(function() {
    'use strict';

    angular
        .module('smartIApp')
        .factory('NotificationRuleSearch', NotificationRuleSearch);

    NotificationRuleSearch.$inject = ['$resource'];

    function NotificationRuleSearch($resource) {
        var resourceUrl =  'api/_search/notification-rules/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
