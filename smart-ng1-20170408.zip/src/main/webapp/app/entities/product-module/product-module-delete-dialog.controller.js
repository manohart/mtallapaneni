(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('ProductModuleDeleteController',ProductModuleDeleteController);

    ProductModuleDeleteController.$inject = ['$uibModalInstance', 'entity', 'ProductModule'];

    function ProductModuleDeleteController($uibModalInstance, entity, ProductModule) {
        var vm = this;

        vm.productModule = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            ProductModule.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
