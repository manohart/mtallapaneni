(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('ProductDetailController', ProductDetailController);

    ProductDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'DataUtils', 'entity', 'Product', 'ProductModule', 'SoftwareRelease', 'Team', 'LineOfBusiness'];

    function ProductDetailController($scope, $rootScope, $stateParams, previousState, DataUtils, entity, Product, ProductModule, SoftwareRelease, Team, LineOfBusiness) {
        var vm = this;

        vm.product = entity;
        vm.previousState = previousState.name;
        vm.byteSize = DataUtils.byteSize;
        vm.openFile = DataUtils.openFile;

        var unsubscribe = $rootScope.$on('smartIApp:productUpdate', function(event, result) {
            vm.product = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
