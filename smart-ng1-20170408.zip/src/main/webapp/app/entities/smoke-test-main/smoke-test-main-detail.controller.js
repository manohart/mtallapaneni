(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('SmokeTestMainDetailController', SmokeTestMainDetailController);

    SmokeTestMainDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'SmokeTestMain', 'SmokeTestSetup', 'SmokeTestResult'];

    function SmokeTestMainDetailController($scope, $rootScope, $stateParams, previousState, entity, SmokeTestMain, SmokeTestSetup, SmokeTestResult) {
        var vm = this;

        vm.smokeTestMain = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartIApp:smokeTestMainUpdate', function(event, result) {
            vm.smokeTestMain = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
