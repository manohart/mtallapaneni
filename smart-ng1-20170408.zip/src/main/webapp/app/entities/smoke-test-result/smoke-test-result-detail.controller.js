(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('SmokeTestResultDetailController', SmokeTestResultDetailController);

    SmokeTestResultDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'SmokeTestResult', 'SmokeTestMain'];

    function SmokeTestResultDetailController($scope, $rootScope, $stateParams, previousState, entity, SmokeTestResult, SmokeTestMain) {
        var vm = this;

        vm.smokeTestResult = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartIApp:smokeTestResultUpdate', function(event, result) {
            vm.smokeTestResult = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
