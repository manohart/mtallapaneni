(function() {
    'use strict';

    angular
        .module('smartIApp')
        .factory('SmokeTestResultSearch', SmokeTestResultSearch);

    SmokeTestResultSearch.$inject = ['$resource'];

    function SmokeTestResultSearch($resource) {
        var resourceUrl =  'api/_search/smoke-test-results/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
