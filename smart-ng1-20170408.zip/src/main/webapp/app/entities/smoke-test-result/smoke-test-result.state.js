(function() {
    'use strict';

    angular
        .module('smartIApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('smoke-test-result', {
            parent: 'entity',
            url: '/smoke-test-result?page&sort&search',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'SmokeTestResults'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/smoke-test-result/smoke-test-results.html',
                    controller: 'SmokeTestResultController',
                    controllerAs: 'vm'
                }
            },
            params: {
                page: {
                    value: '1',
                    squash: true
                },
                sort: {
                    value: 'id,asc',
                    squash: true
                },
                search: null
            },
            resolve: {
                pagingParams: ['$stateParams', 'PaginationUtil', function ($stateParams, PaginationUtil) {
                    return {
                        page: PaginationUtil.parsePage($stateParams.page),
                        sort: $stateParams.sort,
                        predicate: PaginationUtil.parsePredicate($stateParams.sort),
                        ascending: PaginationUtil.parseAscending($stateParams.sort),
                        search: $stateParams.search
                    };
                }]
            }
        })
        .state('smoke-test-result-detail', {
            parent: 'smoke-test-result',
            url: '/smoke-test-result/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'SmokeTestResult'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/smoke-test-result/smoke-test-result-detail.html',
                    controller: 'SmokeTestResultDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'SmokeTestResult', function($stateParams, SmokeTestResult) {
                    return SmokeTestResult.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'smoke-test-result',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('smoke-test-result-detail.edit', {
            parent: 'smoke-test-result-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/smoke-test-result/smoke-test-result-dialog.html',
                    controller: 'SmokeTestResultDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['SmokeTestResult', function(SmokeTestResult) {
                            return SmokeTestResult.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('smoke-test-result.new', {
            parent: 'smoke-test-result',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/smoke-test-result/smoke-test-result-dialog.html',
                    controller: 'SmokeTestResultDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                test: null,
                                result: null,
                                startDate: null,
                                endDate: null,
                                memFootprint: null,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('smoke-test-result', null, { reload: 'smoke-test-result' });
                }, function() {
                    $state.go('smoke-test-result');
                });
            }]
        })
        .state('smoke-test-result.edit', {
            parent: 'smoke-test-result',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/smoke-test-result/smoke-test-result-dialog.html',
                    controller: 'SmokeTestResultDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['SmokeTestResult', function(SmokeTestResult) {
                            return SmokeTestResult.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('smoke-test-result', null, { reload: 'smoke-test-result' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('smoke-test-result.delete', {
            parent: 'smoke-test-result',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/smoke-test-result/smoke-test-result-delete-dialog.html',
                    controller: 'SmokeTestResultDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['SmokeTestResult', function(SmokeTestResult) {
                            return SmokeTestResult.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('smoke-test-result', null, { reload: 'smoke-test-result' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
