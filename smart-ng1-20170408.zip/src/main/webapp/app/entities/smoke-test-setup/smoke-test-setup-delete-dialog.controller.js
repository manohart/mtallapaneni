(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('SmokeTestSetupDeleteController',SmokeTestSetupDeleteController);

    SmokeTestSetupDeleteController.$inject = ['$uibModalInstance', 'entity', 'SmokeTestSetup'];

    function SmokeTestSetupDeleteController($uibModalInstance, entity, SmokeTestSetup) {
        var vm = this;

        vm.smokeTestSetup = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            SmokeTestSetup.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
