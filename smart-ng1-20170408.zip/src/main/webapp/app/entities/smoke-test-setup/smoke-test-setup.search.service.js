(function() {
    'use strict';

    angular
        .module('smartIApp')
        .factory('SmokeTestSetupSearch', SmokeTestSetupSearch);

    SmokeTestSetupSearch.$inject = ['$resource'];

    function SmokeTestSetupSearch($resource) {
        var resourceUrl =  'api/_search/smoke-test-setups/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
