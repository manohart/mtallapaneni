(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('WebApplicationDialogController', WebApplicationDialogController);

    WebApplicationDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', '$q', 'entity', 'WebApplication', 'Application', 'WebService'];

    function WebApplicationDialogController ($timeout, $scope, $stateParams, $uibModalInstance, $q, entity, WebApplication, Application, WebService) {
        var vm = this;

        vm.webApplication = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.applications = Application.query({filter: 'webapplication-is-null'});
        $q.all([vm.webApplication.$promise, vm.applications.$promise]).then(function() {
            if (!vm.webApplication.application || !vm.webApplication.application.id) {
                return $q.reject();
            }
            return Application.get({id : vm.webApplication.application.id}).$promise;
        }).then(function(application) {
            vm.applications.push(application);
        });
        vm.drapplications = Application.query({filter: 'webapplication-is-null'});
        $q.all([vm.webApplication.$promise, vm.drapplications.$promise]).then(function() {
            if (!vm.webApplication.drApplication || !vm.webApplication.drApplication.id) {
                return $q.reject();
            }
            return Application.get({id : vm.webApplication.drApplication.id}).$promise;
        }).then(function(drApplication) {
            vm.drapplications.push(drApplication);
        });
        vm.webservices = WebService.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.webApplication.id !== null) {
                WebApplication.update(vm.webApplication, onSaveSuccess, onSaveError);
            } else {
                WebApplication.save(vm.webApplication, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('smartIApp:webApplicationUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
