(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('WebServiceDetailController', WebServiceDetailController);

    WebServiceDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'DataUtils', 'entity', 'WebService', 'WebServiceConsumer', 'WebApplication'];

    function WebServiceDetailController($scope, $rootScope, $stateParams, previousState, DataUtils, entity, WebService, WebServiceConsumer, WebApplication) {
        var vm = this;

        vm.webService = entity;
        vm.previousState = previousState.name;
        vm.byteSize = DataUtils.byteSize;
        vm.openFile = DataUtils.openFile;

        var unsubscribe = $rootScope.$on('smartIApp:webServiceUpdate', function(event, result) {
            vm.webService = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
