(function() {
    'use strict';

    angular
        .module('smartIApp')
        .constant('paginationConstants', {
            'itemsPerPage': 20
        });
})();
