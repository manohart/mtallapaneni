(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('ActiveBusinessDateDeleteController',ActiveBusinessDateDeleteController);

    ActiveBusinessDateDeleteController.$inject = ['$uibModalInstance', 'entity', 'ActiveBusinessDate'];

    function ActiveBusinessDateDeleteController($uibModalInstance, entity, ActiveBusinessDate) {
        var vm = this;

        vm.activeBusinessDate = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            ActiveBusinessDate.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
