(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('ActiveBusinessDateDialogController', ActiveBusinessDateDialogController);

    ActiveBusinessDateDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'entity', 'ActiveBusinessDate'];

    function ActiveBusinessDateDialogController ($timeout, $scope, $stateParams, $uibModalInstance, entity, ActiveBusinessDate) {
        var vm = this;

        vm.activeBusinessDate = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.activeBusinessDate.id !== null) {
                ActiveBusinessDate.update(vm.activeBusinessDate, onSaveSuccess, onSaveError);
            } else {
                ActiveBusinessDate.save(vm.activeBusinessDate, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('smartIApp:activeBusinessDateUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.calendarDate = false;
        vm.datePickerOpenStatus.businessDate = false;
        vm.datePickerOpenStatus.previousBusinessDate = false;
        vm.datePickerOpenStatus.nextBusinessDate = false;
        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
