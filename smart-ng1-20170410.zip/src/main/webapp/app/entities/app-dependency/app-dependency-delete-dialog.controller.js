(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('AppDependencyDeleteController',AppDependencyDeleteController);

    AppDependencyDeleteController.$inject = ['$uibModalInstance', 'entity', 'AppDependency'];

    function AppDependencyDeleteController($uibModalInstance, entity, AppDependency) {
        var vm = this;

        vm.appDependency = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            AppDependency.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
