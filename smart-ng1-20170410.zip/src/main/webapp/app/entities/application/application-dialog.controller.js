(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('ApplicationDialogController', ApplicationDialogController);

    ApplicationDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'DataUtils', 'entity', 'Application', 'AutoNotification', 'AppDependency', 'BatchDistribution', 'LineOfBusiness', 'ProductModule', 'Server'];

    function ApplicationDialogController ($timeout, $scope, $stateParams, $uibModalInstance, DataUtils, entity, Application, AutoNotification, AppDependency, BatchDistribution, LineOfBusiness, ProductModule, Server) {
        var vm = this;

        vm.application = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.byteSize = DataUtils.byteSize;
        vm.openFile = DataUtils.openFile;
        vm.save = save;
        vm.autonotifications = AutoNotification.query();
        vm.appdependencies = AppDependency.query();
        vm.batchdistributions = BatchDistribution.query();
        vm.lineofbusinesses = LineOfBusiness.query();
        vm.productmodules = ProductModule.query();
        vm.servers = Server.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.application.id !== null) {
                Application.update(vm.application, onSaveSuccess, onSaveError);
            } else {
                Application.save(vm.application, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('smartIApp:applicationUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }


        vm.setDescription = function ($file, application) {
            if ($file) {
                DataUtils.toBase64($file, function(base64Data) {
                    $scope.$apply(function() {
                        application.description = base64Data;
                        application.descriptionContentType = $file.type;
                    });
                });
            }
        };
        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
