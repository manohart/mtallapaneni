(function() {
    'use strict';

    angular
        .module('smartIApp')
        .factory('ArchiveLocationSearch', ArchiveLocationSearch);

    ArchiveLocationSearch.$inject = ['$resource'];

    function ArchiveLocationSearch($resource) {
        var resourceUrl =  'api/_search/archive-locations/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
