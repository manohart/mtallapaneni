(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('AutoNotificationDialogController', AutoNotificationDialogController);

    AutoNotificationDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'entity', 'AutoNotification', 'NotificationRule', 'LineOfBusiness', 'Application'];

    function AutoNotificationDialogController ($timeout, $scope, $stateParams, $uibModalInstance, entity, AutoNotification, NotificationRule, LineOfBusiness, Application) {
        var vm = this;

        vm.autoNotification = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.notificationrules = NotificationRule.query();
        vm.lineofbusinesses = LineOfBusiness.query();
        vm.applications = Application.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.autoNotification.id !== null) {
                AutoNotification.update(vm.autoNotification, onSaveSuccess, onSaveError);
            } else {
                AutoNotification.save(vm.autoNotification, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('smartIApp:autoNotificationUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
