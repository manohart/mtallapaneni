(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('BatchDistributionDeleteController',BatchDistributionDeleteController);

    BatchDistributionDeleteController.$inject = ['$uibModalInstance', 'entity', 'BatchDistribution'];

    function BatchDistributionDeleteController($uibModalInstance, entity, BatchDistribution) {
        var vm = this;

        vm.batchDistribution = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            BatchDistribution.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
