(function() {
    'use strict';

    angular
        .module('smartIApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('batch-distribution', {
            parent: 'entity',
            url: '/batch-distribution?page&sort&search',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'BatchDistributions'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/batch-distribution/batch-distributions.html',
                    controller: 'BatchDistributionController',
                    controllerAs: 'vm'
                }
            },
            params: {
                page: {
                    value: '1',
                    squash: true
                },
                sort: {
                    value: 'id,asc',
                    squash: true
                },
                search: null
            },
            resolve: {
                pagingParams: ['$stateParams', 'PaginationUtil', function ($stateParams, PaginationUtil) {
                    return {
                        page: PaginationUtil.parsePage($stateParams.page),
                        sort: $stateParams.sort,
                        predicate: PaginationUtil.parsePredicate($stateParams.sort),
                        ascending: PaginationUtil.parseAscending($stateParams.sort),
                        search: $stateParams.search
                    };
                }]
            }
        })
        .state('batch-distribution-detail', {
            parent: 'batch-distribution',
            url: '/batch-distribution/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'BatchDistribution'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/batch-distribution/batch-distribution-detail.html',
                    controller: 'BatchDistributionDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'BatchDistribution', function($stateParams, BatchDistribution) {
                    return BatchDistribution.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'batch-distribution',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('batch-distribution-detail.edit', {
            parent: 'batch-distribution-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-distribution/batch-distribution-dialog.html',
                    controller: 'BatchDistributionDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['BatchDistribution', function(BatchDistribution) {
                            return BatchDistribution.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('batch-distribution.new', {
            parent: 'batch-distribution',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-distribution/batch-distribution-dialog.html',
                    controller: 'BatchDistributionDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                active: null,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('batch-distribution', null, { reload: 'batch-distribution' });
                }, function() {
                    $state.go('batch-distribution');
                });
            }]
        })
        .state('batch-distribution.edit', {
            parent: 'batch-distribution',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-distribution/batch-distribution-dialog.html',
                    controller: 'BatchDistributionDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['BatchDistribution', function(BatchDistribution) {
                            return BatchDistribution.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('batch-distribution', null, { reload: 'batch-distribution' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('batch-distribution.delete', {
            parent: 'batch-distribution',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-distribution/batch-distribution-delete-dialog.html',
                    controller: 'BatchDistributionDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['BatchDistribution', function(BatchDistribution) {
                            return BatchDistribution.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('batch-distribution', null, { reload: 'batch-distribution' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
