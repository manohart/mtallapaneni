(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('BatchJobHistoryDetailController', BatchJobHistoryDetailController);

    BatchJobHistoryDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'BatchJobHistory', 'BatchJobIssue', 'BatchJob'];

    function BatchJobHistoryDetailController($scope, $rootScope, $stateParams, previousState, entity, BatchJobHistory, BatchJobIssue, BatchJob) {
        var vm = this;

        vm.batchJobHistory = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartIApp:batchJobHistoryUpdate', function(event, result) {
            vm.batchJobHistory = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
