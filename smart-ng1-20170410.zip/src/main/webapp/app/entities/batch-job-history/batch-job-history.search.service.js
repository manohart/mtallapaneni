(function() {
    'use strict';

    angular
        .module('smartIApp')
        .factory('BatchJobHistorySearch', BatchJobHistorySearch);

    BatchJobHistorySearch.$inject = ['$resource'];

    function BatchJobHistorySearch($resource) {
        var resourceUrl =  'api/_search/batch-job-histories/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
