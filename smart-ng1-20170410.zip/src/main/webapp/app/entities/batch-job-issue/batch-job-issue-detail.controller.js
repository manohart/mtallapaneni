(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('BatchJobIssueDetailController', BatchJobIssueDetailController);

    BatchJobIssueDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'DataUtils', 'entity', 'BatchJobIssue', 'BatchJobHistory'];

    function BatchJobIssueDetailController($scope, $rootScope, $stateParams, previousState, DataUtils, entity, BatchJobIssue, BatchJobHistory) {
        var vm = this;

        vm.batchJobIssue = entity;
        vm.previousState = previousState.name;
        vm.byteSize = DataUtils.byteSize;
        vm.openFile = DataUtils.openFile;

        var unsubscribe = $rootScope.$on('smartIApp:batchJobIssueUpdate', function(event, result) {
            vm.batchJobIssue = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
