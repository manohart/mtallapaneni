(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('BatchJobIssueDialogController', BatchJobIssueDialogController);

    BatchJobIssueDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'DataUtils', 'entity', 'BatchJobIssue', 'BatchJobHistory'];

    function BatchJobIssueDialogController ($timeout, $scope, $stateParams, $uibModalInstance, DataUtils, entity, BatchJobIssue, BatchJobHistory) {
        var vm = this;

        vm.batchJobIssue = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.byteSize = DataUtils.byteSize;
        vm.openFile = DataUtils.openFile;
        vm.save = save;
        vm.batchjobhistories = BatchJobHistory.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.batchJobIssue.id !== null) {
                BatchJobIssue.update(vm.batchJobIssue, onSaveSuccess, onSaveError);
            } else {
                BatchJobIssue.save(vm.batchJobIssue, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('smartIApp:batchJobIssueUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.businessDate = false;

        vm.setErrorMessage = function ($file, batchJobIssue) {
            if ($file) {
                DataUtils.toBase64($file, function(base64Data) {
                    $scope.$apply(function() {
                        batchJobIssue.errorMessage = base64Data;
                        batchJobIssue.errorMessageContentType = $file.type;
                    });
                });
            }
        };

        vm.setRootCause = function ($file, batchJobIssue) {
            if ($file) {
                DataUtils.toBase64($file, function(base64Data) {
                    $scope.$apply(function() {
                        batchJobIssue.rootCause = base64Data;
                        batchJobIssue.rootCauseContentType = $file.type;
                    });
                });
            }
        };

        vm.setResolution = function ($file, batchJobIssue) {
            if ($file) {
                DataUtils.toBase64($file, function(base64Data) {
                    $scope.$apply(function() {
                        batchJobIssue.resolution = base64Data;
                        batchJobIssue.resolutionContentType = $file.type;
                    });
                });
            }
        };
        vm.datePickerOpenStatus.startTime = false;
        vm.datePickerOpenStatus.endTime = false;
        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
