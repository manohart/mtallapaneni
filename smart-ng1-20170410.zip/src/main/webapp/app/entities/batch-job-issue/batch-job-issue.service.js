(function() {
    'use strict';
    angular
        .module('smartIApp')
        .factory('BatchJobIssue', BatchJobIssue);

    BatchJobIssue.$inject = ['$resource', 'DateUtils'];

    function BatchJobIssue ($resource, DateUtils) {
        var resourceUrl =  'api/batch-job-issues/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true},
            'get': {
                method: 'GET',
                transformResponse: function (data) {
                    if (data) {
                        data = angular.fromJson(data);
                        data.businessDate = DateUtils.convertLocalDateFromServer(data.businessDate);
                        data.startTime = DateUtils.convertDateTimeFromServer(data.startTime);
                        data.endTime = DateUtils.convertDateTimeFromServer(data.endTime);
                        data.updatedDate = DateUtils.convertDateTimeFromServer(data.updatedDate);
                    }
                    return data;
                }
            },
            'update': {
                method: 'PUT',
                transformRequest: function (data) {
                    var copy = angular.copy(data);
                    copy.businessDate = DateUtils.convertLocalDateToServer(copy.businessDate);
                    return angular.toJson(copy);
                }
            },
            'save': {
                method: 'POST',
                transformRequest: function (data) {
                    var copy = angular.copy(data);
                    copy.businessDate = DateUtils.convertLocalDateToServer(copy.businessDate);
                    return angular.toJson(copy);
                }
            }
        });
    }
})();
