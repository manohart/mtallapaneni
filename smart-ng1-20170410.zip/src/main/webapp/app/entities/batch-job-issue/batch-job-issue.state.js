(function() {
    'use strict';

    angular
        .module('smartIApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('batch-job-issue', {
            parent: 'entity',
            url: '/batch-job-issue?page&sort&search',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'BatchJobIssues'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/batch-job-issue/batch-job-issues.html',
                    controller: 'BatchJobIssueController',
                    controllerAs: 'vm'
                }
            },
            params: {
                page: {
                    value: '1',
                    squash: true
                },
                sort: {
                    value: 'id,asc',
                    squash: true
                },
                search: null
            },
            resolve: {
                pagingParams: ['$stateParams', 'PaginationUtil', function ($stateParams, PaginationUtil) {
                    return {
                        page: PaginationUtil.parsePage($stateParams.page),
                        sort: $stateParams.sort,
                        predicate: PaginationUtil.parsePredicate($stateParams.sort),
                        ascending: PaginationUtil.parseAscending($stateParams.sort),
                        search: $stateParams.search
                    };
                }]
            }
        })
        .state('batch-job-issue-detail', {
            parent: 'batch-job-issue',
            url: '/batch-job-issue/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'BatchJobIssue'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/batch-job-issue/batch-job-issue-detail.html',
                    controller: 'BatchJobIssueDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'BatchJobIssue', function($stateParams, BatchJobIssue) {
                    return BatchJobIssue.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'batch-job-issue',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('batch-job-issue-detail.edit', {
            parent: 'batch-job-issue-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-job-issue/batch-job-issue-dialog.html',
                    controller: 'BatchJobIssueDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['BatchJobIssue', function(BatchJobIssue) {
                            return BatchJobIssue.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('batch-job-issue.new', {
            parent: 'batch-job-issue',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-job-issue/batch-job-issue-dialog.html',
                    controller: 'BatchJobIssueDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                businessDate: null,
                                initialStatus: null,
                                finalStatus: null,
                                currentStep: null,
                                errorMessage: null,
                                errorMessageContentType: null,
                                rootCauseCode: null,
                                rootCause: null,
                                rootCauseContentType: null,
                                resolution: null,
                                resolutionContentType: null,
                                startTime: null,
                                endTime: null,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('batch-job-issue', null, { reload: 'batch-job-issue' });
                }, function() {
                    $state.go('batch-job-issue');
                });
            }]
        })
        .state('batch-job-issue.edit', {
            parent: 'batch-job-issue',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-job-issue/batch-job-issue-dialog.html',
                    controller: 'BatchJobIssueDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['BatchJobIssue', function(BatchJobIssue) {
                            return BatchJobIssue.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('batch-job-issue', null, { reload: 'batch-job-issue' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('batch-job-issue.delete', {
            parent: 'batch-job-issue',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-job-issue/batch-job-issue-delete-dialog.html',
                    controller: 'BatchJobIssueDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['BatchJobIssue', function(BatchJobIssue) {
                            return BatchJobIssue.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('batch-job-issue', null, { reload: 'batch-job-issue' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
