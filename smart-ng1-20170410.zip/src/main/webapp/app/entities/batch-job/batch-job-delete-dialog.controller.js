(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('BatchJobDeleteController',BatchJobDeleteController);

    BatchJobDeleteController.$inject = ['$uibModalInstance', 'entity', 'BatchJob'];

    function BatchJobDeleteController($uibModalInstance, entity, BatchJob) {
        var vm = this;

        vm.batchJob = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            BatchJob.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
