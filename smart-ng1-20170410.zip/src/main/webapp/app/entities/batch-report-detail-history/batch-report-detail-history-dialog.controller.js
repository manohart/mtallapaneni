(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('BatchReportDetailHistoryDialogController', BatchReportDetailHistoryDialogController);

    BatchReportDetailHistoryDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'entity', 'BatchReportDetailHistory', 'BatchReportHistory', 'DataQualityCheck'];

    function BatchReportDetailHistoryDialogController ($timeout, $scope, $stateParams, $uibModalInstance, entity, BatchReportDetailHistory, BatchReportHistory, DataQualityCheck) {
        var vm = this;

        vm.batchReportDetailHistory = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.batchreporthistories = BatchReportHistory.query();
        vm.dataqualitychecks = DataQualityCheck.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.batchReportDetailHistory.id !== null) {
                BatchReportDetailHistory.update(vm.batchReportDetailHistory, onSaveSuccess, onSaveError);
            } else {
                BatchReportDetailHistory.save(vm.batchReportDetailHistory, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('smartIApp:batchReportDetailHistoryUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
