(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('BatchReportDetailController', BatchReportDetailController);

    BatchReportDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'BatchReport', 'DataQualityCheck', 'BatchReportHistory', 'BatchJob'];

    function BatchReportDetailController($scope, $rootScope, $stateParams, previousState, entity, BatchReport, DataQualityCheck, BatchReportHistory, BatchJob) {
        var vm = this;

        vm.batchReport = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartIApp:batchReportUpdate', function(event, result) {
            vm.batchReport = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
