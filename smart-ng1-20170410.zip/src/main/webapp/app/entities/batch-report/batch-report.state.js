(function() {
    'use strict';

    angular
        .module('smartIApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('batch-report', {
            parent: 'entity',
            url: '/batch-report?page&sort&search',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'BatchReports'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/batch-report/batch-reports.html',
                    controller: 'BatchReportController',
                    controllerAs: 'vm'
                }
            },
            params: {
                page: {
                    value: '1',
                    squash: true
                },
                sort: {
                    value: 'id,asc',
                    squash: true
                },
                search: null
            },
            resolve: {
                pagingParams: ['$stateParams', 'PaginationUtil', function ($stateParams, PaginationUtil) {
                    return {
                        page: PaginationUtil.parsePage($stateParams.page),
                        sort: $stateParams.sort,
                        predicate: PaginationUtil.parsePredicate($stateParams.sort),
                        ascending: PaginationUtil.parseAscending($stateParams.sort),
                        search: $stateParams.search
                    };
                }]
            }
        })
        .state('batch-report-detail', {
            parent: 'batch-report',
            url: '/batch-report/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'BatchReport'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/batch-report/batch-report-detail.html',
                    controller: 'BatchReportDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'BatchReport', function($stateParams, BatchReport) {
                    return BatchReport.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'batch-report',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('batch-report-detail.edit', {
            parent: 'batch-report-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-report/batch-report-dialog.html',
                    controller: 'BatchReportDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['BatchReport', function(BatchReport) {
                            return BatchReport.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('batch-report.new', {
            parent: 'batch-report',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-report/batch-report-dialog.html',
                    controller: 'BatchReportDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                name: null,
                                type: null,
                                description: null,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('batch-report', null, { reload: 'batch-report' });
                }, function() {
                    $state.go('batch-report');
                });
            }]
        })
        .state('batch-report.edit', {
            parent: 'batch-report',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-report/batch-report-dialog.html',
                    controller: 'BatchReportDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['BatchReport', function(BatchReport) {
                            return BatchReport.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('batch-report', null, { reload: 'batch-report' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('batch-report.delete', {
            parent: 'batch-report',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-report/batch-report-delete-dialog.html',
                    controller: 'BatchReportDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['BatchReport', function(BatchReport) {
                            return BatchReport.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('batch-report', null, { reload: 'batch-report' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
