(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('BatchStepProcessorDialogController', BatchStepProcessorDialogController);

    BatchStepProcessorDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'DataUtils', 'entity', 'BatchStepProcessor', 'BatchJob'];

    function BatchStepProcessorDialogController ($timeout, $scope, $stateParams, $uibModalInstance, DataUtils, entity, BatchStepProcessor, BatchJob) {
        var vm = this;

        vm.batchStepProcessor = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.byteSize = DataUtils.byteSize;
        vm.openFile = DataUtils.openFile;
        vm.save = save;
        vm.batchjobs = BatchJob.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.batchStepProcessor.id !== null) {
                BatchStepProcessor.update(vm.batchStepProcessor, onSaveSuccess, onSaveError);
            } else {
                BatchStepProcessor.save(vm.batchStepProcessor, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('smartIApp:batchStepProcessorUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }


        vm.setDescription = function ($file, batchStepProcessor) {
            if ($file) {
                DataUtils.toBase64($file, function(base64Data) {
                    $scope.$apply(function() {
                        batchStepProcessor.description = base64Data;
                        batchStepProcessor.descriptionContentType = $file.type;
                    });
                });
            }
        };

        vm.setTroubleshooting = function ($file, batchStepProcessor) {
            if ($file) {
                DataUtils.toBase64($file, function(base64Data) {
                    $scope.$apply(function() {
                        batchStepProcessor.troubleshooting = base64Data;
                        batchStepProcessor.troubleshootingContentType = $file.type;
                    });
                });
            }
        };
        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
