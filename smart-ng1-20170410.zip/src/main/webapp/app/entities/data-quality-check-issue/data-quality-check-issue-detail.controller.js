(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('DataQualityCheckIssueDetailController', DataQualityCheckIssueDetailController);

    DataQualityCheckIssueDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'DataUtils', 'entity', 'DataQualityCheckIssue', 'BatchReportHistory'];

    function DataQualityCheckIssueDetailController($scope, $rootScope, $stateParams, previousState, DataUtils, entity, DataQualityCheckIssue, BatchReportHistory) {
        var vm = this;

        vm.dataQualityCheckIssue = entity;
        vm.previousState = previousState.name;
        vm.byteSize = DataUtils.byteSize;
        vm.openFile = DataUtils.openFile;

        var unsubscribe = $rootScope.$on('smartIApp:dataQualityCheckIssueUpdate', function(event, result) {
            vm.dataQualityCheckIssue = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
