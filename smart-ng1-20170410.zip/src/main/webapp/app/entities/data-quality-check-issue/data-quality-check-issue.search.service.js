(function() {
    'use strict';

    angular
        .module('smartIApp')
        .factory('DataQualityCheckIssueSearch', DataQualityCheckIssueSearch);

    DataQualityCheckIssueSearch.$inject = ['$resource'];

    function DataQualityCheckIssueSearch($resource) {
        var resourceUrl =  'api/_search/data-quality-check-issues/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
