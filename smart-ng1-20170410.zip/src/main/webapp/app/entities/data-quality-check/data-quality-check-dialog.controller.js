(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('DataQualityCheckDialogController', DataQualityCheckDialogController);

    DataQualityCheckDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'DataUtils', 'entity', 'DataQualityCheck', 'BatchReportDetailHistory', 'WebService', 'BatchReport'];

    function DataQualityCheckDialogController ($timeout, $scope, $stateParams, $uibModalInstance, DataUtils, entity, DataQualityCheck, BatchReportDetailHistory, WebService, BatchReport) {
        var vm = this;

        vm.dataQualityCheck = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.byteSize = DataUtils.byteSize;
        vm.openFile = DataUtils.openFile;
        vm.save = save;
        vm.batchreportdetailhistories = BatchReportDetailHistory.query();
        vm.webservices = WebService.query();
        vm.batchreports = BatchReport.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.dataQualityCheck.id !== null) {
                DataQualityCheck.update(vm.dataQualityCheck, onSaveSuccess, onSaveError);
            } else {
                DataQualityCheck.save(vm.dataQualityCheck, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('smartIApp:dataQualityCheckUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }


        vm.setSqlQuery = function ($file, dataQualityCheck) {
            if ($file) {
                DataUtils.toBase64($file, function(base64Data) {
                    $scope.$apply(function() {
                        dataQualityCheck.sqlQuery = base64Data;
                        dataQualityCheck.sqlQueryContentType = $file.type;
                    });
                });
            }
        };
        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
