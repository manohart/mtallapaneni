(function() {
    'use strict';

    angular
        .module('smartIApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('data-quality-check', {
            parent: 'entity',
            url: '/data-quality-check?page&sort&search',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'DataQualityChecks'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/data-quality-check/data-quality-checks.html',
                    controller: 'DataQualityCheckController',
                    controllerAs: 'vm'
                }
            },
            params: {
                page: {
                    value: '1',
                    squash: true
                },
                sort: {
                    value: 'id,asc',
                    squash: true
                },
                search: null
            },
            resolve: {
                pagingParams: ['$stateParams', 'PaginationUtil', function ($stateParams, PaginationUtil) {
                    return {
                        page: PaginationUtil.parsePage($stateParams.page),
                        sort: $stateParams.sort,
                        predicate: PaginationUtil.parsePredicate($stateParams.sort),
                        ascending: PaginationUtil.parseAscending($stateParams.sort),
                        search: $stateParams.search
                    };
                }]
            }
        })
        .state('data-quality-check-detail', {
            parent: 'data-quality-check',
            url: '/data-quality-check/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'DataQualityCheck'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/data-quality-check/data-quality-check-detail.html',
                    controller: 'DataQualityCheckDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'DataQualityCheck', function($stateParams, DataQualityCheck) {
                    return DataQualityCheck.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'data-quality-check',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('data-quality-check-detail.edit', {
            parent: 'data-quality-check-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/data-quality-check/data-quality-check-dialog.html',
                    controller: 'DataQualityCheckDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['DataQualityCheck', function(DataQualityCheck) {
                            return DataQualityCheck.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('data-quality-check.new', {
            parent: 'data-quality-check',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/data-quality-check/data-quality-check-dialog.html',
                    controller: 'DataQualityCheckDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                name: null,
                                description: null,
                                sqlQuery: null,
                                sqlQueryContentType: null,
                                resultColumns: null,
                                groupColumns: null,
                                expectation: null,
                                reportIssuesOnly: null,
                                sequence: null,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('data-quality-check', null, { reload: 'data-quality-check' });
                }, function() {
                    $state.go('data-quality-check');
                });
            }]
        })
        .state('data-quality-check.edit', {
            parent: 'data-quality-check',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/data-quality-check/data-quality-check-dialog.html',
                    controller: 'DataQualityCheckDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['DataQualityCheck', function(DataQualityCheck) {
                            return DataQualityCheck.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('data-quality-check', null, { reload: 'data-quality-check' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('data-quality-check.delete', {
            parent: 'data-quality-check',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/data-quality-check/data-quality-check-delete-dialog.html',
                    controller: 'DataQualityCheckDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['DataQualityCheck', function(DataQualityCheck) {
                            return DataQualityCheck.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('data-quality-check', null, { reload: 'data-quality-check' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
