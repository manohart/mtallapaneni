(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('LineOfBusinessDetailController', LineOfBusinessDetailController);

    LineOfBusinessDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'LineOfBusiness', 'Application', 'ArchiveLocation', 'AutoNotification', 'Product', 'Template', 'Team'];

    function LineOfBusinessDetailController($scope, $rootScope, $stateParams, previousState, entity, LineOfBusiness, Application, ArchiveLocation, AutoNotification, Product, Template, Team) {
        var vm = this;

        vm.lineOfBusiness = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartIApp:lineOfBusinessUpdate', function(event, result) {
            vm.lineOfBusiness = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
