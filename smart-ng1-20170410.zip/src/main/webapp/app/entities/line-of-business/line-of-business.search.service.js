(function() {
    'use strict';

    angular
        .module('smartIApp')
        .factory('LineOfBusinessSearch', LineOfBusinessSearch);

    LineOfBusinessSearch.$inject = ['$resource'];

    function LineOfBusinessSearch($resource) {
        var resourceUrl =  'api/_search/line-of-businesses/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
