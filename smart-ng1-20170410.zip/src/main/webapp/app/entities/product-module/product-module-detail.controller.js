(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('ProductModuleDetailController', ProductModuleDetailController);

    ProductModuleDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'DataUtils', 'entity', 'ProductModule', 'Application', 'Product'];

    function ProductModuleDetailController($scope, $rootScope, $stateParams, previousState, DataUtils, entity, ProductModule, Application, Product) {
        var vm = this;

        vm.productModule = entity;
        vm.previousState = previousState.name;
        vm.byteSize = DataUtils.byteSize;
        vm.openFile = DataUtils.openFile;

        var unsubscribe = $rootScope.$on('smartIApp:productModuleUpdate', function(event, result) {
            vm.productModule = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
