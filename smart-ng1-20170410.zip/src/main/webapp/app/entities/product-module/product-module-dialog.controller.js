(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('ProductModuleDialogController', ProductModuleDialogController);

    ProductModuleDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'DataUtils', 'entity', 'ProductModule', 'Application', 'Product'];

    function ProductModuleDialogController ($timeout, $scope, $stateParams, $uibModalInstance, DataUtils, entity, ProductModule, Application, Product) {
        var vm = this;

        vm.productModule = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.byteSize = DataUtils.byteSize;
        vm.openFile = DataUtils.openFile;
        vm.save = save;
        vm.applications = Application.query();
        vm.products = Product.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.productModule.id !== null) {
                ProductModule.update(vm.productModule, onSaveSuccess, onSaveError);
            } else {
                ProductModule.save(vm.productModule, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('smartIApp:productModuleUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }


        vm.setDescription = function ($file, productModule) {
            if ($file) {
                DataUtils.toBase64($file, function(base64Data) {
                    $scope.$apply(function() {
                        productModule.description = base64Data;
                        productModule.descriptionContentType = $file.type;
                    });
                });
            }
        };
        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
