(function() {
    'use strict';

    angular
        .module('smartIApp')
        .factory('ServerSearch', ServerSearch);

    ServerSearch.$inject = ['$resource'];

    function ServerSearch($resource) {
        var resourceUrl =  'api/_search/servers/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
