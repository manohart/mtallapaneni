(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('SmokeTestMainDeleteController',SmokeTestMainDeleteController);

    SmokeTestMainDeleteController.$inject = ['$uibModalInstance', 'entity', 'SmokeTestMain'];

    function SmokeTestMainDeleteController($uibModalInstance, entity, SmokeTestMain) {
        var vm = this;

        vm.smokeTestMain = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            SmokeTestMain.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
