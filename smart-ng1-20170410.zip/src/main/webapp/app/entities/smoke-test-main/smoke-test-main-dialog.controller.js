(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('SmokeTestMainDialogController', SmokeTestMainDialogController);

    SmokeTestMainDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'entity', 'SmokeTestMain', 'SmokeTestSetup', 'SmokeTestResult'];

    function SmokeTestMainDialogController ($timeout, $scope, $stateParams, $uibModalInstance, entity, SmokeTestMain, SmokeTestSetup, SmokeTestResult) {
        var vm = this;

        vm.smokeTestMain = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.smoketestsetups = SmokeTestSetup.query();
        vm.smoketestresults = SmokeTestResult.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.smokeTestMain.id !== null) {
                SmokeTestMain.update(vm.smokeTestMain, onSaveSuccess, onSaveError);
            } else {
                SmokeTestMain.save(vm.smokeTestMain, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('smartIApp:smokeTestMainUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.date = false;
        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
