(function() {
    'use strict';

    angular
        .module('smartIApp')
        .factory('SmokeTestMainSearch', SmokeTestMainSearch);

    SmokeTestMainSearch.$inject = ['$resource'];

    function SmokeTestMainSearch($resource) {
        var resourceUrl =  'api/_search/smoke-test-mains/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
