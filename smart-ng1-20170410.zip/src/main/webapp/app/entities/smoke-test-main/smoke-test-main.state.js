(function() {
    'use strict';

    angular
        .module('smartIApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('smoke-test-main', {
            parent: 'entity',
            url: '/smoke-test-main?page&sort&search',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'SmokeTestMains'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/smoke-test-main/smoke-test-mains.html',
                    controller: 'SmokeTestMainController',
                    controllerAs: 'vm'
                }
            },
            params: {
                page: {
                    value: '1',
                    squash: true
                },
                sort: {
                    value: 'id,asc',
                    squash: true
                },
                search: null
            },
            resolve: {
                pagingParams: ['$stateParams', 'PaginationUtil', function ($stateParams, PaginationUtil) {
                    return {
                        page: PaginationUtil.parsePage($stateParams.page),
                        sort: $stateParams.sort,
                        predicate: PaginationUtil.parsePredicate($stateParams.sort),
                        ascending: PaginationUtil.parseAscending($stateParams.sort),
                        search: $stateParams.search
                    };
                }]
            }
        })
        .state('smoke-test-main-detail', {
            parent: 'smoke-test-main',
            url: '/smoke-test-main/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'SmokeTestMain'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/smoke-test-main/smoke-test-main-detail.html',
                    controller: 'SmokeTestMainDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'SmokeTestMain', function($stateParams, SmokeTestMain) {
                    return SmokeTestMain.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'smoke-test-main',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('smoke-test-main-detail.edit', {
            parent: 'smoke-test-main-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/smoke-test-main/smoke-test-main-dialog.html',
                    controller: 'SmokeTestMainDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['SmokeTestMain', function(SmokeTestMain) {
                            return SmokeTestMain.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('smoke-test-main.new', {
            parent: 'smoke-test-main',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/smoke-test-main/smoke-test-main-dialog.html',
                    controller: 'SmokeTestMainDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                date: null,
                                status: null,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('smoke-test-main', null, { reload: 'smoke-test-main' });
                }, function() {
                    $state.go('smoke-test-main');
                });
            }]
        })
        .state('smoke-test-main.edit', {
            parent: 'smoke-test-main',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/smoke-test-main/smoke-test-main-dialog.html',
                    controller: 'SmokeTestMainDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['SmokeTestMain', function(SmokeTestMain) {
                            return SmokeTestMain.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('smoke-test-main', null, { reload: 'smoke-test-main' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('smoke-test-main.delete', {
            parent: 'smoke-test-main',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/smoke-test-main/smoke-test-main-delete-dialog.html',
                    controller: 'SmokeTestMainDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['SmokeTestMain', function(SmokeTestMain) {
                            return SmokeTestMain.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('smoke-test-main', null, { reload: 'smoke-test-main' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
