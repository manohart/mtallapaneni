(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('SmokeTestResultDeleteController',SmokeTestResultDeleteController);

    SmokeTestResultDeleteController.$inject = ['$uibModalInstance', 'entity', 'SmokeTestResult'];

    function SmokeTestResultDeleteController($uibModalInstance, entity, SmokeTestResult) {
        var vm = this;

        vm.smokeTestResult = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            SmokeTestResult.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
