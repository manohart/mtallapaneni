(function() {
    'use strict';
    angular
        .module('smartIApp')
        .factory('SmokeTestResult', SmokeTestResult);

    SmokeTestResult.$inject = ['$resource', 'DateUtils'];

    function SmokeTestResult ($resource, DateUtils) {
        var resourceUrl =  'api/smoke-test-results/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true},
            'get': {
                method: 'GET',
                transformResponse: function (data) {
                    if (data) {
                        data = angular.fromJson(data);
                        data.startDate = DateUtils.convertDateTimeFromServer(data.startDate);
                        data.endDate = DateUtils.convertDateTimeFromServer(data.endDate);
                        data.updatedDate = DateUtils.convertDateTimeFromServer(data.updatedDate);
                    }
                    return data;
                }
            },
            'update': { method:'PUT' }
        });
    }
})();
