(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('SmokeTestSetupDetailController', SmokeTestSetupDetailController);

    SmokeTestSetupDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'DataUtils', 'entity', 'SmokeTestSetup', 'SmokeTestMain'];

    function SmokeTestSetupDetailController($scope, $rootScope, $stateParams, previousState, DataUtils, entity, SmokeTestSetup, SmokeTestMain) {
        var vm = this;

        vm.smokeTestSetup = entity;
        vm.previousState = previousState.name;
        vm.byteSize = DataUtils.byteSize;
        vm.openFile = DataUtils.openFile;

        var unsubscribe = $rootScope.$on('smartIApp:smokeTestSetupUpdate', function(event, result) {
            vm.smokeTestSetup = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
