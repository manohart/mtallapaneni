(function() {
    'use strict';
    angular
        .module('smartIApp')
        .factory('SmokeTestSetup', SmokeTestSetup);

    SmokeTestSetup.$inject = ['$resource', 'DateUtils'];

    function SmokeTestSetup ($resource, DateUtils) {
        var resourceUrl =  'api/smoke-test-setups/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true},
            'get': {
                method: 'GET',
                transformResponse: function (data) {
                    if (data) {
                        data = angular.fromJson(data);
                        data.updatedDate = DateUtils.convertDateTimeFromServer(data.updatedDate);
                    }
                    return data;
                }
            },
            'update': { method:'PUT' }
        });
    }
})();
