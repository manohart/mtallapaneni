(function() {
    'use strict';

    angular
        .module('smartIApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('smoke-test-setup', {
            parent: 'entity',
            url: '/smoke-test-setup?page&sort&search',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'SmokeTestSetups'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/smoke-test-setup/smoke-test-setups.html',
                    controller: 'SmokeTestSetupController',
                    controllerAs: 'vm'
                }
            },
            params: {
                page: {
                    value: '1',
                    squash: true
                },
                sort: {
                    value: 'id,asc',
                    squash: true
                },
                search: null
            },
            resolve: {
                pagingParams: ['$stateParams', 'PaginationUtil', function ($stateParams, PaginationUtil) {
                    return {
                        page: PaginationUtil.parsePage($stateParams.page),
                        sort: $stateParams.sort,
                        predicate: PaginationUtil.parsePredicate($stateParams.sort),
                        ascending: PaginationUtil.parseAscending($stateParams.sort),
                        search: $stateParams.search
                    };
                }]
            }
        })
        .state('smoke-test-setup-detail', {
            parent: 'smoke-test-setup',
            url: '/smoke-test-setup/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'SmokeTestSetup'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/smoke-test-setup/smoke-test-setup-detail.html',
                    controller: 'SmokeTestSetupDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'SmokeTestSetup', function($stateParams, SmokeTestSetup) {
                    return SmokeTestSetup.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'smoke-test-setup',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('smoke-test-setup-detail.edit', {
            parent: 'smoke-test-setup-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/smoke-test-setup/smoke-test-setup-dialog.html',
                    controller: 'SmokeTestSetupDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['SmokeTestSetup', function(SmokeTestSetup) {
                            return SmokeTestSetup.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('smoke-test-setup.new', {
            parent: 'smoke-test-setup',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/smoke-test-setup/smoke-test-setup-dialog.html',
                    controller: 'SmokeTestSetupDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                lob: null,
                                app: null,
                                description: null,
                                descriptionContentType: null,
                                owner: null,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('smoke-test-setup', null, { reload: 'smoke-test-setup' });
                }, function() {
                    $state.go('smoke-test-setup');
                });
            }]
        })
        .state('smoke-test-setup.edit', {
            parent: 'smoke-test-setup',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/smoke-test-setup/smoke-test-setup-dialog.html',
                    controller: 'SmokeTestSetupDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['SmokeTestSetup', function(SmokeTestSetup) {
                            return SmokeTestSetup.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('smoke-test-setup', null, { reload: 'smoke-test-setup' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('smoke-test-setup.delete', {
            parent: 'smoke-test-setup',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/smoke-test-setup/smoke-test-setup-delete-dialog.html',
                    controller: 'SmokeTestSetupDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['SmokeTestSetup', function(SmokeTestSetup) {
                            return SmokeTestSetup.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('smoke-test-setup', null, { reload: 'smoke-test-setup' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
