(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('SoftwareReleaseDeleteController',SoftwareReleaseDeleteController);

    SoftwareReleaseDeleteController.$inject = ['$uibModalInstance', 'entity', 'SoftwareRelease'];

    function SoftwareReleaseDeleteController($uibModalInstance, entity, SoftwareRelease) {
        var vm = this;

        vm.softwareRelease = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            SoftwareRelease.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
