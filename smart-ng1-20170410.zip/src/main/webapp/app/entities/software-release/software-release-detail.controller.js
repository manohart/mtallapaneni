(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('SoftwareReleaseDetailController', SoftwareReleaseDetailController);

    SoftwareReleaseDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'DataUtils', 'entity', 'SoftwareRelease', 'Product'];

    function SoftwareReleaseDetailController($scope, $rootScope, $stateParams, previousState, DataUtils, entity, SoftwareRelease, Product) {
        var vm = this;

        vm.softwareRelease = entity;
        vm.previousState = previousState.name;
        vm.byteSize = DataUtils.byteSize;
        vm.openFile = DataUtils.openFile;

        var unsubscribe = $rootScope.$on('smartIApp:softwareReleaseUpdate', function(event, result) {
            vm.softwareRelease = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
