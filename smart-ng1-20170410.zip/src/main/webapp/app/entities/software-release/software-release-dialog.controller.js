(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('SoftwareReleaseDialogController', SoftwareReleaseDialogController);

    SoftwareReleaseDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'DataUtils', 'entity', 'SoftwareRelease', 'Product'];

    function SoftwareReleaseDialogController ($timeout, $scope, $stateParams, $uibModalInstance, DataUtils, entity, SoftwareRelease, Product) {
        var vm = this;

        vm.softwareRelease = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.byteSize = DataUtils.byteSize;
        vm.openFile = DataUtils.openFile;
        vm.save = save;
        vm.products = Product.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.softwareRelease.id !== null) {
                SoftwareRelease.update(vm.softwareRelease, onSaveSuccess, onSaveError);
            } else {
                SoftwareRelease.save(vm.softwareRelease, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('smartIApp:softwareReleaseUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.releaseDate = false;

        vm.setNewFeatures = function ($file, softwareRelease) {
            if ($file) {
                DataUtils.toBase64($file, function(base64Data) {
                    $scope.$apply(function() {
                        softwareRelease.newFeatures = base64Data;
                        softwareRelease.newFeaturesContentType = $file.type;
                    });
                });
            }
        };

        vm.setEnhancements = function ($file, softwareRelease) {
            if ($file) {
                DataUtils.toBase64($file, function(base64Data) {
                    $scope.$apply(function() {
                        softwareRelease.enhancements = base64Data;
                        softwareRelease.enhancementsContentType = $file.type;
                    });
                });
            }
        };

        vm.setBugFixes = function ($file, softwareRelease) {
            if ($file) {
                DataUtils.toBase64($file, function(base64Data) {
                    $scope.$apply(function() {
                        softwareRelease.bugFixes = base64Data;
                        softwareRelease.bugFixesContentType = $file.type;
                    });
                });
            }
        };

        vm.setKnownIssues = function ($file, softwareRelease) {
            if ($file) {
                DataUtils.toBase64($file, function(base64Data) {
                    $scope.$apply(function() {
                        softwareRelease.knownIssues = base64Data;
                        softwareRelease.knownIssuesContentType = $file.type;
                    });
                });
            }
        };
        vm.datePickerOpenStatus.plannedReleaseDate = false;

        vm.setSummary = function ($file, softwareRelease) {
            if ($file) {
                DataUtils.toBase64($file, function(base64Data) {
                    $scope.$apply(function() {
                        softwareRelease.summary = base64Data;
                        softwareRelease.summaryContentType = $file.type;
                    });
                });
            }
        };
        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
