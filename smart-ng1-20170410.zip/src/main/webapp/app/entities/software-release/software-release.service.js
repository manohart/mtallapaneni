(function() {
    'use strict';
    angular
        .module('smartIApp')
        .factory('SoftwareRelease', SoftwareRelease);

    SoftwareRelease.$inject = ['$resource', 'DateUtils'];

    function SoftwareRelease ($resource, DateUtils) {
        var resourceUrl =  'api/software-releases/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true},
            'get': {
                method: 'GET',
                transformResponse: function (data) {
                    if (data) {
                        data = angular.fromJson(data);
                        data.releaseDate = DateUtils.convertLocalDateFromServer(data.releaseDate);
                        data.plannedReleaseDate = DateUtils.convertLocalDateFromServer(data.plannedReleaseDate);
                        data.updatedDate = DateUtils.convertDateTimeFromServer(data.updatedDate);
                    }
                    return data;
                }
            },
            'update': {
                method: 'PUT',
                transformRequest: function (data) {
                    var copy = angular.copy(data);
                    copy.releaseDate = DateUtils.convertLocalDateToServer(copy.releaseDate);
                    copy.plannedReleaseDate = DateUtils.convertLocalDateToServer(copy.plannedReleaseDate);
                    return angular.toJson(copy);
                }
            },
            'save': {
                method: 'POST',
                transformRequest: function (data) {
                    var copy = angular.copy(data);
                    copy.releaseDate = DateUtils.convertLocalDateToServer(copy.releaseDate);
                    copy.plannedReleaseDate = DateUtils.convertLocalDateToServer(copy.plannedReleaseDate);
                    return angular.toJson(copy);
                }
            }
        });
    }
})();
