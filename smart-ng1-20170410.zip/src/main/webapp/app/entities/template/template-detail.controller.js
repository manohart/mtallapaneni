(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('TemplateDetailController', TemplateDetailController);

    TemplateDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'Template', 'LineOfBusiness'];

    function TemplateDetailController($scope, $rootScope, $stateParams, previousState, entity, Template, LineOfBusiness) {
        var vm = this;

        vm.template = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartIApp:templateUpdate', function(event, result) {
            vm.template = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
