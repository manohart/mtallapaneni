(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('WebApplicationDetailController', WebApplicationDetailController);

    WebApplicationDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'WebApplication', 'Application', 'WebService'];

    function WebApplicationDetailController($scope, $rootScope, $stateParams, previousState, entity, WebApplication, Application, WebService) {
        var vm = this;

        vm.webApplication = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartIApp:webApplicationUpdate', function(event, result) {
            vm.webApplication = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
