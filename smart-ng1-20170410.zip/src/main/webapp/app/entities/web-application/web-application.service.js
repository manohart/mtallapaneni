(function() {
    'use strict';
    angular
        .module('smartIApp')
        .factory('WebApplication', WebApplication);

    WebApplication.$inject = ['$resource', 'DateUtils'];

    function WebApplication ($resource, DateUtils) {
        var resourceUrl =  'api/web-applications/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true},
            'get': {
                method: 'GET',
                transformResponse: function (data) {
                    if (data) {
                        data = angular.fromJson(data);
                        data.updatedDate = DateUtils.convertDateTimeFromServer(data.updatedDate);
                    }
                    return data;
                }
            },
            'update': { method:'PUT' }
        });
    }
})();
