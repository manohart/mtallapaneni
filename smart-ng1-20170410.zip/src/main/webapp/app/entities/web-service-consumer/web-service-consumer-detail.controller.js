(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('WebServiceConsumerDetailController', WebServiceConsumerDetailController);

    WebServiceConsumerDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'WebServiceConsumer', 'Application', 'WebService'];

    function WebServiceConsumerDetailController($scope, $rootScope, $stateParams, previousState, entity, WebServiceConsumer, Application, WebService) {
        var vm = this;

        vm.webServiceConsumer = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('smartIApp:webServiceConsumerUpdate', function(event, result) {
            vm.webServiceConsumer = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
