(function() {
    'use strict';

    angular
        .module('smartIApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('web-service-consumer', {
            parent: 'entity',
            url: '/web-service-consumer?page&sort&search',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'WebServiceConsumers'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/web-service-consumer/web-service-consumers.html',
                    controller: 'WebServiceConsumerController',
                    controllerAs: 'vm'
                }
            },
            params: {
                page: {
                    value: '1',
                    squash: true
                },
                sort: {
                    value: 'id,asc',
                    squash: true
                },
                search: null
            },
            resolve: {
                pagingParams: ['$stateParams', 'PaginationUtil', function ($stateParams, PaginationUtil) {
                    return {
                        page: PaginationUtil.parsePage($stateParams.page),
                        sort: $stateParams.sort,
                        predicate: PaginationUtil.parsePredicate($stateParams.sort),
                        ascending: PaginationUtil.parseAscending($stateParams.sort),
                        search: $stateParams.search
                    };
                }]
            }
        })
        .state('web-service-consumer-detail', {
            parent: 'web-service-consumer',
            url: '/web-service-consumer/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'WebServiceConsumer'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/web-service-consumer/web-service-consumer-detail.html',
                    controller: 'WebServiceConsumerDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'WebServiceConsumer', function($stateParams, WebServiceConsumer) {
                    return WebServiceConsumer.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'web-service-consumer',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('web-service-consumer-detail.edit', {
            parent: 'web-service-consumer-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/web-service-consumer/web-service-consumer-dialog.html',
                    controller: 'WebServiceConsumerDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['WebServiceConsumer', function(WebServiceConsumer) {
                            return WebServiceConsumer.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('web-service-consumer.new', {
            parent: 'web-service-consumer',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/web-service-consumer/web-service-consumer-dialog.html',
                    controller: 'WebServiceConsumerDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('web-service-consumer', null, { reload: 'web-service-consumer' });
                }, function() {
                    $state.go('web-service-consumer');
                });
            }]
        })
        .state('web-service-consumer.edit', {
            parent: 'web-service-consumer',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/web-service-consumer/web-service-consumer-dialog.html',
                    controller: 'WebServiceConsumerDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['WebServiceConsumer', function(WebServiceConsumer) {
                            return WebServiceConsumer.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('web-service-consumer', null, { reload: 'web-service-consumer' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('web-service-consumer.delete', {
            parent: 'web-service-consumer',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/web-service-consumer/web-service-consumer-delete-dialog.html',
                    controller: 'WebServiceConsumerDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['WebServiceConsumer', function(WebServiceConsumer) {
                            return WebServiceConsumer.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('web-service-consumer', null, { reload: 'web-service-consumer' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
