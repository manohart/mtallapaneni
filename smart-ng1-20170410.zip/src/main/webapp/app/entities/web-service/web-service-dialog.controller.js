(function() {
    'use strict';

    angular
        .module('smartIApp')
        .controller('WebServiceDialogController', WebServiceDialogController);

    WebServiceDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'DataUtils', 'entity', 'WebService', 'WebServiceConsumer', 'WebApplication'];

    function WebServiceDialogController ($timeout, $scope, $stateParams, $uibModalInstance, DataUtils, entity, WebService, WebServiceConsumer, WebApplication) {
        var vm = this;

        vm.webService = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.byteSize = DataUtils.byteSize;
        vm.openFile = DataUtils.openFile;
        vm.save = save;
        vm.webserviceconsumers = WebServiceConsumer.query();
        vm.webapplications = WebApplication.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.webService.id !== null) {
                WebService.update(vm.webService, onSaveSuccess, onSaveError);
            } else {
                WebService.save(vm.webService, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('smartIApp:webServiceUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }


        vm.setDescription = function ($file, webService) {
            if ($file) {
                DataUtils.toBase64($file, function(base64Data) {
                    $scope.$apply(function() {
                        webService.description = base64Data;
                        webService.descriptionContentType = $file.type;
                    });
                });
            }
        };
        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
