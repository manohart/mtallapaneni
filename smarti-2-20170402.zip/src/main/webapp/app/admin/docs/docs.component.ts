import { Component } from '@angular/core';

@Component({
    selector: 'smarti-docs',
    templateUrl: './docs.component.html'
})
export class SmartiDocsComponent {
    constructor (
        ) {
        }
}
