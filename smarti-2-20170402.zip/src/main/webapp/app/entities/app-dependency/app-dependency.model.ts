import { Application } from '../application';
export class AppDependency {
    constructor(
        public id?: number,
        public startDate?: any,
        public endDate?: any,
        public updatedDate?: any,
        public application?: Application,
        public dependOn?: Application,
    ) {
    }
}
