import { BatchJob } from '../batch-job';
export class BatchConfig {
    constructor(
        public id?: number,
        public name?: string,
        public value?: string,
        public updatedDate?: any,
        public batchJob?: BatchJob,
    ) {
    }
}
