import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager } from 'ng-jhipster';

import { BatchDistribution } from './batch-distribution.model';
import { BatchDistributionPopupService } from './batch-distribution-popup.service';
import { BatchDistributionService } from './batch-distribution.service';

@Component({
    selector: 'smarti-batch-distribution-delete-dialog',
    templateUrl: './batch-distribution-delete-dialog.component.html'
})
export class BatchDistributionDeleteDialogComponent {

    batchDistribution: BatchDistribution;

    constructor(
        private batchDistributionService: BatchDistributionService,
        public activeModal: NgbActiveModal,
        private eventManager: EventManager
    ) {
    }

    clear () {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete (id: number) {
        this.batchDistributionService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'batchDistributionListModification',
                content: 'Deleted an batchDistribution'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'smarti-batch-distribution-delete-popup',
    template: ''
})
export class BatchDistributionDeletePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private batchDistributionPopupService: BatchDistributionPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            this.modalRef = this.batchDistributionPopupService
                .open(BatchDistributionDeleteDialogComponent, params['id']);
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
