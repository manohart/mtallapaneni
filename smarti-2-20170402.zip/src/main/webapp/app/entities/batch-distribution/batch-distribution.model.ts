import { Distribution } from '../distribution';
import { Application } from '../application';
export class BatchDistribution {
    constructor(
        public id?: number,
        public isActive?: boolean,
        public updatedDate?: any,
        public distribution?: Distribution,
        public application?: Application,
    ) {
        this.isActive = false;
    }
}
