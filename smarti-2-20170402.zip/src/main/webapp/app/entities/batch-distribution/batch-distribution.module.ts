import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SmartISharedModule } from '../../shared';

import {
    BatchDistributionService,
    BatchDistributionPopupService,
    BatchDistributionComponent,
    BatchDistributionDetailComponent,
    BatchDistributionDialogComponent,
    BatchDistributionPopupComponent,
    BatchDistributionDeletePopupComponent,
    BatchDistributionDeleteDialogComponent,
    batchDistributionRoute,
    batchDistributionPopupRoute,
    BatchDistributionResolvePagingParams,
} from './';

let ENTITY_STATES = [
    ...batchDistributionRoute,
    ...batchDistributionPopupRoute,
];

@NgModule({
    imports: [
        SmartISharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [
        BatchDistributionComponent,
        BatchDistributionDetailComponent,
        BatchDistributionDialogComponent,
        BatchDistributionDeleteDialogComponent,
        BatchDistributionPopupComponent,
        BatchDistributionDeletePopupComponent,
    ],
    entryComponents: [
        BatchDistributionComponent,
        BatchDistributionDialogComponent,
        BatchDistributionPopupComponent,
        BatchDistributionDeleteDialogComponent,
        BatchDistributionDeletePopupComponent,
    ],
    providers: [
        BatchDistributionService,
        BatchDistributionPopupService,
        BatchDistributionResolvePagingParams,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartIBatchDistributionModule {}
