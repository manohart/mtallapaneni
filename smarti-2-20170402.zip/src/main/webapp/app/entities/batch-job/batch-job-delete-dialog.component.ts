import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager } from 'ng-jhipster';

import { BatchJob } from './batch-job.model';
import { BatchJobPopupService } from './batch-job-popup.service';
import { BatchJobService } from './batch-job.service';

@Component({
    selector: 'smarti-batch-job-delete-dialog',
    templateUrl: './batch-job-delete-dialog.component.html'
})
export class BatchJobDeleteDialogComponent {

    batchJob: BatchJob;

    constructor(
        private batchJobService: BatchJobService,
        public activeModal: NgbActiveModal,
        private eventManager: EventManager
    ) {
    }

    clear () {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete (id: number) {
        this.batchJobService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'batchJobListModification',
                content: 'Deleted an batchJob'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'smarti-batch-job-delete-popup',
    template: ''
})
export class BatchJobDeletePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private batchJobPopupService: BatchJobPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            this.modalRef = this.batchJobPopupService
                .open(BatchJobDeleteDialogComponent, params['id']);
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
