import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager, AlertService } from 'ng-jhipster';

import { BatchJob } from './batch-job.model';
import { BatchJobPopupService } from './batch-job-popup.service';
import { BatchJobService } from './batch-job.service';
import { Application, ApplicationService } from '../application';
import { BatchJobHistory, BatchJobHistoryService } from '../batch-job-history';
import { BatchReport, BatchReportService } from '../batch-report';
import { BatchConfig, BatchConfigService } from '../batch-config';
import { BatchStepProcessor, BatchStepProcessorService } from '../batch-step-processor';

@Component({
    selector: 'smarti-batch-job-dialog',
    templateUrl: './batch-job-dialog.component.html'
})
export class BatchJobDialogComponent implements OnInit {

    batchJob: BatchJob;
    authorities: any[];
    isSaving: boolean;

    applications: Application[];

    batchjobhistories: BatchJobHistory[];

    batchreports: BatchReport[];

    batchconfigs: BatchConfig[];

    batchstepprocessors: BatchStepProcessor[];
    constructor(
        public activeModal: NgbActiveModal,
        private alertService: AlertService,
        private batchJobService: BatchJobService,
        private applicationService: ApplicationService,
        private batchJobHistoryService: BatchJobHistoryService,
        private batchReportService: BatchReportService,
        private batchConfigService: BatchConfigService,
        private batchStepProcessorService: BatchStepProcessorService,
        private eventManager: EventManager
    ) {
    }

    ngOnInit() {
        this.isSaving = false;
        this.authorities = ['ROLE_USER', 'ROLE_ADMIN'];
        this.applicationService.query({filter: 'batchjob-is-null'}).subscribe((res: Response) => {
            if (!this.batchJob.application || !this.batchJob.application.id) {
                this.applications = res.json();
            } else {
                this.applicationService.find(this.batchJob.application.id).subscribe((subRes: Application) => {
                    this.applications = [subRes].concat(res.json());
                }, (subRes: Response) => this.onError(subRes.json()));
            }
        }, (res: Response) => this.onError(res.json()));
        this.batchJobHistoryService.query().subscribe(
            (res: Response) => { this.batchjobhistories = res.json(); }, (res: Response) => this.onError(res.json()));
        this.batchReportService.query().subscribe(
            (res: Response) => { this.batchreports = res.json(); }, (res: Response) => this.onError(res.json()));
        this.batchConfigService.query().subscribe(
            (res: Response) => { this.batchconfigs = res.json(); }, (res: Response) => this.onError(res.json()));
        this.batchStepProcessorService.query().subscribe(
            (res: Response) => { this.batchstepprocessors = res.json(); }, (res: Response) => this.onError(res.json()));
    }
    clear () {
        this.activeModal.dismiss('cancel');
    }

    save () {
        this.isSaving = true;
        if (this.batchJob.id !== undefined) {
            this.batchJobService.update(this.batchJob)
                .subscribe((res: BatchJob) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        } else {
            this.batchJobService.create(this.batchJob)
                .subscribe((res: BatchJob) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        }
    }

    private onSaveSuccess (result: BatchJob) {
        this.eventManager.broadcast({ name: 'batchJobListModification', content: 'OK'});
        this.isSaving = false;
        this.activeModal.dismiss(result);
    }

    private onSaveError (error) {
        this.isSaving = false;
        this.onError(error);
    }

    private onError (error) {
        this.alertService.error(error.message, null, null);
    }

    trackApplicationById(index: number, item: Application) {
        return item.id;
    }

    trackBatchJobHistoryById(index: number, item: BatchJobHistory) {
        return item.id;
    }

    trackBatchReportById(index: number, item: BatchReport) {
        return item.id;
    }

    trackBatchConfigById(index: number, item: BatchConfig) {
        return item.id;
    }

    trackBatchStepProcessorById(index: number, item: BatchStepProcessor) {
        return item.id;
    }
}

@Component({
    selector: 'smarti-batch-job-popup',
    template: ''
})
export class BatchJobPopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private batchJobPopupService: BatchJobPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            if ( params['id'] ) {
                this.modalRef = this.batchJobPopupService
                    .open(BatchJobDialogComponent, params['id']);
            } else {
                this.modalRef = this.batchJobPopupService
                    .open(BatchJobDialogComponent);
            }

        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
