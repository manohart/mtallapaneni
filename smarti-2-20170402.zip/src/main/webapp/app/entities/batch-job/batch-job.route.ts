import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, CanActivate } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { PaginationUtil } from 'ng-jhipster';

import { BatchJobComponent } from './batch-job.component';
import { BatchJobDetailComponent } from './batch-job-detail.component';
import { BatchJobPopupComponent } from './batch-job-dialog.component';
import { BatchJobDeletePopupComponent } from './batch-job-delete-dialog.component';

import { Principal } from '../../shared';

@Injectable()
export class BatchJobResolvePagingParams implements Resolve<any> {

  constructor(private paginationUtil: PaginationUtil) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
      let page = route.queryParams['page'] ? route.queryParams['page'] : '1';
      let sort = route.queryParams['sort'] ? route.queryParams['sort'] : 'id,asc';
      return {
          page: this.paginationUtil.parsePage(page),
          predicate: this.paginationUtil.parsePredicate(sort),
          ascending: this.paginationUtil.parseAscending(sort)
    };
  }
}

export const batchJobRoute: Routes = [
  {
    path: 'batch-job',
    component: BatchJobComponent,
    resolve: {
      'pagingParams': BatchJobResolvePagingParams
    },
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchJobs'
    }
  }, {
    path: 'batch-job/:id',
    component: BatchJobDetailComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchJobs'
    }
  }
];

export const batchJobPopupRoute: Routes = [
  {
    path: 'batch-job-new',
    component: BatchJobPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchJobs'
    },
    outlet: 'popup'
  },
  {
    path: 'batch-job/:id/edit',
    component: BatchJobPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchJobs'
    },
    outlet: 'popup'
  },
  {
    path: 'batch-job/:id/delete',
    component: BatchJobDeletePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchJobs'
    },
    outlet: 'popup'
  }
];
