import { Injectable, Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { BatchReportDetailHistory } from './batch-report-detail-history.model';
import { BatchReportDetailHistoryService } from './batch-report-detail-history.service';
@Injectable()
export class BatchReportDetailHistoryPopupService {
    private isOpen = false;
    constructor (
        private datePipe: DatePipe,
        private modalService: NgbModal,
        private router: Router,
        private batchReportDetailHistoryService: BatchReportDetailHistoryService

    ) {}

    open (component: Component, id?: number | any): NgbModalRef {
        if (this.isOpen) {
            return;
        }
        this.isOpen = true;

        if (id) {
            this.batchReportDetailHistoryService.find(id).subscribe(batchReportDetailHistory => {
                batchReportDetailHistory.updatedDate = this.datePipe
                    .transform(batchReportDetailHistory.updatedDate, 'yyyy-MM-ddThh:mm');
                this.batchReportDetailHistoryModalRef(component, batchReportDetailHistory);
            });
        } else {
            return this.batchReportDetailHistoryModalRef(component, new BatchReportDetailHistory());
        }
    }

    batchReportDetailHistoryModalRef(component: Component, batchReportDetailHistory: BatchReportDetailHistory): NgbModalRef {
        let modalRef = this.modalService.open(component, { size: 'lg', backdrop: 'static'});
        modalRef.componentInstance.batchReportDetailHistory = batchReportDetailHistory;
        modalRef.result.then(result => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        }, (reason) => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        });
        return modalRef;
    }
}
