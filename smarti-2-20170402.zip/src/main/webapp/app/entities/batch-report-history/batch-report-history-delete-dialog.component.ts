import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager } from 'ng-jhipster';

import { BatchReportHistory } from './batch-report-history.model';
import { BatchReportHistoryPopupService } from './batch-report-history-popup.service';
import { BatchReportHistoryService } from './batch-report-history.service';

@Component({
    selector: 'smarti-batch-report-history-delete-dialog',
    templateUrl: './batch-report-history-delete-dialog.component.html'
})
export class BatchReportHistoryDeleteDialogComponent {

    batchReportHistory: BatchReportHistory;

    constructor(
        private batchReportHistoryService: BatchReportHistoryService,
        public activeModal: NgbActiveModal,
        private eventManager: EventManager
    ) {
    }

    clear () {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete (id: number) {
        this.batchReportHistoryService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'batchReportHistoryListModification',
                content: 'Deleted an batchReportHistory'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'smarti-batch-report-history-delete-popup',
    template: ''
})
export class BatchReportHistoryDeletePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private batchReportHistoryPopupService: BatchReportHistoryPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            this.modalRef = this.batchReportHistoryPopupService
                .open(BatchReportHistoryDeleteDialogComponent, params['id']);
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
