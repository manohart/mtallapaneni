import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BatchReportHistory } from './batch-report-history.model';
import { BatchReportHistoryService } from './batch-report-history.service';

@Component({
    selector: 'smarti-batch-report-history-detail',
    templateUrl: './batch-report-history-detail.component.html'
})
export class BatchReportHistoryDetailComponent implements OnInit, OnDestroy {

    batchReportHistory: BatchReportHistory;
    private subscription: any;

    constructor(
        private batchReportHistoryService: BatchReportHistoryService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.batchReportHistoryService.find(id).subscribe(batchReportHistory => {
            this.batchReportHistory = batchReportHistory;
        });
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
