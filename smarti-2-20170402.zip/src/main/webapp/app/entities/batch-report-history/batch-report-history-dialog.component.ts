import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager, AlertService } from 'ng-jhipster';

import { BatchReportHistory } from './batch-report-history.model';
import { BatchReportHistoryPopupService } from './batch-report-history-popup.service';
import { BatchReportHistoryService } from './batch-report-history.service';
import { BatchReportDetailHistory, BatchReportDetailHistoryService } from '../batch-report-detail-history';
import { DataQualityCheckIssue, DataQualityCheckIssueService } from '../data-quality-check-issue';
import { BatchReport, BatchReportService } from '../batch-report';

@Component({
    selector: 'smarti-batch-report-history-dialog',
    templateUrl: './batch-report-history-dialog.component.html'
})
export class BatchReportHistoryDialogComponent implements OnInit {

    batchReportHistory: BatchReportHistory;
    authorities: any[];
    isSaving: boolean;

    batchreportdetailhistories: BatchReportDetailHistory[];

    dataqualitycheckissues: DataQualityCheckIssue[];

    batchreports: BatchReport[];
    constructor(
        public activeModal: NgbActiveModal,
        private alertService: AlertService,
        private batchReportHistoryService: BatchReportHistoryService,
        private batchReportDetailHistoryService: BatchReportDetailHistoryService,
        private dataQualityCheckIssueService: DataQualityCheckIssueService,
        private batchReportService: BatchReportService,
        private eventManager: EventManager
    ) {
    }

    ngOnInit() {
        this.isSaving = false;
        this.authorities = ['ROLE_USER', 'ROLE_ADMIN'];
        this.batchReportDetailHistoryService.query().subscribe(
            (res: Response) => { this.batchreportdetailhistories = res.json(); }, (res: Response) => this.onError(res.json()));
        this.dataQualityCheckIssueService.query().subscribe(
            (res: Response) => { this.dataqualitycheckissues = res.json(); }, (res: Response) => this.onError(res.json()));
        this.batchReportService.query().subscribe(
            (res: Response) => { this.batchreports = res.json(); }, (res: Response) => this.onError(res.json()));
    }
    clear () {
        this.activeModal.dismiss('cancel');
    }

    save () {
        this.isSaving = true;
        if (this.batchReportHistory.id !== undefined) {
            this.batchReportHistoryService.update(this.batchReportHistory)
                .subscribe((res: BatchReportHistory) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        } else {
            this.batchReportHistoryService.create(this.batchReportHistory)
                .subscribe((res: BatchReportHistory) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        }
    }

    private onSaveSuccess (result: BatchReportHistory) {
        this.eventManager.broadcast({ name: 'batchReportHistoryListModification', content: 'OK'});
        this.isSaving = false;
        this.activeModal.dismiss(result);
    }

    private onSaveError (error) {
        this.isSaving = false;
        this.onError(error);
    }

    private onError (error) {
        this.alertService.error(error.message, null, null);
    }

    trackBatchReportDetailHistoryById(index: number, item: BatchReportDetailHistory) {
        return item.id;
    }

    trackDataQualityCheckIssueById(index: number, item: DataQualityCheckIssue) {
        return item.id;
    }

    trackBatchReportById(index: number, item: BatchReport) {
        return item.id;
    }
}

@Component({
    selector: 'smarti-batch-report-history-popup',
    template: ''
})
export class BatchReportHistoryPopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private batchReportHistoryPopupService: BatchReportHistoryPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            if ( params['id'] ) {
                this.modalRef = this.batchReportHistoryPopupService
                    .open(BatchReportHistoryDialogComponent, params['id']);
            } else {
                this.modalRef = this.batchReportHistoryPopupService
                    .open(BatchReportHistoryDialogComponent);
            }

        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
