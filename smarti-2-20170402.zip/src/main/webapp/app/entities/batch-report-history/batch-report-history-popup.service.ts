import { Injectable, Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { BatchReportHistory } from './batch-report-history.model';
import { BatchReportHistoryService } from './batch-report-history.service';
@Injectable()
export class BatchReportHistoryPopupService {
    private isOpen = false;
    constructor (
        private datePipe: DatePipe,
        private modalService: NgbModal,
        private router: Router,
        private batchReportHistoryService: BatchReportHistoryService

    ) {}

    open (component: Component, id?: number | any): NgbModalRef {
        if (this.isOpen) {
            return;
        }
        this.isOpen = true;

        if (id) {
            this.batchReportHistoryService.find(id).subscribe(batchReportHistory => {
                if (batchReportHistory.businessDate) {
                    batchReportHistory.businessDate = {
                        year: batchReportHistory.businessDate.getFullYear(),
                        month: batchReportHistory.businessDate.getMonth() + 1,
                        day: batchReportHistory.businessDate.getDate()
                    };
                }
                batchReportHistory.startTime = this.datePipe
                    .transform(batchReportHistory.startTime, 'yyyy-MM-ddThh:mm');
                batchReportHistory.endTime = this.datePipe
                    .transform(batchReportHistory.endTime, 'yyyy-MM-ddThh:mm');
                this.batchReportHistoryModalRef(component, batchReportHistory);
            });
        } else {
            return this.batchReportHistoryModalRef(component, new BatchReportHistory());
        }
    }

    batchReportHistoryModalRef(component: Component, batchReportHistory: BatchReportHistory): NgbModalRef {
        let modalRef = this.modalService.open(component, { size: 'lg', backdrop: 'static'});
        modalRef.componentInstance.batchReportHistory = batchReportHistory;
        modalRef.result.then(result => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        }, (reason) => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        });
        return modalRef;
    }
}
