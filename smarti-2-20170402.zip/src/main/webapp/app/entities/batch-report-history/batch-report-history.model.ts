import { BatchReportDetailHistory } from '../batch-report-detail-history';
import { DataQualityCheckIssue } from '../data-quality-check-issue';
import { BatchReport } from '../batch-report';
export class BatchReportHistory {
    constructor(
        public id?: number,
        public businessDate?: any,
        public status?: string,
        public startTime?: any,
        public endTime?: any,
        public summaryDetail?: BatchReportDetailHistory,
        public summaryDetailAudit?: DataQualityCheckIssue,
        public reportConfig?: BatchReport,
    ) {
    }
}
