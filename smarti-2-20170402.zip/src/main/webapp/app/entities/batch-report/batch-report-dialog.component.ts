import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager, AlertService } from 'ng-jhipster';

import { BatchReport } from './batch-report.model';
import { BatchReportPopupService } from './batch-report-popup.service';
import { BatchReportService } from './batch-report.service';
import { DataQualityCheck, DataQualityCheckService } from '../data-quality-check';
import { BatchReportHistory, BatchReportHistoryService } from '../batch-report-history';
import { BatchJob, BatchJobService } from '../batch-job';

@Component({
    selector: 'smarti-batch-report-dialog',
    templateUrl: './batch-report-dialog.component.html'
})
export class BatchReportDialogComponent implements OnInit {

    batchReport: BatchReport;
    authorities: any[];
    isSaving: boolean;

    dataqualitychecks: DataQualityCheck[];

    batchreporthistories: BatchReportHistory[];

    batchjobs: BatchJob[];
    constructor(
        public activeModal: NgbActiveModal,
        private alertService: AlertService,
        private batchReportService: BatchReportService,
        private dataQualityCheckService: DataQualityCheckService,
        private batchReportHistoryService: BatchReportHistoryService,
        private batchJobService: BatchJobService,
        private eventManager: EventManager
    ) {
    }

    ngOnInit() {
        this.isSaving = false;
        this.authorities = ['ROLE_USER', 'ROLE_ADMIN'];
        this.dataQualityCheckService.query().subscribe(
            (res: Response) => { this.dataqualitychecks = res.json(); }, (res: Response) => this.onError(res.json()));
        this.batchReportHistoryService.query().subscribe(
            (res: Response) => { this.batchreporthistories = res.json(); }, (res: Response) => this.onError(res.json()));
        this.batchJobService.query().subscribe(
            (res: Response) => { this.batchjobs = res.json(); }, (res: Response) => this.onError(res.json()));
    }
    clear () {
        this.activeModal.dismiss('cancel');
    }

    save () {
        this.isSaving = true;
        if (this.batchReport.id !== undefined) {
            this.batchReportService.update(this.batchReport)
                .subscribe((res: BatchReport) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        } else {
            this.batchReportService.create(this.batchReport)
                .subscribe((res: BatchReport) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        }
    }

    private onSaveSuccess (result: BatchReport) {
        this.eventManager.broadcast({ name: 'batchReportListModification', content: 'OK'});
        this.isSaving = false;
        this.activeModal.dismiss(result);
    }

    private onSaveError (error) {
        this.isSaving = false;
        this.onError(error);
    }

    private onError (error) {
        this.alertService.error(error.message, null, null);
    }

    trackDataQualityCheckById(index: number, item: DataQualityCheck) {
        return item.id;
    }

    trackBatchReportHistoryById(index: number, item: BatchReportHistory) {
        return item.id;
    }

    trackBatchJobById(index: number, item: BatchJob) {
        return item.id;
    }
}

@Component({
    selector: 'smarti-batch-report-popup',
    template: ''
})
export class BatchReportPopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private batchReportPopupService: BatchReportPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            if ( params['id'] ) {
                this.modalRef = this.batchReportPopupService
                    .open(BatchReportDialogComponent, params['id']);
            } else {
                this.modalRef = this.batchReportPopupService
                    .open(BatchReportDialogComponent);
            }

        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
