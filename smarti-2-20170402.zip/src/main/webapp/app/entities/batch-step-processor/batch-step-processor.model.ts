import { BatchJob } from '../batch-job';
export class BatchStepProcessor {
    constructor(
        public id?: number,
        public stepNumber?: number,
        public name?: string,
        public processor?: string,
        public description?: any,
        public troubleshooting?: any,
        public contIfFailed?: boolean,
        public preCheck?: string,
        public postCheck?: string,
        public contIfCheckFailed?: boolean,
        public isActive?: boolean,
        public updatedDate?: any,
        public batchJob?: BatchJob,
    ) {
        this.contIfFailed = false;
        this.contIfCheckFailed = false;
        this.isActive = false;
    }
}
