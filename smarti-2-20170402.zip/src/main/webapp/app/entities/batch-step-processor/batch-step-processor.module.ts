import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SmartISharedModule } from '../../shared';

import {
    BatchStepProcessorService,
    BatchStepProcessorPopupService,
    BatchStepProcessorComponent,
    BatchStepProcessorDetailComponent,
    BatchStepProcessorDialogComponent,
    BatchStepProcessorPopupComponent,
    BatchStepProcessorDeletePopupComponent,
    BatchStepProcessorDeleteDialogComponent,
    batchStepProcessorRoute,
    batchStepProcessorPopupRoute,
    BatchStepProcessorResolvePagingParams,
} from './';

let ENTITY_STATES = [
    ...batchStepProcessorRoute,
    ...batchStepProcessorPopupRoute,
];

@NgModule({
    imports: [
        SmartISharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [
        BatchStepProcessorComponent,
        BatchStepProcessorDetailComponent,
        BatchStepProcessorDialogComponent,
        BatchStepProcessorDeleteDialogComponent,
        BatchStepProcessorPopupComponent,
        BatchStepProcessorDeletePopupComponent,
    ],
    entryComponents: [
        BatchStepProcessorComponent,
        BatchStepProcessorDialogComponent,
        BatchStepProcessorPopupComponent,
        BatchStepProcessorDeleteDialogComponent,
        BatchStepProcessorDeletePopupComponent,
    ],
    providers: [
        BatchStepProcessorService,
        BatchStepProcessorPopupService,
        BatchStepProcessorResolvePagingParams,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartIBatchStepProcessorModule {}
