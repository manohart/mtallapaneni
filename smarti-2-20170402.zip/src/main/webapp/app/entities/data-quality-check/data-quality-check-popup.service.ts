import { Injectable, Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { DataQualityCheck } from './data-quality-check.model';
import { DataQualityCheckService } from './data-quality-check.service';
@Injectable()
export class DataQualityCheckPopupService {
    private isOpen = false;
    constructor (
        private datePipe: DatePipe,
        private modalService: NgbModal,
        private router: Router,
        private dataQualityCheckService: DataQualityCheckService

    ) {}

    open (component: Component, id?: number | any): NgbModalRef {
        if (this.isOpen) {
            return;
        }
        this.isOpen = true;

        if (id) {
            this.dataQualityCheckService.find(id).subscribe(dataQualityCheck => {
                dataQualityCheck.startDate = this.datePipe
                    .transform(dataQualityCheck.startDate, 'yyyy-MM-ddThh:mm');
                dataQualityCheck.endDate = this.datePipe
                    .transform(dataQualityCheck.endDate, 'yyyy-MM-ddThh:mm');
                dataQualityCheck.updatedDate = this.datePipe
                    .transform(dataQualityCheck.updatedDate, 'yyyy-MM-ddThh:mm');
                this.dataQualityCheckModalRef(component, dataQualityCheck);
            });
        } else {
            return this.dataQualityCheckModalRef(component, new DataQualityCheck());
        }
    }

    dataQualityCheckModalRef(component: Component, dataQualityCheck: DataQualityCheck): NgbModalRef {
        let modalRef = this.modalService.open(component, { size: 'lg', backdrop: 'static'});
        modalRef.componentInstance.dataQualityCheck = dataQualityCheck;
        modalRef.result.then(result => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        }, (reason) => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        });
        return modalRef;
    }
}
