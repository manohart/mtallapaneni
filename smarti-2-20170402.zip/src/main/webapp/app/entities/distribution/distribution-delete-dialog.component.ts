import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager } from 'ng-jhipster';

import { Distribution } from './distribution.model';
import { DistributionPopupService } from './distribution-popup.service';
import { DistributionService } from './distribution.service';

@Component({
    selector: 'smarti-distribution-delete-dialog',
    templateUrl: './distribution-delete-dialog.component.html'
})
export class DistributionDeleteDialogComponent {

    distribution: Distribution;

    constructor(
        private distributionService: DistributionService,
        public activeModal: NgbActiveModal,
        private eventManager: EventManager
    ) {
    }

    clear () {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete (id: number) {
        this.distributionService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'distributionListModification',
                content: 'Deleted an distribution'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'smarti-distribution-delete-popup',
    template: ''
})
export class DistributionDeletePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private distributionPopupService: DistributionPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            this.modalRef = this.distributionPopupService
                .open(DistributionDeleteDialogComponent, params['id']);
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
