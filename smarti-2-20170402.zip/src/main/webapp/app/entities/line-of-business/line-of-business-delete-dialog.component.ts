import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager } from 'ng-jhipster';

import { LineOfBusiness } from './line-of-business.model';
import { LineOfBusinessPopupService } from './line-of-business-popup.service';
import { LineOfBusinessService } from './line-of-business.service';

@Component({
    selector: 'smarti-line-of-business-delete-dialog',
    templateUrl: './line-of-business-delete-dialog.component.html'
})
export class LineOfBusinessDeleteDialogComponent {

    lineOfBusiness: LineOfBusiness;

    constructor(
        private lineOfBusinessService: LineOfBusinessService,
        public activeModal: NgbActiveModal,
        private eventManager: EventManager
    ) {
    }

    clear () {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete (id: number) {
        this.lineOfBusinessService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'lineOfBusinessListModification',
                content: 'Deleted an lineOfBusiness'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'smarti-line-of-business-delete-popup',
    template: ''
})
export class LineOfBusinessDeletePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private lineOfBusinessPopupService: LineOfBusinessPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            this.modalRef = this.lineOfBusinessPopupService
                .open(LineOfBusinessDeleteDialogComponent, params['id']);
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
