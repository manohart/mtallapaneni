import { Application } from '../application';
import { ArchiveLocation } from '../archive-location';
import { AutoNotification } from '../auto-notification';
import { Product } from '../product';
import { Template } from '../template';
import { Team } from '../team';
export class LineOfBusiness {
    constructor(
        public id?: number,
        public name?: string,
        public description?: string,
        public ownerSid?: string,
        public managerSid?: string,
        public businessSponsorSid?: string,
        public startDate?: any,
        public endDate?: any,
        public updatedDate?: any,
        public subLob?: LineOfBusiness,
        public application?: Application,
        public archive?: ArchiveLocation,
        public notificationRule?: AutoNotification,
        public product?: Product,
        public template?: Template,
        public team?: Team,
        public superLob?: LineOfBusiness,
    ) {
    }
}
