import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SmartISharedModule } from '../../shared';

import {
    LineOfBusinessService,
    LineOfBusinessPopupService,
    LineOfBusinessComponent,
    LineOfBusinessDetailComponent,
    LineOfBusinessDialogComponent,
    LineOfBusinessPopupComponent,
    LineOfBusinessDeletePopupComponent,
    LineOfBusinessDeleteDialogComponent,
    lineOfBusinessRoute,
    lineOfBusinessPopupRoute,
    LineOfBusinessResolvePagingParams,
} from './';

let ENTITY_STATES = [
    ...lineOfBusinessRoute,
    ...lineOfBusinessPopupRoute,
];

@NgModule({
    imports: [
        SmartISharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [
        LineOfBusinessComponent,
        LineOfBusinessDetailComponent,
        LineOfBusinessDialogComponent,
        LineOfBusinessDeleteDialogComponent,
        LineOfBusinessPopupComponent,
        LineOfBusinessDeletePopupComponent,
    ],
    entryComponents: [
        LineOfBusinessComponent,
        LineOfBusinessDialogComponent,
        LineOfBusinessPopupComponent,
        LineOfBusinessDeleteDialogComponent,
        LineOfBusinessDeletePopupComponent,
    ],
    providers: [
        LineOfBusinessService,
        LineOfBusinessPopupService,
        LineOfBusinessResolvePagingParams,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartILineOfBusinessModule {}
