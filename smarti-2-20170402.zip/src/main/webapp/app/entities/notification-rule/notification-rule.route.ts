import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, CanActivate } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { PaginationUtil } from 'ng-jhipster';

import { NotificationRuleComponent } from './notification-rule.component';
import { NotificationRuleDetailComponent } from './notification-rule-detail.component';
import { NotificationRulePopupComponent } from './notification-rule-dialog.component';
import { NotificationRuleDeletePopupComponent } from './notification-rule-delete-dialog.component';

import { Principal } from '../../shared';

@Injectable()
export class NotificationRuleResolvePagingParams implements Resolve<any> {

  constructor(private paginationUtil: PaginationUtil) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
      let page = route.queryParams['page'] ? route.queryParams['page'] : '1';
      let sort = route.queryParams['sort'] ? route.queryParams['sort'] : 'id,asc';
      return {
          page: this.paginationUtil.parsePage(page),
          predicate: this.paginationUtil.parsePredicate(sort),
          ascending: this.paginationUtil.parseAscending(sort)
    };
  }
}

export const notificationRuleRoute: Routes = [
  {
    path: 'notification-rule',
    component: NotificationRuleComponent,
    resolve: {
      'pagingParams': NotificationRuleResolvePagingParams
    },
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'NotificationRules'
    }
  }, {
    path: 'notification-rule/:id',
    component: NotificationRuleDetailComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'NotificationRules'
    }
  }
];

export const notificationRulePopupRoute: Routes = [
  {
    path: 'notification-rule-new',
    component: NotificationRulePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'NotificationRules'
    },
    outlet: 'popup'
  },
  {
    path: 'notification-rule/:id/edit',
    component: NotificationRulePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'NotificationRules'
    },
    outlet: 'popup'
  },
  {
    path: 'notification-rule/:id/delete',
    component: NotificationRuleDeletePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'NotificationRules'
    },
    outlet: 'popup'
  }
];
