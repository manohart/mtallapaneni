export * from './product-module.model';
export * from './product-module-popup.service';
export * from './product-module.service';
export * from './product-module-dialog.component';
export * from './product-module-delete-dialog.component';
export * from './product-module-detail.component';
export * from './product-module.component';
export * from './product-module.route';
