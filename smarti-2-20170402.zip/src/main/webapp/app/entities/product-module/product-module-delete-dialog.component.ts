import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager } from 'ng-jhipster';

import { ProductModule } from './product-module.model';
import { ProductModulePopupService } from './product-module-popup.service';
import { ProductModuleService } from './product-module.service';

@Component({
    selector: 'smarti-product-module-delete-dialog',
    templateUrl: './product-module-delete-dialog.component.html'
})
export class ProductModuleDeleteDialogComponent {

    productModule: ProductModule;

    constructor(
        private productModuleService: ProductModuleService,
        public activeModal: NgbActiveModal,
        private eventManager: EventManager
    ) {
    }

    clear () {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete (id: number) {
        this.productModuleService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'productModuleListModification',
                content: 'Deleted an productModule'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'smarti-product-module-delete-popup',
    template: ''
})
export class ProductModuleDeletePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private productModulePopupService: ProductModulePopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            this.modalRef = this.productModulePopupService
                .open(ProductModuleDeleteDialogComponent, params['id']);
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
