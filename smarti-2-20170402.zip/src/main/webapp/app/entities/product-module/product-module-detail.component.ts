import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataUtils } from 'ng-jhipster';
import { ProductModule } from './product-module.model';
import { ProductModuleService } from './product-module.service';

@Component({
    selector: 'smarti-product-module-detail',
    templateUrl: './product-module-detail.component.html'
})
export class ProductModuleDetailComponent implements OnInit, OnDestroy {

    productModule: ProductModule;
    private subscription: any;

    constructor(
        private dataUtils: DataUtils,
        private productModuleService: ProductModuleService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.productModuleService.find(id).subscribe(productModule => {
            this.productModule = productModule;
        });
    }
    byteSize(field) {
        return this.dataUtils.byteSize(field);
    }

    openFile(contentType, field) {
        return this.dataUtils.openFile(contentType, field);
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
