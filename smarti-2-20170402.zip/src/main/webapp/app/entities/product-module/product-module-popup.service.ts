import { Injectable, Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { ProductModule } from './product-module.model';
import { ProductModuleService } from './product-module.service';
@Injectable()
export class ProductModulePopupService {
    private isOpen = false;
    constructor (
        private datePipe: DatePipe,
        private modalService: NgbModal,
        private router: Router,
        private productModuleService: ProductModuleService

    ) {}

    open (component: Component, id?: number | any): NgbModalRef {
        if (this.isOpen) {
            return;
        }
        this.isOpen = true;

        if (id) {
            this.productModuleService.find(id).subscribe(productModule => {
                productModule.startDate = this.datePipe
                    .transform(productModule.startDate, 'yyyy-MM-ddThh:mm');
                productModule.endDate = this.datePipe
                    .transform(productModule.endDate, 'yyyy-MM-ddThh:mm');
                productModule.updatedDate = this.datePipe
                    .transform(productModule.updatedDate, 'yyyy-MM-ddThh:mm');
                this.productModuleModalRef(component, productModule);
            });
        } else {
            return this.productModuleModalRef(component, new ProductModule());
        }
    }

    productModuleModalRef(component: Component, productModule: ProductModule): NgbModalRef {
        let modalRef = this.modalService.open(component, { size: 'lg', backdrop: 'static'});
        modalRef.componentInstance.productModule = productModule;
        modalRef.result.then(result => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        }, (reason) => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        });
        return modalRef;
    }
}
