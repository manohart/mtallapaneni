import { Application } from '../application';
import { Product } from '../product';
export class ProductModule {
    constructor(
        public id?: number,
        public name?: string,
        public description?: any,
        public sourceCode?: string,
        public tracker?: string,
        public ciLink?: string,
        public techStack?: string,
        public startDate?: any,
        public endDate?: any,
        public updatedDate?: any,
        public application?: Application,
        public product?: Product,
    ) {
    }
}
