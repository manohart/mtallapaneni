import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SmartISharedModule } from '../../shared';

import {
    ProductModuleService,
    ProductModulePopupService,
    ProductModuleComponent,
    ProductModuleDetailComponent,
    ProductModuleDialogComponent,
    ProductModulePopupComponent,
    ProductModuleDeletePopupComponent,
    ProductModuleDeleteDialogComponent,
    productModuleRoute,
    productModulePopupRoute,
    ProductModuleResolvePagingParams,
} from './';

let ENTITY_STATES = [
    ...productModuleRoute,
    ...productModulePopupRoute,
];

@NgModule({
    imports: [
        SmartISharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [
        ProductModuleComponent,
        ProductModuleDetailComponent,
        ProductModuleDialogComponent,
        ProductModuleDeleteDialogComponent,
        ProductModulePopupComponent,
        ProductModuleDeletePopupComponent,
    ],
    entryComponents: [
        ProductModuleComponent,
        ProductModuleDialogComponent,
        ProductModulePopupComponent,
        ProductModuleDeleteDialogComponent,
        ProductModuleDeletePopupComponent,
    ],
    providers: [
        ProductModuleService,
        ProductModulePopupService,
        ProductModuleResolvePagingParams,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartIProductModuleModule {}
