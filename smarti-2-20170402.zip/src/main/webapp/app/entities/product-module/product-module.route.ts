import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, CanActivate } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { PaginationUtil } from 'ng-jhipster';

import { ProductModuleComponent } from './product-module.component';
import { ProductModuleDetailComponent } from './product-module-detail.component';
import { ProductModulePopupComponent } from './product-module-dialog.component';
import { ProductModuleDeletePopupComponent } from './product-module-delete-dialog.component';

import { Principal } from '../../shared';

@Injectable()
export class ProductModuleResolvePagingParams implements Resolve<any> {

  constructor(private paginationUtil: PaginationUtil) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
      let page = route.queryParams['page'] ? route.queryParams['page'] : '1';
      let sort = route.queryParams['sort'] ? route.queryParams['sort'] : 'id,asc';
      return {
          page: this.paginationUtil.parsePage(page),
          predicate: this.paginationUtil.parsePredicate(sort),
          ascending: this.paginationUtil.parseAscending(sort)
    };
  }
}

export const productModuleRoute: Routes = [
  {
    path: 'product-module',
    component: ProductModuleComponent,
    resolve: {
      'pagingParams': ProductModuleResolvePagingParams
    },
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'ProductModules'
    }
  }, {
    path: 'product-module/:id',
    component: ProductModuleDetailComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'ProductModules'
    }
  }
];

export const productModulePopupRoute: Routes = [
  {
    path: 'product-module-new',
    component: ProductModulePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'ProductModules'
    },
    outlet: 'popup'
  },
  {
    path: 'product-module/:id/edit',
    component: ProductModulePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'ProductModules'
    },
    outlet: 'popup'
  },
  {
    path: 'product-module/:id/delete',
    component: ProductModuleDeletePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'ProductModules'
    },
    outlet: 'popup'
  }
];
