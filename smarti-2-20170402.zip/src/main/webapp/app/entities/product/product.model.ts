import { ProductModule } from '../product-module';
import { SoftwareRelease } from '../software-release';
import { Team } from '../team';
import { LineOfBusiness } from '../line-of-business';
export class Product {
    constructor(
        public id?: number,
        public name?: string,
        public description?: any,
        public sealId?: number,
        public sourceCode?: string,
        public tracker?: string,
        public startDate?: any,
        public endDate?: any,
        public updatedDate?: any,
        public module?: ProductModule,
        public release?: SoftwareRelease,
        public techonology?: Team,
        public support?: Team,
        public business?: Team,
        public lob?: LineOfBusiness,
    ) {
    }
}
