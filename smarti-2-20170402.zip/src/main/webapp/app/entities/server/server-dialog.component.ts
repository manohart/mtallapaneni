import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager, AlertService } from 'ng-jhipster';

import { Server } from './server.model';
import { ServerPopupService } from './server-popup.service';
import { ServerService } from './server.service';
import { Application, ApplicationService } from '../application';
import { LineOfBusiness, LineOfBusinessService } from '../line-of-business';

@Component({
    selector: 'smarti-server-dialog',
    templateUrl: './server-dialog.component.html'
})
export class ServerDialogComponent implements OnInit {

    server: Server;
    authorities: any[];
    isSaving: boolean;

    applications: Application[];

    lineofbusinesses: LineOfBusiness[];
    constructor(
        public activeModal: NgbActiveModal,
        private alertService: AlertService,
        private serverService: ServerService,
        private applicationService: ApplicationService,
        private lineOfBusinessService: LineOfBusinessService,
        private eventManager: EventManager
    ) {
    }

    ngOnInit() {
        this.isSaving = false;
        this.authorities = ['ROLE_USER', 'ROLE_ADMIN'];
        this.applicationService.query().subscribe(
            (res: Response) => { this.applications = res.json(); }, (res: Response) => this.onError(res.json()));
        this.lineOfBusinessService.query().subscribe(
            (res: Response) => { this.lineofbusinesses = res.json(); }, (res: Response) => this.onError(res.json()));
    }
    clear () {
        this.activeModal.dismiss('cancel');
    }

    save () {
        this.isSaving = true;
        if (this.server.id !== undefined) {
            this.serverService.update(this.server)
                .subscribe((res: Server) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        } else {
            this.serverService.create(this.server)
                .subscribe((res: Server) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        }
    }

    private onSaveSuccess (result: Server) {
        this.eventManager.broadcast({ name: 'serverListModification', content: 'OK'});
        this.isSaving = false;
        this.activeModal.dismiss(result);
    }

    private onSaveError (error) {
        this.isSaving = false;
        this.onError(error);
    }

    private onError (error) {
        this.alertService.error(error.message, null, null);
    }

    trackApplicationById(index: number, item: Application) {
        return item.id;
    }

    trackLineOfBusinessById(index: number, item: LineOfBusiness) {
        return item.id;
    }
}

@Component({
    selector: 'smarti-server-popup',
    template: ''
})
export class ServerPopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private serverPopupService: ServerPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            if ( params['id'] ) {
                this.modalRef = this.serverPopupService
                    .open(ServerDialogComponent, params['id']);
            } else {
                this.modalRef = this.serverPopupService
                    .open(ServerDialogComponent);
            }

        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
