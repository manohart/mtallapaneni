import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager } from 'ng-jhipster';

import { SmokeTestMain } from './smoke-test-main.model';
import { SmokeTestMainPopupService } from './smoke-test-main-popup.service';
import { SmokeTestMainService } from './smoke-test-main.service';

@Component({
    selector: 'smarti-smoke-test-main-delete-dialog',
    templateUrl: './smoke-test-main-delete-dialog.component.html'
})
export class SmokeTestMainDeleteDialogComponent {

    smokeTestMain: SmokeTestMain;

    constructor(
        private smokeTestMainService: SmokeTestMainService,
        public activeModal: NgbActiveModal,
        private eventManager: EventManager
    ) {
    }

    clear () {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete (id: number) {
        this.smokeTestMainService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'smokeTestMainListModification',
                content: 'Deleted an smokeTestMain'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'smarti-smoke-test-main-delete-popup',
    template: ''
})
export class SmokeTestMainDeletePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private smokeTestMainPopupService: SmokeTestMainPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            this.modalRef = this.smokeTestMainPopupService
                .open(SmokeTestMainDeleteDialogComponent, params['id']);
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
