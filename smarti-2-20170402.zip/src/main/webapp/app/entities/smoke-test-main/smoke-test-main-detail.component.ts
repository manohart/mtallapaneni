import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SmokeTestMain } from './smoke-test-main.model';
import { SmokeTestMainService } from './smoke-test-main.service';

@Component({
    selector: 'smarti-smoke-test-main-detail',
    templateUrl: './smoke-test-main-detail.component.html'
})
export class SmokeTestMainDetailComponent implements OnInit, OnDestroy {

    smokeTestMain: SmokeTestMain;
    private subscription: any;

    constructor(
        private smokeTestMainService: SmokeTestMainService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.smokeTestMainService.find(id).subscribe(smokeTestMain => {
            this.smokeTestMain = smokeTestMain;
        });
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
