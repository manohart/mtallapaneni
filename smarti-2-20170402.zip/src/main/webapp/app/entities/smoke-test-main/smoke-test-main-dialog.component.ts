import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager, AlertService } from 'ng-jhipster';

import { SmokeTestMain } from './smoke-test-main.model';
import { SmokeTestMainPopupService } from './smoke-test-main-popup.service';
import { SmokeTestMainService } from './smoke-test-main.service';
import { SmokeTestSetup, SmokeTestSetupService } from '../smoke-test-setup';
import { SmokeTestResult, SmokeTestResultService } from '../smoke-test-result';

@Component({
    selector: 'smarti-smoke-test-main-dialog',
    templateUrl: './smoke-test-main-dialog.component.html'
})
export class SmokeTestMainDialogComponent implements OnInit {

    smokeTestMain: SmokeTestMain;
    authorities: any[];
    isSaving: boolean;

    smoketestsetups: SmokeTestSetup[];

    smoketestresults: SmokeTestResult[];
    constructor(
        public activeModal: NgbActiveModal,
        private alertService: AlertService,
        private smokeTestMainService: SmokeTestMainService,
        private smokeTestSetupService: SmokeTestSetupService,
        private smokeTestResultService: SmokeTestResultService,
        private eventManager: EventManager
    ) {
    }

    ngOnInit() {
        this.isSaving = false;
        this.authorities = ['ROLE_USER', 'ROLE_ADMIN'];
        this.smokeTestSetupService.query().subscribe(
            (res: Response) => { this.smoketestsetups = res.json(); }, (res: Response) => this.onError(res.json()));
        this.smokeTestResultService.query().subscribe(
            (res: Response) => { this.smoketestresults = res.json(); }, (res: Response) => this.onError(res.json()));
    }
    clear () {
        this.activeModal.dismiss('cancel');
    }

    save () {
        this.isSaving = true;
        if (this.smokeTestMain.id !== undefined) {
            this.smokeTestMainService.update(this.smokeTestMain)
                .subscribe((res: SmokeTestMain) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        } else {
            this.smokeTestMainService.create(this.smokeTestMain)
                .subscribe((res: SmokeTestMain) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        }
    }

    private onSaveSuccess (result: SmokeTestMain) {
        this.eventManager.broadcast({ name: 'smokeTestMainListModification', content: 'OK'});
        this.isSaving = false;
        this.activeModal.dismiss(result);
    }

    private onSaveError (error) {
        this.isSaving = false;
        this.onError(error);
    }

    private onError (error) {
        this.alertService.error(error.message, null, null);
    }

    trackSmokeTestSetupById(index: number, item: SmokeTestSetup) {
        return item.id;
    }

    trackSmokeTestResultById(index: number, item: SmokeTestResult) {
        return item.id;
    }
}

@Component({
    selector: 'smarti-smoke-test-main-popup',
    template: ''
})
export class SmokeTestMainPopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private smokeTestMainPopupService: SmokeTestMainPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            if ( params['id'] ) {
                this.modalRef = this.smokeTestMainPopupService
                    .open(SmokeTestMainDialogComponent, params['id']);
            } else {
                this.modalRef = this.smokeTestMainPopupService
                    .open(SmokeTestMainDialogComponent);
            }

        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
