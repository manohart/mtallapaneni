import { Injectable, Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { SmokeTestMain } from './smoke-test-main.model';
import { SmokeTestMainService } from './smoke-test-main.service';
@Injectable()
export class SmokeTestMainPopupService {
    private isOpen = false;
    constructor (
        private datePipe: DatePipe,
        private modalService: NgbModal,
        private router: Router,
        private smokeTestMainService: SmokeTestMainService

    ) {}

    open (component: Component, id?: number | any): NgbModalRef {
        if (this.isOpen) {
            return;
        }
        this.isOpen = true;

        if (id) {
            this.smokeTestMainService.find(id).subscribe(smokeTestMain => {
                if (smokeTestMain.date) {
                    smokeTestMain.date = {
                        year: smokeTestMain.date.getFullYear(),
                        month: smokeTestMain.date.getMonth() + 1,
                        day: smokeTestMain.date.getDate()
                    };
                }
                smokeTestMain.updatedDate = this.datePipe
                    .transform(smokeTestMain.updatedDate, 'yyyy-MM-ddThh:mm');
                this.smokeTestMainModalRef(component, smokeTestMain);
            });
        } else {
            return this.smokeTestMainModalRef(component, new SmokeTestMain());
        }
    }

    smokeTestMainModalRef(component: Component, smokeTestMain: SmokeTestMain): NgbModalRef {
        let modalRef = this.modalService.open(component, { size: 'lg', backdrop: 'static'});
        modalRef.componentInstance.smokeTestMain = smokeTestMain;
        modalRef.result.then(result => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        }, (reason) => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        });
        return modalRef;
    }
}
