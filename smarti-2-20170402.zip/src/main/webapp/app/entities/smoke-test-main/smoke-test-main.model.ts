import { SmokeTestSetup } from '../smoke-test-setup';
import { SmokeTestResult } from '../smoke-test-result';
export class SmokeTestMain {
    constructor(
        public id?: number,
        public date?: any,
        public status?: string,
        public updatedDate?: any,
        public smokeTestSetup?: SmokeTestSetup,
        public testResult?: SmokeTestResult,
    ) {
    }
}
