import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SmartISharedModule } from '../../shared';

import {
    SmokeTestMainService,
    SmokeTestMainPopupService,
    SmokeTestMainComponent,
    SmokeTestMainDetailComponent,
    SmokeTestMainDialogComponent,
    SmokeTestMainPopupComponent,
    SmokeTestMainDeletePopupComponent,
    SmokeTestMainDeleteDialogComponent,
    smokeTestMainRoute,
    smokeTestMainPopupRoute,
    SmokeTestMainResolvePagingParams,
} from './';

let ENTITY_STATES = [
    ...smokeTestMainRoute,
    ...smokeTestMainPopupRoute,
];

@NgModule({
    imports: [
        SmartISharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [
        SmokeTestMainComponent,
        SmokeTestMainDetailComponent,
        SmokeTestMainDialogComponent,
        SmokeTestMainDeleteDialogComponent,
        SmokeTestMainPopupComponent,
        SmokeTestMainDeletePopupComponent,
    ],
    entryComponents: [
        SmokeTestMainComponent,
        SmokeTestMainDialogComponent,
        SmokeTestMainPopupComponent,
        SmokeTestMainDeleteDialogComponent,
        SmokeTestMainDeletePopupComponent,
    ],
    providers: [
        SmokeTestMainService,
        SmokeTestMainPopupService,
        SmokeTestMainResolvePagingParams,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartISmokeTestMainModule {}
