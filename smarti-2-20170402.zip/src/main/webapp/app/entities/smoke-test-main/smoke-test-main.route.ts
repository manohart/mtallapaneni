import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, CanActivate } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { PaginationUtil } from 'ng-jhipster';

import { SmokeTestMainComponent } from './smoke-test-main.component';
import { SmokeTestMainDetailComponent } from './smoke-test-main-detail.component';
import { SmokeTestMainPopupComponent } from './smoke-test-main-dialog.component';
import { SmokeTestMainDeletePopupComponent } from './smoke-test-main-delete-dialog.component';

import { Principal } from '../../shared';

@Injectable()
export class SmokeTestMainResolvePagingParams implements Resolve<any> {

  constructor(private paginationUtil: PaginationUtil) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
      let page = route.queryParams['page'] ? route.queryParams['page'] : '1';
      let sort = route.queryParams['sort'] ? route.queryParams['sort'] : 'id,asc';
      return {
          page: this.paginationUtil.parsePage(page),
          predicate: this.paginationUtil.parsePredicate(sort),
          ascending: this.paginationUtil.parseAscending(sort)
    };
  }
}

export const smokeTestMainRoute: Routes = [
  {
    path: 'smoke-test-main',
    component: SmokeTestMainComponent,
    resolve: {
      'pagingParams': SmokeTestMainResolvePagingParams
    },
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'SmokeTestMains'
    }
  }, {
    path: 'smoke-test-main/:id',
    component: SmokeTestMainDetailComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'SmokeTestMains'
    }
  }
];

export const smokeTestMainPopupRoute: Routes = [
  {
    path: 'smoke-test-main-new',
    component: SmokeTestMainPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'SmokeTestMains'
    },
    outlet: 'popup'
  },
  {
    path: 'smoke-test-main/:id/edit',
    component: SmokeTestMainPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'SmokeTestMains'
    },
    outlet: 'popup'
  },
  {
    path: 'smoke-test-main/:id/delete',
    component: SmokeTestMainDeletePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'SmokeTestMains'
    },
    outlet: 'popup'
  }
];
