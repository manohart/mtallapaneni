import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager } from 'ng-jhipster';

import { SmokeTestResult } from './smoke-test-result.model';
import { SmokeTestResultPopupService } from './smoke-test-result-popup.service';
import { SmokeTestResultService } from './smoke-test-result.service';

@Component({
    selector: 'smarti-smoke-test-result-delete-dialog',
    templateUrl: './smoke-test-result-delete-dialog.component.html'
})
export class SmokeTestResultDeleteDialogComponent {

    smokeTestResult: SmokeTestResult;

    constructor(
        private smokeTestResultService: SmokeTestResultService,
        public activeModal: NgbActiveModal,
        private eventManager: EventManager
    ) {
    }

    clear () {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete (id: number) {
        this.smokeTestResultService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'smokeTestResultListModification',
                content: 'Deleted an smokeTestResult'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'smarti-smoke-test-result-delete-popup',
    template: ''
})
export class SmokeTestResultDeletePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private smokeTestResultPopupService: SmokeTestResultPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            this.modalRef = this.smokeTestResultPopupService
                .open(SmokeTestResultDeleteDialogComponent, params['id']);
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
