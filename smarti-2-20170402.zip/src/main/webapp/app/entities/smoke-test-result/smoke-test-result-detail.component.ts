import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SmokeTestResult } from './smoke-test-result.model';
import { SmokeTestResultService } from './smoke-test-result.service';

@Component({
    selector: 'smarti-smoke-test-result-detail',
    templateUrl: './smoke-test-result-detail.component.html'
})
export class SmokeTestResultDetailComponent implements OnInit, OnDestroy {

    smokeTestResult: SmokeTestResult;
    private subscription: any;

    constructor(
        private smokeTestResultService: SmokeTestResultService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.smokeTestResultService.find(id).subscribe(smokeTestResult => {
            this.smokeTestResult = smokeTestResult;
        });
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
