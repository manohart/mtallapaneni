import { Injectable, Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { SmokeTestResult } from './smoke-test-result.model';
import { SmokeTestResultService } from './smoke-test-result.service';
@Injectable()
export class SmokeTestResultPopupService {
    private isOpen = false;
    constructor (
        private datePipe: DatePipe,
        private modalService: NgbModal,
        private router: Router,
        private smokeTestResultService: SmokeTestResultService

    ) {}

    open (component: Component, id?: number | any): NgbModalRef {
        if (this.isOpen) {
            return;
        }
        this.isOpen = true;

        if (id) {
            this.smokeTestResultService.find(id).subscribe(smokeTestResult => {
                smokeTestResult.startDate = this.datePipe
                    .transform(smokeTestResult.startDate, 'yyyy-MM-ddThh:mm');
                smokeTestResult.endDate = this.datePipe
                    .transform(smokeTestResult.endDate, 'yyyy-MM-ddThh:mm');
                smokeTestResult.updatedDate = this.datePipe
                    .transform(smokeTestResult.updatedDate, 'yyyy-MM-ddThh:mm');
                this.smokeTestResultModalRef(component, smokeTestResult);
            });
        } else {
            return this.smokeTestResultModalRef(component, new SmokeTestResult());
        }
    }

    smokeTestResultModalRef(component: Component, smokeTestResult: SmokeTestResult): NgbModalRef {
        let modalRef = this.modalService.open(component, { size: 'lg', backdrop: 'static'});
        modalRef.componentInstance.smokeTestResult = smokeTestResult;
        modalRef.result.then(result => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        }, (reason) => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        });
        return modalRef;
    }
}
