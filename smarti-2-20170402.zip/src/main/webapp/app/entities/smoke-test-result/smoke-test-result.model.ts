import { SmokeTestMain } from '../smoke-test-main';
export class SmokeTestResult {
    constructor(
        public id?: number,
        public test?: string,
        public result?: string,
        public startDate?: any,
        public endDate?: any,
        public memFootprint?: number,
        public updatedDate?: any,
        public smokeTestMain?: SmokeTestMain,
    ) {
    }
}
