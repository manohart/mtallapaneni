import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SmartISharedModule } from '../../shared';

import {
    SmokeTestResultService,
    SmokeTestResultPopupService,
    SmokeTestResultComponent,
    SmokeTestResultDetailComponent,
    SmokeTestResultDialogComponent,
    SmokeTestResultPopupComponent,
    SmokeTestResultDeletePopupComponent,
    SmokeTestResultDeleteDialogComponent,
    smokeTestResultRoute,
    smokeTestResultPopupRoute,
    SmokeTestResultResolvePagingParams,
} from './';

let ENTITY_STATES = [
    ...smokeTestResultRoute,
    ...smokeTestResultPopupRoute,
];

@NgModule({
    imports: [
        SmartISharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [
        SmokeTestResultComponent,
        SmokeTestResultDetailComponent,
        SmokeTestResultDialogComponent,
        SmokeTestResultDeleteDialogComponent,
        SmokeTestResultPopupComponent,
        SmokeTestResultDeletePopupComponent,
    ],
    entryComponents: [
        SmokeTestResultComponent,
        SmokeTestResultDialogComponent,
        SmokeTestResultPopupComponent,
        SmokeTestResultDeleteDialogComponent,
        SmokeTestResultDeletePopupComponent,
    ],
    providers: [
        SmokeTestResultService,
        SmokeTestResultPopupService,
        SmokeTestResultResolvePagingParams,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartISmokeTestResultModule {}
