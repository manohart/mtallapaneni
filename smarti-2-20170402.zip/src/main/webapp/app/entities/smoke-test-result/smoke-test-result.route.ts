import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, CanActivate } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { PaginationUtil } from 'ng-jhipster';

import { SmokeTestResultComponent } from './smoke-test-result.component';
import { SmokeTestResultDetailComponent } from './smoke-test-result-detail.component';
import { SmokeTestResultPopupComponent } from './smoke-test-result-dialog.component';
import { SmokeTestResultDeletePopupComponent } from './smoke-test-result-delete-dialog.component';

import { Principal } from '../../shared';

@Injectable()
export class SmokeTestResultResolvePagingParams implements Resolve<any> {

  constructor(private paginationUtil: PaginationUtil) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
      let page = route.queryParams['page'] ? route.queryParams['page'] : '1';
      let sort = route.queryParams['sort'] ? route.queryParams['sort'] : 'id,asc';
      return {
          page: this.paginationUtil.parsePage(page),
          predicate: this.paginationUtil.parsePredicate(sort),
          ascending: this.paginationUtil.parseAscending(sort)
    };
  }
}

export const smokeTestResultRoute: Routes = [
  {
    path: 'smoke-test-result',
    component: SmokeTestResultComponent,
    resolve: {
      'pagingParams': SmokeTestResultResolvePagingParams
    },
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'SmokeTestResults'
    }
  }, {
    path: 'smoke-test-result/:id',
    component: SmokeTestResultDetailComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'SmokeTestResults'
    }
  }
];

export const smokeTestResultPopupRoute: Routes = [
  {
    path: 'smoke-test-result-new',
    component: SmokeTestResultPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'SmokeTestResults'
    },
    outlet: 'popup'
  },
  {
    path: 'smoke-test-result/:id/edit',
    component: SmokeTestResultPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'SmokeTestResults'
    },
    outlet: 'popup'
  },
  {
    path: 'smoke-test-result/:id/delete',
    component: SmokeTestResultDeletePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'SmokeTestResults'
    },
    outlet: 'popup'
  }
];
