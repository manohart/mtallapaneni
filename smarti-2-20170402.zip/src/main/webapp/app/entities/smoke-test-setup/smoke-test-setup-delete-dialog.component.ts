import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager } from 'ng-jhipster';

import { SmokeTestSetup } from './smoke-test-setup.model';
import { SmokeTestSetupPopupService } from './smoke-test-setup-popup.service';
import { SmokeTestSetupService } from './smoke-test-setup.service';

@Component({
    selector: 'smarti-smoke-test-setup-delete-dialog',
    templateUrl: './smoke-test-setup-delete-dialog.component.html'
})
export class SmokeTestSetupDeleteDialogComponent {

    smokeTestSetup: SmokeTestSetup;

    constructor(
        private smokeTestSetupService: SmokeTestSetupService,
        public activeModal: NgbActiveModal,
        private eventManager: EventManager
    ) {
    }

    clear () {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete (id: number) {
        this.smokeTestSetupService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'smokeTestSetupListModification',
                content: 'Deleted an smokeTestSetup'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'smarti-smoke-test-setup-delete-popup',
    template: ''
})
export class SmokeTestSetupDeletePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private smokeTestSetupPopupService: SmokeTestSetupPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            this.modalRef = this.smokeTestSetupPopupService
                .open(SmokeTestSetupDeleteDialogComponent, params['id']);
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
