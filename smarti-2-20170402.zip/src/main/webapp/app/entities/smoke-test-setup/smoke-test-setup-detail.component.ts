import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataUtils } from 'ng-jhipster';
import { SmokeTestSetup } from './smoke-test-setup.model';
import { SmokeTestSetupService } from './smoke-test-setup.service';

@Component({
    selector: 'smarti-smoke-test-setup-detail',
    templateUrl: './smoke-test-setup-detail.component.html'
})
export class SmokeTestSetupDetailComponent implements OnInit, OnDestroy {

    smokeTestSetup: SmokeTestSetup;
    private subscription: any;

    constructor(
        private dataUtils: DataUtils,
        private smokeTestSetupService: SmokeTestSetupService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.smokeTestSetupService.find(id).subscribe(smokeTestSetup => {
            this.smokeTestSetup = smokeTestSetup;
        });
    }
    byteSize(field) {
        return this.dataUtils.byteSize(field);
    }

    openFile(contentType, field) {
        return this.dataUtils.openFile(contentType, field);
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
