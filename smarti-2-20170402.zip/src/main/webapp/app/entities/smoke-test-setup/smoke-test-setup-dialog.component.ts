import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager, AlertService, DataUtils } from 'ng-jhipster';

import { SmokeTestSetup } from './smoke-test-setup.model';
import { SmokeTestSetupPopupService } from './smoke-test-setup-popup.service';
import { SmokeTestSetupService } from './smoke-test-setup.service';
import { SmokeTestMain, SmokeTestMainService } from '../smoke-test-main';

@Component({
    selector: 'smarti-smoke-test-setup-dialog',
    templateUrl: './smoke-test-setup-dialog.component.html'
})
export class SmokeTestSetupDialogComponent implements OnInit {

    smokeTestSetup: SmokeTestSetup;
    authorities: any[];
    isSaving: boolean;

    smoketestmains: SmokeTestMain[];
    constructor(
        public activeModal: NgbActiveModal,
        private dataUtils: DataUtils,
        private alertService: AlertService,
        private smokeTestSetupService: SmokeTestSetupService,
        private smokeTestMainService: SmokeTestMainService,
        private eventManager: EventManager
    ) {
    }

    ngOnInit() {
        this.isSaving = false;
        this.authorities = ['ROLE_USER', 'ROLE_ADMIN'];
        this.smokeTestMainService.query().subscribe(
            (res: Response) => { this.smoketestmains = res.json(); }, (res: Response) => this.onError(res.json()));
    }
    byteSize(field) {
        return this.dataUtils.byteSize(field);
    }

    openFile(contentType, field) {
        return this.dataUtils.openFile(contentType, field);
    }

    setFileData($event, smokeTestSetup, field, isImage) {
        if ($event.target.files && $event.target.files[0]) {
            let $file = $event.target.files[0];
            if (isImage && !/^image\//.test($file.type)) {
                return;
            }
            this.dataUtils.toBase64($file, (base64Data) => {
                smokeTestSetup[field] = base64Data;
                smokeTestSetup[`${field}ContentType`] = $file.type;
            });
        }
    }
    clear () {
        this.activeModal.dismiss('cancel');
    }

    save () {
        this.isSaving = true;
        if (this.smokeTestSetup.id !== undefined) {
            this.smokeTestSetupService.update(this.smokeTestSetup)
                .subscribe((res: SmokeTestSetup) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        } else {
            this.smokeTestSetupService.create(this.smokeTestSetup)
                .subscribe((res: SmokeTestSetup) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        }
    }

    private onSaveSuccess (result: SmokeTestSetup) {
        this.eventManager.broadcast({ name: 'smokeTestSetupListModification', content: 'OK'});
        this.isSaving = false;
        this.activeModal.dismiss(result);
    }

    private onSaveError (error) {
        this.isSaving = false;
        this.onError(error);
    }

    private onError (error) {
        this.alertService.error(error.message, null, null);
    }

    trackSmokeTestMainById(index: number, item: SmokeTestMain) {
        return item.id;
    }
}

@Component({
    selector: 'smarti-smoke-test-setup-popup',
    template: ''
})
export class SmokeTestSetupPopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private smokeTestSetupPopupService: SmokeTestSetupPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            if ( params['id'] ) {
                this.modalRef = this.smokeTestSetupPopupService
                    .open(SmokeTestSetupDialogComponent, params['id']);
            } else {
                this.modalRef = this.smokeTestSetupPopupService
                    .open(SmokeTestSetupDialogComponent);
            }

        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
