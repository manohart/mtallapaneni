import { SmokeTestMain } from '../smoke-test-main';
export class SmokeTestSetup {
    constructor(
        public id?: number,
        public lob?: string,
        public app?: string,
        public description?: any,
        public owner?: string,
        public updatedDate?: any,
        public testSummary?: SmokeTestMain,
    ) {
    }
}
