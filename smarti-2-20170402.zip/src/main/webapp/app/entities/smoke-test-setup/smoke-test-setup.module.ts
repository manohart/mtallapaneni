import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SmartISharedModule } from '../../shared';

import {
    SmokeTestSetupService,
    SmokeTestSetupPopupService,
    SmokeTestSetupComponent,
    SmokeTestSetupDetailComponent,
    SmokeTestSetupDialogComponent,
    SmokeTestSetupPopupComponent,
    SmokeTestSetupDeletePopupComponent,
    SmokeTestSetupDeleteDialogComponent,
    smokeTestSetupRoute,
    smokeTestSetupPopupRoute,
    SmokeTestSetupResolvePagingParams,
} from './';

let ENTITY_STATES = [
    ...smokeTestSetupRoute,
    ...smokeTestSetupPopupRoute,
];

@NgModule({
    imports: [
        SmartISharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [
        SmokeTestSetupComponent,
        SmokeTestSetupDetailComponent,
        SmokeTestSetupDialogComponent,
        SmokeTestSetupDeleteDialogComponent,
        SmokeTestSetupPopupComponent,
        SmokeTestSetupDeletePopupComponent,
    ],
    entryComponents: [
        SmokeTestSetupComponent,
        SmokeTestSetupDialogComponent,
        SmokeTestSetupPopupComponent,
        SmokeTestSetupDeleteDialogComponent,
        SmokeTestSetupDeletePopupComponent,
    ],
    providers: [
        SmokeTestSetupService,
        SmokeTestSetupPopupService,
        SmokeTestSetupResolvePagingParams,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartISmokeTestSetupModule {}
