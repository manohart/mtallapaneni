import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, CanActivate } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { PaginationUtil } from 'ng-jhipster';

import { SmokeTestSetupComponent } from './smoke-test-setup.component';
import { SmokeTestSetupDetailComponent } from './smoke-test-setup-detail.component';
import { SmokeTestSetupPopupComponent } from './smoke-test-setup-dialog.component';
import { SmokeTestSetupDeletePopupComponent } from './smoke-test-setup-delete-dialog.component';

import { Principal } from '../../shared';

@Injectable()
export class SmokeTestSetupResolvePagingParams implements Resolve<any> {

  constructor(private paginationUtil: PaginationUtil) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
      let page = route.queryParams['page'] ? route.queryParams['page'] : '1';
      let sort = route.queryParams['sort'] ? route.queryParams['sort'] : 'id,asc';
      return {
          page: this.paginationUtil.parsePage(page),
          predicate: this.paginationUtil.parsePredicate(sort),
          ascending: this.paginationUtil.parseAscending(sort)
    };
  }
}

export const smokeTestSetupRoute: Routes = [
  {
    path: 'smoke-test-setup',
    component: SmokeTestSetupComponent,
    resolve: {
      'pagingParams': SmokeTestSetupResolvePagingParams
    },
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'SmokeTestSetups'
    }
  }, {
    path: 'smoke-test-setup/:id',
    component: SmokeTestSetupDetailComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'SmokeTestSetups'
    }
  }
];

export const smokeTestSetupPopupRoute: Routes = [
  {
    path: 'smoke-test-setup-new',
    component: SmokeTestSetupPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'SmokeTestSetups'
    },
    outlet: 'popup'
  },
  {
    path: 'smoke-test-setup/:id/edit',
    component: SmokeTestSetupPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'SmokeTestSetups'
    },
    outlet: 'popup'
  },
  {
    path: 'smoke-test-setup/:id/delete',
    component: SmokeTestSetupDeletePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'SmokeTestSetups'
    },
    outlet: 'popup'
  }
];
