import { Injectable, Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { SoftwareRelease } from './software-release.model';
import { SoftwareReleaseService } from './software-release.service';
@Injectable()
export class SoftwareReleasePopupService {
    private isOpen = false;
    constructor (
        private datePipe: DatePipe,
        private modalService: NgbModal,
        private router: Router,
        private softwareReleaseService: SoftwareReleaseService

    ) {}

    open (component: Component, id?: number | any): NgbModalRef {
        if (this.isOpen) {
            return;
        }
        this.isOpen = true;

        if (id) {
            this.softwareReleaseService.find(id).subscribe(softwareRelease => {
                if (softwareRelease.releaseDate) {
                    softwareRelease.releaseDate = {
                        year: softwareRelease.releaseDate.getFullYear(),
                        month: softwareRelease.releaseDate.getMonth() + 1,
                        day: softwareRelease.releaseDate.getDate()
                    };
                }
                if (softwareRelease.plannedReleaseDate) {
                    softwareRelease.plannedReleaseDate = {
                        year: softwareRelease.plannedReleaseDate.getFullYear(),
                        month: softwareRelease.plannedReleaseDate.getMonth() + 1,
                        day: softwareRelease.plannedReleaseDate.getDate()
                    };
                }
                softwareRelease.updatedDate = this.datePipe
                    .transform(softwareRelease.updatedDate, 'yyyy-MM-ddThh:mm');
                this.softwareReleaseModalRef(component, softwareRelease);
            });
        } else {
            return this.softwareReleaseModalRef(component, new SoftwareRelease());
        }
    }

    softwareReleaseModalRef(component: Component, softwareRelease: SoftwareRelease): NgbModalRef {
        let modalRef = this.modalService.open(component, { size: 'lg', backdrop: 'static'});
        modalRef.componentInstance.softwareRelease = softwareRelease;
        modalRef.result.then(result => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        }, (reason) => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        });
        return modalRef;
    }
}
