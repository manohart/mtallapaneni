
const enum ReleaseType {
    'MAJOR',
    'MINOR',
    'MAINTENANCE',
    'EMMERGENCY',
    'OTHER'

};

const enum ReleaseState {
    'PRE_ALPHA',
    'ALPHA',
    'BETA',
    'RELEASE_CANDIDATE',
    'FINAL_RELEASE'

};
import { Product } from '../product';
export class SoftwareRelease {
    constructor(
        public id?: number,
        public type?: ReleaseType,
        public releaseDate?: any,
        public sprint?: string,
        public version?: string,
        public newFeatures?: any,
        public enhancements?: any,
        public bugFixes?: any,
        public knownIssues?: any,
        public releaseState?: ReleaseState,
        public plannedReleaseDate?: any,
        public summary?: any,
        public updatedDate?: any,
        public software?: Product,
    ) {
    }
}
