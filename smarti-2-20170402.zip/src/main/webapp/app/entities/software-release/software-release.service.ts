import { Injectable } from '@angular/core';
import { Http, Response, URLSearchParams, BaseRequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';

import { SoftwareRelease } from './software-release.model';
import { DateUtils } from 'ng-jhipster';
@Injectable()
export class SoftwareReleaseService {

    private resourceUrl = 'api/software-releases';
    private resourceSearchUrl = 'api/_search/software-releases';

    constructor(private http: Http, private dateUtils: DateUtils) { }

    create(softwareRelease: SoftwareRelease): Observable<SoftwareRelease> {
        let copy: SoftwareRelease = Object.assign({}, softwareRelease);
        copy.releaseDate = this.dateUtils
            .convertLocalDateToServer(softwareRelease.releaseDate);
        copy.plannedReleaseDate = this.dateUtils
            .convertLocalDateToServer(softwareRelease.plannedReleaseDate);
        copy.updatedDate = this.dateUtils.toDate(softwareRelease.updatedDate);
        return this.http.post(this.resourceUrl, copy).map((res: Response) => {
            return res.json();
        });
    }

    update(softwareRelease: SoftwareRelease): Observable<SoftwareRelease> {
        let copy: SoftwareRelease = Object.assign({}, softwareRelease);
        copy.releaseDate = this.dateUtils
            .convertLocalDateToServer(softwareRelease.releaseDate);
        copy.plannedReleaseDate = this.dateUtils
            .convertLocalDateToServer(softwareRelease.plannedReleaseDate);

        copy.updatedDate = this.dateUtils.toDate(softwareRelease.updatedDate);
        return this.http.put(this.resourceUrl, copy).map((res: Response) => {
            return res.json();
        });
    }

    find(id: number): Observable<SoftwareRelease> {
        return this.http.get(`${this.resourceUrl}/${id}`).map((res: Response) => {
            let jsonResponse = res.json();
            jsonResponse.releaseDate = this.dateUtils
                .convertLocalDateFromServer(jsonResponse.releaseDate);
            jsonResponse.plannedReleaseDate = this.dateUtils
                .convertLocalDateFromServer(jsonResponse.plannedReleaseDate);
            jsonResponse.updatedDate = this.dateUtils
                .convertDateTimeFromServer(jsonResponse.updatedDate);
            return jsonResponse;
        });
    }

    query(req?: any): Observable<Response> {
        let options = this.createRequestOption(req);
        return this.http.get(this.resourceUrl, options)
            .map((res: any) => this.convertResponse(res))
        ;
    }

    delete(id: number): Observable<Response> {
        return this.http.delete(`${this.resourceUrl}/${id}`);
    }

    search(req?: any): Observable<Response> {
        let options = this.createRequestOption(req);
        return this.http.get(this.resourceSearchUrl, options)
            .map((res: any) => this.convertResponse(res))
        ;
    }

    private convertResponse(res: any): any {
        let jsonResponse = res.json();
        for (let i = 0; i < jsonResponse.length; i++) {
            jsonResponse[i].releaseDate = this.dateUtils
                .convertLocalDateFromServer(jsonResponse[i].releaseDate);
            jsonResponse[i].plannedReleaseDate = this.dateUtils
                .convertLocalDateFromServer(jsonResponse[i].plannedReleaseDate);
            jsonResponse[i].updatedDate = this.dateUtils
                .convertDateTimeFromServer(jsonResponse[i].updatedDate);
        }
        res._body = jsonResponse;
        return res;
    }

    private createRequestOption(req?: any): BaseRequestOptions {
        let options: BaseRequestOptions = new BaseRequestOptions();
        if (req) {
            let params: URLSearchParams = new URLSearchParams();
            params.set('page', req.page);
            params.set('size', req.size);
            if (req.sort) {
                params.paramsMap.set('sort', req.sort);
            }
            params.set('query', req.query);

            options.search = params;
        }
        return options;
    }
}
