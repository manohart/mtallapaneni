
const enum TemplateType {
    'BATCH_REPORT',
    'RELEASE_NOTE',
    'DELAY_ALERT',
    'BUSINESS_NOTIFICATION',
    'SUPPORT_NOTIFICATION'

};
import { LineOfBusiness } from '../line-of-business';
export class Template {
    constructor(
        public id?: number,
        public name?: string,
        public description?: string,
        public type?: TemplateType,
        public path?: string,
        public startDate?: any,
        public endDate?: any,
        public updatedDate?: any,
        public lob?: LineOfBusiness,
    ) {
    }
}
