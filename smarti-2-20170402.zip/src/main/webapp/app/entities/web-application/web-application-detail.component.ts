import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { WebApplication } from './web-application.model';
import { WebApplicationService } from './web-application.service';

@Component({
    selector: 'smarti-web-application-detail',
    templateUrl: './web-application-detail.component.html'
})
export class WebApplicationDetailComponent implements OnInit, OnDestroy {

    webApplication: WebApplication;
    private subscription: any;

    constructor(
        private webApplicationService: WebApplicationService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.webApplicationService.find(id).subscribe(webApplication => {
            this.webApplication = webApplication;
        });
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
