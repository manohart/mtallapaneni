import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, CanActivate } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { PaginationUtil } from 'ng-jhipster';

import { WebApplicationComponent } from './web-application.component';
import { WebApplicationDetailComponent } from './web-application-detail.component';
import { WebApplicationPopupComponent } from './web-application-dialog.component';
import { WebApplicationDeletePopupComponent } from './web-application-delete-dialog.component';

import { Principal } from '../../shared';

@Injectable()
export class WebApplicationResolvePagingParams implements Resolve<any> {

  constructor(private paginationUtil: PaginationUtil) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
      let page = route.queryParams['page'] ? route.queryParams['page'] : '1';
      let sort = route.queryParams['sort'] ? route.queryParams['sort'] : 'id,asc';
      return {
          page: this.paginationUtil.parsePage(page),
          predicate: this.paginationUtil.parsePredicate(sort),
          ascending: this.paginationUtil.parseAscending(sort)
    };
  }
}

export const webApplicationRoute: Routes = [
  {
    path: 'web-application',
    component: WebApplicationComponent,
    resolve: {
      'pagingParams': WebApplicationResolvePagingParams
    },
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'WebApplications'
    }
  }, {
    path: 'web-application/:id',
    component: WebApplicationDetailComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'WebApplications'
    }
  }
];

export const webApplicationPopupRoute: Routes = [
  {
    path: 'web-application-new',
    component: WebApplicationPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'WebApplications'
    },
    outlet: 'popup'
  },
  {
    path: 'web-application/:id/edit',
    component: WebApplicationPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'WebApplications'
    },
    outlet: 'popup'
  },
  {
    path: 'web-application/:id/delete',
    component: WebApplicationDeletePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'WebApplications'
    },
    outlet: 'popup'
  }
];
