import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager, AlertService } from 'ng-jhipster';

import { WebServiceConsumer } from './web-service-consumer.model';
import { WebServiceConsumerPopupService } from './web-service-consumer-popup.service';
import { WebServiceConsumerService } from './web-service-consumer.service';
import { Application, ApplicationService } from '../application';
import { WebService, WebServiceService } from '../web-service';

@Component({
    selector: 'smarti-web-service-consumer-dialog',
    templateUrl: './web-service-consumer-dialog.component.html'
})
export class WebServiceConsumerDialogComponent implements OnInit {

    webServiceConsumer: WebServiceConsumer;
    authorities: any[];
    isSaving: boolean;

    applications: Application[];

    webservices: WebService[];
    constructor(
        public activeModal: NgbActiveModal,
        private alertService: AlertService,
        private webServiceConsumerService: WebServiceConsumerService,
        private applicationService: ApplicationService,
        private webServiceService: WebServiceService,
        private eventManager: EventManager
    ) {
    }

    ngOnInit() {
        this.isSaving = false;
        this.authorities = ['ROLE_USER', 'ROLE_ADMIN'];
        this.applicationService.query().subscribe(
            (res: Response) => { this.applications = res.json(); }, (res: Response) => this.onError(res.json()));
        this.webServiceService.query().subscribe(
            (res: Response) => { this.webservices = res.json(); }, (res: Response) => this.onError(res.json()));
    }
    clear () {
        this.activeModal.dismiss('cancel');
    }

    save () {
        this.isSaving = true;
        if (this.webServiceConsumer.id !== undefined) {
            this.webServiceConsumerService.update(this.webServiceConsumer)
                .subscribe((res: WebServiceConsumer) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        } else {
            this.webServiceConsumerService.create(this.webServiceConsumer)
                .subscribe((res: WebServiceConsumer) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        }
    }

    private onSaveSuccess (result: WebServiceConsumer) {
        this.eventManager.broadcast({ name: 'webServiceConsumerListModification', content: 'OK'});
        this.isSaving = false;
        this.activeModal.dismiss(result);
    }

    private onSaveError (error) {
        this.isSaving = false;
        this.onError(error);
    }

    private onError (error) {
        this.alertService.error(error.message, null, null);
    }

    trackApplicationById(index: number, item: Application) {
        return item.id;
    }

    trackWebServiceById(index: number, item: WebService) {
        return item.id;
    }
}

@Component({
    selector: 'smarti-web-service-consumer-popup',
    template: ''
})
export class WebServiceConsumerPopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private webServiceConsumerPopupService: WebServiceConsumerPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            if ( params['id'] ) {
                this.modalRef = this.webServiceConsumerPopupService
                    .open(WebServiceConsumerDialogComponent, params['id']);
            } else {
                this.modalRef = this.webServiceConsumerPopupService
                    .open(WebServiceConsumerDialogComponent);
            }

        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
