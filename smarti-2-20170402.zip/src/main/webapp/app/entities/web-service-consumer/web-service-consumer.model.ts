import { Application } from '../application';
import { WebService } from '../web-service';
export class WebServiceConsumer {
    constructor(
        public id?: number,
        public startDate?: any,
        public endDate?: any,
        public updatedDate?: any,
        public consumer?: Application,
        public prodcuer?: WebService,
    ) {
    }
}
