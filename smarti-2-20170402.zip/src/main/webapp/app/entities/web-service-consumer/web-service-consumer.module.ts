import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SmartISharedModule } from '../../shared';

import {
    WebServiceConsumerService,
    WebServiceConsumerPopupService,
    WebServiceConsumerComponent,
    WebServiceConsumerDetailComponent,
    WebServiceConsumerDialogComponent,
    WebServiceConsumerPopupComponent,
    WebServiceConsumerDeletePopupComponent,
    WebServiceConsumerDeleteDialogComponent,
    webServiceConsumerRoute,
    webServiceConsumerPopupRoute,
    WebServiceConsumerResolvePagingParams,
} from './';

let ENTITY_STATES = [
    ...webServiceConsumerRoute,
    ...webServiceConsumerPopupRoute,
];

@NgModule({
    imports: [
        SmartISharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [
        WebServiceConsumerComponent,
        WebServiceConsumerDetailComponent,
        WebServiceConsumerDialogComponent,
        WebServiceConsumerDeleteDialogComponent,
        WebServiceConsumerPopupComponent,
        WebServiceConsumerDeletePopupComponent,
    ],
    entryComponents: [
        WebServiceConsumerComponent,
        WebServiceConsumerDialogComponent,
        WebServiceConsumerPopupComponent,
        WebServiceConsumerDeleteDialogComponent,
        WebServiceConsumerDeletePopupComponent,
    ],
    providers: [
        WebServiceConsumerService,
        WebServiceConsumerPopupService,
        WebServiceConsumerResolvePagingParams,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartIWebServiceConsumerModule {}
