import { WebServiceConsumer } from '../web-service-consumer';
import { WebApplication } from '../web-application';
export class WebService {
    constructor(
        public id?: number,
        public name?: string,
        public description?: any,
        public resourcePath?: string,
        public startDate?: any,
        public endDate?: any,
        public updatedDate?: any,
        public consumer?: WebServiceConsumer,
        public webApplication?: WebApplication,
    ) {
    }
}
