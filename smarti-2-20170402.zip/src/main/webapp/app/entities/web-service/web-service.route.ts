import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, CanActivate } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { PaginationUtil } from 'ng-jhipster';

import { WebServiceComponent } from './web-service.component';
import { WebServiceDetailComponent } from './web-service-detail.component';
import { WebServicePopupComponent } from './web-service-dialog.component';
import { WebServiceDeletePopupComponent } from './web-service-delete-dialog.component';

import { Principal } from '../../shared';

@Injectable()
export class WebServiceResolvePagingParams implements Resolve<any> {

  constructor(private paginationUtil: PaginationUtil) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
      let page = route.queryParams['page'] ? route.queryParams['page'] : '1';
      let sort = route.queryParams['sort'] ? route.queryParams['sort'] : 'id,asc';
      return {
          page: this.paginationUtil.parsePage(page),
          predicate: this.paginationUtil.parsePredicate(sort),
          ascending: this.paginationUtil.parseAscending(sort)
    };
  }
}

export const webServiceRoute: Routes = [
  {
    path: 'web-service',
    component: WebServiceComponent,
    resolve: {
      'pagingParams': WebServiceResolvePagingParams
    },
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'WebServices'
    }
  }, {
    path: 'web-service/:id',
    component: WebServiceDetailComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'WebServices'
    }
  }
];

export const webServicePopupRoute: Routes = [
  {
    path: 'web-service-new',
    component: WebServicePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'WebServices'
    },
    outlet: 'popup'
  },
  {
    path: 'web-service/:id/edit',
    component: WebServicePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'WebServices'
    },
    outlet: 'popup'
  },
  {
    path: 'web-service/:id/delete',
    component: WebServiceDeletePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'WebServices'
    },
    outlet: 'popup'
  }
];
