/* after changing this file run 'npm run webpack:build:vendor' or 'npm install' or 'npm run webpack:build' */
/* tslint:disable */
import '../content/css/vendor.css';
