/**
 * Spring Framework configuration files.
 */
package org.mano.smarti.config;
