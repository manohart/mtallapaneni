/**
 * JPA domain objects.
 */
package org.mano.smarti.domain;
