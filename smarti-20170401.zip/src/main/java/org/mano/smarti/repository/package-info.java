/**
 * Spring Data JPA repositories.
 */
package org.mano.smarti.repository;
