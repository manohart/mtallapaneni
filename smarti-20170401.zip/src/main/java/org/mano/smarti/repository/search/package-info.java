/**
 * Spring Data Elasticsearch repositories.
 */
package org.mano.smarti.repository.search;
