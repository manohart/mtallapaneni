/**
 * Service layer beans.
 */
package org.mano.smarti.service;
