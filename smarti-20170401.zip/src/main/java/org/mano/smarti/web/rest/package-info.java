/**
 * Spring MVC REST controllers.
 */
package org.mano.smarti.web.rest;
