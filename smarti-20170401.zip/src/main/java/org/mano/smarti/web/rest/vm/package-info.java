/**
 * View Models used by Spring MVC REST controllers.
 */
package org.mano.smarti.web.rest.vm;
