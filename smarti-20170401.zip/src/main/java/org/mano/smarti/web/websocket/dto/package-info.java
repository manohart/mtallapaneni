/**
 * Data Access Objects used by WebSocket services.
 */
package org.mano.smarti.web.websocket.dto;
