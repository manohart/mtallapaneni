/**
 * WebSocket services, using Spring Websocket.
 */
package org.mano.smarti.web.websocket;
