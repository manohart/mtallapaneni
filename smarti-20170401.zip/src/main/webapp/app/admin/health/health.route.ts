import { Route } from '@angular/router';

import { SmartiHealthCheckComponent } from './health.component';

export const healthRoute: Route = {
  path: 'smarti-health',
  component: SmartiHealthCheckComponent,
  data: {
    pageTitle: 'Health Checks'
  }
};
