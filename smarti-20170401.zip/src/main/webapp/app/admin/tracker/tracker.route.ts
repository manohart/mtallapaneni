import { Route } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { SmartiTrackerComponent } from './tracker.component';
import { SmartiTrackerService, Principal } from '../../shared';

export const trackerRoute: Route = {
  path: 'smarti-tracker',
  component: SmartiTrackerComponent,
  data: {
    pageTitle: 'Real-time user activities'
  }
};
