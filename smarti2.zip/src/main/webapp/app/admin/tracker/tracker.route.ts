import { Route } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { JhiTrackerComponent } from './tracker.component';
import { JhiTrackerService, Principal } from '../../shared';

export const trackerRoute: Route = {
  path: 'jhi-tracker',
  component: JhiTrackerComponent,
  data: {
    pageTitle: 'Real-time user activities'
  }
};
