import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager } from 'ng-jhipster';

import { ActiveBusinessDate } from './active-business-date.model';
import { ActiveBusinessDatePopupService } from './active-business-date-popup.service';
import { ActiveBusinessDateService } from './active-business-date.service';

@Component({
    selector: 'marti-active-business-date-delete-dialog',
    templateUrl: './active-business-date-delete-dialog.component.html'
})
export class ActiveBusinessDateDeleteDialogComponent {

    activeBusinessDate: ActiveBusinessDate;

    constructor(
        private activeBusinessDateService: ActiveBusinessDateService,
        public activeModal: NgbActiveModal,
        private eventManager: EventManager
    ) {
    }

    clear () {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete (id: number) {
        this.activeBusinessDateService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'activeBusinessDateListModification',
                content: 'Deleted an activeBusinessDate'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'marti-active-business-date-delete-popup',
    template: ''
})
export class ActiveBusinessDateDeletePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private activeBusinessDatePopupService: ActiveBusinessDatePopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            this.modalRef = this.activeBusinessDatePopupService
                .open(ActiveBusinessDateDeleteDialogComponent, params['id']);
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
