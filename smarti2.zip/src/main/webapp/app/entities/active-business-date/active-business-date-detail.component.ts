import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ActiveBusinessDate } from './active-business-date.model';
import { ActiveBusinessDateService } from './active-business-date.service';

@Component({
    selector: 'marti-active-business-date-detail',
    templateUrl: './active-business-date-detail.component.html'
})
export class ActiveBusinessDateDetailComponent implements OnInit, OnDestroy {

    activeBusinessDate: ActiveBusinessDate;
    private subscription: any;

    constructor(
        private activeBusinessDateService: ActiveBusinessDateService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.activeBusinessDateService.find(id).subscribe(activeBusinessDate => {
            this.activeBusinessDate = activeBusinessDate;
        });
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
