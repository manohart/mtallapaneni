import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager, AlertService } from 'ng-jhipster';

import { ActiveBusinessDate } from './active-business-date.model';
import { ActiveBusinessDatePopupService } from './active-business-date-popup.service';
import { ActiveBusinessDateService } from './active-business-date.service';

@Component({
    selector: 'marti-active-business-date-dialog',
    templateUrl: './active-business-date-dialog.component.html'
})
export class ActiveBusinessDateDialogComponent implements OnInit {

    activeBusinessDate: ActiveBusinessDate;
    authorities: any[];
    isSaving: boolean;
    constructor(
        public activeModal: NgbActiveModal,
        private alertService: AlertService,
        private activeBusinessDateService: ActiveBusinessDateService,
        private eventManager: EventManager
    ) {
    }

    ngOnInit() {
        this.isSaving = false;
        this.authorities = ['ROLE_USER', 'ROLE_ADMIN'];
    }
    clear () {
        this.activeModal.dismiss('cancel');
    }

    save () {
        this.isSaving = true;
        if (this.activeBusinessDate.id !== undefined) {
            this.activeBusinessDateService.update(this.activeBusinessDate)
                .subscribe((res: ActiveBusinessDate) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        } else {
            this.activeBusinessDateService.create(this.activeBusinessDate)
                .subscribe((res: ActiveBusinessDate) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        }
    }

    private onSaveSuccess (result: ActiveBusinessDate) {
        this.eventManager.broadcast({ name: 'activeBusinessDateListModification', content: 'OK'});
        this.isSaving = false;
        this.activeModal.dismiss(result);
    }

    private onSaveError (error) {
        this.isSaving = false;
        this.onError(error);
    }

    private onError (error) {
        this.alertService.error(error.message, null, null);
    }
}

@Component({
    selector: 'marti-active-business-date-popup',
    template: ''
})
export class ActiveBusinessDatePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private activeBusinessDatePopupService: ActiveBusinessDatePopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            if ( params['id'] ) {
                this.modalRef = this.activeBusinessDatePopupService
                    .open(ActiveBusinessDateDialogComponent, params['id']);
            } else {
                this.modalRef = this.activeBusinessDatePopupService
                    .open(ActiveBusinessDateDialogComponent);
            }

        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
