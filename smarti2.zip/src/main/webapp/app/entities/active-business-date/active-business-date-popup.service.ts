import { Injectable, Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { ActiveBusinessDate } from './active-business-date.model';
import { ActiveBusinessDateService } from './active-business-date.service';
@Injectable()
export class ActiveBusinessDatePopupService {
    private isOpen = false;
    constructor (
        private datePipe: DatePipe,
        private modalService: NgbModal,
        private router: Router,
        private activeBusinessDateService: ActiveBusinessDateService

    ) {}

    open (component: Component, id?: number | any): NgbModalRef {
        if (this.isOpen) {
            return;
        }
        this.isOpen = true;

        if (id) {
            this.activeBusinessDateService.find(id).subscribe(activeBusinessDate => {
                if (activeBusinessDate.calendarDate) {
                    activeBusinessDate.calendarDate = {
                        year: activeBusinessDate.calendarDate.getFullYear(),
                        month: activeBusinessDate.calendarDate.getMonth() + 1,
                        day: activeBusinessDate.calendarDate.getDate()
                    };
                }
                if (activeBusinessDate.businessDate) {
                    activeBusinessDate.businessDate = {
                        year: activeBusinessDate.businessDate.getFullYear(),
                        month: activeBusinessDate.businessDate.getMonth() + 1,
                        day: activeBusinessDate.businessDate.getDate()
                    };
                }
                if (activeBusinessDate.previousBusinessDate) {
                    activeBusinessDate.previousBusinessDate = {
                        year: activeBusinessDate.previousBusinessDate.getFullYear(),
                        month: activeBusinessDate.previousBusinessDate.getMonth() + 1,
                        day: activeBusinessDate.previousBusinessDate.getDate()
                    };
                }
                if (activeBusinessDate.nextBusinessDate) {
                    activeBusinessDate.nextBusinessDate = {
                        year: activeBusinessDate.nextBusinessDate.getFullYear(),
                        month: activeBusinessDate.nextBusinessDate.getMonth() + 1,
                        day: activeBusinessDate.nextBusinessDate.getDate()
                    };
                }
                activeBusinessDate.updatedDate = this.datePipe
                    .transform(activeBusinessDate.updatedDate, 'yyyy-MM-ddThh:mm');
                this.activeBusinessDateModalRef(component, activeBusinessDate);
            });
        } else {
            return this.activeBusinessDateModalRef(component, new ActiveBusinessDate());
        }
    }

    activeBusinessDateModalRef(component: Component, activeBusinessDate: ActiveBusinessDate): NgbModalRef {
        let modalRef = this.modalService.open(component, { size: 'lg', backdrop: 'static'});
        modalRef.componentInstance.activeBusinessDate = activeBusinessDate;
        modalRef.result.then(result => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        }, (reason) => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        });
        return modalRef;
    }
}
