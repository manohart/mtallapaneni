export class ActiveBusinessDate {
    constructor(
        public id?: number,
        public locationCode?: string,
        public calendarDate?: any,
        public isHoliday?: boolean,
        public businessDate?: any,
        public previousBusinessDate?: any,
        public nextBusinessDate?: any,
        public updatedDate?: any,
    ) {
        this.isHoliday = false;
    }
}
