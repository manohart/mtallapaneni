import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SmartISharedModule } from '../../shared';

import {
    ActiveBusinessDateService,
    ActiveBusinessDatePopupService,
    ActiveBusinessDateComponent,
    ActiveBusinessDateDetailComponent,
    ActiveBusinessDateDialogComponent,
    ActiveBusinessDatePopupComponent,
    ActiveBusinessDateDeletePopupComponent,
    ActiveBusinessDateDeleteDialogComponent,
    activeBusinessDateRoute,
    activeBusinessDatePopupRoute,
    ActiveBusinessDateResolvePagingParams,
} from './';

let ENTITY_STATES = [
    ...activeBusinessDateRoute,
    ...activeBusinessDatePopupRoute,
];

@NgModule({
    imports: [
        SmartISharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [
        ActiveBusinessDateComponent,
        ActiveBusinessDateDetailComponent,
        ActiveBusinessDateDialogComponent,
        ActiveBusinessDateDeleteDialogComponent,
        ActiveBusinessDatePopupComponent,
        ActiveBusinessDateDeletePopupComponent,
    ],
    entryComponents: [
        ActiveBusinessDateComponent,
        ActiveBusinessDateDialogComponent,
        ActiveBusinessDatePopupComponent,
        ActiveBusinessDateDeleteDialogComponent,
        ActiveBusinessDateDeletePopupComponent,
    ],
    providers: [
        ActiveBusinessDateService,
        ActiveBusinessDatePopupService,
        ActiveBusinessDateResolvePagingParams,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartIActiveBusinessDateModule {}
