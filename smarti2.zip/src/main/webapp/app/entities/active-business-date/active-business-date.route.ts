import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, CanActivate } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { PaginationUtil } from 'ng-jhipster';

import { ActiveBusinessDateComponent } from './active-business-date.component';
import { ActiveBusinessDateDetailComponent } from './active-business-date-detail.component';
import { ActiveBusinessDatePopupComponent } from './active-business-date-dialog.component';
import { ActiveBusinessDateDeletePopupComponent } from './active-business-date-delete-dialog.component';

import { Principal } from '../../shared';

@Injectable()
export class ActiveBusinessDateResolvePagingParams implements Resolve<any> {

  constructor(private paginationUtil: PaginationUtil) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
      let page = route.queryParams['page'] ? route.queryParams['page'] : '1';
      let sort = route.queryParams['sort'] ? route.queryParams['sort'] : 'id,asc';
      return {
          page: this.paginationUtil.parsePage(page),
          predicate: this.paginationUtil.parsePredicate(sort),
          ascending: this.paginationUtil.parseAscending(sort)
    };
  }
}

export const activeBusinessDateRoute: Routes = [
  {
    path: 'active-business-date',
    component: ActiveBusinessDateComponent,
    resolve: {
      'pagingParams': ActiveBusinessDateResolvePagingParams
    },
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'ActiveBusinessDates'
    }
  }, {
    path: 'active-business-date/:id',
    component: ActiveBusinessDateDetailComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'ActiveBusinessDates'
    }
  }
];

export const activeBusinessDatePopupRoute: Routes = [
  {
    path: 'active-business-date-new',
    component: ActiveBusinessDatePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'ActiveBusinessDates'
    },
    outlet: 'popup'
  },
  {
    path: 'active-business-date/:id/edit',
    component: ActiveBusinessDatePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'ActiveBusinessDates'
    },
    outlet: 'popup'
  },
  {
    path: 'active-business-date/:id/delete',
    component: ActiveBusinessDateDeletePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'ActiveBusinessDates'
    },
    outlet: 'popup'
  }
];
