import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager } from 'ng-jhipster';

import { AppDependency } from './app-dependency.model';
import { AppDependencyPopupService } from './app-dependency-popup.service';
import { AppDependencyService } from './app-dependency.service';

@Component({
    selector: 'marti-app-dependency-delete-dialog',
    templateUrl: './app-dependency-delete-dialog.component.html'
})
export class AppDependencyDeleteDialogComponent {

    appDependency: AppDependency;

    constructor(
        private appDependencyService: AppDependencyService,
        public activeModal: NgbActiveModal,
        private eventManager: EventManager
    ) {
    }

    clear () {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete (id: number) {
        this.appDependencyService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'appDependencyListModification',
                content: 'Deleted an appDependency'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'marti-app-dependency-delete-popup',
    template: ''
})
export class AppDependencyDeletePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private appDependencyPopupService: AppDependencyPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            this.modalRef = this.appDependencyPopupService
                .open(AppDependencyDeleteDialogComponent, params['id']);
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
