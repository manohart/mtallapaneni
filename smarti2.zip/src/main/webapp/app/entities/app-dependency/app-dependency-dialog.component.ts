import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager, AlertService } from 'ng-jhipster';

import { AppDependency } from './app-dependency.model';
import { AppDependencyPopupService } from './app-dependency-popup.service';
import { AppDependencyService } from './app-dependency.service';
import { Application, ApplicationService } from '../application';

@Component({
    selector: 'marti-app-dependency-dialog',
    templateUrl: './app-dependency-dialog.component.html'
})
export class AppDependencyDialogComponent implements OnInit {

    appDependency: AppDependency;
    authorities: any[];
    isSaving: boolean;

    applications: Application[];
    constructor(
        public activeModal: NgbActiveModal,
        private alertService: AlertService,
        private appDependencyService: AppDependencyService,
        private applicationService: ApplicationService,
        private eventManager: EventManager
    ) {
    }

    ngOnInit() {
        this.isSaving = false;
        this.authorities = ['ROLE_USER', 'ROLE_ADMIN'];
        this.applicationService.query().subscribe(
            (res: Response) => { this.applications = res.json(); }, (res: Response) => this.onError(res.json()));
    }
    clear () {
        this.activeModal.dismiss('cancel');
    }

    save () {
        this.isSaving = true;
        if (this.appDependency.id !== undefined) {
            this.appDependencyService.update(this.appDependency)
                .subscribe((res: AppDependency) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        } else {
            this.appDependencyService.create(this.appDependency)
                .subscribe((res: AppDependency) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        }
    }

    private onSaveSuccess (result: AppDependency) {
        this.eventManager.broadcast({ name: 'appDependencyListModification', content: 'OK'});
        this.isSaving = false;
        this.activeModal.dismiss(result);
    }

    private onSaveError (error) {
        this.isSaving = false;
        this.onError(error);
    }

    private onError (error) {
        this.alertService.error(error.message, null, null);
    }

    trackApplicationById(index: number, item: Application) {
        return item.id;
    }
}

@Component({
    selector: 'marti-app-dependency-popup',
    template: ''
})
export class AppDependencyPopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private appDependencyPopupService: AppDependencyPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            if ( params['id'] ) {
                this.modalRef = this.appDependencyPopupService
                    .open(AppDependencyDialogComponent, params['id']);
            } else {
                this.modalRef = this.appDependencyPopupService
                    .open(AppDependencyDialogComponent);
            }

        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
