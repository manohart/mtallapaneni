import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SmartISharedModule } from '../../shared';

import {
    AppDependencyService,
    AppDependencyPopupService,
    AppDependencyComponent,
    AppDependencyDetailComponent,
    AppDependencyDialogComponent,
    AppDependencyPopupComponent,
    AppDependencyDeletePopupComponent,
    AppDependencyDeleteDialogComponent,
    appDependencyRoute,
    appDependencyPopupRoute,
    AppDependencyResolvePagingParams,
} from './';

let ENTITY_STATES = [
    ...appDependencyRoute,
    ...appDependencyPopupRoute,
];

@NgModule({
    imports: [
        SmartISharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [
        AppDependencyComponent,
        AppDependencyDetailComponent,
        AppDependencyDialogComponent,
        AppDependencyDeleteDialogComponent,
        AppDependencyPopupComponent,
        AppDependencyDeletePopupComponent,
    ],
    entryComponents: [
        AppDependencyComponent,
        AppDependencyDialogComponent,
        AppDependencyPopupComponent,
        AppDependencyDeleteDialogComponent,
        AppDependencyDeletePopupComponent,
    ],
    providers: [
        AppDependencyService,
        AppDependencyPopupService,
        AppDependencyResolvePagingParams,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartIAppDependencyModule {}
