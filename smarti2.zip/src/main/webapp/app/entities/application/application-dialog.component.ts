import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager, AlertService, DataUtils } from 'ng-jhipster';

import { Application } from './application.model';
import { ApplicationPopupService } from './application-popup.service';
import { ApplicationService } from './application.service';
import { AutoNotification, AutoNotificationService } from '../auto-notification';
import { AppDependency, AppDependencyService } from '../app-dependency';
import { BatchDistribution, BatchDistributionService } from '../batch-distribution';
import { LineOfBusiness, LineOfBusinessService } from '../line-of-business';
import { Product, ProductService } from '../product';
import { Server, ServerService } from '../server';

@Component({
    selector: 'marti-application-dialog',
    templateUrl: './application-dialog.component.html'
})
export class ApplicationDialogComponent implements OnInit {

    application: Application;
    authorities: any[];
    isSaving: boolean;

    autonotifications: AutoNotification[];

    appdependencies: AppDependency[];

    batchdistributions: BatchDistribution[];

    lineofbusinesses: LineOfBusiness[];

    products: Product[];

    servers: Server[];
    constructor(
        public activeModal: NgbActiveModal,
        private dataUtils: DataUtils,
        private alertService: AlertService,
        private applicationService: ApplicationService,
        private autoNotificationService: AutoNotificationService,
        private appDependencyService: AppDependencyService,
        private batchDistributionService: BatchDistributionService,
        private lineOfBusinessService: LineOfBusinessService,
        private productService: ProductService,
        private serverService: ServerService,
        private eventManager: EventManager
    ) {
    }

    ngOnInit() {
        this.isSaving = false;
        this.authorities = ['ROLE_USER', 'ROLE_ADMIN'];
        this.autoNotificationService.query().subscribe(
            (res: Response) => { this.autonotifications = res.json(); }, (res: Response) => this.onError(res.json()));
        this.appDependencyService.query().subscribe(
            (res: Response) => { this.appdependencies = res.json(); }, (res: Response) => this.onError(res.json()));
        this.batchDistributionService.query().subscribe(
            (res: Response) => { this.batchdistributions = res.json(); }, (res: Response) => this.onError(res.json()));
        this.lineOfBusinessService.query().subscribe(
            (res: Response) => { this.lineofbusinesses = res.json(); }, (res: Response) => this.onError(res.json()));
        this.productService.query().subscribe(
            (res: Response) => { this.products = res.json(); }, (res: Response) => this.onError(res.json()));
        this.serverService.query().subscribe(
            (res: Response) => { this.servers = res.json(); }, (res: Response) => this.onError(res.json()));
    }
    byteSize(field) {
        return this.dataUtils.byteSize(field);
    }

    openFile(contentType, field) {
        return this.dataUtils.openFile(contentType, field);
    }

    setFileData($event, application, field, isImage) {
        if ($event.target.files && $event.target.files[0]) {
            let $file = $event.target.files[0];
            if (isImage && !/^image\//.test($file.type)) {
                return;
            }
            this.dataUtils.toBase64($file, (base64Data) => {
                application[field] = base64Data;
                application[`${field}ContentType`] = $file.type;
            });
        }
    }
    clear () {
        this.activeModal.dismiss('cancel');
    }

    save () {
        this.isSaving = true;
        if (this.application.id !== undefined) {
            this.applicationService.update(this.application)
                .subscribe((res: Application) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        } else {
            this.applicationService.create(this.application)
                .subscribe((res: Application) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        }
    }

    private onSaveSuccess (result: Application) {
        this.eventManager.broadcast({ name: 'applicationListModification', content: 'OK'});
        this.isSaving = false;
        this.activeModal.dismiss(result);
    }

    private onSaveError (error) {
        this.isSaving = false;
        this.onError(error);
    }

    private onError (error) {
        this.alertService.error(error.message, null, null);
    }

    trackAutoNotificationById(index: number, item: AutoNotification) {
        return item.id;
    }

    trackAppDependencyById(index: number, item: AppDependency) {
        return item.id;
    }

    trackBatchDistributionById(index: number, item: BatchDistribution) {
        return item.id;
    }

    trackLineOfBusinessById(index: number, item: LineOfBusiness) {
        return item.id;
    }

    trackProductById(index: number, item: Product) {
        return item.id;
    }

    trackServerById(index: number, item: Server) {
        return item.id;
    }
}

@Component({
    selector: 'marti-application-popup',
    template: ''
})
export class ApplicationPopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private applicationPopupService: ApplicationPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            if ( params['id'] ) {
                this.modalRef = this.applicationPopupService
                    .open(ApplicationDialogComponent, params['id']);
            } else {
                this.modalRef = this.applicationPopupService
                    .open(ApplicationDialogComponent);
            }

        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
