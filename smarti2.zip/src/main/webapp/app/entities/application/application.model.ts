
const enum InfraCategory {
    'INVEST',
    'MAINTAIN',
    'DIVEST'

};

const enum AppType {
    'BATCH',
    'WEB',
    'ANDROID',
    'IOS',
    'BLACK_BERRY',
    'WINDOWS',
    'OTHERS'

};

const enum ApplicationRisk {
    'HIGH',
    'MEDIUM',
    'LOW'

};

const enum LocationCode {
    'GLOBAL',
    'NYU',
    'LON',
    'TOK',
    'EMEA',
    'NAM',
    'HKG',
    'IND',
    'NONE'

};
import { AutoNotification } from '../auto-notification';
import { AppDependency } from '../app-dependency';
import { BatchDistribution } from '../batch-distribution';
import { LineOfBusiness } from '../line-of-business';
import { Product } from '../product';
import { Server } from '../server';
export class Application {
    constructor(
        public id?: number,
        public name?: string,
        public description?: any,
        public category?: InfraCategory,
        public type?: AppType,
        public riskLevel?: ApplicationRisk,
        public sla?: string,
        public locationCode?: LocationCode,
        public impactedRegions?: string,
        public documenationPath?: string,
        public deployedPath?: string,
        public isActive?: boolean,
        public updatedDate?: any,
        public notificationRule?: AutoNotification,
        public dependents?: AppDependency,
        public distributions?: BatchDistribution,
        public lob?: LineOfBusiness,
        public product?: Product,
        public appServer?: Server,
        public dbServer?: Server,
    ) {
        this.isActive = false;
    }
}
