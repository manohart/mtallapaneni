import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager } from 'ng-jhipster';

import { ArchiveLocation } from './archive-location.model';
import { ArchiveLocationPopupService } from './archive-location-popup.service';
import { ArchiveLocationService } from './archive-location.service';

@Component({
    selector: 'marti-archive-location-delete-dialog',
    templateUrl: './archive-location-delete-dialog.component.html'
})
export class ArchiveLocationDeleteDialogComponent {

    archiveLocation: ArchiveLocation;

    constructor(
        private archiveLocationService: ArchiveLocationService,
        public activeModal: NgbActiveModal,
        private eventManager: EventManager
    ) {
    }

    clear () {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete (id: number) {
        this.archiveLocationService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'archiveLocationListModification',
                content: 'Deleted an archiveLocation'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'marti-archive-location-delete-popup',
    template: ''
})
export class ArchiveLocationDeletePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private archiveLocationPopupService: ArchiveLocationPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            this.modalRef = this.archiveLocationPopupService
                .open(ArchiveLocationDeleteDialogComponent, params['id']);
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
