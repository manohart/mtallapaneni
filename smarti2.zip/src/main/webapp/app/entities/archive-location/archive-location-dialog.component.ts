import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager, AlertService } from 'ng-jhipster';

import { ArchiveLocation } from './archive-location.model';
import { ArchiveLocationPopupService } from './archive-location-popup.service';
import { ArchiveLocationService } from './archive-location.service';
import { LineOfBusiness, LineOfBusinessService } from '../line-of-business';

@Component({
    selector: 'marti-archive-location-dialog',
    templateUrl: './archive-location-dialog.component.html'
})
export class ArchiveLocationDialogComponent implements OnInit {

    archiveLocation: ArchiveLocation;
    authorities: any[];
    isSaving: boolean;

    lineofbusinesses: LineOfBusiness[];
    constructor(
        public activeModal: NgbActiveModal,
        private alertService: AlertService,
        private archiveLocationService: ArchiveLocationService,
        private lineOfBusinessService: LineOfBusinessService,
        private eventManager: EventManager
    ) {
    }

    ngOnInit() {
        this.isSaving = false;
        this.authorities = ['ROLE_USER', 'ROLE_ADMIN'];
        this.lineOfBusinessService.query().subscribe(
            (res: Response) => { this.lineofbusinesses = res.json(); }, (res: Response) => this.onError(res.json()));
    }
    clear () {
        this.activeModal.dismiss('cancel');
    }

    save () {
        this.isSaving = true;
        if (this.archiveLocation.id !== undefined) {
            this.archiveLocationService.update(this.archiveLocation)
                .subscribe((res: ArchiveLocation) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        } else {
            this.archiveLocationService.create(this.archiveLocation)
                .subscribe((res: ArchiveLocation) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        }
    }

    private onSaveSuccess (result: ArchiveLocation) {
        this.eventManager.broadcast({ name: 'archiveLocationListModification', content: 'OK'});
        this.isSaving = false;
        this.activeModal.dismiss(result);
    }

    private onSaveError (error) {
        this.isSaving = false;
        this.onError(error);
    }

    private onError (error) {
        this.alertService.error(error.message, null, null);
    }

    trackLineOfBusinessById(index: number, item: LineOfBusiness) {
        return item.id;
    }
}

@Component({
    selector: 'marti-archive-location-popup',
    template: ''
})
export class ArchiveLocationPopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private archiveLocationPopupService: ArchiveLocationPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            if ( params['id'] ) {
                this.modalRef = this.archiveLocationPopupService
                    .open(ArchiveLocationDialogComponent, params['id']);
            } else {
                this.modalRef = this.archiveLocationPopupService
                    .open(ArchiveLocationDialogComponent);
            }

        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
