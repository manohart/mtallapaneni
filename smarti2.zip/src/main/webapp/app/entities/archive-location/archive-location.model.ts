import { LineOfBusiness } from '../line-of-business';
export class ArchiveLocation {
    constructor(
        public id?: number,
        public name?: string,
        public description?: string,
        public path?: string,
        public isActive?: boolean,
        public updatedDate?: any,
        public lob?: LineOfBusiness,
    ) {
        this.isActive = false;
    }
}
