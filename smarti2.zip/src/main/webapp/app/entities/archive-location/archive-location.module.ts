import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SmartISharedModule } from '../../shared';

import {
    ArchiveLocationService,
    ArchiveLocationPopupService,
    ArchiveLocationComponent,
    ArchiveLocationDetailComponent,
    ArchiveLocationDialogComponent,
    ArchiveLocationPopupComponent,
    ArchiveLocationDeletePopupComponent,
    ArchiveLocationDeleteDialogComponent,
    archiveLocationRoute,
    archiveLocationPopupRoute,
    ArchiveLocationResolvePagingParams,
} from './';

let ENTITY_STATES = [
    ...archiveLocationRoute,
    ...archiveLocationPopupRoute,
];

@NgModule({
    imports: [
        SmartISharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [
        ArchiveLocationComponent,
        ArchiveLocationDetailComponent,
        ArchiveLocationDialogComponent,
        ArchiveLocationDeleteDialogComponent,
        ArchiveLocationPopupComponent,
        ArchiveLocationDeletePopupComponent,
    ],
    entryComponents: [
        ArchiveLocationComponent,
        ArchiveLocationDialogComponent,
        ArchiveLocationPopupComponent,
        ArchiveLocationDeleteDialogComponent,
        ArchiveLocationDeletePopupComponent,
    ],
    providers: [
        ArchiveLocationService,
        ArchiveLocationPopupService,
        ArchiveLocationResolvePagingParams,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartIArchiveLocationModule {}
