import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, CanActivate } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { PaginationUtil } from 'ng-jhipster';

import { ArchiveLocationComponent } from './archive-location.component';
import { ArchiveLocationDetailComponent } from './archive-location-detail.component';
import { ArchiveLocationPopupComponent } from './archive-location-dialog.component';
import { ArchiveLocationDeletePopupComponent } from './archive-location-delete-dialog.component';

import { Principal } from '../../shared';

@Injectable()
export class ArchiveLocationResolvePagingParams implements Resolve<any> {

  constructor(private paginationUtil: PaginationUtil) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
      let page = route.queryParams['page'] ? route.queryParams['page'] : '1';
      let sort = route.queryParams['sort'] ? route.queryParams['sort'] : 'id,asc';
      return {
          page: this.paginationUtil.parsePage(page),
          predicate: this.paginationUtil.parsePredicate(sort),
          ascending: this.paginationUtil.parseAscending(sort)
    };
  }
}

export const archiveLocationRoute: Routes = [
  {
    path: 'archive-location',
    component: ArchiveLocationComponent,
    resolve: {
      'pagingParams': ArchiveLocationResolvePagingParams
    },
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'ArchiveLocations'
    }
  }, {
    path: 'archive-location/:id',
    component: ArchiveLocationDetailComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'ArchiveLocations'
    }
  }
];

export const archiveLocationPopupRoute: Routes = [
  {
    path: 'archive-location-new',
    component: ArchiveLocationPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'ArchiveLocations'
    },
    outlet: 'popup'
  },
  {
    path: 'archive-location/:id/edit',
    component: ArchiveLocationPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'ArchiveLocations'
    },
    outlet: 'popup'
  },
  {
    path: 'archive-location/:id/delete',
    component: ArchiveLocationDeletePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'ArchiveLocations'
    },
    outlet: 'popup'
  }
];
