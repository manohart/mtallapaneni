import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager } from 'ng-jhipster';

import { AutoNotification } from './auto-notification.model';
import { AutoNotificationPopupService } from './auto-notification-popup.service';
import { AutoNotificationService } from './auto-notification.service';

@Component({
    selector: 'marti-auto-notification-delete-dialog',
    templateUrl: './auto-notification-delete-dialog.component.html'
})
export class AutoNotificationDeleteDialogComponent {

    autoNotification: AutoNotification;

    constructor(
        private autoNotificationService: AutoNotificationService,
        public activeModal: NgbActiveModal,
        private eventManager: EventManager
    ) {
    }

    clear () {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete (id: number) {
        this.autoNotificationService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'autoNotificationListModification',
                content: 'Deleted an autoNotification'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'marti-auto-notification-delete-popup',
    template: ''
})
export class AutoNotificationDeletePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private autoNotificationPopupService: AutoNotificationPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            this.modalRef = this.autoNotificationPopupService
                .open(AutoNotificationDeleteDialogComponent, params['id']);
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
