import { Injectable, Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { AutoNotification } from './auto-notification.model';
import { AutoNotificationService } from './auto-notification.service';
@Injectable()
export class AutoNotificationPopupService {
    private isOpen = false;
    constructor (
        private datePipe: DatePipe,
        private modalService: NgbModal,
        private router: Router,
        private autoNotificationService: AutoNotificationService

    ) {}

    open (component: Component, id?: number | any): NgbModalRef {
        if (this.isOpen) {
            return;
        }
        this.isOpen = true;

        if (id) {
            this.autoNotificationService.find(id).subscribe(autoNotification => {
                autoNotification.updatedDate = this.datePipe
                    .transform(autoNotification.updatedDate, 'yyyy-MM-ddThh:mm');
                this.autoNotificationModalRef(component, autoNotification);
            });
        } else {
            return this.autoNotificationModalRef(component, new AutoNotification());
        }
    }

    autoNotificationModalRef(component: Component, autoNotification: AutoNotification): NgbModalRef {
        let modalRef = this.modalService.open(component, { size: 'lg', backdrop: 'static'});
        modalRef.componentInstance.autoNotification = autoNotification;
        modalRef.result.then(result => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        }, (reason) => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        });
        return modalRef;
    }
}
