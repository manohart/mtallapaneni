import { NotificationRule } from '../notification-rule';
import { LineOfBusiness } from '../line-of-business';
import { Application } from '../application';
export class AutoNotification {
    constructor(
        public id?: number,
        public isActive?: boolean,
        public updatedDate?: any,
        public rule?: NotificationRule,
        public lob?: LineOfBusiness,
        public application?: Application,
    ) {
        this.isActive = false;
    }
}
