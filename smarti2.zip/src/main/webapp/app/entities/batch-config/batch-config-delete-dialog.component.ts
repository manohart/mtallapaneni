import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager } from 'ng-jhipster';

import { BatchConfig } from './batch-config.model';
import { BatchConfigPopupService } from './batch-config-popup.service';
import { BatchConfigService } from './batch-config.service';

@Component({
    selector: 'marti-batch-config-delete-dialog',
    templateUrl: './batch-config-delete-dialog.component.html'
})
export class BatchConfigDeleteDialogComponent {

    batchConfig: BatchConfig;

    constructor(
        private batchConfigService: BatchConfigService,
        public activeModal: NgbActiveModal,
        private eventManager: EventManager
    ) {
    }

    clear () {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete (id: number) {
        this.batchConfigService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'batchConfigListModification',
                content: 'Deleted an batchConfig'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'marti-batch-config-delete-popup',
    template: ''
})
export class BatchConfigDeletePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private batchConfigPopupService: BatchConfigPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            this.modalRef = this.batchConfigPopupService
                .open(BatchConfigDeleteDialogComponent, params['id']);
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
