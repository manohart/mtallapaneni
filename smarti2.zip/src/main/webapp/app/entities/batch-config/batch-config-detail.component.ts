import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BatchConfig } from './batch-config.model';
import { BatchConfigService } from './batch-config.service';

@Component({
    selector: 'marti-batch-config-detail',
    templateUrl: './batch-config-detail.component.html'
})
export class BatchConfigDetailComponent implements OnInit, OnDestroy {

    batchConfig: BatchConfig;
    private subscription: any;

    constructor(
        private batchConfigService: BatchConfigService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.batchConfigService.find(id).subscribe(batchConfig => {
            this.batchConfig = batchConfig;
        });
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
