import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager, AlertService } from 'ng-jhipster';

import { BatchConfig } from './batch-config.model';
import { BatchConfigPopupService } from './batch-config-popup.service';
import { BatchConfigService } from './batch-config.service';
import { BatchJob, BatchJobService } from '../batch-job';

@Component({
    selector: 'marti-batch-config-dialog',
    templateUrl: './batch-config-dialog.component.html'
})
export class BatchConfigDialogComponent implements OnInit {

    batchConfig: BatchConfig;
    authorities: any[];
    isSaving: boolean;

    batchjobs: BatchJob[];
    constructor(
        public activeModal: NgbActiveModal,
        private alertService: AlertService,
        private batchConfigService: BatchConfigService,
        private batchJobService: BatchJobService,
        private eventManager: EventManager
    ) {
    }

    ngOnInit() {
        this.isSaving = false;
        this.authorities = ['ROLE_USER', 'ROLE_ADMIN'];
        this.batchJobService.query().subscribe(
            (res: Response) => { this.batchjobs = res.json(); }, (res: Response) => this.onError(res.json()));
    }
    clear () {
        this.activeModal.dismiss('cancel');
    }

    save () {
        this.isSaving = true;
        if (this.batchConfig.id !== undefined) {
            this.batchConfigService.update(this.batchConfig)
                .subscribe((res: BatchConfig) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        } else {
            this.batchConfigService.create(this.batchConfig)
                .subscribe((res: BatchConfig) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        }
    }

    private onSaveSuccess (result: BatchConfig) {
        this.eventManager.broadcast({ name: 'batchConfigListModification', content: 'OK'});
        this.isSaving = false;
        this.activeModal.dismiss(result);
    }

    private onSaveError (error) {
        this.isSaving = false;
        this.onError(error);
    }

    private onError (error) {
        this.alertService.error(error.message, null, null);
    }

    trackBatchJobById(index: number, item: BatchJob) {
        return item.id;
    }
}

@Component({
    selector: 'marti-batch-config-popup',
    template: ''
})
export class BatchConfigPopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private batchConfigPopupService: BatchConfigPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            if ( params['id'] ) {
                this.modalRef = this.batchConfigPopupService
                    .open(BatchConfigDialogComponent, params['id']);
            } else {
                this.modalRef = this.batchConfigPopupService
                    .open(BatchConfigDialogComponent);
            }

        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
