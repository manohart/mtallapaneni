import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, CanActivate } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { PaginationUtil } from 'ng-jhipster';

import { BatchConfigComponent } from './batch-config.component';
import { BatchConfigDetailComponent } from './batch-config-detail.component';
import { BatchConfigPopupComponent } from './batch-config-dialog.component';
import { BatchConfigDeletePopupComponent } from './batch-config-delete-dialog.component';

import { Principal } from '../../shared';

@Injectable()
export class BatchConfigResolvePagingParams implements Resolve<any> {

  constructor(private paginationUtil: PaginationUtil) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
      let page = route.queryParams['page'] ? route.queryParams['page'] : '1';
      let sort = route.queryParams['sort'] ? route.queryParams['sort'] : 'id,asc';
      return {
          page: this.paginationUtil.parsePage(page),
          predicate: this.paginationUtil.parsePredicate(sort),
          ascending: this.paginationUtil.parseAscending(sort)
    };
  }
}

export const batchConfigRoute: Routes = [
  {
    path: 'batch-config',
    component: BatchConfigComponent,
    resolve: {
      'pagingParams': BatchConfigResolvePagingParams
    },
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchConfigs'
    }
  }, {
    path: 'batch-config/:id',
    component: BatchConfigDetailComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchConfigs'
    }
  }
];

export const batchConfigPopupRoute: Routes = [
  {
    path: 'batch-config-new',
    component: BatchConfigPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchConfigs'
    },
    outlet: 'popup'
  },
  {
    path: 'batch-config/:id/edit',
    component: BatchConfigPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchConfigs'
    },
    outlet: 'popup'
  },
  {
    path: 'batch-config/:id/delete',
    component: BatchConfigDeletePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'BatchConfigs'
    },
    outlet: 'popup'
  }
];
