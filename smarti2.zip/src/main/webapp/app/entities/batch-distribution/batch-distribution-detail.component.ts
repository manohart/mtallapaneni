import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BatchDistribution } from './batch-distribution.model';
import { BatchDistributionService } from './batch-distribution.service';

@Component({
    selector: 'marti-batch-distribution-detail',
    templateUrl: './batch-distribution-detail.component.html'
})
export class BatchDistributionDetailComponent implements OnInit, OnDestroy {

    batchDistribution: BatchDistribution;
    private subscription: any;

    constructor(
        private batchDistributionService: BatchDistributionService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.batchDistributionService.find(id).subscribe(batchDistribution => {
            this.batchDistribution = batchDistribution;
        });
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
