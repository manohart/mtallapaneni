import { BatchJobIssue } from '../batch-job-issue';
import { BatchJob } from '../batch-job';
export class BatchJobHistory {
    constructor(
        public id?: number,
        public businessDate?: any,
        public status?: string,
        public currentStep?: string,
        public startTime?: any,
        public endTime?: any,
        public historyAudit?: BatchJobIssue,
        public batchJob?: BatchJob,
    ) {
    }
}
