import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SmartISharedModule } from '../../shared';

import {
    BatchJobHistoryService,
    BatchJobHistoryPopupService,
    BatchJobHistoryComponent,
    BatchJobHistoryDetailComponent,
    BatchJobHistoryDialogComponent,
    BatchJobHistoryPopupComponent,
    BatchJobHistoryDeletePopupComponent,
    BatchJobHistoryDeleteDialogComponent,
    batchJobHistoryRoute,
    batchJobHistoryPopupRoute,
    BatchJobHistoryResolvePagingParams,
} from './';

let ENTITY_STATES = [
    ...batchJobHistoryRoute,
    ...batchJobHistoryPopupRoute,
];

@NgModule({
    imports: [
        SmartISharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [
        BatchJobHistoryComponent,
        BatchJobHistoryDetailComponent,
        BatchJobHistoryDialogComponent,
        BatchJobHistoryDeleteDialogComponent,
        BatchJobHistoryPopupComponent,
        BatchJobHistoryDeletePopupComponent,
    ],
    entryComponents: [
        BatchJobHistoryComponent,
        BatchJobHistoryDialogComponent,
        BatchJobHistoryPopupComponent,
        BatchJobHistoryDeleteDialogComponent,
        BatchJobHistoryDeletePopupComponent,
    ],
    providers: [
        BatchJobHistoryService,
        BatchJobHistoryPopupService,
        BatchJobHistoryResolvePagingParams,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartIBatchJobHistoryModule {}
