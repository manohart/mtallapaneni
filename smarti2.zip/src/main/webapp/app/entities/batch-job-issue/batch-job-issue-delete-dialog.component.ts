import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager } from 'ng-jhipster';

import { BatchJobIssue } from './batch-job-issue.model';
import { BatchJobIssuePopupService } from './batch-job-issue-popup.service';
import { BatchJobIssueService } from './batch-job-issue.service';

@Component({
    selector: 'marti-batch-job-issue-delete-dialog',
    templateUrl: './batch-job-issue-delete-dialog.component.html'
})
export class BatchJobIssueDeleteDialogComponent {

    batchJobIssue: BatchJobIssue;

    constructor(
        private batchJobIssueService: BatchJobIssueService,
        public activeModal: NgbActiveModal,
        private eventManager: EventManager
    ) {
    }

    clear () {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete (id: number) {
        this.batchJobIssueService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'batchJobIssueListModification',
                content: 'Deleted an batchJobIssue'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'marti-batch-job-issue-delete-popup',
    template: ''
})
export class BatchJobIssueDeletePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private batchJobIssuePopupService: BatchJobIssuePopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            this.modalRef = this.batchJobIssuePopupService
                .open(BatchJobIssueDeleteDialogComponent, params['id']);
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
