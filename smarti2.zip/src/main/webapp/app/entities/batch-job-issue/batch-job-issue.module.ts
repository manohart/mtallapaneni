import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SmartISharedModule } from '../../shared';

import {
    BatchJobIssueService,
    BatchJobIssuePopupService,
    BatchJobIssueComponent,
    BatchJobIssueDetailComponent,
    BatchJobIssueDialogComponent,
    BatchJobIssuePopupComponent,
    BatchJobIssueDeletePopupComponent,
    BatchJobIssueDeleteDialogComponent,
    batchJobIssueRoute,
    batchJobIssuePopupRoute,
    BatchJobIssueResolvePagingParams,
} from './';

let ENTITY_STATES = [
    ...batchJobIssueRoute,
    ...batchJobIssuePopupRoute,
];

@NgModule({
    imports: [
        SmartISharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [
        BatchJobIssueComponent,
        BatchJobIssueDetailComponent,
        BatchJobIssueDialogComponent,
        BatchJobIssueDeleteDialogComponent,
        BatchJobIssuePopupComponent,
        BatchJobIssueDeletePopupComponent,
    ],
    entryComponents: [
        BatchJobIssueComponent,
        BatchJobIssueDialogComponent,
        BatchJobIssuePopupComponent,
        BatchJobIssueDeleteDialogComponent,
        BatchJobIssueDeletePopupComponent,
    ],
    providers: [
        BatchJobIssueService,
        BatchJobIssuePopupService,
        BatchJobIssueResolvePagingParams,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartIBatchJobIssueModule {}
