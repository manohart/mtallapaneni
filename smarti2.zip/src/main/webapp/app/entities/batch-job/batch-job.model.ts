
const enum BatchType {
    'SOB',
    'COB',
    'OTHER'

};

const enum Scheduler {
    'CONTROL_M',
    'AUTOSYS',
    'WINDOWS_TS',
    'QUARTZ',
    'CRON',
    'JENKINS',
    'OTHERS'

};
import { Application } from '../application';
import { BatchJobHistory } from '../batch-job-history';
import { BatchReport } from '../batch-report';
import { BatchConfig } from '../batch-config';
import { BatchStepProcessor } from '../batch-step-processor';
export class BatchJob {
    constructor(
        public id?: number,
        public batchType?: BatchType,
        public scheduler?: Scheduler,
        public cron?: string,
        public fixedRate?: number,
        public fixedDelay?: number,
        public timeZone?: string,
        public skipOnHoliday?: boolean,
        public holidayRunStatus?: string,
        public isActive?: boolean,
        public updatedDate?: any,
        public application?: Application,
        public history?: BatchJobHistory,
        public report?: BatchReport,
        public configurations?: BatchConfig,
        public stepProcessors?: BatchStepProcessor,
    ) {
        this.skipOnHoliday = false;
        this.isActive = false;
    }
}
