import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SmartISharedModule } from '../../shared';

import {
    BatchJobService,
    BatchJobPopupService,
    BatchJobComponent,
    BatchJobDetailComponent,
    BatchJobDialogComponent,
    BatchJobPopupComponent,
    BatchJobDeletePopupComponent,
    BatchJobDeleteDialogComponent,
    batchJobRoute,
    batchJobPopupRoute,
    BatchJobResolvePagingParams,
} from './';

let ENTITY_STATES = [
    ...batchJobRoute,
    ...batchJobPopupRoute,
];

@NgModule({
    imports: [
        SmartISharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [
        BatchJobComponent,
        BatchJobDetailComponent,
        BatchJobDialogComponent,
        BatchJobDeleteDialogComponent,
        BatchJobPopupComponent,
        BatchJobDeletePopupComponent,
    ],
    entryComponents: [
        BatchJobComponent,
        BatchJobDialogComponent,
        BatchJobPopupComponent,
        BatchJobDeleteDialogComponent,
        BatchJobDeletePopupComponent,
    ],
    providers: [
        BatchJobService,
        BatchJobPopupService,
        BatchJobResolvePagingParams,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartIBatchJobModule {}
