import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager } from 'ng-jhipster';

import { BatchReportDetailHistory } from './batch-report-detail-history.model';
import { BatchReportDetailHistoryPopupService } from './batch-report-detail-history-popup.service';
import { BatchReportDetailHistoryService } from './batch-report-detail-history.service';

@Component({
    selector: 'marti-batch-report-detail-history-delete-dialog',
    templateUrl: './batch-report-detail-history-delete-dialog.component.html'
})
export class BatchReportDetailHistoryDeleteDialogComponent {

    batchReportDetailHistory: BatchReportDetailHistory;

    constructor(
        private batchReportDetailHistoryService: BatchReportDetailHistoryService,
        public activeModal: NgbActiveModal,
        private eventManager: EventManager
    ) {
    }

    clear () {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete (id: number) {
        this.batchReportDetailHistoryService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'batchReportDetailHistoryListModification',
                content: 'Deleted an batchReportDetailHistory'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'marti-batch-report-detail-history-delete-popup',
    template: ''
})
export class BatchReportDetailHistoryDeletePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private batchReportDetailHistoryPopupService: BatchReportDetailHistoryPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            this.modalRef = this.batchReportDetailHistoryPopupService
                .open(BatchReportDetailHistoryDeleteDialogComponent, params['id']);
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
