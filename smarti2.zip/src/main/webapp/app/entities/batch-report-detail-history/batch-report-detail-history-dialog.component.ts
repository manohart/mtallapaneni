import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager, AlertService } from 'ng-jhipster';

import { BatchReportDetailHistory } from './batch-report-detail-history.model';
import { BatchReportDetailHistoryPopupService } from './batch-report-detail-history-popup.service';
import { BatchReportDetailHistoryService } from './batch-report-detail-history.service';
import { BatchReportHistory, BatchReportHistoryService } from '../batch-report-history';
import { DataQualityCheck, DataQualityCheckService } from '../data-quality-check';

@Component({
    selector: 'marti-batch-report-detail-history-dialog',
    templateUrl: './batch-report-detail-history-dialog.component.html'
})
export class BatchReportDetailHistoryDialogComponent implements OnInit {

    batchReportDetailHistory: BatchReportDetailHistory;
    authorities: any[];
    isSaving: boolean;

    batchreporthistories: BatchReportHistory[];

    dataqualitychecks: DataQualityCheck[];
    constructor(
        public activeModal: NgbActiveModal,
        private alertService: AlertService,
        private batchReportDetailHistoryService: BatchReportDetailHistoryService,
        private batchReportHistoryService: BatchReportHistoryService,
        private dataQualityCheckService: DataQualityCheckService,
        private eventManager: EventManager
    ) {
    }

    ngOnInit() {
        this.isSaving = false;
        this.authorities = ['ROLE_USER', 'ROLE_ADMIN'];
        this.batchReportHistoryService.query().subscribe(
            (res: Response) => { this.batchreporthistories = res.json(); }, (res: Response) => this.onError(res.json()));
        this.dataQualityCheckService.query().subscribe(
            (res: Response) => { this.dataqualitychecks = res.json(); }, (res: Response) => this.onError(res.json()));
    }
    clear () {
        this.activeModal.dismiss('cancel');
    }

    save () {
        this.isSaving = true;
        if (this.batchReportDetailHistory.id !== undefined) {
            this.batchReportDetailHistoryService.update(this.batchReportDetailHistory)
                .subscribe((res: BatchReportDetailHistory) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        } else {
            this.batchReportDetailHistoryService.create(this.batchReportDetailHistory)
                .subscribe((res: BatchReportDetailHistory) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        }
    }

    private onSaveSuccess (result: BatchReportDetailHistory) {
        this.eventManager.broadcast({ name: 'batchReportDetailHistoryListModification', content: 'OK'});
        this.isSaving = false;
        this.activeModal.dismiss(result);
    }

    private onSaveError (error) {
        this.isSaving = false;
        this.onError(error);
    }

    private onError (error) {
        this.alertService.error(error.message, null, null);
    }

    trackBatchReportHistoryById(index: number, item: BatchReportHistory) {
        return item.id;
    }

    trackDataQualityCheckById(index: number, item: DataQualityCheck) {
        return item.id;
    }
}

@Component({
    selector: 'marti-batch-report-detail-history-popup',
    template: ''
})
export class BatchReportDetailHistoryPopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private batchReportDetailHistoryPopupService: BatchReportDetailHistoryPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            if ( params['id'] ) {
                this.modalRef = this.batchReportDetailHistoryPopupService
                    .open(BatchReportDetailHistoryDialogComponent, params['id']);
            } else {
                this.modalRef = this.batchReportDetailHistoryPopupService
                    .open(BatchReportDetailHistoryDialogComponent);
            }

        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
