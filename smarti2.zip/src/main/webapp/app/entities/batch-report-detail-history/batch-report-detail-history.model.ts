import { BatchReportHistory } from '../batch-report-history';
import { DataQualityCheck } from '../data-quality-check';
export class BatchReportDetailHistory {
    constructor(
        public id?: number,
        public records?: number,
        public issues?: number,
        public status?: string,
        public updatedDate?: any,
        public batchReport?: BatchReportHistory,
        public dataQualityCheck?: DataQualityCheck,
    ) {
    }
}
