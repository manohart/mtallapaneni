import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SmartISharedModule } from '../../shared';

import {
    BatchReportHistoryService,
    BatchReportHistoryPopupService,
    BatchReportHistoryComponent,
    BatchReportHistoryDetailComponent,
    BatchReportHistoryDialogComponent,
    BatchReportHistoryPopupComponent,
    BatchReportHistoryDeletePopupComponent,
    BatchReportHistoryDeleteDialogComponent,
    batchReportHistoryRoute,
    batchReportHistoryPopupRoute,
    BatchReportHistoryResolvePagingParams,
} from './';

let ENTITY_STATES = [
    ...batchReportHistoryRoute,
    ...batchReportHistoryPopupRoute,
];

@NgModule({
    imports: [
        SmartISharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [
        BatchReportHistoryComponent,
        BatchReportHistoryDetailComponent,
        BatchReportHistoryDialogComponent,
        BatchReportHistoryDeleteDialogComponent,
        BatchReportHistoryPopupComponent,
        BatchReportHistoryDeletePopupComponent,
    ],
    entryComponents: [
        BatchReportHistoryComponent,
        BatchReportHistoryDialogComponent,
        BatchReportHistoryPopupComponent,
        BatchReportHistoryDeleteDialogComponent,
        BatchReportHistoryDeletePopupComponent,
    ],
    providers: [
        BatchReportHistoryService,
        BatchReportHistoryPopupService,
        BatchReportHistoryResolvePagingParams,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartIBatchReportHistoryModule {}
