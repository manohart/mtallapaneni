import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BatchReport } from './batch-report.model';
import { BatchReportService } from './batch-report.service';

@Component({
    selector: 'marti-batch-report-detail',
    templateUrl: './batch-report-detail.component.html'
})
export class BatchReportDetailComponent implements OnInit, OnDestroy {

    batchReport: BatchReport;
    private subscription: any;

    constructor(
        private batchReportService: BatchReportService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.batchReportService.find(id).subscribe(batchReport => {
            this.batchReport = batchReport;
        });
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
