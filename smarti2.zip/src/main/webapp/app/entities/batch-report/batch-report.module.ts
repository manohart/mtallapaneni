import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SmartISharedModule } from '../../shared';

import {
    BatchReportService,
    BatchReportPopupService,
    BatchReportComponent,
    BatchReportDetailComponent,
    BatchReportDialogComponent,
    BatchReportPopupComponent,
    BatchReportDeletePopupComponent,
    BatchReportDeleteDialogComponent,
    batchReportRoute,
    batchReportPopupRoute,
    BatchReportResolvePagingParams,
} from './';

let ENTITY_STATES = [
    ...batchReportRoute,
    ...batchReportPopupRoute,
];

@NgModule({
    imports: [
        SmartISharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [
        BatchReportComponent,
        BatchReportDetailComponent,
        BatchReportDialogComponent,
        BatchReportDeleteDialogComponent,
        BatchReportPopupComponent,
        BatchReportDeletePopupComponent,
    ],
    entryComponents: [
        BatchReportComponent,
        BatchReportDialogComponent,
        BatchReportPopupComponent,
        BatchReportDeleteDialogComponent,
        BatchReportDeletePopupComponent,
    ],
    providers: [
        BatchReportService,
        BatchReportPopupService,
        BatchReportResolvePagingParams,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartIBatchReportModule {}
