import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataUtils } from 'ng-jhipster';
import { DataQualityCheckIssue } from './data-quality-check-issue.model';
import { DataQualityCheckIssueService } from './data-quality-check-issue.service';

@Component({
    selector: 'marti-data-quality-check-issue-detail',
    templateUrl: './data-quality-check-issue-detail.component.html'
})
export class DataQualityCheckIssueDetailComponent implements OnInit, OnDestroy {

    dataQualityCheckIssue: DataQualityCheckIssue;
    private subscription: any;

    constructor(
        private dataUtils: DataUtils,
        private dataQualityCheckIssueService: DataQualityCheckIssueService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.dataQualityCheckIssueService.find(id).subscribe(dataQualityCheckIssue => {
            this.dataQualityCheckIssue = dataQualityCheckIssue;
        });
    }
    byteSize(field) {
        return this.dataUtils.byteSize(field);
    }

    openFile(contentType, field) {
        return this.dataUtils.openFile(contentType, field);
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
