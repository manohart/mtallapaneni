
const enum DataQualityIssueRootCause {
    'UPSTREAM_DATA',
    'OWN_DATA',
    'PROGRAM_BUG',
    'UNKNOWN',
    'OTHER'

};
import { BatchReportHistory } from '../batch-report-history';
export class DataQualityCheckIssue {
    constructor(
        public id?: number,
        public records?: number,
        public issues?: number,
        public initialStatus?: string,
        public rootCauseCode?: DataQualityIssueRootCause,
        public rootCause?: any,
        public resolution?: any,
        public finalStatus?: string,
        public updatedDate?: any,
        public batchReport?: BatchReportHistory,
    ) {
    }
}
