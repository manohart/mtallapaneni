import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SmartISharedModule } from '../../shared';

import {
    DataQualityCheckIssueService,
    DataQualityCheckIssuePopupService,
    DataQualityCheckIssueComponent,
    DataQualityCheckIssueDetailComponent,
    DataQualityCheckIssueDialogComponent,
    DataQualityCheckIssuePopupComponent,
    DataQualityCheckIssueDeletePopupComponent,
    DataQualityCheckIssueDeleteDialogComponent,
    dataQualityCheckIssueRoute,
    dataQualityCheckIssuePopupRoute,
    DataQualityCheckIssueResolvePagingParams,
} from './';

let ENTITY_STATES = [
    ...dataQualityCheckIssueRoute,
    ...dataQualityCheckIssuePopupRoute,
];

@NgModule({
    imports: [
        SmartISharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [
        DataQualityCheckIssueComponent,
        DataQualityCheckIssueDetailComponent,
        DataQualityCheckIssueDialogComponent,
        DataQualityCheckIssueDeleteDialogComponent,
        DataQualityCheckIssuePopupComponent,
        DataQualityCheckIssueDeletePopupComponent,
    ],
    entryComponents: [
        DataQualityCheckIssueComponent,
        DataQualityCheckIssueDialogComponent,
        DataQualityCheckIssuePopupComponent,
        DataQualityCheckIssueDeleteDialogComponent,
        DataQualityCheckIssueDeletePopupComponent,
    ],
    providers: [
        DataQualityCheckIssueService,
        DataQualityCheckIssuePopupService,
        DataQualityCheckIssueResolvePagingParams,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartIDataQualityCheckIssueModule {}
