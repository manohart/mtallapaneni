import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager } from 'ng-jhipster';

import { DataQualityCheck } from './data-quality-check.model';
import { DataQualityCheckPopupService } from './data-quality-check-popup.service';
import { DataQualityCheckService } from './data-quality-check.service';

@Component({
    selector: 'marti-data-quality-check-delete-dialog',
    templateUrl: './data-quality-check-delete-dialog.component.html'
})
export class DataQualityCheckDeleteDialogComponent {

    dataQualityCheck: DataQualityCheck;

    constructor(
        private dataQualityCheckService: DataQualityCheckService,
        public activeModal: NgbActiveModal,
        private eventManager: EventManager
    ) {
    }

    clear () {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete (id: number) {
        this.dataQualityCheckService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'dataQualityCheckListModification',
                content: 'Deleted an dataQualityCheck'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'marti-data-quality-check-delete-popup',
    template: ''
})
export class DataQualityCheckDeletePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private dataQualityCheckPopupService: DataQualityCheckPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            this.modalRef = this.dataQualityCheckPopupService
                .open(DataQualityCheckDeleteDialogComponent, params['id']);
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
