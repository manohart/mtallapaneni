import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataUtils } from 'ng-jhipster';
import { DataQualityCheck } from './data-quality-check.model';
import { DataQualityCheckService } from './data-quality-check.service';

@Component({
    selector: 'marti-data-quality-check-detail',
    templateUrl: './data-quality-check-detail.component.html'
})
export class DataQualityCheckDetailComponent implements OnInit, OnDestroy {

    dataQualityCheck: DataQualityCheck;
    private subscription: any;

    constructor(
        private dataUtils: DataUtils,
        private dataQualityCheckService: DataQualityCheckService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.dataQualityCheckService.find(id).subscribe(dataQualityCheck => {
            this.dataQualityCheck = dataQualityCheck;
        });
    }
    byteSize(field) {
        return this.dataUtils.byteSize(field);
    }

    openFile(contentType, field) {
        return this.dataUtils.openFile(contentType, field);
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
