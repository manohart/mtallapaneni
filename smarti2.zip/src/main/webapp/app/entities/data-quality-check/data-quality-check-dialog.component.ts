import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager, AlertService, DataUtils } from 'ng-jhipster';

import { DataQualityCheck } from './data-quality-check.model';
import { DataQualityCheckPopupService } from './data-quality-check-popup.service';
import { DataQualityCheckService } from './data-quality-check.service';
import { BatchReportDetailHistory, BatchReportDetailHistoryService } from '../batch-report-detail-history';
import { WebService, WebServiceService } from '../web-service';
import { BatchReport, BatchReportService } from '../batch-report';

@Component({
    selector: 'marti-data-quality-check-dialog',
    templateUrl: './data-quality-check-dialog.component.html'
})
export class DataQualityCheckDialogComponent implements OnInit {

    dataQualityCheck: DataQualityCheck;
    authorities: any[];
    isSaving: boolean;

    batchreportdetailhistories: BatchReportDetailHistory[];

    webservices: WebService[];

    batchreports: BatchReport[];
    constructor(
        public activeModal: NgbActiveModal,
        private dataUtils: DataUtils,
        private alertService: AlertService,
        private dataQualityCheckService: DataQualityCheckService,
        private batchReportDetailHistoryService: BatchReportDetailHistoryService,
        private webServiceService: WebServiceService,
        private batchReportService: BatchReportService,
        private eventManager: EventManager
    ) {
    }

    ngOnInit() {
        this.isSaving = false;
        this.authorities = ['ROLE_USER', 'ROLE_ADMIN'];
        this.batchReportDetailHistoryService.query().subscribe(
            (res: Response) => { this.batchreportdetailhistories = res.json(); }, (res: Response) => this.onError(res.json()));
        this.webServiceService.query().subscribe(
            (res: Response) => { this.webservices = res.json(); }, (res: Response) => this.onError(res.json()));
        this.batchReportService.query().subscribe(
            (res: Response) => { this.batchreports = res.json(); }, (res: Response) => this.onError(res.json()));
    }
    byteSize(field) {
        return this.dataUtils.byteSize(field);
    }

    openFile(contentType, field) {
        return this.dataUtils.openFile(contentType, field);
    }

    setFileData($event, dataQualityCheck, field, isImage) {
        if ($event.target.files && $event.target.files[0]) {
            let $file = $event.target.files[0];
            if (isImage && !/^image\//.test($file.type)) {
                return;
            }
            this.dataUtils.toBase64($file, (base64Data) => {
                dataQualityCheck[field] = base64Data;
                dataQualityCheck[`${field}ContentType`] = $file.type;
            });
        }
    }
    clear () {
        this.activeModal.dismiss('cancel');
    }

    save () {
        this.isSaving = true;
        if (this.dataQualityCheck.id !== undefined) {
            this.dataQualityCheckService.update(this.dataQualityCheck)
                .subscribe((res: DataQualityCheck) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        } else {
            this.dataQualityCheckService.create(this.dataQualityCheck)
                .subscribe((res: DataQualityCheck) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        }
    }

    private onSaveSuccess (result: DataQualityCheck) {
        this.eventManager.broadcast({ name: 'dataQualityCheckListModification', content: 'OK'});
        this.isSaving = false;
        this.activeModal.dismiss(result);
    }

    private onSaveError (error) {
        this.isSaving = false;
        this.onError(error);
    }

    private onError (error) {
        this.alertService.error(error.message, null, null);
    }

    trackBatchReportDetailHistoryById(index: number, item: BatchReportDetailHistory) {
        return item.id;
    }

    trackWebServiceById(index: number, item: WebService) {
        return item.id;
    }

    trackBatchReportById(index: number, item: BatchReport) {
        return item.id;
    }
}

@Component({
    selector: 'marti-data-quality-check-popup',
    template: ''
})
export class DataQualityCheckPopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private dataQualityCheckPopupService: DataQualityCheckPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            if ( params['id'] ) {
                this.modalRef = this.dataQualityCheckPopupService
                    .open(DataQualityCheckDialogComponent, params['id']);
            } else {
                this.modalRef = this.dataQualityCheckPopupService
                    .open(DataQualityCheckDialogComponent);
            }

        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
