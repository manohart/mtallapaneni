import { Injectable, Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { Distribution } from './distribution.model';
import { DistributionService } from './distribution.service';
@Injectable()
export class DistributionPopupService {
    private isOpen = false;
    constructor (
        private datePipe: DatePipe,
        private modalService: NgbModal,
        private router: Router,
        private distributionService: DistributionService

    ) {}

    open (component: Component, id?: number | any): NgbModalRef {
        if (this.isOpen) {
            return;
        }
        this.isOpen = true;

        if (id) {
            this.distributionService.find(id).subscribe(distribution => {
                distribution.updatedDate = this.datePipe
                    .transform(distribution.updatedDate, 'yyyy-MM-ddThh:mm');
                this.distributionModalRef(component, distribution);
            });
        } else {
            return this.distributionModalRef(component, new Distribution());
        }
    }

    distributionModalRef(component: Component, distribution: Distribution): NgbModalRef {
        let modalRef = this.modalService.open(component, { size: 'lg', backdrop: 'static'});
        modalRef.componentInstance.distribution = distribution;
        modalRef.result.then(result => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        }, (reason) => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        });
        return modalRef;
    }
}
