import { LineOfBusiness } from '../line-of-business';
export class Distribution {
    constructor(
        public id?: number,
        public name?: string,
        public fromAddress?: string,
        public toAddress?: string,
        public ccAddress?: string,
        public skipEmpty?: boolean,
        public isActive?: boolean,
        public updatedDate?: any,
        public lob?: LineOfBusiness,
    ) {
        this.skipEmpty = false;
        this.isActive = false;
    }
}
