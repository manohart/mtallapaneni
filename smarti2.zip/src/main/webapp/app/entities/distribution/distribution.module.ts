import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SmartISharedModule } from '../../shared';

import {
    DistributionService,
    DistributionPopupService,
    DistributionComponent,
    DistributionDetailComponent,
    DistributionDialogComponent,
    DistributionPopupComponent,
    DistributionDeletePopupComponent,
    DistributionDeleteDialogComponent,
    distributionRoute,
    distributionPopupRoute,
    DistributionResolvePagingParams,
} from './';

let ENTITY_STATES = [
    ...distributionRoute,
    ...distributionPopupRoute,
];

@NgModule({
    imports: [
        SmartISharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [
        DistributionComponent,
        DistributionDetailComponent,
        DistributionDialogComponent,
        DistributionDeleteDialogComponent,
        DistributionPopupComponent,
        DistributionDeletePopupComponent,
    ],
    entryComponents: [
        DistributionComponent,
        DistributionDialogComponent,
        DistributionPopupComponent,
        DistributionDeleteDialogComponent,
        DistributionDeletePopupComponent,
    ],
    providers: [
        DistributionService,
        DistributionPopupService,
        DistributionResolvePagingParams,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartIDistributionModule {}
