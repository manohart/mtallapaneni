import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, CanActivate } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { PaginationUtil } from 'ng-jhipster';

import { DistributionComponent } from './distribution.component';
import { DistributionDetailComponent } from './distribution-detail.component';
import { DistributionPopupComponent } from './distribution-dialog.component';
import { DistributionDeletePopupComponent } from './distribution-delete-dialog.component';

import { Principal } from '../../shared';

@Injectable()
export class DistributionResolvePagingParams implements Resolve<any> {

  constructor(private paginationUtil: PaginationUtil) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
      let page = route.queryParams['page'] ? route.queryParams['page'] : '1';
      let sort = route.queryParams['sort'] ? route.queryParams['sort'] : 'id,asc';
      return {
          page: this.paginationUtil.parsePage(page),
          predicate: this.paginationUtil.parsePredicate(sort),
          ascending: this.paginationUtil.parseAscending(sort)
    };
  }
}

export const distributionRoute: Routes = [
  {
    path: 'distribution',
    component: DistributionComponent,
    resolve: {
      'pagingParams': DistributionResolvePagingParams
    },
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'Distributions'
    }
  }, {
    path: 'distribution/:id',
    component: DistributionDetailComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'Distributions'
    }
  }
];

export const distributionPopupRoute: Routes = [
  {
    path: 'distribution-new',
    component: DistributionPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'Distributions'
    },
    outlet: 'popup'
  },
  {
    path: 'distribution/:id/edit',
    component: DistributionPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'Distributions'
    },
    outlet: 'popup'
  },
  {
    path: 'distribution/:id/delete',
    component: DistributionDeletePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'Distributions'
    },
    outlet: 'popup'
  }
];
