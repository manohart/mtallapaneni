import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { SmartIBatchStepProcessorModule } from './batch-step-processor/batch-step-processor.module';
import { SmartIActiveBusinessDateModule } from './active-business-date/active-business-date.module';
import { SmartIApplicationModule } from './application/application.module';
import { SmartIArchiveLocationModule } from './archive-location/archive-location.module';
import { SmartIAutoNotificationModule } from './auto-notification/auto-notification.module';
import { SmartIBatchConfigModule } from './batch-config/batch-config.module';
import { SmartIBatchDistributionModule } from './batch-distribution/batch-distribution.module';
import { SmartIBatchJobModule } from './batch-job/batch-job.module';
import { SmartIBatchJobHistoryModule } from './batch-job-history/batch-job-history.module';
import { SmartIBatchJobIssueModule } from './batch-job-issue/batch-job-issue.module';
import { SmartIBatchReportModule } from './batch-report/batch-report.module';
import { SmartIBatchReportDetailHistoryModule } from './batch-report-detail-history/batch-report-detail-history.module';
import { SmartIBatchReportHistoryModule } from './batch-report-history/batch-report-history.module';
import { SmartIAppDependencyModule } from './app-dependency/app-dependency.module';
import { SmartIDataQualityCheckModule } from './data-quality-check/data-quality-check.module';
import { SmartIDataQualityCheckIssueModule } from './data-quality-check-issue/data-quality-check-issue.module';
import { SmartIDistributionModule } from './distribution/distribution.module';
import { SmartILineOfBusinessModule } from './line-of-business/line-of-business.module';
import { SmartINotificationRuleModule } from './notification-rule/notification-rule.module';
import { SmartIProductModule } from './product/product.module';
import { SmartIServerModule } from './server/server.module';
import { SmartISoftwareReleaseModule } from './software-release/software-release.module';
import { SmartITeamModule } from './team/team.module';
import { SmartITemplateModule } from './template/template.module';
import { SmartIWebApplicationModule } from './web-application/web-application.module';
import { SmartIWebServiceModule } from './web-service/web-service.module';
import { SmartIWebServiceConsumerModule } from './web-service-consumer/web-service-consumer.module';
/* jhipster-needle-add-entity-module-import - JHipster will add entity modules imports here */

@NgModule({
    imports: [
        SmartIBatchStepProcessorModule,
        SmartIActiveBusinessDateModule,
        SmartIApplicationModule,
        SmartIArchiveLocationModule,
        SmartIAutoNotificationModule,
        SmartIBatchConfigModule,
        SmartIBatchDistributionModule,
        SmartIBatchJobModule,
        SmartIBatchJobHistoryModule,
        SmartIBatchJobIssueModule,
        SmartIBatchReportModule,
        SmartIBatchReportDetailHistoryModule,
        SmartIBatchReportHistoryModule,
        SmartIAppDependencyModule,
        SmartIDataQualityCheckModule,
        SmartIDataQualityCheckIssueModule,
        SmartIDistributionModule,
        SmartILineOfBusinessModule,
        SmartINotificationRuleModule,
        SmartIProductModule,
        SmartIServerModule,
        SmartISoftwareReleaseModule,
        SmartITeamModule,
        SmartITemplateModule,
        SmartIWebApplicationModule,
        SmartIWebServiceModule,
        SmartIWebServiceConsumerModule,
        /* jhipster-needle-add-entity-module - JHipster will add entity modules here */
    ],
    declarations: [],
    entryComponents: [],
    providers: [],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartIEntityModule {}
