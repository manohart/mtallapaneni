import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { LineOfBusiness } from './line-of-business.model';
import { LineOfBusinessService } from './line-of-business.service';

@Component({
    selector: 'marti-line-of-business-detail',
    templateUrl: './line-of-business-detail.component.html'
})
export class LineOfBusinessDetailComponent implements OnInit, OnDestroy {

    lineOfBusiness: LineOfBusiness;
    private subscription: any;

    constructor(
        private lineOfBusinessService: LineOfBusinessService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.lineOfBusinessService.find(id).subscribe(lineOfBusiness => {
            this.lineOfBusiness = lineOfBusiness;
        });
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
