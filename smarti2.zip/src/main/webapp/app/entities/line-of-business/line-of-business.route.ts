import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, CanActivate } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { PaginationUtil } from 'ng-jhipster';

import { LineOfBusinessComponent } from './line-of-business.component';
import { LineOfBusinessDetailComponent } from './line-of-business-detail.component';
import { LineOfBusinessPopupComponent } from './line-of-business-dialog.component';
import { LineOfBusinessDeletePopupComponent } from './line-of-business-delete-dialog.component';

import { Principal } from '../../shared';

@Injectable()
export class LineOfBusinessResolvePagingParams implements Resolve<any> {

  constructor(private paginationUtil: PaginationUtil) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
      let page = route.queryParams['page'] ? route.queryParams['page'] : '1';
      let sort = route.queryParams['sort'] ? route.queryParams['sort'] : 'id,asc';
      return {
          page: this.paginationUtil.parsePage(page),
          predicate: this.paginationUtil.parsePredicate(sort),
          ascending: this.paginationUtil.parseAscending(sort)
    };
  }
}

export const lineOfBusinessRoute: Routes = [
  {
    path: 'line-of-business',
    component: LineOfBusinessComponent,
    resolve: {
      'pagingParams': LineOfBusinessResolvePagingParams
    },
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'LineOfBusinesses'
    }
  }, {
    path: 'line-of-business/:id',
    component: LineOfBusinessDetailComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'LineOfBusinesses'
    }
  }
];

export const lineOfBusinessPopupRoute: Routes = [
  {
    path: 'line-of-business-new',
    component: LineOfBusinessPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'LineOfBusinesses'
    },
    outlet: 'popup'
  },
  {
    path: 'line-of-business/:id/edit',
    component: LineOfBusinessPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'LineOfBusinesses'
    },
    outlet: 'popup'
  },
  {
    path: 'line-of-business/:id/delete',
    component: LineOfBusinessDeletePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'LineOfBusinesses'
    },
    outlet: 'popup'
  }
];
