import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NotificationRule } from './notification-rule.model';
import { NotificationRuleService } from './notification-rule.service';

@Component({
    selector: 'marti-notification-rule-detail',
    templateUrl: './notification-rule-detail.component.html'
})
export class NotificationRuleDetailComponent implements OnInit, OnDestroy {

    notificationRule: NotificationRule;
    private subscription: any;

    constructor(
        private notificationRuleService: NotificationRuleService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.notificationRuleService.find(id).subscribe(notificationRule => {
            this.notificationRule = notificationRule;
        });
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
