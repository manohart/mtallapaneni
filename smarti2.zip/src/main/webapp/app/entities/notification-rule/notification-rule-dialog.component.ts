import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager, AlertService } from 'ng-jhipster';

import { NotificationRule } from './notification-rule.model';
import { NotificationRulePopupService } from './notification-rule-popup.service';
import { NotificationRuleService } from './notification-rule.service';

@Component({
    selector: 'marti-notification-rule-dialog',
    templateUrl: './notification-rule-dialog.component.html'
})
export class NotificationRuleDialogComponent implements OnInit {

    notificationRule: NotificationRule;
    authorities: any[];
    isSaving: boolean;
    constructor(
        public activeModal: NgbActiveModal,
        private alertService: AlertService,
        private notificationRuleService: NotificationRuleService,
        private eventManager: EventManager
    ) {
    }

    ngOnInit() {
        this.isSaving = false;
        this.authorities = ['ROLE_USER', 'ROLE_ADMIN'];
    }
    clear () {
        this.activeModal.dismiss('cancel');
    }

    save () {
        this.isSaving = true;
        if (this.notificationRule.id !== undefined) {
            this.notificationRuleService.update(this.notificationRule)
                .subscribe((res: NotificationRule) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        } else {
            this.notificationRuleService.create(this.notificationRule)
                .subscribe((res: NotificationRule) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        }
    }

    private onSaveSuccess (result: NotificationRule) {
        this.eventManager.broadcast({ name: 'notificationRuleListModification', content: 'OK'});
        this.isSaving = false;
        this.activeModal.dismiss(result);
    }

    private onSaveError (error) {
        this.isSaving = false;
        this.onError(error);
    }

    private onError (error) {
        this.alertService.error(error.message, null, null);
    }
}

@Component({
    selector: 'marti-notification-rule-popup',
    template: ''
})
export class NotificationRulePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private notificationRulePopupService: NotificationRulePopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            if ( params['id'] ) {
                this.modalRef = this.notificationRulePopupService
                    .open(NotificationRuleDialogComponent, params['id']);
            } else {
                this.modalRef = this.notificationRulePopupService
                    .open(NotificationRuleDialogComponent);
            }

        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
