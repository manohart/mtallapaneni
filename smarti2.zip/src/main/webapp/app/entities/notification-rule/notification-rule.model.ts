export class NotificationRule {
    constructor(
        public id?: number,
        public name?: string,
        public description?: string,
        public javaClass?: string,
        public isActive?: boolean,
        public updatedDate?: any,
    ) {
        this.isActive = false;
    }
}
