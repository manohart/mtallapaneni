export * from './product.model';
export * from './product-popup.service';
export * from './product.service';
export * from './product-dialog.component';
export * from './product-delete-dialog.component';
export * from './product-detail.component';
export * from './product.component';
export * from './product.route';
