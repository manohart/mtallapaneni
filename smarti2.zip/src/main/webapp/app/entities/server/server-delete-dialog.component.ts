import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager } from 'ng-jhipster';

import { Server } from './server.model';
import { ServerPopupService } from './server-popup.service';
import { ServerService } from './server.service';

@Component({
    selector: 'marti-server-delete-dialog',
    templateUrl: './server-delete-dialog.component.html'
})
export class ServerDeleteDialogComponent {

    server: Server;

    constructor(
        private serverService: ServerService,
        public activeModal: NgbActiveModal,
        private eventManager: EventManager
    ) {
    }

    clear () {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete (id: number) {
        this.serverService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'serverListModification',
                content: 'Deleted an server'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'marti-server-delete-popup',
    template: ''
})
export class ServerDeletePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private serverPopupService: ServerPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            this.modalRef = this.serverPopupService
                .open(ServerDeleteDialogComponent, params['id']);
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
