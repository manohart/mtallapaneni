import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Server } from './server.model';
import { ServerService } from './server.service';

@Component({
    selector: 'marti-server-detail',
    templateUrl: './server-detail.component.html'
})
export class ServerDetailComponent implements OnInit, OnDestroy {

    server: Server;
    private subscription: any;

    constructor(
        private serverService: ServerService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.serverService.find(id).subscribe(server => {
            this.server = server;
        });
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
