import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager } from 'ng-jhipster';

import { SoftwareRelease } from './software-release.model';
import { SoftwareReleasePopupService } from './software-release-popup.service';
import { SoftwareReleaseService } from './software-release.service';

@Component({
    selector: 'marti-software-release-delete-dialog',
    templateUrl: './software-release-delete-dialog.component.html'
})
export class SoftwareReleaseDeleteDialogComponent {

    softwareRelease: SoftwareRelease;

    constructor(
        private softwareReleaseService: SoftwareReleaseService,
        public activeModal: NgbActiveModal,
        private eventManager: EventManager
    ) {
    }

    clear () {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete (id: number) {
        this.softwareReleaseService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'softwareReleaseListModification',
                content: 'Deleted an softwareRelease'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'marti-software-release-delete-popup',
    template: ''
})
export class SoftwareReleaseDeletePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private softwareReleasePopupService: SoftwareReleasePopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            this.modalRef = this.softwareReleasePopupService
                .open(SoftwareReleaseDeleteDialogComponent, params['id']);
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
