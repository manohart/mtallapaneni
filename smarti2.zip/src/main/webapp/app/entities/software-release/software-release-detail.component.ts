import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataUtils } from 'ng-jhipster';
import { SoftwareRelease } from './software-release.model';
import { SoftwareReleaseService } from './software-release.service';

@Component({
    selector: 'marti-software-release-detail',
    templateUrl: './software-release-detail.component.html'
})
export class SoftwareReleaseDetailComponent implements OnInit, OnDestroy {

    softwareRelease: SoftwareRelease;
    private subscription: any;

    constructor(
        private dataUtils: DataUtils,
        private softwareReleaseService: SoftwareReleaseService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.softwareReleaseService.find(id).subscribe(softwareRelease => {
            this.softwareRelease = softwareRelease;
        });
    }
    byteSize(field) {
        return this.dataUtils.byteSize(field);
    }

    openFile(contentType, field) {
        return this.dataUtils.openFile(contentType, field);
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
