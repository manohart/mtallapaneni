import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager, AlertService, DataUtils } from 'ng-jhipster';

import { SoftwareRelease } from './software-release.model';
import { SoftwareReleasePopupService } from './software-release-popup.service';
import { SoftwareReleaseService } from './software-release.service';
import { Product, ProductService } from '../product';

@Component({
    selector: 'marti-software-release-dialog',
    templateUrl: './software-release-dialog.component.html'
})
export class SoftwareReleaseDialogComponent implements OnInit {

    softwareRelease: SoftwareRelease;
    authorities: any[];
    isSaving: boolean;

    products: Product[];
    constructor(
        public activeModal: NgbActiveModal,
        private dataUtils: DataUtils,
        private alertService: AlertService,
        private softwareReleaseService: SoftwareReleaseService,
        private productService: ProductService,
        private eventManager: EventManager
    ) {
    }

    ngOnInit() {
        this.isSaving = false;
        this.authorities = ['ROLE_USER', 'ROLE_ADMIN'];
        this.productService.query().subscribe(
            (res: Response) => { this.products = res.json(); }, (res: Response) => this.onError(res.json()));
    }
    byteSize(field) {
        return this.dataUtils.byteSize(field);
    }

    openFile(contentType, field) {
        return this.dataUtils.openFile(contentType, field);
    }

    setFileData($event, softwareRelease, field, isImage) {
        if ($event.target.files && $event.target.files[0]) {
            let $file = $event.target.files[0];
            if (isImage && !/^image\//.test($file.type)) {
                return;
            }
            this.dataUtils.toBase64($file, (base64Data) => {
                softwareRelease[field] = base64Data;
                softwareRelease[`${field}ContentType`] = $file.type;
            });
        }
    }
    clear () {
        this.activeModal.dismiss('cancel');
    }

    save () {
        this.isSaving = true;
        if (this.softwareRelease.id !== undefined) {
            this.softwareReleaseService.update(this.softwareRelease)
                .subscribe((res: SoftwareRelease) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        } else {
            this.softwareReleaseService.create(this.softwareRelease)
                .subscribe((res: SoftwareRelease) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        }
    }

    private onSaveSuccess (result: SoftwareRelease) {
        this.eventManager.broadcast({ name: 'softwareReleaseListModification', content: 'OK'});
        this.isSaving = false;
        this.activeModal.dismiss(result);
    }

    private onSaveError (error) {
        this.isSaving = false;
        this.onError(error);
    }

    private onError (error) {
        this.alertService.error(error.message, null, null);
    }

    trackProductById(index: number, item: Product) {
        return item.id;
    }
}

@Component({
    selector: 'marti-software-release-popup',
    template: ''
})
export class SoftwareReleasePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private softwareReleasePopupService: SoftwareReleasePopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            if ( params['id'] ) {
                this.modalRef = this.softwareReleasePopupService
                    .open(SoftwareReleaseDialogComponent, params['id']);
            } else {
                this.modalRef = this.softwareReleasePopupService
                    .open(SoftwareReleaseDialogComponent);
            }

        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
