import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager, AlertService } from 'ng-jhipster';

import { WebApplication } from './web-application.model';
import { WebApplicationPopupService } from './web-application-popup.service';
import { WebApplicationService } from './web-application.service';
import { Application, ApplicationService } from '../application';
import { WebService, WebServiceService } from '../web-service';

@Component({
    selector: 'marti-web-application-dialog',
    templateUrl: './web-application-dialog.component.html'
})
export class WebApplicationDialogComponent implements OnInit {

    webApplication: WebApplication;
    authorities: any[];
    isSaving: boolean;

    applications: Application[];

    drapplications: Application[];

    webservices: WebService[];
    constructor(
        public activeModal: NgbActiveModal,
        private alertService: AlertService,
        private webApplicationService: WebApplicationService,
        private applicationService: ApplicationService,
        private webServiceService: WebServiceService,
        private eventManager: EventManager
    ) {
    }

    ngOnInit() {
        this.isSaving = false;
        this.authorities = ['ROLE_USER', 'ROLE_ADMIN'];
        this.applicationService.query({filter: 'webapplication-is-null'}).subscribe((res: Response) => {
            if (!this.webApplication.application || !this.webApplication.application.id) {
                this.applications = res.json();
            } else {
                this.applicationService.find(this.webApplication.application.id).subscribe((subRes: Application) => {
                    this.applications = [subRes].concat(res.json());
                }, (subRes: Response) => this.onError(subRes.json()));
            }
        }, (res: Response) => this.onError(res.json()));
        this.applicationService.query({filter: 'webapplication-is-null'}).subscribe((res: Response) => {
            if (!this.webApplication.drApplication || !this.webApplication.drApplication.id) {
                this.drapplications = res.json();
            } else {
                this.applicationService.find(this.webApplication.drApplication.id).subscribe((subRes: Application) => {
                    this.drapplications = [subRes].concat(res.json());
                }, (subRes: Response) => this.onError(subRes.json()));
            }
        }, (res: Response) => this.onError(res.json()));
        this.webServiceService.query().subscribe(
            (res: Response) => { this.webservices = res.json(); }, (res: Response) => this.onError(res.json()));
    }
    clear () {
        this.activeModal.dismiss('cancel');
    }

    save () {
        this.isSaving = true;
        if (this.webApplication.id !== undefined) {
            this.webApplicationService.update(this.webApplication)
                .subscribe((res: WebApplication) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        } else {
            this.webApplicationService.create(this.webApplication)
                .subscribe((res: WebApplication) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        }
    }

    private onSaveSuccess (result: WebApplication) {
        this.eventManager.broadcast({ name: 'webApplicationListModification', content: 'OK'});
        this.isSaving = false;
        this.activeModal.dismiss(result);
    }

    private onSaveError (error) {
        this.isSaving = false;
        this.onError(error);
    }

    private onError (error) {
        this.alertService.error(error.message, null, null);
    }

    trackApplicationById(index: number, item: Application) {
        return item.id;
    }

    trackWebServiceById(index: number, item: WebService) {
        return item.id;
    }
}

@Component({
    selector: 'marti-web-application-popup',
    template: ''
})
export class WebApplicationPopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private webApplicationPopupService: WebApplicationPopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            if ( params['id'] ) {
                this.modalRef = this.webApplicationPopupService
                    .open(WebApplicationDialogComponent, params['id']);
            } else {
                this.modalRef = this.webApplicationPopupService
                    .open(WebApplicationDialogComponent);
            }

        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
