import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { WebServiceConsumer } from './web-service-consumer.model';
import { WebServiceConsumerService } from './web-service-consumer.service';

@Component({
    selector: 'marti-web-service-consumer-detail',
    templateUrl: './web-service-consumer-detail.component.html'
})
export class WebServiceConsumerDetailComponent implements OnInit, OnDestroy {

    webServiceConsumer: WebServiceConsumer;
    private subscription: any;

    constructor(
        private webServiceConsumerService: WebServiceConsumerService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.webServiceConsumerService.find(id).subscribe(webServiceConsumer => {
            this.webServiceConsumer = webServiceConsumer;
        });
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
