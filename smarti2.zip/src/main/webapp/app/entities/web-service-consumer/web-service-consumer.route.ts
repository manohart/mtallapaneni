import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes, CanActivate } from '@angular/router';

import { UserRouteAccessService } from '../../shared';
import { PaginationUtil } from 'ng-jhipster';

import { WebServiceConsumerComponent } from './web-service-consumer.component';
import { WebServiceConsumerDetailComponent } from './web-service-consumer-detail.component';
import { WebServiceConsumerPopupComponent } from './web-service-consumer-dialog.component';
import { WebServiceConsumerDeletePopupComponent } from './web-service-consumer-delete-dialog.component';

import { Principal } from '../../shared';

@Injectable()
export class WebServiceConsumerResolvePagingParams implements Resolve<any> {

  constructor(private paginationUtil: PaginationUtil) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
      let page = route.queryParams['page'] ? route.queryParams['page'] : '1';
      let sort = route.queryParams['sort'] ? route.queryParams['sort'] : 'id,asc';
      return {
          page: this.paginationUtil.parsePage(page),
          predicate: this.paginationUtil.parsePredicate(sort),
          ascending: this.paginationUtil.parseAscending(sort)
    };
  }
}

export const webServiceConsumerRoute: Routes = [
  {
    path: 'web-service-consumer',
    component: WebServiceConsumerComponent,
    resolve: {
      'pagingParams': WebServiceConsumerResolvePagingParams
    },
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'WebServiceConsumers'
    }
  }, {
    path: 'web-service-consumer/:id',
    component: WebServiceConsumerDetailComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'WebServiceConsumers'
    }
  }
];

export const webServiceConsumerPopupRoute: Routes = [
  {
    path: 'web-service-consumer-new',
    component: WebServiceConsumerPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'WebServiceConsumers'
    },
    outlet: 'popup'
  },
  {
    path: 'web-service-consumer/:id/edit',
    component: WebServiceConsumerPopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'WebServiceConsumers'
    },
    outlet: 'popup'
  },
  {
    path: 'web-service-consumer/:id/delete',
    component: WebServiceConsumerDeletePopupComponent,
    data: {
        authorities: ['ROLE_USER'],
        pageTitle: 'WebServiceConsumers'
    },
    outlet: 'popup'
  }
];
