export * from './web-service.model';
export * from './web-service-popup.service';
export * from './web-service.service';
export * from './web-service-dialog.component';
export * from './web-service-delete-dialog.component';
export * from './web-service-detail.component';
export * from './web-service.component';
export * from './web-service.route';
