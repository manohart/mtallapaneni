import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager } from 'ng-jhipster';

import { WebService } from './web-service.model';
import { WebServicePopupService } from './web-service-popup.service';
import { WebServiceService } from './web-service.service';

@Component({
    selector: 'marti-web-service-delete-dialog',
    templateUrl: './web-service-delete-dialog.component.html'
})
export class WebServiceDeleteDialogComponent {

    webService: WebService;

    constructor(
        private webServiceService: WebServiceService,
        public activeModal: NgbActiveModal,
        private eventManager: EventManager
    ) {
    }

    clear () {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete (id: number) {
        this.webServiceService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'webServiceListModification',
                content: 'Deleted an webService'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'marti-web-service-delete-popup',
    template: ''
})
export class WebServiceDeletePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private webServicePopupService: WebServicePopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            this.modalRef = this.webServicePopupService
                .open(WebServiceDeleteDialogComponent, params['id']);
        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
