import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataUtils } from 'ng-jhipster';
import { WebService } from './web-service.model';
import { WebServiceService } from './web-service.service';

@Component({
    selector: 'marti-web-service-detail',
    templateUrl: './web-service-detail.component.html'
})
export class WebServiceDetailComponent implements OnInit, OnDestroy {

    webService: WebService;
    private subscription: any;

    constructor(
        private dataUtils: DataUtils,
        private webServiceService: WebServiceService,
        private route: ActivatedRoute
    ) {
    }

    ngOnInit() {
        this.subscription = this.route.params.subscribe(params => {
            this.load(params['id']);
        });
    }

    load (id) {
        this.webServiceService.find(id).subscribe(webService => {
            this.webService = webService;
        });
    }
    byteSize(field) {
        return this.dataUtils.byteSize(field);
    }

    openFile(contentType, field) {
        return this.dataUtils.openFile(contentType, field);
    }
    previousState() {
        window.history.back();
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

}
