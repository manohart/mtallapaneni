import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EventManager, AlertService, DataUtils } from 'ng-jhipster';

import { WebService } from './web-service.model';
import { WebServicePopupService } from './web-service-popup.service';
import { WebServiceService } from './web-service.service';
import { WebServiceConsumer, WebServiceConsumerService } from '../web-service-consumer';
import { WebApplication, WebApplicationService } from '../web-application';

@Component({
    selector: 'marti-web-service-dialog',
    templateUrl: './web-service-dialog.component.html'
})
export class WebServiceDialogComponent implements OnInit {

    webService: WebService;
    authorities: any[];
    isSaving: boolean;

    webserviceconsumers: WebServiceConsumer[];

    webapplications: WebApplication[];
    constructor(
        public activeModal: NgbActiveModal,
        private dataUtils: DataUtils,
        private alertService: AlertService,
        private webServiceService: WebServiceService,
        private webServiceConsumerService: WebServiceConsumerService,
        private webApplicationService: WebApplicationService,
        private eventManager: EventManager
    ) {
    }

    ngOnInit() {
        this.isSaving = false;
        this.authorities = ['ROLE_USER', 'ROLE_ADMIN'];
        this.webServiceConsumerService.query().subscribe(
            (res: Response) => { this.webserviceconsumers = res.json(); }, (res: Response) => this.onError(res.json()));
        this.webApplicationService.query().subscribe(
            (res: Response) => { this.webapplications = res.json(); }, (res: Response) => this.onError(res.json()));
    }
    byteSize(field) {
        return this.dataUtils.byteSize(field);
    }

    openFile(contentType, field) {
        return this.dataUtils.openFile(contentType, field);
    }

    setFileData($event, webService, field, isImage) {
        if ($event.target.files && $event.target.files[0]) {
            let $file = $event.target.files[0];
            if (isImage && !/^image\//.test($file.type)) {
                return;
            }
            this.dataUtils.toBase64($file, (base64Data) => {
                webService[field] = base64Data;
                webService[`${field}ContentType`] = $file.type;
            });
        }
    }
    clear () {
        this.activeModal.dismiss('cancel');
    }

    save () {
        this.isSaving = true;
        if (this.webService.id !== undefined) {
            this.webServiceService.update(this.webService)
                .subscribe((res: WebService) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        } else {
            this.webServiceService.create(this.webService)
                .subscribe((res: WebService) =>
                    this.onSaveSuccess(res), (res: Response) => this.onSaveError(res.json()));
        }
    }

    private onSaveSuccess (result: WebService) {
        this.eventManager.broadcast({ name: 'webServiceListModification', content: 'OK'});
        this.isSaving = false;
        this.activeModal.dismiss(result);
    }

    private onSaveError (error) {
        this.isSaving = false;
        this.onError(error);
    }

    private onError (error) {
        this.alertService.error(error.message, null, null);
    }

    trackWebServiceConsumerById(index: number, item: WebServiceConsumer) {
        return item.id;
    }

    trackWebApplicationById(index: number, item: WebApplication) {
        return item.id;
    }
}

@Component({
    selector: 'marti-web-service-popup',
    template: ''
})
export class WebServicePopupComponent implements OnInit, OnDestroy {

    modalRef: NgbModalRef;
    routeSub: any;

    constructor (
        private route: ActivatedRoute,
        private webServicePopupService: WebServicePopupService
    ) {}

    ngOnInit() {
        this.routeSub = this.route.params.subscribe(params => {
            if ( params['id'] ) {
                this.modalRef = this.webServicePopupService
                    .open(WebServiceDialogComponent, params['id']);
            } else {
                this.modalRef = this.webServicePopupService
                    .open(WebServiceDialogComponent);
            }

        });
    }

    ngOnDestroy() {
        this.routeSub.unsubscribe();
    }
}
