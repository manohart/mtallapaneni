import { Injectable, Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { WebService } from './web-service.model';
import { WebServiceService } from './web-service.service';
@Injectable()
export class WebServicePopupService {
    private isOpen = false;
    constructor (
        private datePipe: DatePipe,
        private modalService: NgbModal,
        private router: Router,
        private webServiceService: WebServiceService

    ) {}

    open (component: Component, id?: number | any): NgbModalRef {
        if (this.isOpen) {
            return;
        }
        this.isOpen = true;

        if (id) {
            this.webServiceService.find(id).subscribe(webService => {
                webService.updatedDate = this.datePipe
                    .transform(webService.updatedDate, 'yyyy-MM-ddThh:mm');
                this.webServiceModalRef(component, webService);
            });
        } else {
            return this.webServiceModalRef(component, new WebService());
        }
    }

    webServiceModalRef(component: Component, webService: WebService): NgbModalRef {
        let modalRef = this.modalService.open(component, { size: 'lg', backdrop: 'static'});
        modalRef.componentInstance.webService = webService;
        modalRef.result.then(result => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        }, (reason) => {
            this.router.navigate([{ outlets: { popup: null }}], { replaceUrl: true });
            this.isOpen = false;
        });
        return modalRef;
    }
}
