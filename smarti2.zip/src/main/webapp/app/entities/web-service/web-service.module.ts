import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { SmartISharedModule } from '../../shared';

import {
    WebServiceService,
    WebServicePopupService,
    WebServiceComponent,
    WebServiceDetailComponent,
    WebServiceDialogComponent,
    WebServicePopupComponent,
    WebServiceDeletePopupComponent,
    WebServiceDeleteDialogComponent,
    webServiceRoute,
    webServicePopupRoute,
    WebServiceResolvePagingParams,
} from './';

let ENTITY_STATES = [
    ...webServiceRoute,
    ...webServicePopupRoute,
];

@NgModule({
    imports: [
        SmartISharedModule,
        RouterModule.forRoot(ENTITY_STATES, { useHash: true })
    ],
    declarations: [
        WebServiceComponent,
        WebServiceDetailComponent,
        WebServiceDialogComponent,
        WebServiceDeleteDialogComponent,
        WebServicePopupComponent,
        WebServiceDeletePopupComponent,
    ],
    entryComponents: [
        WebServiceComponent,
        WebServiceDialogComponent,
        WebServicePopupComponent,
        WebServiceDeleteDialogComponent,
        WebServiceDeletePopupComponent,
    ],
    providers: [
        WebServiceService,
        WebServicePopupService,
        WebServiceResolvePagingParams,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SmartIWebServiceModule {}
