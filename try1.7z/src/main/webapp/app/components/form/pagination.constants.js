(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .constant('paginationConstants', {
            'itemsPerPage': 20
        });
})();
