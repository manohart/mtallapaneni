(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('AppDependencyDialogController', AppDependencyDialogController);

    AppDependencyDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', '$q', 'entity', 'AppDependency', 'Application'];

    function AppDependencyDialogController ($timeout, $scope, $stateParams, $uibModalInstance, $q, entity, AppDependency, Application) {
        var vm = this;

        vm.appDependency = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.applications = Application.query({filter: 'appdependency-is-null'});
        $q.all([vm.appDependency.$promise, vm.applications.$promise]).then(function() {
            if (!vm.appDependency.applicationId) {
                return $q.reject();
            }
            return Application.get({id : vm.appDependency.applicationId}).$promise;
        }).then(function(application) {
            vm.applications.push(application);
        });
        vm.dependsons = Application.query({filter: 'appdependency-is-null'});
        $q.all([vm.appDependency.$promise, vm.dependsons.$promise]).then(function() {
            if (!vm.appDependency.dependsOnId) {
                return $q.reject();
            }
            return Application.get({id : vm.appDependency.dependsOnId}).$promise;
        }).then(function(dependsOn) {
            vm.dependsons.push(dependsOn);
        });

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.appDependency.id !== null) {
                AppDependency.update(vm.appDependency, onSaveSuccess, onSaveError);
            } else {
                AppDependency.save(vm.appDependency, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('healthCheckApp:appDependencyUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
