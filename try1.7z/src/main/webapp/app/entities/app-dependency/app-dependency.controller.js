(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('AppDependencyController', AppDependencyController);

    AppDependencyController.$inject = ['$scope', '$state', 'AppDependency'];

    function AppDependencyController ($scope, $state, AppDependency) {
        var vm = this;
        
        vm.appDependencies = [];

        loadAll();

        function loadAll() {
            AppDependency.query(function(result) {
                vm.appDependencies = result;
            });
        }
    }
})();
