(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('ArchiveLocationDeleteController',ArchiveLocationDeleteController);

    ArchiveLocationDeleteController.$inject = ['$uibModalInstance', 'entity', 'ArchiveLocation'];

    function ArchiveLocationDeleteController($uibModalInstance, entity, ArchiveLocation) {
        var vm = this;

        vm.archiveLocation = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;
        
        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            ArchiveLocation.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
