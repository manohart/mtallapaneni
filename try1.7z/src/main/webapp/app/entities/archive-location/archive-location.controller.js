(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('ArchiveLocationController', ArchiveLocationController);

    ArchiveLocationController.$inject = ['$scope', '$state', 'ArchiveLocation'];

    function ArchiveLocationController ($scope, $state, ArchiveLocation) {
        var vm = this;
        
        vm.archiveLocations = [];

        loadAll();

        function loadAll() {
            ArchiveLocation.query(function(result) {
                vm.archiveLocations = result;
            });
        }
    }
})();
