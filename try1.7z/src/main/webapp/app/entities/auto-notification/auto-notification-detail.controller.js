(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('AutoNotificationDetailController', AutoNotificationDetailController);

    AutoNotificationDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'AutoNotification', 'Application'];

    function AutoNotificationDetailController($scope, $rootScope, $stateParams, previousState, entity, AutoNotification, Application) {
        var vm = this;

        vm.autoNotification = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('healthCheckApp:autoNotificationUpdate', function(event, result) {
            vm.autoNotification = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
