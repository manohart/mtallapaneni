(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('AutoNotificationController', AutoNotificationController);

    AutoNotificationController.$inject = ['$scope', '$state', 'AutoNotification'];

    function AutoNotificationController ($scope, $state, AutoNotification) {
        var vm = this;
        
        vm.autoNotifications = [];

        loadAll();

        function loadAll() {
            AutoNotification.query(function(result) {
                vm.autoNotifications = result;
            });
        }
    }
})();
