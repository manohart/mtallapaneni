(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('BatchJobController', BatchJobController);

    BatchJobController.$inject = ['$scope', '$state', 'BatchJob'];

    function BatchJobController ($scope, $state, BatchJob) {
        var vm = this;
        
        vm.batchJobs = [];

        loadAll();

        function loadAll() {
            BatchJob.query(function(result) {
                vm.batchJobs = result;
            });
        }
    }
})();
