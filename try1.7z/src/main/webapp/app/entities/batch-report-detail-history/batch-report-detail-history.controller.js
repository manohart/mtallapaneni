(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('BatchReportDetailHistoryController', BatchReportDetailHistoryController);

    BatchReportDetailHistoryController.$inject = ['$scope', '$state', 'BatchReportDetailHistory'];

    function BatchReportDetailHistoryController ($scope, $state, BatchReportDetailHistory) {
        var vm = this;
        
        vm.batchReportDetailHistories = [];

        loadAll();

        function loadAll() {
            BatchReportDetailHistory.query(function(result) {
                vm.batchReportDetailHistories = result;
            });
        }
    }
})();
