(function() {
    'use strict';
    angular
        .module('healthCheckApp')
        .factory('BatchReportDetailHistory', BatchReportDetailHistory);

    BatchReportDetailHistory.$inject = ['$resource'];

    function BatchReportDetailHistory ($resource) {
        var resourceUrl =  'api/batch-report-detail-histories/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true},
            'get': {
                method: 'GET',
                transformResponse: function (data) {
                    if (data) {
                        data = angular.fromJson(data);
                    }
                    return data;
                }
            },
            'update': { method:'PUT' }
        });
    }
})();
