(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('BatchReportHistoryDeleteController',BatchReportHistoryDeleteController);

    BatchReportHistoryDeleteController.$inject = ['$uibModalInstance', 'entity', 'BatchReportHistory'];

    function BatchReportHistoryDeleteController($uibModalInstance, entity, BatchReportHistory) {
        var vm = this;

        vm.batchReportHistory = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;
        
        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            BatchReportHistory.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
