(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('BatchReportHistoryDetailController', BatchReportHistoryDetailController);

    BatchReportHistoryDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'BatchReportHistory', 'BatchReport', 'BatchReportDetailHistory'];

    function BatchReportHistoryDetailController($scope, $rootScope, $stateParams, previousState, entity, BatchReportHistory, BatchReport, BatchReportDetailHistory) {
        var vm = this;

        vm.batchReportHistory = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('healthCheckApp:batchReportHistoryUpdate', function(event, result) {
            vm.batchReportHistory = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
