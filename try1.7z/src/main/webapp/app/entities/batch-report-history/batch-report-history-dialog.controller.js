(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('BatchReportHistoryDialogController', BatchReportHistoryDialogController);

    BatchReportHistoryDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', '$q', 'entity', 'BatchReportHistory', 'BatchReport', 'BatchReportDetailHistory'];

    function BatchReportHistoryDialogController ($timeout, $scope, $stateParams, $uibModalInstance, $q, entity, BatchReportHistory, BatchReport, BatchReportDetailHistory) {
        var vm = this;

        vm.batchReportHistory = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.batchreports = BatchReport.query();
        vm.batchreportdetailhistories = BatchReportDetailHistory.query();
        vm.reports = BatchReport.query({filter: 'batchreporthistory-is-null'});
        $q.all([vm.batchReportHistory.$promise, vm.reports.$promise]).then(function() {
            if (!vm.batchReportHistory.reportId) {
                return $q.reject();
            }
            return BatchReport.get({id : vm.batchReportHistory.reportId}).$promise;
        }).then(function(report) {
            vm.reports.push(report);
        });

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.batchReportHistory.id !== null) {
                BatchReportHistory.update(vm.batchReportHistory, onSaveSuccess, onSaveError);
            } else {
                BatchReportHistory.save(vm.batchReportHistory, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('healthCheckApp:batchReportHistoryUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.businessDate = false;
        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
