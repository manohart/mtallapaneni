(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('BatchReportHistoryController', BatchReportHistoryController);

    BatchReportHistoryController.$inject = ['$scope', '$state', 'BatchReportHistory'];

    function BatchReportHistoryController ($scope, $state, BatchReportHistory) {
        var vm = this;
        
        vm.batchReportHistories = [];

        loadAll();

        function loadAll() {
            BatchReportHistory.query(function(result) {
                vm.batchReportHistories = result;
            });
        }
    }
})();
