(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('batch-report-history', {
            parent: 'entity',
            url: '/batch-report-history',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'healthCheckApp.batchReportHistory.home.title'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/batch-report-history/batch-report-histories.html',
                    controller: 'BatchReportHistoryController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                translatePartialLoader: ['$translate', '$translatePartialLoader', function ($translate, $translatePartialLoader) {
                    $translatePartialLoader.addPart('batchReportHistory');
                    $translatePartialLoader.addPart('global');
                    return $translate.refresh();
                }]
            }
        })
        .state('batch-report-history-detail', {
            parent: 'entity',
            url: '/batch-report-history/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'healthCheckApp.batchReportHistory.detail.title'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/batch-report-history/batch-report-history-detail.html',
                    controller: 'BatchReportHistoryDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                translatePartialLoader: ['$translate', '$translatePartialLoader', function ($translate, $translatePartialLoader) {
                    $translatePartialLoader.addPart('batchReportHistory');
                    return $translate.refresh();
                }],
                entity: ['$stateParams', 'BatchReportHistory', function($stateParams, BatchReportHistory) {
                    return BatchReportHistory.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'batch-report-history',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('batch-report-history-detail.edit', {
            parent: 'batch-report-history-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-report-history/batch-report-history-dialog.html',
                    controller: 'BatchReportHistoryDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['BatchReportHistory', function(BatchReportHistory) {
                            return BatchReportHistory.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('batch-report-history.new', {
            parent: 'batch-report-history',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-report-history/batch-report-history-dialog.html',
                    controller: 'BatchReportHistoryDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                initialStatus: null,
                                finalStatus: null,
                                businessDate: null,
                                comment: null,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('batch-report-history', null, { reload: 'batch-report-history' });
                }, function() {
                    $state.go('batch-report-history');
                });
            }]
        })
        .state('batch-report-history.edit', {
            parent: 'batch-report-history',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-report-history/batch-report-history-dialog.html',
                    controller: 'BatchReportHistoryDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['BatchReportHistory', function(BatchReportHistory) {
                            return BatchReportHistory.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('batch-report-history', null, { reload: 'batch-report-history' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('batch-report-history.delete', {
            parent: 'batch-report-history',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-report-history/batch-report-history-delete-dialog.html',
                    controller: 'BatchReportHistoryDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['BatchReportHistory', function(BatchReportHistory) {
                            return BatchReportHistory.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('batch-report-history', null, { reload: 'batch-report-history' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
