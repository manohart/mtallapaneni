(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('BatchReportDetailController', BatchReportDetailController);

    BatchReportDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'BatchReport', 'BatchJob', 'DbCheck', 'BatchReportHistory', 'Distribution'];

    function BatchReportDetailController($scope, $rootScope, $stateParams, previousState, entity, BatchReport, BatchJob, DbCheck, BatchReportHistory, Distribution) {
        var vm = this;

        vm.batchReport = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('healthCheckApp:batchReportUpdate', function(event, result) {
            vm.batchReport = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
