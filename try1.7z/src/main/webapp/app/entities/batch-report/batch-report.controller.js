(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('BatchReportController', BatchReportController);

    BatchReportController.$inject = ['$scope', '$state', 'BatchReport'];

    function BatchReportController ($scope, $state, BatchReport) {
        var vm = this;
        
        vm.batchReports = [];

        loadAll();

        function loadAll() {
            BatchReport.query(function(result) {
                vm.batchReports = result;
            });
        }
    }
})();
