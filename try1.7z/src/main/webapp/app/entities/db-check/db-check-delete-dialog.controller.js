(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('DbCheckDeleteController',DbCheckDeleteController);

    DbCheckDeleteController.$inject = ['$uibModalInstance', 'entity', 'DbCheck'];

    function DbCheckDeleteController($uibModalInstance, entity, DbCheck) {
        var vm = this;

        vm.dbCheck = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;
        
        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            DbCheck.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
