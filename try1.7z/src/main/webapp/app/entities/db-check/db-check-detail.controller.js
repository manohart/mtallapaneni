(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('DbCheckDetailController', DbCheckDetailController);

    DbCheckDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'DbCheck', 'BatchReport', 'HealthChecker'];

    function DbCheckDetailController($scope, $rootScope, $stateParams, previousState, entity, DbCheck, BatchReport, HealthChecker) {
        var vm = this;

        vm.dbCheck = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('healthCheckApp:dbCheckUpdate', function(event, result) {
            vm.dbCheck = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
