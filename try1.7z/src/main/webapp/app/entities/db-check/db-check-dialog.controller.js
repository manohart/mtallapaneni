(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('DbCheckDialogController', DbCheckDialogController);

    DbCheckDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', '$q', 'entity', 'DbCheck', 'BatchReport', 'HealthChecker'];

    function DbCheckDialogController ($timeout, $scope, $stateParams, $uibModalInstance, $q, entity, DbCheck, BatchReport, HealthChecker) {
        var vm = this;

        vm.dbCheck = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.batchreports = BatchReport.query();
        vm.reports = BatchReport.query({filter: 'dbcheck-is-null'});
        $q.all([vm.dbCheck.$promise, vm.reports.$promise]).then(function() {
            if (!vm.dbCheck.reportId) {
                return $q.reject();
            }
            return BatchReport.get({id : vm.dbCheck.reportId}).$promise;
        }).then(function(report) {
            vm.reports.push(report);
        });
        vm.healthcheckers = HealthChecker.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.dbCheck.id !== null) {
                DbCheck.update(vm.dbCheck, onSaveSuccess, onSaveError);
            } else {
                DbCheck.save(vm.dbCheck, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('healthCheckApp:dbCheckUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
