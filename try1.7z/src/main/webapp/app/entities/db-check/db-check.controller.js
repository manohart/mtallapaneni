(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('DbCheckController', DbCheckController);

    DbCheckController.$inject = ['$scope', '$state', 'DbCheck'];

    function DbCheckController ($scope, $state, DbCheck) {
        var vm = this;
        
        vm.dbChecks = [];

        loadAll();

        function loadAll() {
            DbCheck.query(function(result) {
                vm.dbChecks = result;
            });
        }
    }
})();
