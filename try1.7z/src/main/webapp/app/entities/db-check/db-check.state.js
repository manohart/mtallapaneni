(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('db-check', {
            parent: 'entity',
            url: '/db-check',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'healthCheckApp.dbCheck.home.title'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/db-check/db-checks.html',
                    controller: 'DbCheckController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                translatePartialLoader: ['$translate', '$translatePartialLoader', function ($translate, $translatePartialLoader) {
                    $translatePartialLoader.addPart('dbCheck');
                    $translatePartialLoader.addPart('global');
                    return $translate.refresh();
                }]
            }
        })
        .state('db-check-detail', {
            parent: 'entity',
            url: '/db-check/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'healthCheckApp.dbCheck.detail.title'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/db-check/db-check-detail.html',
                    controller: 'DbCheckDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                translatePartialLoader: ['$translate', '$translatePartialLoader', function ($translate, $translatePartialLoader) {
                    $translatePartialLoader.addPart('dbCheck');
                    return $translate.refresh();
                }],
                entity: ['$stateParams', 'DbCheck', function($stateParams, DbCheck) {
                    return DbCheck.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'db-check',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('db-check-detail.edit', {
            parent: 'db-check-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/db-check/db-check-dialog.html',
                    controller: 'DbCheckDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['DbCheck', function(DbCheck) {
                            return DbCheck.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('db-check.new', {
            parent: 'db-check',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/db-check/db-check-dialog.html',
                    controller: 'DbCheckDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                name: null,
                                sqlQuery: null,
                                description: null,
                                expectation: null,
                                reportIssuesOnly: null,
                                groupColumns: null,
                                sequence: null,
                                isActive: null,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('db-check', null, { reload: 'db-check' });
                }, function() {
                    $state.go('db-check');
                });
            }]
        })
        .state('db-check.edit', {
            parent: 'db-check',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/db-check/db-check-dialog.html',
                    controller: 'DbCheckDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['DbCheck', function(DbCheck) {
                            return DbCheck.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('db-check', null, { reload: 'db-check' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('db-check.delete', {
            parent: 'db-check',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/db-check/db-check-delete-dialog.html',
                    controller: 'DbCheckDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['DbCheck', function(DbCheck) {
                            return DbCheck.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('db-check', null, { reload: 'db-check' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
