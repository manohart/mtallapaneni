(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('DevOpsController', DevOpsController);

    DevOpsController.$inject = ['$scope', '$state', 'DevOps'];

    function DevOpsController ($scope, $state, DevOps) {
        var vm = this;
        
        vm.devOps = [];

        loadAll();

        function loadAll() {
            DevOps.query(function(result) {
                vm.devOps = result;
            });
        }
    }
})();
