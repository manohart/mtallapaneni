(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('DistributionDetailController', DistributionDetailController);

    DistributionDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'Distribution'];

    function DistributionDetailController($scope, $rootScope, $stateParams, previousState, entity, Distribution) {
        var vm = this;

        vm.distribution = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('healthCheckApp:distributionUpdate', function(event, result) {
            vm.distribution = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
