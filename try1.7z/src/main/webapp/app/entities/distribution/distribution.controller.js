(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('DistributionController', DistributionController);

    DistributionController.$inject = ['$scope', '$state', 'Distribution'];

    function DistributionController ($scope, $state, Distribution) {
        var vm = this;
        
        vm.distributions = [];

        loadAll();

        function loadAll() {
            Distribution.query(function(result) {
                vm.distributions = result;
            });
        }
    }
})();
