(function() {
    'use strict';
    angular
        .module('healthCheckApp')
        .factory('Distribution', Distribution);

    Distribution.$inject = ['$resource', 'DateUtils'];

    function Distribution ($resource, DateUtils) {
        var resourceUrl =  'api/distributions/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true},
            'get': {
                method: 'GET',
                transformResponse: function (data) {
                    if (data) {
                        data = angular.fromJson(data);
                        data.updatedDate = DateUtils.convertDateTimeFromServer(data.updatedDate);
                    }
                    return data;
                }
            },
            'update': { method:'PUT' }
        });
    }
})();
