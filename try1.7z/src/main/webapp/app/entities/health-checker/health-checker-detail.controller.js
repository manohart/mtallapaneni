(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('HealthCheckerDetailController', HealthCheckerDetailController);

    HealthCheckerDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'HealthChecker', 'DbCheck'];

    function HealthCheckerDetailController($scope, $rootScope, $stateParams, previousState, entity, HealthChecker, DbCheck) {
        var vm = this;

        vm.healthChecker = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('healthCheckApp:healthCheckerUpdate', function(event, result) {
            vm.healthChecker = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
