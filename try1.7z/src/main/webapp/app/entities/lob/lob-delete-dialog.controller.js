(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('LobDeleteController',LobDeleteController);

    LobDeleteController.$inject = ['$uibModalInstance', 'entity', 'Lob'];

    function LobDeleteController($uibModalInstance, entity, Lob) {
        var vm = this;

        vm.lob = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;
        
        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            Lob.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
