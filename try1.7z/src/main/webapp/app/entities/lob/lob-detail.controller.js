(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('LobDetailController', LobDetailController);

    LobDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'Lob', 'ReleaseNoteHistory', 'Server', 'ArchiveLocation', 'Template'];

    function LobDetailController($scope, $rootScope, $stateParams, previousState, entity, Lob, ReleaseNoteHistory, Server, ArchiveLocation, Template) {
        var vm = this;

        vm.lob = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('healthCheckApp:lobUpdate', function(event, result) {
            vm.lob = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
