(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('LobController', LobController);

    LobController.$inject = ['$scope', '$state', 'Lob'];

    function LobController ($scope, $state, Lob) {
        var vm = this;
        
        vm.lobs = [];

        loadAll();

        function loadAll() {
            Lob.query(function(result) {
                vm.lobs = result;
            });
        }
    }
})();
