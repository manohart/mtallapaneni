(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('lob', {
            parent: 'entity',
            url: '/lob',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'healthCheckApp.lob.home.title'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/lob/lobs.html',
                    controller: 'LobController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                translatePartialLoader: ['$translate', '$translatePartialLoader', function ($translate, $translatePartialLoader) {
                    $translatePartialLoader.addPart('lob');
                    $translatePartialLoader.addPart('global');
                    return $translate.refresh();
                }]
            }
        })
        .state('lob-detail', {
            parent: 'entity',
            url: '/lob/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'healthCheckApp.lob.detail.title'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/lob/lob-detail.html',
                    controller: 'LobDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                translatePartialLoader: ['$translate', '$translatePartialLoader', function ($translate, $translatePartialLoader) {
                    $translatePartialLoader.addPart('lob');
                    return $translate.refresh();
                }],
                entity: ['$stateParams', 'Lob', function($stateParams, Lob) {
                    return Lob.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'lob',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('lob-detail.edit', {
            parent: 'lob-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/lob/lob-dialog.html',
                    controller: 'LobDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['Lob', function(Lob) {
                            return Lob.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('lob.new', {
            parent: 'lob',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/lob/lob-dialog.html',
                    controller: 'LobDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                name: null,
                                region: null,
                                sla: null,
                                ctoSid: null,
                                ownerSid: null,
                                businessSponsorSid: null,
                                isActive: false,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('lob', null, { reload: 'lob' });
                }, function() {
                    $state.go('lob');
                });
            }]
        })
        .state('lob.edit', {
            parent: 'lob',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/lob/lob-dialog.html',
                    controller: 'LobDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['Lob', function(Lob) {
                            return Lob.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('lob', null, { reload: 'lob' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('lob.delete', {
            parent: 'lob',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/lob/lob-delete-dialog.html',
                    controller: 'LobDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['Lob', function(Lob) {
                            return Lob.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('lob', null, { reload: 'lob' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
