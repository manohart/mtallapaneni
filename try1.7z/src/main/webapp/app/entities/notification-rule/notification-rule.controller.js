(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('NotificationRuleController', NotificationRuleController);

    NotificationRuleController.$inject = ['$scope', '$state', 'NotificationRule'];

    function NotificationRuleController ($scope, $state, NotificationRule) {
        var vm = this;
        
        vm.notificationRules = [];

        loadAll();

        function loadAll() {
            NotificationRule.query(function(result) {
                vm.notificationRules = result;
            });
        }
    }
})();
