(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('ReleaseNoteHistoryDeleteController',ReleaseNoteHistoryDeleteController);

    ReleaseNoteHistoryDeleteController.$inject = ['$uibModalInstance', 'entity', 'ReleaseNoteHistory'];

    function ReleaseNoteHistoryDeleteController($uibModalInstance, entity, ReleaseNoteHistory) {
        var vm = this;

        vm.releaseNoteHistory = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;
        
        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            ReleaseNoteHistory.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
