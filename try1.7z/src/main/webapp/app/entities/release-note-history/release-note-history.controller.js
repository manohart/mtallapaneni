(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('ReleaseNoteHistoryController', ReleaseNoteHistoryController);

    ReleaseNoteHistoryController.$inject = ['$scope', '$state', 'ReleaseNoteHistory'];

    function ReleaseNoteHistoryController ($scope, $state, ReleaseNoteHistory) {
        var vm = this;
        
        vm.releaseNoteHistories = [];

        loadAll();

        function loadAll() {
            ReleaseNoteHistory.query(function(result) {
                vm.releaseNoteHistories = result;
            });
        }
    }
})();
