(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('WebAppController', WebAppController);

    WebAppController.$inject = ['$scope', '$state', 'WebApp'];

    function WebAppController ($scope, $state, WebApp) {
        var vm = this;
        
        vm.webApps = [];

        loadAll();

        function loadAll() {
            WebApp.query(function(result) {
                vm.webApps = result;
            });
        }
    }
})();
