(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('WebServiceConsumerDetailController', WebServiceConsumerDetailController);

    WebServiceConsumerDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'WebServiceConsumer', 'WebService', 'Application'];

    function WebServiceConsumerDetailController($scope, $rootScope, $stateParams, previousState, entity, WebServiceConsumer, WebService, Application) {
        var vm = this;

        vm.webServiceConsumer = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('healthCheckApp:webServiceConsumerUpdate', function(event, result) {
            vm.webServiceConsumer = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
