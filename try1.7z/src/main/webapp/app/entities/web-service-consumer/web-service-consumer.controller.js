(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('WebServiceConsumerController', WebServiceConsumerController);

    WebServiceConsumerController.$inject = ['$scope', '$state', 'WebServiceConsumer'];

    function WebServiceConsumerController ($scope, $state, WebServiceConsumer) {
        var vm = this;
        
        vm.webServiceConsumers = [];

        loadAll();

        function loadAll() {
            WebServiceConsumer.query(function(result) {
                vm.webServiceConsumers = result;
            });
        }
    }
})();
