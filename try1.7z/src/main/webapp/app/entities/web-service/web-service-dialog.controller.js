(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('WebServiceDialogController', WebServiceDialogController);

    WebServiceDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', '$q', 'entity', 'WebService', 'WebApp', 'WebServiceConsumer'];

    function WebServiceDialogController ($timeout, $scope, $stateParams, $uibModalInstance, $q, entity, WebService, WebApp, WebServiceConsumer) {
        var vm = this;

        vm.webService = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.webapps = WebApp.query();
        vm.webserviceconsumers = WebServiceConsumer.query();
        vm.applications = WebApp.query({filter: 'webservice-is-null'});
        $q.all([vm.webService.$promise, vm.applications.$promise]).then(function() {
            if (!vm.webService.applicationId) {
                return $q.reject();
            }
            return WebApp.get({id : vm.webService.applicationId}).$promise;
        }).then(function(application) {
            vm.applications.push(application);
        });

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.webService.id !== null) {
                WebService.update(vm.webService, onSaveSuccess, onSaveError);
            } else {
                WebService.save(vm.webService, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('healthCheckApp:webServiceUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
