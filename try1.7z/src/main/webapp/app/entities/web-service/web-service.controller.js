(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('WebServiceController', WebServiceController);

    WebServiceController.$inject = ['$scope', '$state', 'WebService'];

    function WebServiceController ($scope, $state, WebService) {
        var vm = this;
        
        vm.webServices = [];

        loadAll();

        function loadAll() {
            WebService.query(function(result) {
                vm.webServices = result;
            });
        }
    }
})();
