package com.jpmorgan.am.spectrum.web.rest;

import com.jpmorgan.am.spectrum.HealthCheckApp;

import com.jpmorgan.am.spectrum.domain.BatchJob;
import com.jpmorgan.am.spectrum.repository.BatchJobRepository;
import com.jpmorgan.am.spectrum.service.BatchJobService;
import com.jpmorgan.am.spectrum.service.dto.BatchJobDTO;
import com.jpmorgan.am.spectrum.service.mapper.BatchJobMapper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneId;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.jpmorgan.am.spectrum.domain.enumeration.AppScheduler;
/**
 * Test class for the BatchJobResource REST controller.
 *
 * @see BatchJobResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = HealthCheckApp.class)
public class BatchJobResourceIntTest {

    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(ZoneId.of("Z"));


    private static final AppScheduler DEFAULT_SCHEDULER = AppScheduler.CONTROL_M;
    private static final AppScheduler UPDATED_SCHEDULER = AppScheduler.AUTOSYS;

    private static final Boolean DEFAULT_IS_ACTIVE = false;
    private static final Boolean UPDATED_IS_ACTIVE = true;

    private static final ZonedDateTime DEFAULT_UPDATED_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneId.systemDefault());
    private static final ZonedDateTime UPDATED_UPDATED_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);
    private static final String DEFAULT_UPDATED_DATE_STR = dateTimeFormatter.format(DEFAULT_UPDATED_DATE);

    @Inject
    private BatchJobRepository batchJobRepository;

    @Inject
    private BatchJobMapper batchJobMapper;

    @Inject
    private BatchJobService batchJobService;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restBatchJobMockMvc;

    private BatchJob batchJob;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        BatchJobResource batchJobResource = new BatchJobResource();
        ReflectionTestUtils.setField(batchJobResource, "batchJobService", batchJobService);
        this.restBatchJobMockMvc = MockMvcBuilders.standaloneSetup(batchJobResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static BatchJob createEntity(EntityManager em) {
        BatchJob batchJob = new BatchJob();
        batchJob.setScheduler(DEFAULT_SCHEDULER);
        batchJob.setIsActive(DEFAULT_IS_ACTIVE);
        batchJob.setUpdatedDate(DEFAULT_UPDATED_DATE);
        return batchJob;
    }

    @Before
    public void initTest() {
        batchJob = createEntity(em);
    }

    @Test
    @Transactional
    public void createBatchJob() throws Exception {
        int databaseSizeBeforeCreate = batchJobRepository.findAll().size();

        // Create the BatchJob
        BatchJobDTO batchJobDTO = batchJobMapper.batchJobToBatchJobDTO(batchJob);

        restBatchJobMockMvc.perform(post("/api/batch-jobs")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batchJobDTO)))
                .andExpect(status().isCreated());

        // Validate the BatchJob in the database
        List<BatchJob> batchJobs = batchJobRepository.findAll();
        assertThat(batchJobs).hasSize(databaseSizeBeforeCreate + 1);
        BatchJob testBatchJob = batchJobs.get(batchJobs.size() - 1);
        assertThat(testBatchJob.getScheduler()).isEqualTo(DEFAULT_SCHEDULER);
        assertThat(testBatchJob.isIsActive()).isEqualTo(DEFAULT_IS_ACTIVE);
        assertThat(testBatchJob.getUpdatedDate()).isEqualTo(DEFAULT_UPDATED_DATE);
    }

    @Test
    @Transactional
    public void checkSchedulerIsRequired() throws Exception {
        int databaseSizeBeforeTest = batchJobRepository.findAll().size();
        // set the field null
        batchJob.setScheduler(null);

        // Create the BatchJob, which fails.
        BatchJobDTO batchJobDTO = batchJobMapper.batchJobToBatchJobDTO(batchJob);

        restBatchJobMockMvc.perform(post("/api/batch-jobs")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batchJobDTO)))
                .andExpect(status().isBadRequest());

        List<BatchJob> batchJobs = batchJobRepository.findAll();
        assertThat(batchJobs).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkIsActiveIsRequired() throws Exception {
        int databaseSizeBeforeTest = batchJobRepository.findAll().size();
        // set the field null
        batchJob.setIsActive(null);

        // Create the BatchJob, which fails.
        BatchJobDTO batchJobDTO = batchJobMapper.batchJobToBatchJobDTO(batchJob);

        restBatchJobMockMvc.perform(post("/api/batch-jobs")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batchJobDTO)))
                .andExpect(status().isBadRequest());

        List<BatchJob> batchJobs = batchJobRepository.findAll();
        assertThat(batchJobs).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllBatchJobs() throws Exception {
        // Initialize the database
        batchJobRepository.saveAndFlush(batchJob);

        // Get all the batchJobs
        restBatchJobMockMvc.perform(get("/api/batch-jobs?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andExpect(jsonPath("$.[*].id").value(hasItem(batchJob.getId().intValue())))
                .andExpect(jsonPath("$.[*].scheduler").value(hasItem(DEFAULT_SCHEDULER.toString())))
                .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
                .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }

    @Test
    @Transactional
    public void getBatchJob() throws Exception {
        // Initialize the database
        batchJobRepository.saveAndFlush(batchJob);

        // Get the batchJob
        restBatchJobMockMvc.perform(get("/api/batch-jobs/{id}", batchJob.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(batchJob.getId().intValue()))
            .andExpect(jsonPath("$.scheduler").value(DEFAULT_SCHEDULER.toString()))
            .andExpect(jsonPath("$.isActive").value(DEFAULT_IS_ACTIVE.booleanValue()))
            .andExpect(jsonPath("$.updatedDate").value(DEFAULT_UPDATED_DATE_STR));
    }

    @Test
    @Transactional
    public void getNonExistingBatchJob() throws Exception {
        // Get the batchJob
        restBatchJobMockMvc.perform(get("/api/batch-jobs/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateBatchJob() throws Exception {
        // Initialize the database
        batchJobRepository.saveAndFlush(batchJob);
        int databaseSizeBeforeUpdate = batchJobRepository.findAll().size();

        // Update the batchJob
        BatchJob updatedBatchJob = batchJobRepository.findOne(batchJob.getId());
        updatedBatchJob.setScheduler(UPDATED_SCHEDULER);
        updatedBatchJob.setIsActive(UPDATED_IS_ACTIVE);
        updatedBatchJob.setUpdatedDate(UPDATED_UPDATED_DATE);
        BatchJobDTO batchJobDTO = batchJobMapper.batchJobToBatchJobDTO(updatedBatchJob);

        restBatchJobMockMvc.perform(put("/api/batch-jobs")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batchJobDTO)))
                .andExpect(status().isOk());

        // Validate the BatchJob in the database
        List<BatchJob> batchJobs = batchJobRepository.findAll();
        assertThat(batchJobs).hasSize(databaseSizeBeforeUpdate);
        BatchJob testBatchJob = batchJobs.get(batchJobs.size() - 1);
        assertThat(testBatchJob.getScheduler()).isEqualTo(UPDATED_SCHEDULER);
        assertThat(testBatchJob.isIsActive()).isEqualTo(UPDATED_IS_ACTIVE);
        assertThat(testBatchJob.getUpdatedDate()).isEqualTo(UPDATED_UPDATED_DATE);
    }

    @Test
    @Transactional
    public void deleteBatchJob() throws Exception {
        // Initialize the database
        batchJobRepository.saveAndFlush(batchJob);
        int databaseSizeBeforeDelete = batchJobRepository.findAll().size();

        // Get the batchJob
        restBatchJobMockMvc.perform(delete("/api/batch-jobs/{id}", batchJob.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate the database is empty
        List<BatchJob> batchJobs = batchJobRepository.findAll();
        assertThat(batchJobs).hasSize(databaseSizeBeforeDelete - 1);
    }
}
