package com.jpmorgan.am.spectrum.web.rest;

import com.jpmorgan.am.spectrum.HealthCheckApp;

import com.jpmorgan.am.spectrum.domain.Distribution;
import com.jpmorgan.am.spectrum.repository.DistributionRepository;
import com.jpmorgan.am.spectrum.service.DistributionService;
import com.jpmorgan.am.spectrum.service.dto.DistributionDTO;
import com.jpmorgan.am.spectrum.service.mapper.DistributionMapper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneId;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the DistributionResource REST controller.
 *
 * @see DistributionResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = HealthCheckApp.class)
public class DistributionResourceIntTest {

    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(ZoneId.of("Z"));

    private static final String DEFAULT_NAME = "AAAAA";
    private static final String UPDATED_NAME = "BBBBB";
    private static final String DEFAULT_FROM_ADDRESS = "AAAAA";
    private static final String UPDATED_FROM_ADDRESS = "BBBBB";
    private static final String DEFAULT_TO_ADDRESS = "AAAAA";
    private static final String UPDATED_TO_ADDRESS = "BBBBB";
    private static final String DEFAULT_CC_ADDRESS = "AAAAA";
    private static final String UPDATED_CC_ADDRESS = "BBBBB";

    private static final Boolean DEFAULT_SKIP_EMPTY = false;
    private static final Boolean UPDATED_SKIP_EMPTY = true;

    private static final Boolean DEFAULT_IS_ACTIVE = false;
    private static final Boolean UPDATED_IS_ACTIVE = true;

    private static final ZonedDateTime DEFAULT_UPDATED_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneId.systemDefault());
    private static final ZonedDateTime UPDATED_UPDATED_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);
    private static final String DEFAULT_UPDATED_DATE_STR = dateTimeFormatter.format(DEFAULT_UPDATED_DATE);

    @Inject
    private DistributionRepository distributionRepository;

    @Inject
    private DistributionMapper distributionMapper;

    @Inject
    private DistributionService distributionService;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restDistributionMockMvc;

    private Distribution distribution;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        DistributionResource distributionResource = new DistributionResource();
        ReflectionTestUtils.setField(distributionResource, "distributionService", distributionService);
        this.restDistributionMockMvc = MockMvcBuilders.standaloneSetup(distributionResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Distribution createEntity(EntityManager em) {
        Distribution distribution = new Distribution();
        distribution.setName(DEFAULT_NAME);
        distribution.setFromAddress(DEFAULT_FROM_ADDRESS);
        distribution.setToAddress(DEFAULT_TO_ADDRESS);
        distribution.setCcAddress(DEFAULT_CC_ADDRESS);
        distribution.setSkipEmpty(DEFAULT_SKIP_EMPTY);
        distribution.setIsActive(DEFAULT_IS_ACTIVE);
        distribution.setUpdatedDate(DEFAULT_UPDATED_DATE);
        return distribution;
    }

    @Before
    public void initTest() {
        distribution = createEntity(em);
    }

    @Test
    @Transactional
    public void createDistribution() throws Exception {
        int databaseSizeBeforeCreate = distributionRepository.findAll().size();

        // Create the Distribution
        DistributionDTO distributionDTO = distributionMapper.distributionToDistributionDTO(distribution);

        restDistributionMockMvc.perform(post("/api/distributions")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(distributionDTO)))
                .andExpect(status().isCreated());

        // Validate the Distribution in the database
        List<Distribution> distributions = distributionRepository.findAll();
        assertThat(distributions).hasSize(databaseSizeBeforeCreate + 1);
        Distribution testDistribution = distributions.get(distributions.size() - 1);
        assertThat(testDistribution.getName()).isEqualTo(DEFAULT_NAME);
        assertThat(testDistribution.getFromAddress()).isEqualTo(DEFAULT_FROM_ADDRESS);
        assertThat(testDistribution.getToAddress()).isEqualTo(DEFAULT_TO_ADDRESS);
        assertThat(testDistribution.getCcAddress()).isEqualTo(DEFAULT_CC_ADDRESS);
        assertThat(testDistribution.isSkipEmpty()).isEqualTo(DEFAULT_SKIP_EMPTY);
        assertThat(testDistribution.isIsActive()).isEqualTo(DEFAULT_IS_ACTIVE);
        assertThat(testDistribution.getUpdatedDate()).isEqualTo(DEFAULT_UPDATED_DATE);
    }

    @Test
    @Transactional
    public void checkNameIsRequired() throws Exception {
        int databaseSizeBeforeTest = distributionRepository.findAll().size();
        // set the field null
        distribution.setName(null);

        // Create the Distribution, which fails.
        DistributionDTO distributionDTO = distributionMapper.distributionToDistributionDTO(distribution);

        restDistributionMockMvc.perform(post("/api/distributions")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(distributionDTO)))
                .andExpect(status().isBadRequest());

        List<Distribution> distributions = distributionRepository.findAll();
        assertThat(distributions).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkFromAddressIsRequired() throws Exception {
        int databaseSizeBeforeTest = distributionRepository.findAll().size();
        // set the field null
        distribution.setFromAddress(null);

        // Create the Distribution, which fails.
        DistributionDTO distributionDTO = distributionMapper.distributionToDistributionDTO(distribution);

        restDistributionMockMvc.perform(post("/api/distributions")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(distributionDTO)))
                .andExpect(status().isBadRequest());

        List<Distribution> distributions = distributionRepository.findAll();
        assertThat(distributions).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkToAddressIsRequired() throws Exception {
        int databaseSizeBeforeTest = distributionRepository.findAll().size();
        // set the field null
        distribution.setToAddress(null);

        // Create the Distribution, which fails.
        DistributionDTO distributionDTO = distributionMapper.distributionToDistributionDTO(distribution);

        restDistributionMockMvc.perform(post("/api/distributions")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(distributionDTO)))
                .andExpect(status().isBadRequest());

        List<Distribution> distributions = distributionRepository.findAll();
        assertThat(distributions).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkCcAddressIsRequired() throws Exception {
        int databaseSizeBeforeTest = distributionRepository.findAll().size();
        // set the field null
        distribution.setCcAddress(null);

        // Create the Distribution, which fails.
        DistributionDTO distributionDTO = distributionMapper.distributionToDistributionDTO(distribution);

        restDistributionMockMvc.perform(post("/api/distributions")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(distributionDTO)))
                .andExpect(status().isBadRequest());

        List<Distribution> distributions = distributionRepository.findAll();
        assertThat(distributions).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkSkipEmptyIsRequired() throws Exception {
        int databaseSizeBeforeTest = distributionRepository.findAll().size();
        // set the field null
        distribution.setSkipEmpty(null);

        // Create the Distribution, which fails.
        DistributionDTO distributionDTO = distributionMapper.distributionToDistributionDTO(distribution);

        restDistributionMockMvc.perform(post("/api/distributions")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(distributionDTO)))
                .andExpect(status().isBadRequest());

        List<Distribution> distributions = distributionRepository.findAll();
        assertThat(distributions).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkIsActiveIsRequired() throws Exception {
        int databaseSizeBeforeTest = distributionRepository.findAll().size();
        // set the field null
        distribution.setIsActive(null);

        // Create the Distribution, which fails.
        DistributionDTO distributionDTO = distributionMapper.distributionToDistributionDTO(distribution);

        restDistributionMockMvc.perform(post("/api/distributions")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(distributionDTO)))
                .andExpect(status().isBadRequest());

        List<Distribution> distributions = distributionRepository.findAll();
        assertThat(distributions).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllDistributions() throws Exception {
        // Initialize the database
        distributionRepository.saveAndFlush(distribution);

        // Get all the distributions
        restDistributionMockMvc.perform(get("/api/distributions?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andExpect(jsonPath("$.[*].id").value(hasItem(distribution.getId().intValue())))
                .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
                .andExpect(jsonPath("$.[*].fromAddress").value(hasItem(DEFAULT_FROM_ADDRESS.toString())))
                .andExpect(jsonPath("$.[*].toAddress").value(hasItem(DEFAULT_TO_ADDRESS.toString())))
                .andExpect(jsonPath("$.[*].ccAddress").value(hasItem(DEFAULT_CC_ADDRESS.toString())))
                .andExpect(jsonPath("$.[*].skipEmpty").value(hasItem(DEFAULT_SKIP_EMPTY.booleanValue())))
                .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
                .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }

    @Test
    @Transactional
    public void getDistribution() throws Exception {
        // Initialize the database
        distributionRepository.saveAndFlush(distribution);

        // Get the distribution
        restDistributionMockMvc.perform(get("/api/distributions/{id}", distribution.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(distribution.getId().intValue()))
            .andExpect(jsonPath("$.name").value(DEFAULT_NAME.toString()))
            .andExpect(jsonPath("$.fromAddress").value(DEFAULT_FROM_ADDRESS.toString()))
            .andExpect(jsonPath("$.toAddress").value(DEFAULT_TO_ADDRESS.toString()))
            .andExpect(jsonPath("$.ccAddress").value(DEFAULT_CC_ADDRESS.toString()))
            .andExpect(jsonPath("$.skipEmpty").value(DEFAULT_SKIP_EMPTY.booleanValue()))
            .andExpect(jsonPath("$.isActive").value(DEFAULT_IS_ACTIVE.booleanValue()))
            .andExpect(jsonPath("$.updatedDate").value(DEFAULT_UPDATED_DATE_STR));
    }

    @Test
    @Transactional
    public void getNonExistingDistribution() throws Exception {
        // Get the distribution
        restDistributionMockMvc.perform(get("/api/distributions/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateDistribution() throws Exception {
        // Initialize the database
        distributionRepository.saveAndFlush(distribution);
        int databaseSizeBeforeUpdate = distributionRepository.findAll().size();

        // Update the distribution
        Distribution updatedDistribution = distributionRepository.findOne(distribution.getId());
        updatedDistribution.setName(UPDATED_NAME);
        updatedDistribution.setFromAddress(UPDATED_FROM_ADDRESS);
        updatedDistribution.setToAddress(UPDATED_TO_ADDRESS);
        updatedDistribution.setCcAddress(UPDATED_CC_ADDRESS);
        updatedDistribution.setSkipEmpty(UPDATED_SKIP_EMPTY);
        updatedDistribution.setIsActive(UPDATED_IS_ACTIVE);
        updatedDistribution.setUpdatedDate(UPDATED_UPDATED_DATE);
        DistributionDTO distributionDTO = distributionMapper.distributionToDistributionDTO(updatedDistribution);

        restDistributionMockMvc.perform(put("/api/distributions")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(distributionDTO)))
                .andExpect(status().isOk());

        // Validate the Distribution in the database
        List<Distribution> distributions = distributionRepository.findAll();
        assertThat(distributions).hasSize(databaseSizeBeforeUpdate);
        Distribution testDistribution = distributions.get(distributions.size() - 1);
        assertThat(testDistribution.getName()).isEqualTo(UPDATED_NAME);
        assertThat(testDistribution.getFromAddress()).isEqualTo(UPDATED_FROM_ADDRESS);
        assertThat(testDistribution.getToAddress()).isEqualTo(UPDATED_TO_ADDRESS);
        assertThat(testDistribution.getCcAddress()).isEqualTo(UPDATED_CC_ADDRESS);
        assertThat(testDistribution.isSkipEmpty()).isEqualTo(UPDATED_SKIP_EMPTY);
        assertThat(testDistribution.isIsActive()).isEqualTo(UPDATED_IS_ACTIVE);
        assertThat(testDistribution.getUpdatedDate()).isEqualTo(UPDATED_UPDATED_DATE);
    }

    @Test
    @Transactional
    public void deleteDistribution() throws Exception {
        // Initialize the database
        distributionRepository.saveAndFlush(distribution);
        int databaseSizeBeforeDelete = distributionRepository.findAll().size();

        // Get the distribution
        restDistributionMockMvc.perform(delete("/api/distributions/{id}", distribution.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate the database is empty
        List<Distribution> distributions = distributionRepository.findAll();
        assertThat(distributions).hasSize(databaseSizeBeforeDelete - 1);
    }
}
