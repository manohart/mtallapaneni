package com.jpmorgan.am.spectrum.web.rest;

import com.jpmorgan.am.spectrum.HealthCheckApp;

import com.jpmorgan.am.spectrum.domain.Server;
import com.jpmorgan.am.spectrum.repository.ServerRepository;
import com.jpmorgan.am.spectrum.service.ServerService;
import com.jpmorgan.am.spectrum.service.dto.ServerDTO;
import com.jpmorgan.am.spectrum.service.mapper.ServerMapper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneId;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.jpmorgan.am.spectrum.domain.enumeration.Environment;
import com.jpmorgan.am.spectrum.domain.enumeration.ServerType;
import com.jpmorgan.am.spectrum.domain.enumeration.OsType;
/**
 * Test class for the ServerResource REST controller.
 *
 * @see ServerResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = HealthCheckApp.class)
public class ServerResourceIntTest {

    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(ZoneId.of("Z"));

    private static final String DEFAULT_HOSTNAME = "AAAAAAAAAA";
    private static final String UPDATED_HOSTNAME = "BBBBBBBBBB";
    private static final String DEFAULT_ALIAS = "AAAAAAAAAA";
    private static final String UPDATED_ALIAS = "BBBBBBBBBB";

    private static final Environment DEFAULT_ENVIRONMENT = Environment.PRODUCTION;
    private static final Environment UPDATED_ENVIRONMENT = Environment.RESEARCH;

    private static final ServerType DEFAULT_TYPE = ServerType.APP;
    private static final ServerType UPDATED_TYPE = ServerType.DB;

    private static final OsType DEFAULT_OS_TYPE = OsType.WINDOWS;
    private static final OsType UPDATED_OS_TYPE = OsType.LINUX;
    private static final String DEFAULT_DESCRIPTION = "AAAAA";
    private static final String UPDATED_DESCRIPTION = "BBBBB";

    private static final Boolean DEFAULT_IS_ACTIVE = false;
    private static final Boolean UPDATED_IS_ACTIVE = true;

    private static final ZonedDateTime DEFAULT_UPDATED_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneId.systemDefault());
    private static final ZonedDateTime UPDATED_UPDATED_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);
    private static final String DEFAULT_UPDATED_DATE_STR = dateTimeFormatter.format(DEFAULT_UPDATED_DATE);

    @Inject
    private ServerRepository serverRepository;

    @Inject
    private ServerMapper serverMapper;

    @Inject
    private ServerService serverService;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restServerMockMvc;

    private Server server;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        ServerResource serverResource = new ServerResource();
        ReflectionTestUtils.setField(serverResource, "serverService", serverService);
        this.restServerMockMvc = MockMvcBuilders.standaloneSetup(serverResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Server createEntity(EntityManager em) {
        Server server = new Server();
        server.setHostname(DEFAULT_HOSTNAME);
        server.setAlias(DEFAULT_ALIAS);
        server.setEnvironment(DEFAULT_ENVIRONMENT);
        server.setType(DEFAULT_TYPE);
        server.setOsType(DEFAULT_OS_TYPE);
        server.setDescription(DEFAULT_DESCRIPTION);
        server.setIsActive(DEFAULT_IS_ACTIVE);
        server.setUpdatedDate(DEFAULT_UPDATED_DATE);
        return server;
    }

    @Before
    public void initTest() {
        server = createEntity(em);
    }

    @Test
    @Transactional
    public void createServer() throws Exception {
        int databaseSizeBeforeCreate = serverRepository.findAll().size();

        // Create the Server
        ServerDTO serverDTO = serverMapper.serverToServerDTO(server);

        restServerMockMvc.perform(post("/api/servers")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(serverDTO)))
                .andExpect(status().isCreated());

        // Validate the Server in the database
        List<Server> servers = serverRepository.findAll();
        assertThat(servers).hasSize(databaseSizeBeforeCreate + 1);
        Server testServer = servers.get(servers.size() - 1);
        assertThat(testServer.getHostname()).isEqualTo(DEFAULT_HOSTNAME);
        assertThat(testServer.getAlias()).isEqualTo(DEFAULT_ALIAS);
        assertThat(testServer.getEnvironment()).isEqualTo(DEFAULT_ENVIRONMENT);
        assertThat(testServer.getType()).isEqualTo(DEFAULT_TYPE);
        assertThat(testServer.getOsType()).isEqualTo(DEFAULT_OS_TYPE);
        assertThat(testServer.getDescription()).isEqualTo(DEFAULT_DESCRIPTION);
        assertThat(testServer.isIsActive()).isEqualTo(DEFAULT_IS_ACTIVE);
        assertThat(testServer.getUpdatedDate()).isEqualTo(DEFAULT_UPDATED_DATE);
    }

    @Test
    @Transactional
    public void checkHostnameIsRequired() throws Exception {
        int databaseSizeBeforeTest = serverRepository.findAll().size();
        // set the field null
        server.setHostname(null);

        // Create the Server, which fails.
        ServerDTO serverDTO = serverMapper.serverToServerDTO(server);

        restServerMockMvc.perform(post("/api/servers")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(serverDTO)))
                .andExpect(status().isBadRequest());

        List<Server> servers = serverRepository.findAll();
        assertThat(servers).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkAliasIsRequired() throws Exception {
        int databaseSizeBeforeTest = serverRepository.findAll().size();
        // set the field null
        server.setAlias(null);

        // Create the Server, which fails.
        ServerDTO serverDTO = serverMapper.serverToServerDTO(server);

        restServerMockMvc.perform(post("/api/servers")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(serverDTO)))
                .andExpect(status().isBadRequest());

        List<Server> servers = serverRepository.findAll();
        assertThat(servers).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkEnvironmentIsRequired() throws Exception {
        int databaseSizeBeforeTest = serverRepository.findAll().size();
        // set the field null
        server.setEnvironment(null);

        // Create the Server, which fails.
        ServerDTO serverDTO = serverMapper.serverToServerDTO(server);

        restServerMockMvc.perform(post("/api/servers")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(serverDTO)))
                .andExpect(status().isBadRequest());

        List<Server> servers = serverRepository.findAll();
        assertThat(servers).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkTypeIsRequired() throws Exception {
        int databaseSizeBeforeTest = serverRepository.findAll().size();
        // set the field null
        server.setType(null);

        // Create the Server, which fails.
        ServerDTO serverDTO = serverMapper.serverToServerDTO(server);

        restServerMockMvc.perform(post("/api/servers")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(serverDTO)))
                .andExpect(status().isBadRequest());

        List<Server> servers = serverRepository.findAll();
        assertThat(servers).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkOsTypeIsRequired() throws Exception {
        int databaseSizeBeforeTest = serverRepository.findAll().size();
        // set the field null
        server.setOsType(null);

        // Create the Server, which fails.
        ServerDTO serverDTO = serverMapper.serverToServerDTO(server);

        restServerMockMvc.perform(post("/api/servers")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(serverDTO)))
                .andExpect(status().isBadRequest());

        List<Server> servers = serverRepository.findAll();
        assertThat(servers).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkDescriptionIsRequired() throws Exception {
        int databaseSizeBeforeTest = serverRepository.findAll().size();
        // set the field null
        server.setDescription(null);

        // Create the Server, which fails.
        ServerDTO serverDTO = serverMapper.serverToServerDTO(server);

        restServerMockMvc.perform(post("/api/servers")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(serverDTO)))
                .andExpect(status().isBadRequest());

        List<Server> servers = serverRepository.findAll();
        assertThat(servers).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkIsActiveIsRequired() throws Exception {
        int databaseSizeBeforeTest = serverRepository.findAll().size();
        // set the field null
        server.setIsActive(null);

        // Create the Server, which fails.
        ServerDTO serverDTO = serverMapper.serverToServerDTO(server);

        restServerMockMvc.perform(post("/api/servers")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(serverDTO)))
                .andExpect(status().isBadRequest());

        List<Server> servers = serverRepository.findAll();
        assertThat(servers).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllServers() throws Exception {
        // Initialize the database
        serverRepository.saveAndFlush(server);

        // Get all the servers
        restServerMockMvc.perform(get("/api/servers?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andExpect(jsonPath("$.[*].id").value(hasItem(server.getId().intValue())))
                .andExpect(jsonPath("$.[*].hostname").value(hasItem(DEFAULT_HOSTNAME.toString())))
                .andExpect(jsonPath("$.[*].alias").value(hasItem(DEFAULT_ALIAS.toString())))
                .andExpect(jsonPath("$.[*].environment").value(hasItem(DEFAULT_ENVIRONMENT.toString())))
                .andExpect(jsonPath("$.[*].type").value(hasItem(DEFAULT_TYPE.toString())))
                .andExpect(jsonPath("$.[*].osType").value(hasItem(DEFAULT_OS_TYPE.toString())))
                .andExpect(jsonPath("$.[*].description").value(hasItem(DEFAULT_DESCRIPTION.toString())))
                .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
                .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }

    @Test
    @Transactional
    public void getServer() throws Exception {
        // Initialize the database
        serverRepository.saveAndFlush(server);

        // Get the server
        restServerMockMvc.perform(get("/api/servers/{id}", server.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(server.getId().intValue()))
            .andExpect(jsonPath("$.hostname").value(DEFAULT_HOSTNAME.toString()))
            .andExpect(jsonPath("$.alias").value(DEFAULT_ALIAS.toString()))
            .andExpect(jsonPath("$.environment").value(DEFAULT_ENVIRONMENT.toString()))
            .andExpect(jsonPath("$.type").value(DEFAULT_TYPE.toString()))
            .andExpect(jsonPath("$.osType").value(DEFAULT_OS_TYPE.toString()))
            .andExpect(jsonPath("$.description").value(DEFAULT_DESCRIPTION.toString()))
            .andExpect(jsonPath("$.isActive").value(DEFAULT_IS_ACTIVE.booleanValue()))
            .andExpect(jsonPath("$.updatedDate").value(DEFAULT_UPDATED_DATE_STR));
    }

    @Test
    @Transactional
    public void getNonExistingServer() throws Exception {
        // Get the server
        restServerMockMvc.perform(get("/api/servers/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateServer() throws Exception {
        // Initialize the database
        serverRepository.saveAndFlush(server);
        int databaseSizeBeforeUpdate = serverRepository.findAll().size();

        // Update the server
        Server updatedServer = serverRepository.findOne(server.getId());
        updatedServer.setHostname(UPDATED_HOSTNAME);
        updatedServer.setAlias(UPDATED_ALIAS);
        updatedServer.setEnvironment(UPDATED_ENVIRONMENT);
        updatedServer.setType(UPDATED_TYPE);
        updatedServer.setOsType(UPDATED_OS_TYPE);
        updatedServer.setDescription(UPDATED_DESCRIPTION);
        updatedServer.setIsActive(UPDATED_IS_ACTIVE);
        updatedServer.setUpdatedDate(UPDATED_UPDATED_DATE);
        ServerDTO serverDTO = serverMapper.serverToServerDTO(updatedServer);

        restServerMockMvc.perform(put("/api/servers")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(serverDTO)))
                .andExpect(status().isOk());

        // Validate the Server in the database
        List<Server> servers = serverRepository.findAll();
        assertThat(servers).hasSize(databaseSizeBeforeUpdate);
        Server testServer = servers.get(servers.size() - 1);
        assertThat(testServer.getHostname()).isEqualTo(UPDATED_HOSTNAME);
        assertThat(testServer.getAlias()).isEqualTo(UPDATED_ALIAS);
        assertThat(testServer.getEnvironment()).isEqualTo(UPDATED_ENVIRONMENT);
        assertThat(testServer.getType()).isEqualTo(UPDATED_TYPE);
        assertThat(testServer.getOsType()).isEqualTo(UPDATED_OS_TYPE);
        assertThat(testServer.getDescription()).isEqualTo(UPDATED_DESCRIPTION);
        assertThat(testServer.isIsActive()).isEqualTo(UPDATED_IS_ACTIVE);
        assertThat(testServer.getUpdatedDate()).isEqualTo(UPDATED_UPDATED_DATE);
    }

    @Test
    @Transactional
    public void deleteServer() throws Exception {
        // Initialize the database
        serverRepository.saveAndFlush(server);
        int databaseSizeBeforeDelete = serverRepository.findAll().size();

        // Get the server
        restServerMockMvc.perform(delete("/api/servers/{id}", server.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate the database is empty
        List<Server> servers = serverRepository.findAll();
        assertThat(servers).hasSize(databaseSizeBeforeDelete - 1);
    }
}
