'use strict';

describe('Controller Tests', function() {

    describe('WebService Management Detail Controller', function() {
        var $scope, $rootScope;
        var MockEntity, MockPreviousState, MockWebService, MockWebApp, MockWebServiceConsumer;
        var createController;

        beforeEach(inject(function($injector) {
            $rootScope = $injector.get('$rootScope');
            $scope = $rootScope.$new();
            MockEntity = jasmine.createSpy('MockEntity');
            MockPreviousState = jasmine.createSpy('MockPreviousState');
            MockWebService = jasmine.createSpy('MockWebService');
            MockWebApp = jasmine.createSpy('MockWebApp');
            MockWebServiceConsumer = jasmine.createSpy('MockWebServiceConsumer');
            

            var locals = {
                '$scope': $scope,
                '$rootScope': $rootScope,
                'entity': MockEntity,
                'previousState': MockPreviousState,
                'WebService': MockWebService,
                'WebApp': MockWebApp,
                'WebServiceConsumer': MockWebServiceConsumer
            };
            createController = function() {
                $injector.get('$controller')("WebServiceDetailController", locals);
            };
        }));


        describe('Root Scope Listening', function() {
            it('Unregisters root scope listener upon scope destruction', function() {
                var eventType = 'healthCheckApp:webServiceUpdate';

                createController();
                expect($rootScope.$$listenerCount[eventType]).toEqual(1);

                $scope.$destroy();
                expect($rootScope.$$listenerCount[eventType]).toBeUndefined();
            });
        });
    });

});
