(function() {
    'use strict';
    angular
        .module('healthCheckApp')
        .factory('AppDependency', AppDependency);

    AppDependency.$inject = ['$resource', 'DateUtils'];

    function AppDependency ($resource, DateUtils) {
        var resourceUrl =  'api/app-dependencies/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true},
            'get': {
                method: 'GET',
                transformResponse: function (data) {
                    if (data) {
                        data = angular.fromJson(data);
                        data.updatedDate = DateUtils.convertDateTimeFromServer(data.updatedDate);
                    }
                    return data;
                }
            },
            'update': { method:'PUT' }
        });
    }
})();
