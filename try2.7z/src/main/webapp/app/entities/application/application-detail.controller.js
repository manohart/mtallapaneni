(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('ApplicationDetailController', ApplicationDetailController);

    ApplicationDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'Application', 'AutoNotification', 'Lob', 'DevOps', 'Team', 'Server'];

    function ApplicationDetailController($scope, $rootScope, $stateParams, previousState, entity, Application, AutoNotification, Lob, DevOps, Team, Server) {
        var vm = this;

        vm.application = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('healthCheckApp:applicationUpdate', function(event, result) {
            vm.application = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
