(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('ApplicationDialogController', ApplicationDialogController);

    ApplicationDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', '$q', 'entity', 'Application', 'AutoNotification', 'Lob', 'DevOps', 'Team', 'Server'];

    function ApplicationDialogController ($timeout, $scope, $stateParams, $uibModalInstance, $q, entity, Application, AutoNotification, Lob, DevOps, Team, Server) {
        var vm = this;

        vm.application = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.autonotifications = AutoNotification.query();
        vm.lobs = Lob.query({filter: 'application-is-null'});
        $q.all([vm.application.$promise, vm.lobs.$promise]).then(function() {
            if (!vm.application.lobId) {
                return $q.reject();
            }
            return Lob.get({id : vm.application.lobId}).$promise;
        }).then(function(lob) {
            vm.lobs.push(lob);
        });
        vm.devops = DevOps.query({filter: 'application-is-null'});
        $q.all([vm.application.$promise, vm.devops.$promise]).then(function() {
            if (!vm.application.devOpsId) {
                return $q.reject();
            }
            return DevOps.get({id : vm.application.devOpsId}).$promise;
        }).then(function(devOps) {
            vm.devops.push(devOps);
        });
        vm.techteams = Team.query({filter: 'application-is-null'});
        $q.all([vm.application.$promise, vm.techteams.$promise]).then(function() {
            if (!vm.application.techTeamId) {
                return $q.reject();
            }
            return Team.get({id : vm.application.techTeamId}).$promise;
        }).then(function(techTeam) {
            vm.techteams.push(techTeam);
        });
        vm.supportteams = Team.query({filter: 'application-is-null'});
        $q.all([vm.application.$promise, vm.supportteams.$promise]).then(function() {
            if (!vm.application.supportTeamId) {
                return $q.reject();
            }
            return Team.get({id : vm.application.supportTeamId}).$promise;
        }).then(function(supportTeam) {
            vm.supportteams.push(supportTeam);
        });
        vm.businessteams = Team.query({filter: 'application-is-null'});
        $q.all([vm.application.$promise, vm.businessteams.$promise]).then(function() {
            if (!vm.application.businessTeamId) {
                return $q.reject();
            }
            return Team.get({id : vm.application.businessTeamId}).$promise;
        }).then(function(businessTeam) {
            vm.businessteams.push(businessTeam);
        });
        vm.hostservers = Server.query({filter: 'application-is-null'});
        $q.all([vm.application.$promise, vm.hostservers.$promise]).then(function() {
            if (!vm.application.hostServerId) {
                return $q.reject();
            }
            return Server.get({id : vm.application.hostServerId}).$promise;
        }).then(function(hostServer) {
            vm.hostservers.push(hostServer);
        });

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.application.id !== null) {
                Application.update(vm.application, onSaveSuccess, onSaveError);
            } else {
                Application.save(vm.application, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('healthCheckApp:applicationUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
