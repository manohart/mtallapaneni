(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('ArchiveLocationDetailController', ArchiveLocationDetailController);

    ArchiveLocationDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'ArchiveLocation'];

    function ArchiveLocationDetailController($scope, $rootScope, $stateParams, previousState, entity, ArchiveLocation) {
        var vm = this;

        vm.archiveLocation = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('healthCheckApp:archiveLocationUpdate', function(event, result) {
            vm.archiveLocation = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
