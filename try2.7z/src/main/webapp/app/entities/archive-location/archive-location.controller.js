(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('ArchiveLocationController', ArchiveLocationController);

    ArchiveLocationController.$inject = ['$scope', '$state', 'ArchiveLocation', 'ArchiveLocationSearch'];

    function ArchiveLocationController ($scope, $state, ArchiveLocation, ArchiveLocationSearch) {
        var vm = this;
        
        vm.archiveLocations = [];
        vm.search = search;
        vm.loadAll = loadAll;

        loadAll();

        function loadAll() {
            ArchiveLocation.query(function(result) {
                vm.archiveLocations = result;
            });
        }

        function search () {
            if (!vm.searchQuery) {
                return vm.loadAll();
            }
            ArchiveLocationSearch.query({query: vm.searchQuery}, function(result) {
                vm.archiveLocations = result;
            });
        }    }
})();
