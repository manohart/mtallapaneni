(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('AutoNotificationController', AutoNotificationController);

    AutoNotificationController.$inject = ['$scope', '$state', 'AutoNotification', 'AutoNotificationSearch'];

    function AutoNotificationController ($scope, $state, AutoNotification, AutoNotificationSearch) {
        var vm = this;
        
        vm.autoNotifications = [];
        vm.search = search;
        vm.loadAll = loadAll;

        loadAll();

        function loadAll() {
            AutoNotification.query(function(result) {
                vm.autoNotifications = result;
            });
        }

        function search () {
            if (!vm.searchQuery) {
                return vm.loadAll();
            }
            AutoNotificationSearch.query({query: vm.searchQuery}, function(result) {
                vm.autoNotifications = result;
            });
        }    }
})();
