(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .factory('AutoNotificationSearch', AutoNotificationSearch);

    AutoNotificationSearch.$inject = ['$resource'];

    function AutoNotificationSearch($resource) {
        var resourceUrl =  'api/_search/auto-notifications/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
