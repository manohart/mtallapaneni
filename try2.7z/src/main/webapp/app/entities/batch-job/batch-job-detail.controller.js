(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('BatchJobDetailController', BatchJobDetailController);

    BatchJobDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'BatchJob', 'BatchReport', 'Application'];

    function BatchJobDetailController($scope, $rootScope, $stateParams, previousState, entity, BatchJob, BatchReport, Application) {
        var vm = this;

        vm.batchJob = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('healthCheckApp:batchJobUpdate', function(event, result) {
            vm.batchJob = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
