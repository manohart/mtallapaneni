(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('BatchJobDialogController', BatchJobDialogController);

    BatchJobDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', '$q', 'entity', 'BatchJob', 'BatchReport', 'Application'];

    function BatchJobDialogController ($timeout, $scope, $stateParams, $uibModalInstance, $q, entity, BatchJob, BatchReport, Application) {
        var vm = this;

        vm.batchJob = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.batchreports = BatchReport.query();
        vm.applications = Application.query({filter: 'batchjob-is-null'});
        $q.all([vm.batchJob.$promise, vm.applications.$promise]).then(function() {
            if (!vm.batchJob.applicationId) {
                return $q.reject();
            }
            return Application.get({id : vm.batchJob.applicationId}).$promise;
        }).then(function(application) {
            vm.applications.push(application);
        });

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.batchJob.id !== null) {
                BatchJob.update(vm.batchJob, onSaveSuccess, onSaveError);
            } else {
                BatchJob.save(vm.batchJob, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('healthCheckApp:batchJobUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
