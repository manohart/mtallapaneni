(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('BatchJobController', BatchJobController);

    BatchJobController.$inject = ['$scope', '$state', 'BatchJob', 'BatchJobSearch'];

    function BatchJobController ($scope, $state, BatchJob, BatchJobSearch) {
        var vm = this;
        
        vm.batchJobs = [];
        vm.search = search;
        vm.loadAll = loadAll;

        loadAll();

        function loadAll() {
            BatchJob.query(function(result) {
                vm.batchJobs = result;
            });
        }

        function search () {
            if (!vm.searchQuery) {
                return vm.loadAll();
            }
            BatchJobSearch.query({query: vm.searchQuery}, function(result) {
                vm.batchJobs = result;
            });
        }    }
})();
