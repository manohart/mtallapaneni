(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('batch-job', {
            parent: 'entity',
            url: '/batch-job',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'healthCheckApp.batchJob.home.title'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/batch-job/batch-jobs.html',
                    controller: 'BatchJobController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                translatePartialLoader: ['$translate', '$translatePartialLoader', function ($translate, $translatePartialLoader) {
                    $translatePartialLoader.addPart('batchJob');
                    $translatePartialLoader.addPart('appScheduler');
                    $translatePartialLoader.addPart('global');
                    return $translate.refresh();
                }]
            }
        })
        .state('batch-job-detail', {
            parent: 'entity',
            url: '/batch-job/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'healthCheckApp.batchJob.detail.title'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/batch-job/batch-job-detail.html',
                    controller: 'BatchJobDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                translatePartialLoader: ['$translate', '$translatePartialLoader', function ($translate, $translatePartialLoader) {
                    $translatePartialLoader.addPart('batchJob');
                    $translatePartialLoader.addPart('appScheduler');
                    return $translate.refresh();
                }],
                entity: ['$stateParams', 'BatchJob', function($stateParams, BatchJob) {
                    return BatchJob.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'batch-job',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('batch-job-detail.edit', {
            parent: 'batch-job-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-job/batch-job-dialog.html',
                    controller: 'BatchJobDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['BatchJob', function(BatchJob) {
                            return BatchJob.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('batch-job.new', {
            parent: 'batch-job',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-job/batch-job-dialog.html',
                    controller: 'BatchJobDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                scheduler: null,
                                isActive: false,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('batch-job', null, { reload: 'batch-job' });
                }, function() {
                    $state.go('batch-job');
                });
            }]
        })
        .state('batch-job.edit', {
            parent: 'batch-job',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-job/batch-job-dialog.html',
                    controller: 'BatchJobDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['BatchJob', function(BatchJob) {
                            return BatchJob.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('batch-job', null, { reload: 'batch-job' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('batch-job.delete', {
            parent: 'batch-job',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/batch-job/batch-job-delete-dialog.html',
                    controller: 'BatchJobDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['BatchJob', function(BatchJob) {
                            return BatchJob.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('batch-job', null, { reload: 'batch-job' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
