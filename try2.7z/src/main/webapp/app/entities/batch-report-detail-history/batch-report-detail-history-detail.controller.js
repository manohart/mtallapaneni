(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('BatchReportDetailHistoryDetailController', BatchReportDetailHistoryDetailController);

    BatchReportDetailHistoryDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'BatchReportDetailHistory', 'BatchReportHistory'];

    function BatchReportDetailHistoryDetailController($scope, $rootScope, $stateParams, previousState, entity, BatchReportDetailHistory, BatchReportHistory) {
        var vm = this;

        vm.batchReportDetailHistory = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('healthCheckApp:batchReportDetailHistoryUpdate', function(event, result) {
            vm.batchReportDetailHistory = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
