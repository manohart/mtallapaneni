(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('BatchReportDetailHistoryDialogController', BatchReportDetailHistoryDialogController);

    BatchReportDetailHistoryDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'entity', 'BatchReportDetailHistory', 'BatchReportHistory'];

    function BatchReportDetailHistoryDialogController ($timeout, $scope, $stateParams, $uibModalInstance, entity, BatchReportDetailHistory, BatchReportHistory) {
        var vm = this;

        vm.batchReportDetailHistory = entity;
        vm.clear = clear;
        vm.save = save;
        vm.batchreporthistories = BatchReportHistory.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.batchReportDetailHistory.id !== null) {
                BatchReportDetailHistory.update(vm.batchReportDetailHistory, onSaveSuccess, onSaveError);
            } else {
                BatchReportDetailHistory.save(vm.batchReportDetailHistory, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('healthCheckApp:batchReportDetailHistoryUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }


    }
})();
