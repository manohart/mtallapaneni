(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('BatchReportDetailHistoryController', BatchReportDetailHistoryController);

    BatchReportDetailHistoryController.$inject = ['$scope', '$state', 'BatchReportDetailHistory', 'BatchReportDetailHistorySearch'];

    function BatchReportDetailHistoryController ($scope, $state, BatchReportDetailHistory, BatchReportDetailHistorySearch) {
        var vm = this;
        
        vm.batchReportDetailHistories = [];
        vm.search = search;
        vm.loadAll = loadAll;

        loadAll();

        function loadAll() {
            BatchReportDetailHistory.query(function(result) {
                vm.batchReportDetailHistories = result;
            });
        }

        function search () {
            if (!vm.searchQuery) {
                return vm.loadAll();
            }
            BatchReportDetailHistorySearch.query({query: vm.searchQuery}, function(result) {
                vm.batchReportDetailHistories = result;
            });
        }    }
})();
