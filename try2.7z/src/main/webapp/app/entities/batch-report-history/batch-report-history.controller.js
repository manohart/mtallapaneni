(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('BatchReportHistoryController', BatchReportHistoryController);

    BatchReportHistoryController.$inject = ['$scope', '$state', 'BatchReportHistory', 'BatchReportHistorySearch'];

    function BatchReportHistoryController ($scope, $state, BatchReportHistory, BatchReportHistorySearch) {
        var vm = this;
        
        vm.batchReportHistories = [];
        vm.search = search;
        vm.loadAll = loadAll;

        loadAll();

        function loadAll() {
            BatchReportHistory.query(function(result) {
                vm.batchReportHistories = result;
            });
        }

        function search () {
            if (!vm.searchQuery) {
                return vm.loadAll();
            }
            BatchReportHistorySearch.query({query: vm.searchQuery}, function(result) {
                vm.batchReportHistories = result;
            });
        }    }
})();
