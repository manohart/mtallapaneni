(function() {
    'use strict';
    angular
        .module('healthCheckApp')
        .factory('BatchReportHistory', BatchReportHistory);

    BatchReportHistory.$inject = ['$resource', 'DateUtils'];

    function BatchReportHistory ($resource, DateUtils) {
        var resourceUrl =  'api/batch-report-histories/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true},
            'get': {
                method: 'GET',
                transformResponse: function (data) {
                    if (data) {
                        data = angular.fromJson(data);
                        data.businessDate = DateUtils.convertLocalDateFromServer(data.businessDate);
                        data.updatedDate = DateUtils.convertDateTimeFromServer(data.updatedDate);
                    }
                    return data;
                }
            },
            'update': {
                method: 'PUT',
                transformRequest: function (data) {
                    data.businessDate = DateUtils.convertLocalDateToServer(data.businessDate);
                    return angular.toJson(data);
                }
            },
            'save': {
                method: 'POST',
                transformRequest: function (data) {
                    data.businessDate = DateUtils.convertLocalDateToServer(data.businessDate);
                    return angular.toJson(data);
                }
            }
        });
    }
})();
