(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('BatchReportDialogController', BatchReportDialogController);

    BatchReportDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', '$q', 'entity', 'BatchReport', 'BatchJob', 'DbCheck', 'BatchReportHistory', 'Distribution'];

    function BatchReportDialogController ($timeout, $scope, $stateParams, $uibModalInstance, $q, entity, BatchReport, BatchJob, DbCheck, BatchReportHistory, Distribution) {
        var vm = this;

        vm.batchReport = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.batchjobs = BatchJob.query();
        vm.dbchecks = DbCheck.query();
        vm.batchreporthistories = BatchReportHistory.query();
        vm.distributions = Distribution.query();
        vm.batches = BatchJob.query({filter: 'batchreport-is-null'});
        $q.all([vm.batchReport.$promise, vm.batches.$promise]).then(function() {
            if (!vm.batchReport.batchId) {
                return $q.reject();
            }
            return BatchJob.get({id : vm.batchReport.batchId}).$promise;
        }).then(function(batch) {
            vm.batches.push(batch);
        });

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.batchReport.id !== null) {
                BatchReport.update(vm.batchReport, onSaveSuccess, onSaveError);
            } else {
                BatchReport.save(vm.batchReport, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('healthCheckApp:batchReportUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
