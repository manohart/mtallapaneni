(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('BatchReportController', BatchReportController);

    BatchReportController.$inject = ['$scope', '$state', 'BatchReport', 'BatchReportSearch'];

    function BatchReportController ($scope, $state, BatchReport, BatchReportSearch) {
        var vm = this;
        
        vm.batchReports = [];
        vm.search = search;
        vm.loadAll = loadAll;

        loadAll();

        function loadAll() {
            BatchReport.query(function(result) {
                vm.batchReports = result;
            });
        }

        function search () {
            if (!vm.searchQuery) {
                return vm.loadAll();
            }
            BatchReportSearch.query({query: vm.searchQuery}, function(result) {
                vm.batchReports = result;
            });
        }    }
})();
