(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('DbCheckController', DbCheckController);

    DbCheckController.$inject = ['$scope', '$state', 'DbCheck', 'DbCheckSearch'];

    function DbCheckController ($scope, $state, DbCheck, DbCheckSearch) {
        var vm = this;
        
        vm.dbChecks = [];
        vm.search = search;
        vm.loadAll = loadAll;

        loadAll();

        function loadAll() {
            DbCheck.query(function(result) {
                vm.dbChecks = result;
            });
        }

        function search () {
            if (!vm.searchQuery) {
                return vm.loadAll();
            }
            DbCheckSearch.query({query: vm.searchQuery}, function(result) {
                vm.dbChecks = result;
            });
        }    }
})();
