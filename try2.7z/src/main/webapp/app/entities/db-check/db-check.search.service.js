(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .factory('DbCheckSearch', DbCheckSearch);

    DbCheckSearch.$inject = ['$resource'];

    function DbCheckSearch($resource) {
        var resourceUrl =  'api/_search/db-checks/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
