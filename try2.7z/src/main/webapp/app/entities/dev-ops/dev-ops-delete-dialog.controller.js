(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('DevOpsDeleteController',DevOpsDeleteController);

    DevOpsDeleteController.$inject = ['$uibModalInstance', 'entity', 'DevOps'];

    function DevOpsDeleteController($uibModalInstance, entity, DevOps) {
        var vm = this;

        vm.devOps = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;
        
        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            DevOps.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
