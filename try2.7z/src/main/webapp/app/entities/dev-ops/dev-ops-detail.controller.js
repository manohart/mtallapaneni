(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('DevOpsDetailController', DevOpsDetailController);

    DevOpsDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'DevOps'];

    function DevOpsDetailController($scope, $rootScope, $stateParams, previousState, entity, DevOps) {
        var vm = this;

        vm.devOps = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('healthCheckApp:devOpsUpdate', function(event, result) {
            vm.devOps = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
