(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('DevOpsController', DevOpsController);

    DevOpsController.$inject = ['$scope', '$state', 'DevOps', 'DevOpsSearch'];

    function DevOpsController ($scope, $state, DevOps, DevOpsSearch) {
        var vm = this;
        
        vm.devOps = [];
        vm.search = search;
        vm.loadAll = loadAll;

        loadAll();

        function loadAll() {
            DevOps.query(function(result) {
                vm.devOps = result;
            });
        }

        function search () {
            if (!vm.searchQuery) {
                return vm.loadAll();
            }
            DevOpsSearch.query({query: vm.searchQuery}, function(result) {
                vm.devOps = result;
            });
        }    }
})();
