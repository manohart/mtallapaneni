(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .factory('DevOpsSearch', DevOpsSearch);

    DevOpsSearch.$inject = ['$resource'];

    function DevOpsSearch($resource) {
        var resourceUrl =  'api/_search/dev-ops/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
