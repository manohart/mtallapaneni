(function() {
    'use strict';
    angular
        .module('healthCheckApp')
        .factory('DevOps', DevOps);

    DevOps.$inject = ['$resource', 'DateUtils'];

    function DevOps ($resource, DateUtils) {
        var resourceUrl =  'api/dev-ops/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true},
            'get': {
                method: 'GET',
                transformResponse: function (data) {
                    if (data) {
                        data = angular.fromJson(data);
                        data.updatedDate = DateUtils.convertDateTimeFromServer(data.updatedDate);
                    }
                    return data;
                }
            },
            'update': { method:'PUT' }
        });
    }
})();
