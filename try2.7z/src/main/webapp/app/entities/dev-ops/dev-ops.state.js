(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('dev-ops', {
            parent: 'entity',
            url: '/dev-ops',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'healthCheckApp.devOps.home.title'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/dev-ops/dev-ops.html',
                    controller: 'DevOpsController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                translatePartialLoader: ['$translate', '$translatePartialLoader', function ($translate, $translatePartialLoader) {
                    $translatePartialLoader.addPart('devOps');
                    $translatePartialLoader.addPart('global');
                    return $translate.refresh();
                }]
            }
        })
        .state('dev-ops-detail', {
            parent: 'entity',
            url: '/dev-ops/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'healthCheckApp.devOps.detail.title'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/dev-ops/dev-ops-detail.html',
                    controller: 'DevOpsDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                translatePartialLoader: ['$translate', '$translatePartialLoader', function ($translate, $translatePartialLoader) {
                    $translatePartialLoader.addPart('devOps');
                    return $translate.refresh();
                }],
                entity: ['$stateParams', 'DevOps', function($stateParams, DevOps) {
                    return DevOps.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'dev-ops',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('dev-ops-detail.edit', {
            parent: 'dev-ops-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/dev-ops/dev-ops-dialog.html',
                    controller: 'DevOpsDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['DevOps', function(DevOps) {
                            return DevOps.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('dev-ops.new', {
            parent: 'dev-ops',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/dev-ops/dev-ops-dialog.html',
                    controller: 'DevOpsDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                name: null,
                                sealId: null,
                                codeRepo: null,
                                scrumBoard: null,
                                ciBuild: null,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('dev-ops', null, { reload: 'dev-ops' });
                }, function() {
                    $state.go('dev-ops');
                });
            }]
        })
        .state('dev-ops.edit', {
            parent: 'dev-ops',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/dev-ops/dev-ops-dialog.html',
                    controller: 'DevOpsDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['DevOps', function(DevOps) {
                            return DevOps.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('dev-ops', null, { reload: 'dev-ops' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('dev-ops.delete', {
            parent: 'dev-ops',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/dev-ops/dev-ops-delete-dialog.html',
                    controller: 'DevOpsDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['DevOps', function(DevOps) {
                            return DevOps.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('dev-ops', null, { reload: 'dev-ops' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
