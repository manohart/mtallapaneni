(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('DistributionController', DistributionController);

    DistributionController.$inject = ['$scope', '$state', 'Distribution', 'DistributionSearch'];

    function DistributionController ($scope, $state, Distribution, DistributionSearch) {
        var vm = this;
        
        vm.distributions = [];
        vm.search = search;
        vm.loadAll = loadAll;

        loadAll();

        function loadAll() {
            Distribution.query(function(result) {
                vm.distributions = result;
            });
        }

        function search () {
            if (!vm.searchQuery) {
                return vm.loadAll();
            }
            DistributionSearch.query({query: vm.searchQuery}, function(result) {
                vm.distributions = result;
            });
        }    }
})();
