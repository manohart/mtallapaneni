(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .factory('DistributionSearch', DistributionSearch);

    DistributionSearch.$inject = ['$resource'];

    function DistributionSearch($resource) {
        var resourceUrl =  'api/_search/distributions/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
