(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('distribution', {
            parent: 'entity',
            url: '/distribution',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'healthCheckApp.distribution.home.title'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/distribution/distributions.html',
                    controller: 'DistributionController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                translatePartialLoader: ['$translate', '$translatePartialLoader', function ($translate, $translatePartialLoader) {
                    $translatePartialLoader.addPart('distribution');
                    $translatePartialLoader.addPart('global');
                    return $translate.refresh();
                }]
            }
        })
        .state('distribution-detail', {
            parent: 'entity',
            url: '/distribution/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'healthCheckApp.distribution.detail.title'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/distribution/distribution-detail.html',
                    controller: 'DistributionDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                translatePartialLoader: ['$translate', '$translatePartialLoader', function ($translate, $translatePartialLoader) {
                    $translatePartialLoader.addPart('distribution');
                    return $translate.refresh();
                }],
                entity: ['$stateParams', 'Distribution', function($stateParams, Distribution) {
                    return Distribution.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'distribution',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('distribution-detail.edit', {
            parent: 'distribution-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/distribution/distribution-dialog.html',
                    controller: 'DistributionDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['Distribution', function(Distribution) {
                            return Distribution.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('distribution.new', {
            parent: 'distribution',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/distribution/distribution-dialog.html',
                    controller: 'DistributionDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                name: null,
                                fromAddress: null,
                                toAddress: null,
                                ccAddress: null,
                                skipEmpty: false,
                                isActive: false,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('distribution', null, { reload: 'distribution' });
                }, function() {
                    $state.go('distribution');
                });
            }]
        })
        .state('distribution.edit', {
            parent: 'distribution',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/distribution/distribution-dialog.html',
                    controller: 'DistributionDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['Distribution', function(Distribution) {
                            return Distribution.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('distribution', null, { reload: 'distribution' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('distribution.delete', {
            parent: 'distribution',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/distribution/distribution-delete-dialog.html',
                    controller: 'DistributionDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['Distribution', function(Distribution) {
                            return Distribution.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('distribution', null, { reload: 'distribution' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
