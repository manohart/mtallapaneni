(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('LobDialogController', LobDialogController);

    LobDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', '$q', 'entity', 'Lob', 'ReleaseNoteHistory', 'Server', 'ArchiveLocation', 'Template'];

    function LobDialogController ($timeout, $scope, $stateParams, $uibModalInstance, $q, entity, Lob, ReleaseNoteHistory, Server, ArchiveLocation, Template) {
        var vm = this;

        vm.lob = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.releasenotehistories = ReleaseNoteHistory.query();
        vm.servers = Server.query();
        vm.archives = ArchiveLocation.query({filter: 'lob-is-null'});
        $q.all([vm.lob.$promise, vm.archives.$promise]).then(function() {
            if (!vm.lob.archiveId) {
                return $q.reject();
            }
            return ArchiveLocation.get({id : vm.lob.archiveId}).$promise;
        }).then(function(archive) {
            vm.archives.push(archive);
        });
        vm.releasetemplates = Template.query({filter: 'lob-is-null'});
        $q.all([vm.lob.$promise, vm.releasetemplates.$promise]).then(function() {
            if (!vm.lob.releaseTemplateId) {
                return $q.reject();
            }
            return Template.get({id : vm.lob.releaseTemplateId}).$promise;
        }).then(function(releaseTemplate) {
            vm.releasetemplates.push(releaseTemplate);
        });
        vm.batchtemplates = Template.query({filter: 'lob-is-null'});
        $q.all([vm.lob.$promise, vm.batchtemplates.$promise]).then(function() {
            if (!vm.lob.batchTemplateId) {
                return $q.reject();
            }
            return Template.get({id : vm.lob.batchTemplateId}).$promise;
        }).then(function(batchTemplate) {
            vm.batchtemplates.push(batchTemplate);
        });

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.lob.id !== null) {
                Lob.update(vm.lob, onSaveSuccess, onSaveError);
            } else {
                Lob.save(vm.lob, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('healthCheckApp:lobUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
