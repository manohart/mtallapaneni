(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('LobController', LobController);

    LobController.$inject = ['$scope', '$state', 'Lob', 'LobSearch'];

    function LobController ($scope, $state, Lob, LobSearch) {
        var vm = this;
        
        vm.lobs = [];
        vm.search = search;
        vm.loadAll = loadAll;

        loadAll();

        function loadAll() {
            Lob.query(function(result) {
                vm.lobs = result;
            });
        }

        function search () {
            if (!vm.searchQuery) {
                return vm.loadAll();
            }
            LobSearch.query({query: vm.searchQuery}, function(result) {
                vm.lobs = result;
            });
        }    }
})();
