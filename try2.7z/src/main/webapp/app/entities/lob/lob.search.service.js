(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .factory('LobSearch', LobSearch);

    LobSearch.$inject = ['$resource'];

    function LobSearch($resource) {
        var resourceUrl =  'api/_search/lobs/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
