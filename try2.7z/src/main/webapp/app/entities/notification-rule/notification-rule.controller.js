(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('NotificationRuleController', NotificationRuleController);

    NotificationRuleController.$inject = ['$scope', '$state', 'NotificationRule', 'NotificationRuleSearch'];

    function NotificationRuleController ($scope, $state, NotificationRule, NotificationRuleSearch) {
        var vm = this;
        
        vm.notificationRules = [];
        vm.search = search;
        vm.loadAll = loadAll;

        loadAll();

        function loadAll() {
            NotificationRule.query(function(result) {
                vm.notificationRules = result;
            });
        }

        function search () {
            if (!vm.searchQuery) {
                return vm.loadAll();
            }
            NotificationRuleSearch.query({query: vm.searchQuery}, function(result) {
                vm.notificationRules = result;
            });
        }    }
})();
