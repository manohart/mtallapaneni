(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('ReleaseNoteHistoryDetailController', ReleaseNoteHistoryDetailController);

    ReleaseNoteHistoryDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'ReleaseNoteHistory', 'Lob'];

    function ReleaseNoteHistoryDetailController($scope, $rootScope, $stateParams, previousState, entity, ReleaseNoteHistory, Lob) {
        var vm = this;

        vm.releaseNoteHistory = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('healthCheckApp:releaseNoteHistoryUpdate', function(event, result) {
            vm.releaseNoteHistory = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
