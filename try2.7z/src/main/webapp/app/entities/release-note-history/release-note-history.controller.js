(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('ReleaseNoteHistoryController', ReleaseNoteHistoryController);

    ReleaseNoteHistoryController.$inject = ['$scope', '$state', 'ReleaseNoteHistory', 'ReleaseNoteHistorySearch'];

    function ReleaseNoteHistoryController ($scope, $state, ReleaseNoteHistory, ReleaseNoteHistorySearch) {
        var vm = this;
        
        vm.releaseNoteHistories = [];
        vm.search = search;
        vm.loadAll = loadAll;

        loadAll();

        function loadAll() {
            ReleaseNoteHistory.query(function(result) {
                vm.releaseNoteHistories = result;
            });
        }

        function search () {
            if (!vm.searchQuery) {
                return vm.loadAll();
            }
            ReleaseNoteHistorySearch.query({query: vm.searchQuery}, function(result) {
                vm.releaseNoteHistories = result;
            });
        }    }
})();
