(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .factory('ReleaseNoteHistorySearch', ReleaseNoteHistorySearch);

    ReleaseNoteHistorySearch.$inject = ['$resource'];

    function ReleaseNoteHistorySearch($resource) {
        var resourceUrl =  'api/_search/release-note-histories/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
