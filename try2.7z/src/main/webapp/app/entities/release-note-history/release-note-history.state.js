(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('release-note-history', {
            parent: 'entity',
            url: '/release-note-history',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'healthCheckApp.releaseNoteHistory.home.title'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/release-note-history/release-note-histories.html',
                    controller: 'ReleaseNoteHistoryController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                translatePartialLoader: ['$translate', '$translatePartialLoader', function ($translate, $translatePartialLoader) {
                    $translatePartialLoader.addPart('releaseNoteHistory');
                    $translatePartialLoader.addPart('global');
                    return $translate.refresh();
                }]
            }
        })
        .state('release-note-history-detail', {
            parent: 'entity',
            url: '/release-note-history/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'healthCheckApp.releaseNoteHistory.detail.title'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/release-note-history/release-note-history-detail.html',
                    controller: 'ReleaseNoteHistoryDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                translatePartialLoader: ['$translate', '$translatePartialLoader', function ($translate, $translatePartialLoader) {
                    $translatePartialLoader.addPart('releaseNoteHistory');
                    return $translate.refresh();
                }],
                entity: ['$stateParams', 'ReleaseNoteHistory', function($stateParams, ReleaseNoteHistory) {
                    return ReleaseNoteHistory.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'release-note-history',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('release-note-history-detail.edit', {
            parent: 'release-note-history-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/release-note-history/release-note-history-dialog.html',
                    controller: 'ReleaseNoteHistoryDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['ReleaseNoteHistory', function(ReleaseNoteHistory) {
                            return ReleaseNoteHistory.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('release-note-history.new', {
            parent: 'release-note-history',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/release-note-history/release-note-history-dialog.html',
                    controller: 'ReleaseNoteHistoryDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                name: null,
                                comment: null,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('release-note-history', null, { reload: 'release-note-history' });
                }, function() {
                    $state.go('release-note-history');
                });
            }]
        })
        .state('release-note-history.edit', {
            parent: 'release-note-history',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/release-note-history/release-note-history-dialog.html',
                    controller: 'ReleaseNoteHistoryDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['ReleaseNoteHistory', function(ReleaseNoteHistory) {
                            return ReleaseNoteHistory.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('release-note-history', null, { reload: 'release-note-history' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('release-note-history.delete', {
            parent: 'release-note-history',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/release-note-history/release-note-history-delete-dialog.html',
                    controller: 'ReleaseNoteHistoryDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['ReleaseNoteHistory', function(ReleaseNoteHistory) {
                            return ReleaseNoteHistory.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('release-note-history', null, { reload: 'release-note-history' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
