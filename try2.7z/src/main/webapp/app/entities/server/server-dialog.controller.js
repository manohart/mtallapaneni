(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('ServerDialogController', ServerDialogController);

    ServerDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'entity', 'Server', 'Lob'];

    function ServerDialogController ($timeout, $scope, $stateParams, $uibModalInstance, entity, Server, Lob) {
        var vm = this;

        vm.server = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.lobs = Lob.query();

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.server.id !== null) {
                Server.update(vm.server, onSaveSuccess, onSaveError);
            } else {
                Server.save(vm.server, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('healthCheckApp:serverUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
