(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('ServerController', ServerController);

    ServerController.$inject = ['$scope', '$state', 'Server', 'ServerSearch'];

    function ServerController ($scope, $state, Server, ServerSearch) {
        var vm = this;
        
        vm.servers = [];
        vm.search = search;
        vm.loadAll = loadAll;

        loadAll();

        function loadAll() {
            Server.query(function(result) {
                vm.servers = result;
            });
        }

        function search () {
            if (!vm.searchQuery) {
                return vm.loadAll();
            }
            ServerSearch.query({query: vm.searchQuery}, function(result) {
                vm.servers = result;
            });
        }    }
})();
