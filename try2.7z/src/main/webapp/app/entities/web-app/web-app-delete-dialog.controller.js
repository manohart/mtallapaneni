(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('WebAppDeleteController',WebAppDeleteController);

    WebAppDeleteController.$inject = ['$uibModalInstance', 'entity', 'WebApp'];

    function WebAppDeleteController($uibModalInstance, entity, WebApp) {
        var vm = this;

        vm.webApp = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;
        
        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            WebApp.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
