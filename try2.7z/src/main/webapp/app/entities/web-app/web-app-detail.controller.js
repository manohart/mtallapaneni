(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('WebAppDetailController', WebAppDetailController);

    WebAppDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'WebApp', 'WebService', 'Application'];

    function WebAppDetailController($scope, $rootScope, $stateParams, previousState, entity, WebApp, WebService, Application) {
        var vm = this;

        vm.webApp = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('healthCheckApp:webAppUpdate', function(event, result) {
            vm.webApp = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
