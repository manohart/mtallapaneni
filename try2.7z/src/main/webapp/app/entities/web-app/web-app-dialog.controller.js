(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('WebAppDialogController', WebAppDialogController);

    WebAppDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', '$q', 'entity', 'WebApp', 'WebService', 'Application'];

    function WebAppDialogController ($timeout, $scope, $stateParams, $uibModalInstance, $q, entity, WebApp, WebService, Application) {
        var vm = this;

        vm.webApp = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.webservices = WebService.query();
        vm.applications = Application.query({filter: 'webapp-is-null'});
        $q.all([vm.webApp.$promise, vm.applications.$promise]).then(function() {
            if (!vm.webApp.applicationId) {
                return $q.reject();
            }
            return Application.get({id : vm.webApp.applicationId}).$promise;
        }).then(function(application) {
            vm.applications.push(application);
        });

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.webApp.id !== null) {
                WebApp.update(vm.webApp, onSaveSuccess, onSaveError);
            } else {
                WebApp.save(vm.webApp, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('healthCheckApp:webAppUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
