(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('WebAppController', WebAppController);

    WebAppController.$inject = ['$scope', '$state', 'WebApp', 'WebAppSearch'];

    function WebAppController ($scope, $state, WebApp, WebAppSearch) {
        var vm = this;
        
        vm.webApps = [];
        vm.search = search;
        vm.loadAll = loadAll;

        loadAll();

        function loadAll() {
            WebApp.query(function(result) {
                vm.webApps = result;
            });
        }

        function search () {
            if (!vm.searchQuery) {
                return vm.loadAll();
            }
            WebAppSearch.query({query: vm.searchQuery}, function(result) {
                vm.webApps = result;
            });
        }    }
})();
