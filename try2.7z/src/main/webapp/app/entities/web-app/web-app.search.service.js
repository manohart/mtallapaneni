(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .factory('WebAppSearch', WebAppSearch);

    WebAppSearch.$inject = ['$resource'];

    function WebAppSearch($resource) {
        var resourceUrl =  'api/_search/web-apps/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
