(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('web-app', {
            parent: 'entity',
            url: '/web-app',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'healthCheckApp.webApp.home.title'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/web-app/web-apps.html',
                    controller: 'WebAppController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                translatePartialLoader: ['$translate', '$translatePartialLoader', function ($translate, $translatePartialLoader) {
                    $translatePartialLoader.addPart('webApp');
                    $translatePartialLoader.addPart('global');
                    return $translate.refresh();
                }]
            }
        })
        .state('web-app-detail', {
            parent: 'entity',
            url: '/web-app/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'healthCheckApp.webApp.detail.title'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/web-app/web-app-detail.html',
                    controller: 'WebAppDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                translatePartialLoader: ['$translate', '$translatePartialLoader', function ($translate, $translatePartialLoader) {
                    $translatePartialLoader.addPart('webApp');
                    return $translate.refresh();
                }],
                entity: ['$stateParams', 'WebApp', function($stateParams, WebApp) {
                    return WebApp.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'web-app',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('web-app-detail.edit', {
            parent: 'web-app-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/web-app/web-app-dialog.html',
                    controller: 'WebAppDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['WebApp', function(WebApp) {
                            return WebApp.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('web-app.new', {
            parent: 'web-app',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/web-app/web-app-dialog.html',
                    controller: 'WebAppDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                webServer: null,
                                hostname: null,
                                portNumber: null,
                                context: null,
                                healthUrl: null,
                                healthContains: null,
                                isActive: false,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('web-app', null, { reload: 'web-app' });
                }, function() {
                    $state.go('web-app');
                });
            }]
        })
        .state('web-app.edit', {
            parent: 'web-app',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/web-app/web-app-dialog.html',
                    controller: 'WebAppDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['WebApp', function(WebApp) {
                            return WebApp.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('web-app', null, { reload: 'web-app' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('web-app.delete', {
            parent: 'web-app',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/web-app/web-app-delete-dialog.html',
                    controller: 'WebAppDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['WebApp', function(WebApp) {
                            return WebApp.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('web-app', null, { reload: 'web-app' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
