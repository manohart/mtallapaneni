(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('WebServiceConsumerDialogController', WebServiceConsumerDialogController);

    WebServiceConsumerDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', '$q', 'entity', 'WebServiceConsumer', 'WebService', 'Application'];

    function WebServiceConsumerDialogController ($timeout, $scope, $stateParams, $uibModalInstance, $q, entity, WebServiceConsumer, WebService, Application) {
        var vm = this;

        vm.webServiceConsumer = entity;
        vm.clear = clear;
        vm.datePickerOpenStatus = {};
        vm.openCalendar = openCalendar;
        vm.save = save;
        vm.webservices = WebService.query();
        vm.conmusers = Application.query({filter: 'webserviceconsumer-is-null'});
        $q.all([vm.webServiceConsumer.$promise, vm.conmusers.$promise]).then(function() {
            if (!vm.webServiceConsumer.conmuserId) {
                return $q.reject();
            }
            return Application.get({id : vm.webServiceConsumer.conmuserId}).$promise;
        }).then(function(conmuser) {
            vm.conmusers.push(conmuser);
        });

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.webServiceConsumer.id !== null) {
                WebServiceConsumer.update(vm.webServiceConsumer, onSaveSuccess, onSaveError);
            } else {
                WebServiceConsumer.save(vm.webServiceConsumer, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('healthCheckApp:webServiceConsumerUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }

        vm.datePickerOpenStatus.updatedDate = false;

        function openCalendar (date) {
            vm.datePickerOpenStatus[date] = true;
        }
    }
})();
