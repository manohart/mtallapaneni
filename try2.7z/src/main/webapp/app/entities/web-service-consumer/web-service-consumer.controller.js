(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('WebServiceConsumerController', WebServiceConsumerController);

    WebServiceConsumerController.$inject = ['$scope', '$state', 'WebServiceConsumer', 'WebServiceConsumerSearch'];

    function WebServiceConsumerController ($scope, $state, WebServiceConsumer, WebServiceConsumerSearch) {
        var vm = this;
        
        vm.webServiceConsumers = [];
        vm.search = search;
        vm.loadAll = loadAll;

        loadAll();

        function loadAll() {
            WebServiceConsumer.query(function(result) {
                vm.webServiceConsumers = result;
            });
        }

        function search () {
            if (!vm.searchQuery) {
                return vm.loadAll();
            }
            WebServiceConsumerSearch.query({query: vm.searchQuery}, function(result) {
                vm.webServiceConsumers = result;
            });
        }    }
})();
