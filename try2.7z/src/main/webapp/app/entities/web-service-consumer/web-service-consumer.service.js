(function() {
    'use strict';
    angular
        .module('healthCheckApp')
        .factory('WebServiceConsumer', WebServiceConsumer);

    WebServiceConsumer.$inject = ['$resource', 'DateUtils'];

    function WebServiceConsumer ($resource, DateUtils) {
        var resourceUrl =  'api/web-service-consumers/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true},
            'get': {
                method: 'GET',
                transformResponse: function (data) {
                    if (data) {
                        data = angular.fromJson(data);
                        data.updatedDate = DateUtils.convertDateTimeFromServer(data.updatedDate);
                    }
                    return data;
                }
            },
            'update': { method:'PUT' }
        });
    }
})();
