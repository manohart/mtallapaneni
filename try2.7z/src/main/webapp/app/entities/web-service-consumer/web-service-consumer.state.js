(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('web-service-consumer', {
            parent: 'entity',
            url: '/web-service-consumer',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'healthCheckApp.webServiceConsumer.home.title'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/web-service-consumer/web-service-consumers.html',
                    controller: 'WebServiceConsumerController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                translatePartialLoader: ['$translate', '$translatePartialLoader', function ($translate, $translatePartialLoader) {
                    $translatePartialLoader.addPart('webServiceConsumer');
                    $translatePartialLoader.addPart('global');
                    return $translate.refresh();
                }]
            }
        })
        .state('web-service-consumer-detail', {
            parent: 'entity',
            url: '/web-service-consumer/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'healthCheckApp.webServiceConsumer.detail.title'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/web-service-consumer/web-service-consumer-detail.html',
                    controller: 'WebServiceConsumerDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                translatePartialLoader: ['$translate', '$translatePartialLoader', function ($translate, $translatePartialLoader) {
                    $translatePartialLoader.addPart('webServiceConsumer');
                    return $translate.refresh();
                }],
                entity: ['$stateParams', 'WebServiceConsumer', function($stateParams, WebServiceConsumer) {
                    return WebServiceConsumer.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'web-service-consumer',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('web-service-consumer-detail.edit', {
            parent: 'web-service-consumer-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/web-service-consumer/web-service-consumer-dialog.html',
                    controller: 'WebServiceConsumerDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['WebServiceConsumer', function(WebServiceConsumer) {
                            return WebServiceConsumer.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('web-service-consumer.new', {
            parent: 'web-service-consumer',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/web-service-consumer/web-service-consumer-dialog.html',
                    controller: 'WebServiceConsumerDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                isActive: false,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('web-service-consumer', null, { reload: 'web-service-consumer' });
                }, function() {
                    $state.go('web-service-consumer');
                });
            }]
        })
        .state('web-service-consumer.edit', {
            parent: 'web-service-consumer',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/web-service-consumer/web-service-consumer-dialog.html',
                    controller: 'WebServiceConsumerDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['WebServiceConsumer', function(WebServiceConsumer) {
                            return WebServiceConsumer.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('web-service-consumer', null, { reload: 'web-service-consumer' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('web-service-consumer.delete', {
            parent: 'web-service-consumer',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/web-service-consumer/web-service-consumer-delete-dialog.html',
                    controller: 'WebServiceConsumerDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['WebServiceConsumer', function(WebServiceConsumer) {
                            return WebServiceConsumer.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('web-service-consumer', null, { reload: 'web-service-consumer' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
