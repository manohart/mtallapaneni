(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('WebServiceDetailController', WebServiceDetailController);

    WebServiceDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'WebService', 'WebApp', 'DbCheck', 'WebServiceConsumer'];

    function WebServiceDetailController($scope, $rootScope, $stateParams, previousState, entity, WebService, WebApp, DbCheck, WebServiceConsumer) {
        var vm = this;

        vm.webService = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('healthCheckApp:webServiceUpdate', function(event, result) {
            vm.webService = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
