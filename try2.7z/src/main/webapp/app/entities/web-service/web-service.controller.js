(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .controller('WebServiceController', WebServiceController);

    WebServiceController.$inject = ['$scope', '$state', 'WebService', 'WebServiceSearch'];

    function WebServiceController ($scope, $state, WebService, WebServiceSearch) {
        var vm = this;
        
        vm.webServices = [];
        vm.search = search;
        vm.loadAll = loadAll;

        loadAll();

        function loadAll() {
            WebService.query(function(result) {
                vm.webServices = result;
            });
        }

        function search () {
            if (!vm.searchQuery) {
                return vm.loadAll();
            }
            WebServiceSearch.query({query: vm.searchQuery}, function(result) {
                vm.webServices = result;
            });
        }    }
})();
