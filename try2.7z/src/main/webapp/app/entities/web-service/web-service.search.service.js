(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .factory('WebServiceSearch', WebServiceSearch);

    WebServiceSearch.$inject = ['$resource'];

    function WebServiceSearch($resource) {
        var resourceUrl =  'api/_search/web-services/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
