(function() {
    'use strict';

    angular
        .module('healthCheckApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('web-service', {
            parent: 'entity',
            url: '/web-service',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'healthCheckApp.webService.home.title'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/web-service/web-services.html',
                    controller: 'WebServiceController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                translatePartialLoader: ['$translate', '$translatePartialLoader', function ($translate, $translatePartialLoader) {
                    $translatePartialLoader.addPart('webService');
                    $translatePartialLoader.addPart('global');
                    return $translate.refresh();
                }]
            }
        })
        .state('web-service-detail', {
            parent: 'entity',
            url: '/web-service/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'healthCheckApp.webService.detail.title'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/web-service/web-service-detail.html',
                    controller: 'WebServiceDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                translatePartialLoader: ['$translate', '$translatePartialLoader', function ($translate, $translatePartialLoader) {
                    $translatePartialLoader.addPart('webService');
                    return $translate.refresh();
                }],
                entity: ['$stateParams', 'WebService', function($stateParams, WebService) {
                    return WebService.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'web-service',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('web-service-detail.edit', {
            parent: 'web-service-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/web-service/web-service-dialog.html',
                    controller: 'WebServiceDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['WebService', function(WebService) {
                            return WebService.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('web-service.new', {
            parent: 'web-service',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/web-service/web-service-dialog.html',
                    controller: 'WebServiceDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                name: null,
                                description: null,
                                path: null,
                                params: null,
                                optionalParams: null,
                                isActive: false,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('web-service', null, { reload: 'web-service' });
                }, function() {
                    $state.go('web-service');
                });
            }]
        })
        .state('web-service.edit', {
            parent: 'web-service',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/web-service/web-service-dialog.html',
                    controller: 'WebServiceDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['WebService', function(WebService) {
                            return WebService.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('web-service', null, { reload: 'web-service' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('web-service.delete', {
            parent: 'web-service',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/web-service/web-service-delete-dialog.html',
                    controller: 'WebServiceDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['WebService', function(WebService) {
                            return WebService.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('web-service', null, { reload: 'web-service' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
