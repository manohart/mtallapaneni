package com.jpmorgan.am.spectrum.web.rest;

import com.jpmorgan.am.spectrum.HealthCheckApp;

import com.jpmorgan.am.spectrum.domain.ArchiveLocation;
import com.jpmorgan.am.spectrum.repository.ArchiveLocationRepository;
import com.jpmorgan.am.spectrum.service.ArchiveLocationService;
import com.jpmorgan.am.spectrum.repository.search.ArchiveLocationSearchRepository;
import com.jpmorgan.am.spectrum.service.dto.ArchiveLocationDTO;
import com.jpmorgan.am.spectrum.service.mapper.ArchiveLocationMapper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneId;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the ArchiveLocationResource REST controller.
 *
 * @see ArchiveLocationResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = HealthCheckApp.class)
public class ArchiveLocationResourceIntTest {

    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(ZoneId.of("Z"));

    private static final String DEFAULT_NAME = "AAAAA";
    private static final String UPDATED_NAME = "BBBBB";
    private static final String DEFAULT_PATH = "AAAAA";
    private static final String UPDATED_PATH = "BBBBB";
    private static final String DEFAULT_DESCRIPTION = "AAAAA";
    private static final String UPDATED_DESCRIPTION = "BBBBB";

    private static final Boolean DEFAULT_IS_ACTIVE = false;
    private static final Boolean UPDATED_IS_ACTIVE = true;

    private static final ZonedDateTime DEFAULT_UPDATED_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneId.systemDefault());
    private static final ZonedDateTime UPDATED_UPDATED_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);
    private static final String DEFAULT_UPDATED_DATE_STR = dateTimeFormatter.format(DEFAULT_UPDATED_DATE);

    @Inject
    private ArchiveLocationRepository archiveLocationRepository;

    @Inject
    private ArchiveLocationMapper archiveLocationMapper;

    @Inject
    private ArchiveLocationService archiveLocationService;

    @Inject
    private ArchiveLocationSearchRepository archiveLocationSearchRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restArchiveLocationMockMvc;

    private ArchiveLocation archiveLocation;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        ArchiveLocationResource archiveLocationResource = new ArchiveLocationResource();
        ReflectionTestUtils.setField(archiveLocationResource, "archiveLocationService", archiveLocationService);
        this.restArchiveLocationMockMvc = MockMvcBuilders.standaloneSetup(archiveLocationResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static ArchiveLocation createEntity(EntityManager em) {
        ArchiveLocation archiveLocation = new ArchiveLocation();
        archiveLocation.setName(DEFAULT_NAME);
        archiveLocation.setPath(DEFAULT_PATH);
        archiveLocation.setDescription(DEFAULT_DESCRIPTION);
        archiveLocation.setIsActive(DEFAULT_IS_ACTIVE);
        archiveLocation.setUpdatedDate(DEFAULT_UPDATED_DATE);
        return archiveLocation;
    }

    @Before
    public void initTest() {
        archiveLocationSearchRepository.deleteAll();
        archiveLocation = createEntity(em);
    }

    @Test
    @Transactional
    public void createArchiveLocation() throws Exception {
        int databaseSizeBeforeCreate = archiveLocationRepository.findAll().size();

        // Create the ArchiveLocation
        ArchiveLocationDTO archiveLocationDTO = archiveLocationMapper.archiveLocationToArchiveLocationDTO(archiveLocation);

        restArchiveLocationMockMvc.perform(post("/api/archive-locations")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(archiveLocationDTO)))
                .andExpect(status().isCreated());

        // Validate the ArchiveLocation in the database
        List<ArchiveLocation> archiveLocations = archiveLocationRepository.findAll();
        assertThat(archiveLocations).hasSize(databaseSizeBeforeCreate + 1);
        ArchiveLocation testArchiveLocation = archiveLocations.get(archiveLocations.size() - 1);
        assertThat(testArchiveLocation.getName()).isEqualTo(DEFAULT_NAME);
        assertThat(testArchiveLocation.getPath()).isEqualTo(DEFAULT_PATH);
        assertThat(testArchiveLocation.getDescription()).isEqualTo(DEFAULT_DESCRIPTION);
        assertThat(testArchiveLocation.isIsActive()).isEqualTo(DEFAULT_IS_ACTIVE);
        assertThat(testArchiveLocation.getUpdatedDate()).isEqualTo(DEFAULT_UPDATED_DATE);

        // Validate the ArchiveLocation in ElasticSearch
        ArchiveLocation archiveLocationEs = archiveLocationSearchRepository.findOne(testArchiveLocation.getId());
        assertThat(archiveLocationEs).isEqualToComparingFieldByField(testArchiveLocation);
    }

    @Test
    @Transactional
    public void checkNameIsRequired() throws Exception {
        int databaseSizeBeforeTest = archiveLocationRepository.findAll().size();
        // set the field null
        archiveLocation.setName(null);

        // Create the ArchiveLocation, which fails.
        ArchiveLocationDTO archiveLocationDTO = archiveLocationMapper.archiveLocationToArchiveLocationDTO(archiveLocation);

        restArchiveLocationMockMvc.perform(post("/api/archive-locations")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(archiveLocationDTO)))
                .andExpect(status().isBadRequest());

        List<ArchiveLocation> archiveLocations = archiveLocationRepository.findAll();
        assertThat(archiveLocations).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkPathIsRequired() throws Exception {
        int databaseSizeBeforeTest = archiveLocationRepository.findAll().size();
        // set the field null
        archiveLocation.setPath(null);

        // Create the ArchiveLocation, which fails.
        ArchiveLocationDTO archiveLocationDTO = archiveLocationMapper.archiveLocationToArchiveLocationDTO(archiveLocation);

        restArchiveLocationMockMvc.perform(post("/api/archive-locations")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(archiveLocationDTO)))
                .andExpect(status().isBadRequest());

        List<ArchiveLocation> archiveLocations = archiveLocationRepository.findAll();
        assertThat(archiveLocations).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkDescriptionIsRequired() throws Exception {
        int databaseSizeBeforeTest = archiveLocationRepository.findAll().size();
        // set the field null
        archiveLocation.setDescription(null);

        // Create the ArchiveLocation, which fails.
        ArchiveLocationDTO archiveLocationDTO = archiveLocationMapper.archiveLocationToArchiveLocationDTO(archiveLocation);

        restArchiveLocationMockMvc.perform(post("/api/archive-locations")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(archiveLocationDTO)))
                .andExpect(status().isBadRequest());

        List<ArchiveLocation> archiveLocations = archiveLocationRepository.findAll();
        assertThat(archiveLocations).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkIsActiveIsRequired() throws Exception {
        int databaseSizeBeforeTest = archiveLocationRepository.findAll().size();
        // set the field null
        archiveLocation.setIsActive(null);

        // Create the ArchiveLocation, which fails.
        ArchiveLocationDTO archiveLocationDTO = archiveLocationMapper.archiveLocationToArchiveLocationDTO(archiveLocation);

        restArchiveLocationMockMvc.perform(post("/api/archive-locations")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(archiveLocationDTO)))
                .andExpect(status().isBadRequest());

        List<ArchiveLocation> archiveLocations = archiveLocationRepository.findAll();
        assertThat(archiveLocations).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllArchiveLocations() throws Exception {
        // Initialize the database
        archiveLocationRepository.saveAndFlush(archiveLocation);

        // Get all the archiveLocations
        restArchiveLocationMockMvc.perform(get("/api/archive-locations?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andExpect(jsonPath("$.[*].id").value(hasItem(archiveLocation.getId().intValue())))
                .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
                .andExpect(jsonPath("$.[*].path").value(hasItem(DEFAULT_PATH.toString())))
                .andExpect(jsonPath("$.[*].description").value(hasItem(DEFAULT_DESCRIPTION.toString())))
                .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
                .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }

    @Test
    @Transactional
    public void getArchiveLocation() throws Exception {
        // Initialize the database
        archiveLocationRepository.saveAndFlush(archiveLocation);

        // Get the archiveLocation
        restArchiveLocationMockMvc.perform(get("/api/archive-locations/{id}", archiveLocation.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(archiveLocation.getId().intValue()))
            .andExpect(jsonPath("$.name").value(DEFAULT_NAME.toString()))
            .andExpect(jsonPath("$.path").value(DEFAULT_PATH.toString()))
            .andExpect(jsonPath("$.description").value(DEFAULT_DESCRIPTION.toString()))
            .andExpect(jsonPath("$.isActive").value(DEFAULT_IS_ACTIVE.booleanValue()))
            .andExpect(jsonPath("$.updatedDate").value(DEFAULT_UPDATED_DATE_STR));
    }

    @Test
    @Transactional
    public void getNonExistingArchiveLocation() throws Exception {
        // Get the archiveLocation
        restArchiveLocationMockMvc.perform(get("/api/archive-locations/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateArchiveLocation() throws Exception {
        // Initialize the database
        archiveLocationRepository.saveAndFlush(archiveLocation);
        archiveLocationSearchRepository.save(archiveLocation);
        int databaseSizeBeforeUpdate = archiveLocationRepository.findAll().size();

        // Update the archiveLocation
        ArchiveLocation updatedArchiveLocation = archiveLocationRepository.findOne(archiveLocation.getId());
        updatedArchiveLocation.setName(UPDATED_NAME);
        updatedArchiveLocation.setPath(UPDATED_PATH);
        updatedArchiveLocation.setDescription(UPDATED_DESCRIPTION);
        updatedArchiveLocation.setIsActive(UPDATED_IS_ACTIVE);
        updatedArchiveLocation.setUpdatedDate(UPDATED_UPDATED_DATE);
        ArchiveLocationDTO archiveLocationDTO = archiveLocationMapper.archiveLocationToArchiveLocationDTO(updatedArchiveLocation);

        restArchiveLocationMockMvc.perform(put("/api/archive-locations")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(archiveLocationDTO)))
                .andExpect(status().isOk());

        // Validate the ArchiveLocation in the database
        List<ArchiveLocation> archiveLocations = archiveLocationRepository.findAll();
        assertThat(archiveLocations).hasSize(databaseSizeBeforeUpdate);
        ArchiveLocation testArchiveLocation = archiveLocations.get(archiveLocations.size() - 1);
        assertThat(testArchiveLocation.getName()).isEqualTo(UPDATED_NAME);
        assertThat(testArchiveLocation.getPath()).isEqualTo(UPDATED_PATH);
        assertThat(testArchiveLocation.getDescription()).isEqualTo(UPDATED_DESCRIPTION);
        assertThat(testArchiveLocation.isIsActive()).isEqualTo(UPDATED_IS_ACTIVE);
        assertThat(testArchiveLocation.getUpdatedDate()).isEqualTo(UPDATED_UPDATED_DATE);

        // Validate the ArchiveLocation in ElasticSearch
        ArchiveLocation archiveLocationEs = archiveLocationSearchRepository.findOne(testArchiveLocation.getId());
        assertThat(archiveLocationEs).isEqualToComparingFieldByField(testArchiveLocation);
    }

    @Test
    @Transactional
    public void deleteArchiveLocation() throws Exception {
        // Initialize the database
        archiveLocationRepository.saveAndFlush(archiveLocation);
        archiveLocationSearchRepository.save(archiveLocation);
        int databaseSizeBeforeDelete = archiveLocationRepository.findAll().size();

        // Get the archiveLocation
        restArchiveLocationMockMvc.perform(delete("/api/archive-locations/{id}", archiveLocation.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate ElasticSearch is empty
        boolean archiveLocationExistsInEs = archiveLocationSearchRepository.exists(archiveLocation.getId());
        assertThat(archiveLocationExistsInEs).isFalse();

        // Validate the database is empty
        List<ArchiveLocation> archiveLocations = archiveLocationRepository.findAll();
        assertThat(archiveLocations).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void searchArchiveLocation() throws Exception {
        // Initialize the database
        archiveLocationRepository.saveAndFlush(archiveLocation);
        archiveLocationSearchRepository.save(archiveLocation);

        // Search the archiveLocation
        restArchiveLocationMockMvc.perform(get("/api/_search/archive-locations?query=id:" + archiveLocation.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(archiveLocation.getId().intValue())))
            .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
            .andExpect(jsonPath("$.[*].path").value(hasItem(DEFAULT_PATH.toString())))
            .andExpect(jsonPath("$.[*].description").value(hasItem(DEFAULT_DESCRIPTION.toString())))
            .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
            .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }
}
