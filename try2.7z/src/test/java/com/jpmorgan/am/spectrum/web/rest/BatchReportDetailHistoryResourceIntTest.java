package com.jpmorgan.am.spectrum.web.rest;

import com.jpmorgan.am.spectrum.HealthCheckApp;

import com.jpmorgan.am.spectrum.domain.BatchReportDetailHistory;
import com.jpmorgan.am.spectrum.repository.BatchReportDetailHistoryRepository;
import com.jpmorgan.am.spectrum.service.BatchReportDetailHistoryService;
import com.jpmorgan.am.spectrum.repository.search.BatchReportDetailHistorySearchRepository;
import com.jpmorgan.am.spectrum.service.dto.BatchReportDetailHistoryDTO;
import com.jpmorgan.am.spectrum.service.mapper.BatchReportDetailHistoryMapper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the BatchReportDetailHistoryResource REST controller.
 *
 * @see BatchReportDetailHistoryResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = HealthCheckApp.class)
public class BatchReportDetailHistoryResourceIntTest {


    private static final Integer DEFAULT_RECORDS = 1;
    private static final Integer UPDATED_RECORDS = 2;

    private static final Integer DEFAULT_ISSUES = 1;
    private static final Integer UPDATED_ISSUES = 2;
    private static final String DEFAULT_INITIAL_STATUS = "AAAAA";
    private static final String UPDATED_INITIAL_STATUS = "BBBBB";
    private static final String DEFAULT_FINAL_STATUS = "AAAAA";
    private static final String UPDATED_FINAL_STATUS = "BBBBB";
    private static final String DEFAULT_COMMENT = "AAAAA";
    private static final String UPDATED_COMMENT = "BBBBB";

    @Inject
    private BatchReportDetailHistoryRepository batchReportDetailHistoryRepository;

    @Inject
    private BatchReportDetailHistoryMapper batchReportDetailHistoryMapper;

    @Inject
    private BatchReportDetailHistoryService batchReportDetailHistoryService;

    @Inject
    private BatchReportDetailHistorySearchRepository batchReportDetailHistorySearchRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restBatchReportDetailHistoryMockMvc;

    private BatchReportDetailHistory batchReportDetailHistory;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        BatchReportDetailHistoryResource batchReportDetailHistoryResource = new BatchReportDetailHistoryResource();
        ReflectionTestUtils.setField(batchReportDetailHistoryResource, "batchReportDetailHistoryService", batchReportDetailHistoryService);
        this.restBatchReportDetailHistoryMockMvc = MockMvcBuilders.standaloneSetup(batchReportDetailHistoryResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static BatchReportDetailHistory createEntity(EntityManager em) {
        BatchReportDetailHistory batchReportDetailHistory = new BatchReportDetailHistory();
        batchReportDetailHistory.setRecords(DEFAULT_RECORDS);
        batchReportDetailHistory.setIssues(DEFAULT_ISSUES);
        batchReportDetailHistory.setInitialStatus(DEFAULT_INITIAL_STATUS);
        batchReportDetailHistory.setFinalStatus(DEFAULT_FINAL_STATUS);
        batchReportDetailHistory.setComment(DEFAULT_COMMENT);
        return batchReportDetailHistory;
    }

    @Before
    public void initTest() {
        batchReportDetailHistorySearchRepository.deleteAll();
        batchReportDetailHistory = createEntity(em);
    }

    @Test
    @Transactional
    public void createBatchReportDetailHistory() throws Exception {
        int databaseSizeBeforeCreate = batchReportDetailHistoryRepository.findAll().size();

        // Create the BatchReportDetailHistory
        BatchReportDetailHistoryDTO batchReportDetailHistoryDTO = batchReportDetailHistoryMapper.batchReportDetailHistoryToBatchReportDetailHistoryDTO(batchReportDetailHistory);

        restBatchReportDetailHistoryMockMvc.perform(post("/api/batch-report-detail-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batchReportDetailHistoryDTO)))
                .andExpect(status().isCreated());

        // Validate the BatchReportDetailHistory in the database
        List<BatchReportDetailHistory> batchReportDetailHistories = batchReportDetailHistoryRepository.findAll();
        assertThat(batchReportDetailHistories).hasSize(databaseSizeBeforeCreate + 1);
        BatchReportDetailHistory testBatchReportDetailHistory = batchReportDetailHistories.get(batchReportDetailHistories.size() - 1);
        assertThat(testBatchReportDetailHistory.getRecords()).isEqualTo(DEFAULT_RECORDS);
        assertThat(testBatchReportDetailHistory.getIssues()).isEqualTo(DEFAULT_ISSUES);
        assertThat(testBatchReportDetailHistory.getInitialStatus()).isEqualTo(DEFAULT_INITIAL_STATUS);
        assertThat(testBatchReportDetailHistory.getFinalStatus()).isEqualTo(DEFAULT_FINAL_STATUS);
        assertThat(testBatchReportDetailHistory.getComment()).isEqualTo(DEFAULT_COMMENT);

        // Validate the BatchReportDetailHistory in ElasticSearch
        BatchReportDetailHistory batchReportDetailHistoryEs = batchReportDetailHistorySearchRepository.findOne(testBatchReportDetailHistory.getId());
        assertThat(batchReportDetailHistoryEs).isEqualToComparingFieldByField(testBatchReportDetailHistory);
    }

    @Test
    @Transactional
    public void checkRecordsIsRequired() throws Exception {
        int databaseSizeBeforeTest = batchReportDetailHistoryRepository.findAll().size();
        // set the field null
        batchReportDetailHistory.setRecords(null);

        // Create the BatchReportDetailHistory, which fails.
        BatchReportDetailHistoryDTO batchReportDetailHistoryDTO = batchReportDetailHistoryMapper.batchReportDetailHistoryToBatchReportDetailHistoryDTO(batchReportDetailHistory);

        restBatchReportDetailHistoryMockMvc.perform(post("/api/batch-report-detail-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batchReportDetailHistoryDTO)))
                .andExpect(status().isBadRequest());

        List<BatchReportDetailHistory> batchReportDetailHistories = batchReportDetailHistoryRepository.findAll();
        assertThat(batchReportDetailHistories).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkIssuesIsRequired() throws Exception {
        int databaseSizeBeforeTest = batchReportDetailHistoryRepository.findAll().size();
        // set the field null
        batchReportDetailHistory.setIssues(null);

        // Create the BatchReportDetailHistory, which fails.
        BatchReportDetailHistoryDTO batchReportDetailHistoryDTO = batchReportDetailHistoryMapper.batchReportDetailHistoryToBatchReportDetailHistoryDTO(batchReportDetailHistory);

        restBatchReportDetailHistoryMockMvc.perform(post("/api/batch-report-detail-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batchReportDetailHistoryDTO)))
                .andExpect(status().isBadRequest());

        List<BatchReportDetailHistory> batchReportDetailHistories = batchReportDetailHistoryRepository.findAll();
        assertThat(batchReportDetailHistories).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkInitialStatusIsRequired() throws Exception {
        int databaseSizeBeforeTest = batchReportDetailHistoryRepository.findAll().size();
        // set the field null
        batchReportDetailHistory.setInitialStatus(null);

        // Create the BatchReportDetailHistory, which fails.
        BatchReportDetailHistoryDTO batchReportDetailHistoryDTO = batchReportDetailHistoryMapper.batchReportDetailHistoryToBatchReportDetailHistoryDTO(batchReportDetailHistory);

        restBatchReportDetailHistoryMockMvc.perform(post("/api/batch-report-detail-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batchReportDetailHistoryDTO)))
                .andExpect(status().isBadRequest());

        List<BatchReportDetailHistory> batchReportDetailHistories = batchReportDetailHistoryRepository.findAll();
        assertThat(batchReportDetailHistories).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkFinalStatusIsRequired() throws Exception {
        int databaseSizeBeforeTest = batchReportDetailHistoryRepository.findAll().size();
        // set the field null
        batchReportDetailHistory.setFinalStatus(null);

        // Create the BatchReportDetailHistory, which fails.
        BatchReportDetailHistoryDTO batchReportDetailHistoryDTO = batchReportDetailHistoryMapper.batchReportDetailHistoryToBatchReportDetailHistoryDTO(batchReportDetailHistory);

        restBatchReportDetailHistoryMockMvc.perform(post("/api/batch-report-detail-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batchReportDetailHistoryDTO)))
                .andExpect(status().isBadRequest());

        List<BatchReportDetailHistory> batchReportDetailHistories = batchReportDetailHistoryRepository.findAll();
        assertThat(batchReportDetailHistories).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllBatchReportDetailHistories() throws Exception {
        // Initialize the database
        batchReportDetailHistoryRepository.saveAndFlush(batchReportDetailHistory);

        // Get all the batchReportDetailHistories
        restBatchReportDetailHistoryMockMvc.perform(get("/api/batch-report-detail-histories?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andExpect(jsonPath("$.[*].id").value(hasItem(batchReportDetailHistory.getId().intValue())))
                .andExpect(jsonPath("$.[*].records").value(hasItem(DEFAULT_RECORDS)))
                .andExpect(jsonPath("$.[*].issues").value(hasItem(DEFAULT_ISSUES)))
                .andExpect(jsonPath("$.[*].initialStatus").value(hasItem(DEFAULT_INITIAL_STATUS.toString())))
                .andExpect(jsonPath("$.[*].finalStatus").value(hasItem(DEFAULT_FINAL_STATUS.toString())))
                .andExpect(jsonPath("$.[*].comment").value(hasItem(DEFAULT_COMMENT.toString())));
    }

    @Test
    @Transactional
    public void getBatchReportDetailHistory() throws Exception {
        // Initialize the database
        batchReportDetailHistoryRepository.saveAndFlush(batchReportDetailHistory);

        // Get the batchReportDetailHistory
        restBatchReportDetailHistoryMockMvc.perform(get("/api/batch-report-detail-histories/{id}", batchReportDetailHistory.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(batchReportDetailHistory.getId().intValue()))
            .andExpect(jsonPath("$.records").value(DEFAULT_RECORDS))
            .andExpect(jsonPath("$.issues").value(DEFAULT_ISSUES))
            .andExpect(jsonPath("$.initialStatus").value(DEFAULT_INITIAL_STATUS.toString()))
            .andExpect(jsonPath("$.finalStatus").value(DEFAULT_FINAL_STATUS.toString()))
            .andExpect(jsonPath("$.comment").value(DEFAULT_COMMENT.toString()));
    }

    @Test
    @Transactional
    public void getNonExistingBatchReportDetailHistory() throws Exception {
        // Get the batchReportDetailHistory
        restBatchReportDetailHistoryMockMvc.perform(get("/api/batch-report-detail-histories/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateBatchReportDetailHistory() throws Exception {
        // Initialize the database
        batchReportDetailHistoryRepository.saveAndFlush(batchReportDetailHistory);
        batchReportDetailHistorySearchRepository.save(batchReportDetailHistory);
        int databaseSizeBeforeUpdate = batchReportDetailHistoryRepository.findAll().size();

        // Update the batchReportDetailHistory
        BatchReportDetailHistory updatedBatchReportDetailHistory = batchReportDetailHistoryRepository.findOne(batchReportDetailHistory.getId());
        updatedBatchReportDetailHistory.setRecords(UPDATED_RECORDS);
        updatedBatchReportDetailHistory.setIssues(UPDATED_ISSUES);
        updatedBatchReportDetailHistory.setInitialStatus(UPDATED_INITIAL_STATUS);
        updatedBatchReportDetailHistory.setFinalStatus(UPDATED_FINAL_STATUS);
        updatedBatchReportDetailHistory.setComment(UPDATED_COMMENT);
        BatchReportDetailHistoryDTO batchReportDetailHistoryDTO = batchReportDetailHistoryMapper.batchReportDetailHistoryToBatchReportDetailHistoryDTO(updatedBatchReportDetailHistory);

        restBatchReportDetailHistoryMockMvc.perform(put("/api/batch-report-detail-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batchReportDetailHistoryDTO)))
                .andExpect(status().isOk());

        // Validate the BatchReportDetailHistory in the database
        List<BatchReportDetailHistory> batchReportDetailHistories = batchReportDetailHistoryRepository.findAll();
        assertThat(batchReportDetailHistories).hasSize(databaseSizeBeforeUpdate);
        BatchReportDetailHistory testBatchReportDetailHistory = batchReportDetailHistories.get(batchReportDetailHistories.size() - 1);
        assertThat(testBatchReportDetailHistory.getRecords()).isEqualTo(UPDATED_RECORDS);
        assertThat(testBatchReportDetailHistory.getIssues()).isEqualTo(UPDATED_ISSUES);
        assertThat(testBatchReportDetailHistory.getInitialStatus()).isEqualTo(UPDATED_INITIAL_STATUS);
        assertThat(testBatchReportDetailHistory.getFinalStatus()).isEqualTo(UPDATED_FINAL_STATUS);
        assertThat(testBatchReportDetailHistory.getComment()).isEqualTo(UPDATED_COMMENT);

        // Validate the BatchReportDetailHistory in ElasticSearch
        BatchReportDetailHistory batchReportDetailHistoryEs = batchReportDetailHistorySearchRepository.findOne(testBatchReportDetailHistory.getId());
        assertThat(batchReportDetailHistoryEs).isEqualToComparingFieldByField(testBatchReportDetailHistory);
    }

    @Test
    @Transactional
    public void deleteBatchReportDetailHistory() throws Exception {
        // Initialize the database
        batchReportDetailHistoryRepository.saveAndFlush(batchReportDetailHistory);
        batchReportDetailHistorySearchRepository.save(batchReportDetailHistory);
        int databaseSizeBeforeDelete = batchReportDetailHistoryRepository.findAll().size();

        // Get the batchReportDetailHistory
        restBatchReportDetailHistoryMockMvc.perform(delete("/api/batch-report-detail-histories/{id}", batchReportDetailHistory.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate ElasticSearch is empty
        boolean batchReportDetailHistoryExistsInEs = batchReportDetailHistorySearchRepository.exists(batchReportDetailHistory.getId());
        assertThat(batchReportDetailHistoryExistsInEs).isFalse();

        // Validate the database is empty
        List<BatchReportDetailHistory> batchReportDetailHistories = batchReportDetailHistoryRepository.findAll();
        assertThat(batchReportDetailHistories).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void searchBatchReportDetailHistory() throws Exception {
        // Initialize the database
        batchReportDetailHistoryRepository.saveAndFlush(batchReportDetailHistory);
        batchReportDetailHistorySearchRepository.save(batchReportDetailHistory);

        // Search the batchReportDetailHistory
        restBatchReportDetailHistoryMockMvc.perform(get("/api/_search/batch-report-detail-histories?query=id:" + batchReportDetailHistory.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(batchReportDetailHistory.getId().intValue())))
            .andExpect(jsonPath("$.[*].records").value(hasItem(DEFAULT_RECORDS)))
            .andExpect(jsonPath("$.[*].issues").value(hasItem(DEFAULT_ISSUES)))
            .andExpect(jsonPath("$.[*].initialStatus").value(hasItem(DEFAULT_INITIAL_STATUS.toString())))
            .andExpect(jsonPath("$.[*].finalStatus").value(hasItem(DEFAULT_FINAL_STATUS.toString())))
            .andExpect(jsonPath("$.[*].comment").value(hasItem(DEFAULT_COMMENT.toString())));
    }
}
