package com.jpmorgan.am.spectrum.web.rest;

import com.jpmorgan.am.spectrum.HealthCheckApp;

import com.jpmorgan.am.spectrum.domain.BatchReportHistory;
import com.jpmorgan.am.spectrum.repository.BatchReportHistoryRepository;
import com.jpmorgan.am.spectrum.service.BatchReportHistoryService;
import com.jpmorgan.am.spectrum.repository.search.BatchReportHistorySearchRepository;
import com.jpmorgan.am.spectrum.service.dto.BatchReportHistoryDTO;
import com.jpmorgan.am.spectrum.service.mapper.BatchReportHistoryMapper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.time.LocalDate;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneId;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the BatchReportHistoryResource REST controller.
 *
 * @see BatchReportHistoryResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = HealthCheckApp.class)
public class BatchReportHistoryResourceIntTest {

    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(ZoneId.of("Z"));

    private static final String DEFAULT_INITIAL_STATUS = "AAAAA";
    private static final String UPDATED_INITIAL_STATUS = "BBBBB";
    private static final String DEFAULT_FINAL_STATUS = "AAAAA";
    private static final String UPDATED_FINAL_STATUS = "BBBBB";

    private static final LocalDate DEFAULT_BUSINESS_DATE = LocalDate.ofEpochDay(0L);
    private static final LocalDate UPDATED_BUSINESS_DATE = LocalDate.now(ZoneId.systemDefault());
    private static final String DEFAULT_COMMENT = "AAAAA";
    private static final String UPDATED_COMMENT = "BBBBB";

    private static final ZonedDateTime DEFAULT_UPDATED_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneId.systemDefault());
    private static final ZonedDateTime UPDATED_UPDATED_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);
    private static final String DEFAULT_UPDATED_DATE_STR = dateTimeFormatter.format(DEFAULT_UPDATED_DATE);

    @Inject
    private BatchReportHistoryRepository batchReportHistoryRepository;

    @Inject
    private BatchReportHistoryMapper batchReportHistoryMapper;

    @Inject
    private BatchReportHistoryService batchReportHistoryService;

    @Inject
    private BatchReportHistorySearchRepository batchReportHistorySearchRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restBatchReportHistoryMockMvc;

    private BatchReportHistory batchReportHistory;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        BatchReportHistoryResource batchReportHistoryResource = new BatchReportHistoryResource();
        ReflectionTestUtils.setField(batchReportHistoryResource, "batchReportHistoryService", batchReportHistoryService);
        this.restBatchReportHistoryMockMvc = MockMvcBuilders.standaloneSetup(batchReportHistoryResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static BatchReportHistory createEntity(EntityManager em) {
        BatchReportHistory batchReportHistory = new BatchReportHistory();
        batchReportHistory.setInitialStatus(DEFAULT_INITIAL_STATUS);
        batchReportHistory.setFinalStatus(DEFAULT_FINAL_STATUS);
        batchReportHistory.setBusinessDate(DEFAULT_BUSINESS_DATE);
        batchReportHistory.setComment(DEFAULT_COMMENT);
        batchReportHistory.setUpdatedDate(DEFAULT_UPDATED_DATE);
        return batchReportHistory;
    }

    @Before
    public void initTest() {
        batchReportHistorySearchRepository.deleteAll();
        batchReportHistory = createEntity(em);
    }

    @Test
    @Transactional
    public void createBatchReportHistory() throws Exception {
        int databaseSizeBeforeCreate = batchReportHistoryRepository.findAll().size();

        // Create the BatchReportHistory
        BatchReportHistoryDTO batchReportHistoryDTO = batchReportHistoryMapper.batchReportHistoryToBatchReportHistoryDTO(batchReportHistory);

        restBatchReportHistoryMockMvc.perform(post("/api/batch-report-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batchReportHistoryDTO)))
                .andExpect(status().isCreated());

        // Validate the BatchReportHistory in the database
        List<BatchReportHistory> batchReportHistories = batchReportHistoryRepository.findAll();
        assertThat(batchReportHistories).hasSize(databaseSizeBeforeCreate + 1);
        BatchReportHistory testBatchReportHistory = batchReportHistories.get(batchReportHistories.size() - 1);
        assertThat(testBatchReportHistory.getInitialStatus()).isEqualTo(DEFAULT_INITIAL_STATUS);
        assertThat(testBatchReportHistory.getFinalStatus()).isEqualTo(DEFAULT_FINAL_STATUS);
        assertThat(testBatchReportHistory.getBusinessDate()).isEqualTo(DEFAULT_BUSINESS_DATE);
        assertThat(testBatchReportHistory.getComment()).isEqualTo(DEFAULT_COMMENT);
        assertThat(testBatchReportHistory.getUpdatedDate()).isEqualTo(DEFAULT_UPDATED_DATE);

        // Validate the BatchReportHistory in ElasticSearch
        BatchReportHistory batchReportHistoryEs = batchReportHistorySearchRepository.findOne(testBatchReportHistory.getId());
        assertThat(batchReportHistoryEs).isEqualToComparingFieldByField(testBatchReportHistory);
    }

    @Test
    @Transactional
    public void checkInitialStatusIsRequired() throws Exception {
        int databaseSizeBeforeTest = batchReportHistoryRepository.findAll().size();
        // set the field null
        batchReportHistory.setInitialStatus(null);

        // Create the BatchReportHistory, which fails.
        BatchReportHistoryDTO batchReportHistoryDTO = batchReportHistoryMapper.batchReportHistoryToBatchReportHistoryDTO(batchReportHistory);

        restBatchReportHistoryMockMvc.perform(post("/api/batch-report-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batchReportHistoryDTO)))
                .andExpect(status().isBadRequest());

        List<BatchReportHistory> batchReportHistories = batchReportHistoryRepository.findAll();
        assertThat(batchReportHistories).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkFinalStatusIsRequired() throws Exception {
        int databaseSizeBeforeTest = batchReportHistoryRepository.findAll().size();
        // set the field null
        batchReportHistory.setFinalStatus(null);

        // Create the BatchReportHistory, which fails.
        BatchReportHistoryDTO batchReportHistoryDTO = batchReportHistoryMapper.batchReportHistoryToBatchReportHistoryDTO(batchReportHistory);

        restBatchReportHistoryMockMvc.perform(post("/api/batch-report-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batchReportHistoryDTO)))
                .andExpect(status().isBadRequest());

        List<BatchReportHistory> batchReportHistories = batchReportHistoryRepository.findAll();
        assertThat(batchReportHistories).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkBusinessDateIsRequired() throws Exception {
        int databaseSizeBeforeTest = batchReportHistoryRepository.findAll().size();
        // set the field null
        batchReportHistory.setBusinessDate(null);

        // Create the BatchReportHistory, which fails.
        BatchReportHistoryDTO batchReportHistoryDTO = batchReportHistoryMapper.batchReportHistoryToBatchReportHistoryDTO(batchReportHistory);

        restBatchReportHistoryMockMvc.perform(post("/api/batch-report-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batchReportHistoryDTO)))
                .andExpect(status().isBadRequest());

        List<BatchReportHistory> batchReportHistories = batchReportHistoryRepository.findAll();
        assertThat(batchReportHistories).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllBatchReportHistories() throws Exception {
        // Initialize the database
        batchReportHistoryRepository.saveAndFlush(batchReportHistory);

        // Get all the batchReportHistories
        restBatchReportHistoryMockMvc.perform(get("/api/batch-report-histories?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andExpect(jsonPath("$.[*].id").value(hasItem(batchReportHistory.getId().intValue())))
                .andExpect(jsonPath("$.[*].initialStatus").value(hasItem(DEFAULT_INITIAL_STATUS.toString())))
                .andExpect(jsonPath("$.[*].finalStatus").value(hasItem(DEFAULT_FINAL_STATUS.toString())))
                .andExpect(jsonPath("$.[*].businessDate").value(hasItem(DEFAULT_BUSINESS_DATE.toString())))
                .andExpect(jsonPath("$.[*].comment").value(hasItem(DEFAULT_COMMENT.toString())))
                .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }

    @Test
    @Transactional
    public void getBatchReportHistory() throws Exception {
        // Initialize the database
        batchReportHistoryRepository.saveAndFlush(batchReportHistory);

        // Get the batchReportHistory
        restBatchReportHistoryMockMvc.perform(get("/api/batch-report-histories/{id}", batchReportHistory.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(batchReportHistory.getId().intValue()))
            .andExpect(jsonPath("$.initialStatus").value(DEFAULT_INITIAL_STATUS.toString()))
            .andExpect(jsonPath("$.finalStatus").value(DEFAULT_FINAL_STATUS.toString()))
            .andExpect(jsonPath("$.businessDate").value(DEFAULT_BUSINESS_DATE.toString()))
            .andExpect(jsonPath("$.comment").value(DEFAULT_COMMENT.toString()))
            .andExpect(jsonPath("$.updatedDate").value(DEFAULT_UPDATED_DATE_STR));
    }

    @Test
    @Transactional
    public void getNonExistingBatchReportHistory() throws Exception {
        // Get the batchReportHistory
        restBatchReportHistoryMockMvc.perform(get("/api/batch-report-histories/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateBatchReportHistory() throws Exception {
        // Initialize the database
        batchReportHistoryRepository.saveAndFlush(batchReportHistory);
        batchReportHistorySearchRepository.save(batchReportHistory);
        int databaseSizeBeforeUpdate = batchReportHistoryRepository.findAll().size();

        // Update the batchReportHistory
        BatchReportHistory updatedBatchReportHistory = batchReportHistoryRepository.findOne(batchReportHistory.getId());
        updatedBatchReportHistory.setInitialStatus(UPDATED_INITIAL_STATUS);
        updatedBatchReportHistory.setFinalStatus(UPDATED_FINAL_STATUS);
        updatedBatchReportHistory.setBusinessDate(UPDATED_BUSINESS_DATE);
        updatedBatchReportHistory.setComment(UPDATED_COMMENT);
        updatedBatchReportHistory.setUpdatedDate(UPDATED_UPDATED_DATE);
        BatchReportHistoryDTO batchReportHistoryDTO = batchReportHistoryMapper.batchReportHistoryToBatchReportHistoryDTO(updatedBatchReportHistory);

        restBatchReportHistoryMockMvc.perform(put("/api/batch-report-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batchReportHistoryDTO)))
                .andExpect(status().isOk());

        // Validate the BatchReportHistory in the database
        List<BatchReportHistory> batchReportHistories = batchReportHistoryRepository.findAll();
        assertThat(batchReportHistories).hasSize(databaseSizeBeforeUpdate);
        BatchReportHistory testBatchReportHistory = batchReportHistories.get(batchReportHistories.size() - 1);
        assertThat(testBatchReportHistory.getInitialStatus()).isEqualTo(UPDATED_INITIAL_STATUS);
        assertThat(testBatchReportHistory.getFinalStatus()).isEqualTo(UPDATED_FINAL_STATUS);
        assertThat(testBatchReportHistory.getBusinessDate()).isEqualTo(UPDATED_BUSINESS_DATE);
        assertThat(testBatchReportHistory.getComment()).isEqualTo(UPDATED_COMMENT);
        assertThat(testBatchReportHistory.getUpdatedDate()).isEqualTo(UPDATED_UPDATED_DATE);

        // Validate the BatchReportHistory in ElasticSearch
        BatchReportHistory batchReportHistoryEs = batchReportHistorySearchRepository.findOne(testBatchReportHistory.getId());
        assertThat(batchReportHistoryEs).isEqualToComparingFieldByField(testBatchReportHistory);
    }

    @Test
    @Transactional
    public void deleteBatchReportHistory() throws Exception {
        // Initialize the database
        batchReportHistoryRepository.saveAndFlush(batchReportHistory);
        batchReportHistorySearchRepository.save(batchReportHistory);
        int databaseSizeBeforeDelete = batchReportHistoryRepository.findAll().size();

        // Get the batchReportHistory
        restBatchReportHistoryMockMvc.perform(delete("/api/batch-report-histories/{id}", batchReportHistory.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate ElasticSearch is empty
        boolean batchReportHistoryExistsInEs = batchReportHistorySearchRepository.exists(batchReportHistory.getId());
        assertThat(batchReportHistoryExistsInEs).isFalse();

        // Validate the database is empty
        List<BatchReportHistory> batchReportHistories = batchReportHistoryRepository.findAll();
        assertThat(batchReportHistories).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void searchBatchReportHistory() throws Exception {
        // Initialize the database
        batchReportHistoryRepository.saveAndFlush(batchReportHistory);
        batchReportHistorySearchRepository.save(batchReportHistory);

        // Search the batchReportHistory
        restBatchReportHistoryMockMvc.perform(get("/api/_search/batch-report-histories?query=id:" + batchReportHistory.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(batchReportHistory.getId().intValue())))
            .andExpect(jsonPath("$.[*].initialStatus").value(hasItem(DEFAULT_INITIAL_STATUS.toString())))
            .andExpect(jsonPath("$.[*].finalStatus").value(hasItem(DEFAULT_FINAL_STATUS.toString())))
            .andExpect(jsonPath("$.[*].businessDate").value(hasItem(DEFAULT_BUSINESS_DATE.toString())))
            .andExpect(jsonPath("$.[*].comment").value(hasItem(DEFAULT_COMMENT.toString())))
            .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }
}
