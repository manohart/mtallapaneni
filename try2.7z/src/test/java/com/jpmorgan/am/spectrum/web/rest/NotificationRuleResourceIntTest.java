package com.jpmorgan.am.spectrum.web.rest;

import com.jpmorgan.am.spectrum.HealthCheckApp;

import com.jpmorgan.am.spectrum.domain.NotificationRule;
import com.jpmorgan.am.spectrum.repository.NotificationRuleRepository;
import com.jpmorgan.am.spectrum.service.NotificationRuleService;
import com.jpmorgan.am.spectrum.repository.search.NotificationRuleSearchRepository;
import com.jpmorgan.am.spectrum.service.dto.NotificationRuleDTO;
import com.jpmorgan.am.spectrum.service.mapper.NotificationRuleMapper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneId;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the NotificationRuleResource REST controller.
 *
 * @see NotificationRuleResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = HealthCheckApp.class)
public class NotificationRuleResourceIntTest {

    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(ZoneId.of("Z"));

    private static final String DEFAULT_NAME = "AAAAA";
    private static final String UPDATED_NAME = "BBBBB";
    private static final String DEFAULT_DESCRIPTION = "AAAAA";
    private static final String UPDATED_DESCRIPTION = "BBBBB";
    private static final String DEFAULT_JAVA_CLASS = "AAAAA";
    private static final String UPDATED_JAVA_CLASS = "BBBBB";

    private static final Boolean DEFAULT_IS_ACTIVE = false;
    private static final Boolean UPDATED_IS_ACTIVE = true;

    private static final ZonedDateTime DEFAULT_UPDATED_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneId.systemDefault());
    private static final ZonedDateTime UPDATED_UPDATED_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);
    private static final String DEFAULT_UPDATED_DATE_STR = dateTimeFormatter.format(DEFAULT_UPDATED_DATE);

    @Inject
    private NotificationRuleRepository notificationRuleRepository;

    @Inject
    private NotificationRuleMapper notificationRuleMapper;

    @Inject
    private NotificationRuleService notificationRuleService;

    @Inject
    private NotificationRuleSearchRepository notificationRuleSearchRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restNotificationRuleMockMvc;

    private NotificationRule notificationRule;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        NotificationRuleResource notificationRuleResource = new NotificationRuleResource();
        ReflectionTestUtils.setField(notificationRuleResource, "notificationRuleService", notificationRuleService);
        this.restNotificationRuleMockMvc = MockMvcBuilders.standaloneSetup(notificationRuleResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static NotificationRule createEntity(EntityManager em) {
        NotificationRule notificationRule = new NotificationRule();
        notificationRule.setName(DEFAULT_NAME);
        notificationRule.setDescription(DEFAULT_DESCRIPTION);
        notificationRule.setJavaClass(DEFAULT_JAVA_CLASS);
        notificationRule.setIsActive(DEFAULT_IS_ACTIVE);
        notificationRule.setUpdatedDate(DEFAULT_UPDATED_DATE);
        return notificationRule;
    }

    @Before
    public void initTest() {
        notificationRuleSearchRepository.deleteAll();
        notificationRule = createEntity(em);
    }

    @Test
    @Transactional
    public void createNotificationRule() throws Exception {
        int databaseSizeBeforeCreate = notificationRuleRepository.findAll().size();

        // Create the NotificationRule
        NotificationRuleDTO notificationRuleDTO = notificationRuleMapper.notificationRuleToNotificationRuleDTO(notificationRule);

        restNotificationRuleMockMvc.perform(post("/api/notification-rules")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(notificationRuleDTO)))
                .andExpect(status().isCreated());

        // Validate the NotificationRule in the database
        List<NotificationRule> notificationRules = notificationRuleRepository.findAll();
        assertThat(notificationRules).hasSize(databaseSizeBeforeCreate + 1);
        NotificationRule testNotificationRule = notificationRules.get(notificationRules.size() - 1);
        assertThat(testNotificationRule.getName()).isEqualTo(DEFAULT_NAME);
        assertThat(testNotificationRule.getDescription()).isEqualTo(DEFAULT_DESCRIPTION);
        assertThat(testNotificationRule.getJavaClass()).isEqualTo(DEFAULT_JAVA_CLASS);
        assertThat(testNotificationRule.isIsActive()).isEqualTo(DEFAULT_IS_ACTIVE);
        assertThat(testNotificationRule.getUpdatedDate()).isEqualTo(DEFAULT_UPDATED_DATE);

        // Validate the NotificationRule in ElasticSearch
        NotificationRule notificationRuleEs = notificationRuleSearchRepository.findOne(testNotificationRule.getId());
        assertThat(notificationRuleEs).isEqualToComparingFieldByField(testNotificationRule);
    }

    @Test
    @Transactional
    public void checkNameIsRequired() throws Exception {
        int databaseSizeBeforeTest = notificationRuleRepository.findAll().size();
        // set the field null
        notificationRule.setName(null);

        // Create the NotificationRule, which fails.
        NotificationRuleDTO notificationRuleDTO = notificationRuleMapper.notificationRuleToNotificationRuleDTO(notificationRule);

        restNotificationRuleMockMvc.perform(post("/api/notification-rules")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(notificationRuleDTO)))
                .andExpect(status().isBadRequest());

        List<NotificationRule> notificationRules = notificationRuleRepository.findAll();
        assertThat(notificationRules).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkDescriptionIsRequired() throws Exception {
        int databaseSizeBeforeTest = notificationRuleRepository.findAll().size();
        // set the field null
        notificationRule.setDescription(null);

        // Create the NotificationRule, which fails.
        NotificationRuleDTO notificationRuleDTO = notificationRuleMapper.notificationRuleToNotificationRuleDTO(notificationRule);

        restNotificationRuleMockMvc.perform(post("/api/notification-rules")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(notificationRuleDTO)))
                .andExpect(status().isBadRequest());

        List<NotificationRule> notificationRules = notificationRuleRepository.findAll();
        assertThat(notificationRules).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkJavaClassIsRequired() throws Exception {
        int databaseSizeBeforeTest = notificationRuleRepository.findAll().size();
        // set the field null
        notificationRule.setJavaClass(null);

        // Create the NotificationRule, which fails.
        NotificationRuleDTO notificationRuleDTO = notificationRuleMapper.notificationRuleToNotificationRuleDTO(notificationRule);

        restNotificationRuleMockMvc.perform(post("/api/notification-rules")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(notificationRuleDTO)))
                .andExpect(status().isBadRequest());

        List<NotificationRule> notificationRules = notificationRuleRepository.findAll();
        assertThat(notificationRules).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkIsActiveIsRequired() throws Exception {
        int databaseSizeBeforeTest = notificationRuleRepository.findAll().size();
        // set the field null
        notificationRule.setIsActive(null);

        // Create the NotificationRule, which fails.
        NotificationRuleDTO notificationRuleDTO = notificationRuleMapper.notificationRuleToNotificationRuleDTO(notificationRule);

        restNotificationRuleMockMvc.perform(post("/api/notification-rules")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(notificationRuleDTO)))
                .andExpect(status().isBadRequest());

        List<NotificationRule> notificationRules = notificationRuleRepository.findAll();
        assertThat(notificationRules).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllNotificationRules() throws Exception {
        // Initialize the database
        notificationRuleRepository.saveAndFlush(notificationRule);

        // Get all the notificationRules
        restNotificationRuleMockMvc.perform(get("/api/notification-rules?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andExpect(jsonPath("$.[*].id").value(hasItem(notificationRule.getId().intValue())))
                .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
                .andExpect(jsonPath("$.[*].description").value(hasItem(DEFAULT_DESCRIPTION.toString())))
                .andExpect(jsonPath("$.[*].javaClass").value(hasItem(DEFAULT_JAVA_CLASS.toString())))
                .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
                .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }

    @Test
    @Transactional
    public void getNotificationRule() throws Exception {
        // Initialize the database
        notificationRuleRepository.saveAndFlush(notificationRule);

        // Get the notificationRule
        restNotificationRuleMockMvc.perform(get("/api/notification-rules/{id}", notificationRule.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(notificationRule.getId().intValue()))
            .andExpect(jsonPath("$.name").value(DEFAULT_NAME.toString()))
            .andExpect(jsonPath("$.description").value(DEFAULT_DESCRIPTION.toString()))
            .andExpect(jsonPath("$.javaClass").value(DEFAULT_JAVA_CLASS.toString()))
            .andExpect(jsonPath("$.isActive").value(DEFAULT_IS_ACTIVE.booleanValue()))
            .andExpect(jsonPath("$.updatedDate").value(DEFAULT_UPDATED_DATE_STR));
    }

    @Test
    @Transactional
    public void getNonExistingNotificationRule() throws Exception {
        // Get the notificationRule
        restNotificationRuleMockMvc.perform(get("/api/notification-rules/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateNotificationRule() throws Exception {
        // Initialize the database
        notificationRuleRepository.saveAndFlush(notificationRule);
        notificationRuleSearchRepository.save(notificationRule);
        int databaseSizeBeforeUpdate = notificationRuleRepository.findAll().size();

        // Update the notificationRule
        NotificationRule updatedNotificationRule = notificationRuleRepository.findOne(notificationRule.getId());
        updatedNotificationRule.setName(UPDATED_NAME);
        updatedNotificationRule.setDescription(UPDATED_DESCRIPTION);
        updatedNotificationRule.setJavaClass(UPDATED_JAVA_CLASS);
        updatedNotificationRule.setIsActive(UPDATED_IS_ACTIVE);
        updatedNotificationRule.setUpdatedDate(UPDATED_UPDATED_DATE);
        NotificationRuleDTO notificationRuleDTO = notificationRuleMapper.notificationRuleToNotificationRuleDTO(updatedNotificationRule);

        restNotificationRuleMockMvc.perform(put("/api/notification-rules")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(notificationRuleDTO)))
                .andExpect(status().isOk());

        // Validate the NotificationRule in the database
        List<NotificationRule> notificationRules = notificationRuleRepository.findAll();
        assertThat(notificationRules).hasSize(databaseSizeBeforeUpdate);
        NotificationRule testNotificationRule = notificationRules.get(notificationRules.size() - 1);
        assertThat(testNotificationRule.getName()).isEqualTo(UPDATED_NAME);
        assertThat(testNotificationRule.getDescription()).isEqualTo(UPDATED_DESCRIPTION);
        assertThat(testNotificationRule.getJavaClass()).isEqualTo(UPDATED_JAVA_CLASS);
        assertThat(testNotificationRule.isIsActive()).isEqualTo(UPDATED_IS_ACTIVE);
        assertThat(testNotificationRule.getUpdatedDate()).isEqualTo(UPDATED_UPDATED_DATE);

        // Validate the NotificationRule in ElasticSearch
        NotificationRule notificationRuleEs = notificationRuleSearchRepository.findOne(testNotificationRule.getId());
        assertThat(notificationRuleEs).isEqualToComparingFieldByField(testNotificationRule);
    }

    @Test
    @Transactional
    public void deleteNotificationRule() throws Exception {
        // Initialize the database
        notificationRuleRepository.saveAndFlush(notificationRule);
        notificationRuleSearchRepository.save(notificationRule);
        int databaseSizeBeforeDelete = notificationRuleRepository.findAll().size();

        // Get the notificationRule
        restNotificationRuleMockMvc.perform(delete("/api/notification-rules/{id}", notificationRule.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate ElasticSearch is empty
        boolean notificationRuleExistsInEs = notificationRuleSearchRepository.exists(notificationRule.getId());
        assertThat(notificationRuleExistsInEs).isFalse();

        // Validate the database is empty
        List<NotificationRule> notificationRules = notificationRuleRepository.findAll();
        assertThat(notificationRules).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void searchNotificationRule() throws Exception {
        // Initialize the database
        notificationRuleRepository.saveAndFlush(notificationRule);
        notificationRuleSearchRepository.save(notificationRule);

        // Search the notificationRule
        restNotificationRuleMockMvc.perform(get("/api/_search/notification-rules?query=id:" + notificationRule.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(notificationRule.getId().intValue())))
            .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
            .andExpect(jsonPath("$.[*].description").value(hasItem(DEFAULT_DESCRIPTION.toString())))
            .andExpect(jsonPath("$.[*].javaClass").value(hasItem(DEFAULT_JAVA_CLASS.toString())))
            .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
            .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }
}
