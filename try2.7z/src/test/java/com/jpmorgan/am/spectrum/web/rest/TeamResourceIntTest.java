package com.jpmorgan.am.spectrum.web.rest;

import com.jpmorgan.am.spectrum.HealthCheckApp;

import com.jpmorgan.am.spectrum.domain.Team;
import com.jpmorgan.am.spectrum.repository.TeamRepository;
import com.jpmorgan.am.spectrum.service.TeamService;
import com.jpmorgan.am.spectrum.repository.search.TeamSearchRepository;
import com.jpmorgan.am.spectrum.service.dto.TeamDTO;
import com.jpmorgan.am.spectrum.service.mapper.TeamMapper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneId;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the TeamResource REST controller.
 *
 * @see TeamResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = HealthCheckApp.class)
public class TeamResourceIntTest {

    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(ZoneId.of("Z"));

    private static final String DEFAULT_NAME = "AAAAA";
    private static final String UPDATED_NAME = "BBBBB";
    private static final String DEFAULT_MANAGER_SID = "AAAAAAA";
    private static final String UPDATED_MANAGER_SID = "BBBBBBB";
    private static final String DEFAULT_LEAD_SID = "AAAAAAA";
    private static final String UPDATED_LEAD_SID = "BBBBBBB";
    private static final String DEFAULT_DL = "AAAAA";
    private static final String UPDATED_DL = "BBBBB";

    private static final Boolean DEFAULT_IS_ACTIVE = false;
    private static final Boolean UPDATED_IS_ACTIVE = true;

    private static final ZonedDateTime DEFAULT_UPDATED_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneId.systemDefault());
    private static final ZonedDateTime UPDATED_UPDATED_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);
    private static final String DEFAULT_UPDATED_DATE_STR = dateTimeFormatter.format(DEFAULT_UPDATED_DATE);

    @Inject
    private TeamRepository teamRepository;

    @Inject
    private TeamMapper teamMapper;

    @Inject
    private TeamService teamService;

    @Inject
    private TeamSearchRepository teamSearchRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restTeamMockMvc;

    private Team team;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        TeamResource teamResource = new TeamResource();
        ReflectionTestUtils.setField(teamResource, "teamService", teamService);
        this.restTeamMockMvc = MockMvcBuilders.standaloneSetup(teamResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Team createEntity(EntityManager em) {
        Team team = new Team();
        team.setName(DEFAULT_NAME);
        team.setManagerSid(DEFAULT_MANAGER_SID);
        team.setLeadSid(DEFAULT_LEAD_SID);
        team.setDl(DEFAULT_DL);
        team.setIsActive(DEFAULT_IS_ACTIVE);
        team.setUpdatedDate(DEFAULT_UPDATED_DATE);
        return team;
    }

    @Before
    public void initTest() {
        teamSearchRepository.deleteAll();
        team = createEntity(em);
    }

    @Test
    @Transactional
    public void createTeam() throws Exception {
        int databaseSizeBeforeCreate = teamRepository.findAll().size();

        // Create the Team
        TeamDTO teamDTO = teamMapper.teamToTeamDTO(team);

        restTeamMockMvc.perform(post("/api/teams")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(teamDTO)))
                .andExpect(status().isCreated());

        // Validate the Team in the database
        List<Team> teams = teamRepository.findAll();
        assertThat(teams).hasSize(databaseSizeBeforeCreate + 1);
        Team testTeam = teams.get(teams.size() - 1);
        assertThat(testTeam.getName()).isEqualTo(DEFAULT_NAME);
        assertThat(testTeam.getManagerSid()).isEqualTo(DEFAULT_MANAGER_SID);
        assertThat(testTeam.getLeadSid()).isEqualTo(DEFAULT_LEAD_SID);
        assertThat(testTeam.getDl()).isEqualTo(DEFAULT_DL);
        assertThat(testTeam.isIsActive()).isEqualTo(DEFAULT_IS_ACTIVE);
        assertThat(testTeam.getUpdatedDate()).isEqualTo(DEFAULT_UPDATED_DATE);

        // Validate the Team in ElasticSearch
        Team teamEs = teamSearchRepository.findOne(testTeam.getId());
        assertThat(teamEs).isEqualToComparingFieldByField(testTeam);
    }

    @Test
    @Transactional
    public void checkNameIsRequired() throws Exception {
        int databaseSizeBeforeTest = teamRepository.findAll().size();
        // set the field null
        team.setName(null);

        // Create the Team, which fails.
        TeamDTO teamDTO = teamMapper.teamToTeamDTO(team);

        restTeamMockMvc.perform(post("/api/teams")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(teamDTO)))
                .andExpect(status().isBadRequest());

        List<Team> teams = teamRepository.findAll();
        assertThat(teams).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkManagerSidIsRequired() throws Exception {
        int databaseSizeBeforeTest = teamRepository.findAll().size();
        // set the field null
        team.setManagerSid(null);

        // Create the Team, which fails.
        TeamDTO teamDTO = teamMapper.teamToTeamDTO(team);

        restTeamMockMvc.perform(post("/api/teams")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(teamDTO)))
                .andExpect(status().isBadRequest());

        List<Team> teams = teamRepository.findAll();
        assertThat(teams).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkLeadSidIsRequired() throws Exception {
        int databaseSizeBeforeTest = teamRepository.findAll().size();
        // set the field null
        team.setLeadSid(null);

        // Create the Team, which fails.
        TeamDTO teamDTO = teamMapper.teamToTeamDTO(team);

        restTeamMockMvc.perform(post("/api/teams")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(teamDTO)))
                .andExpect(status().isBadRequest());

        List<Team> teams = teamRepository.findAll();
        assertThat(teams).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkDlIsRequired() throws Exception {
        int databaseSizeBeforeTest = teamRepository.findAll().size();
        // set the field null
        team.setDl(null);

        // Create the Team, which fails.
        TeamDTO teamDTO = teamMapper.teamToTeamDTO(team);

        restTeamMockMvc.perform(post("/api/teams")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(teamDTO)))
                .andExpect(status().isBadRequest());

        List<Team> teams = teamRepository.findAll();
        assertThat(teams).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllTeams() throws Exception {
        // Initialize the database
        teamRepository.saveAndFlush(team);

        // Get all the teams
        restTeamMockMvc.perform(get("/api/teams?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andExpect(jsonPath("$.[*].id").value(hasItem(team.getId().intValue())))
                .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
                .andExpect(jsonPath("$.[*].managerSid").value(hasItem(DEFAULT_MANAGER_SID.toString())))
                .andExpect(jsonPath("$.[*].leadSid").value(hasItem(DEFAULT_LEAD_SID.toString())))
                .andExpect(jsonPath("$.[*].dl").value(hasItem(DEFAULT_DL.toString())))
                .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
                .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }

    @Test
    @Transactional
    public void getTeam() throws Exception {
        // Initialize the database
        teamRepository.saveAndFlush(team);

        // Get the team
        restTeamMockMvc.perform(get("/api/teams/{id}", team.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(team.getId().intValue()))
            .andExpect(jsonPath("$.name").value(DEFAULT_NAME.toString()))
            .andExpect(jsonPath("$.managerSid").value(DEFAULT_MANAGER_SID.toString()))
            .andExpect(jsonPath("$.leadSid").value(DEFAULT_LEAD_SID.toString()))
            .andExpect(jsonPath("$.dl").value(DEFAULT_DL.toString()))
            .andExpect(jsonPath("$.isActive").value(DEFAULT_IS_ACTIVE.booleanValue()))
            .andExpect(jsonPath("$.updatedDate").value(DEFAULT_UPDATED_DATE_STR));
    }

    @Test
    @Transactional
    public void getNonExistingTeam() throws Exception {
        // Get the team
        restTeamMockMvc.perform(get("/api/teams/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateTeam() throws Exception {
        // Initialize the database
        teamRepository.saveAndFlush(team);
        teamSearchRepository.save(team);
        int databaseSizeBeforeUpdate = teamRepository.findAll().size();

        // Update the team
        Team updatedTeam = teamRepository.findOne(team.getId());
        updatedTeam.setName(UPDATED_NAME);
        updatedTeam.setManagerSid(UPDATED_MANAGER_SID);
        updatedTeam.setLeadSid(UPDATED_LEAD_SID);
        updatedTeam.setDl(UPDATED_DL);
        updatedTeam.setIsActive(UPDATED_IS_ACTIVE);
        updatedTeam.setUpdatedDate(UPDATED_UPDATED_DATE);
        TeamDTO teamDTO = teamMapper.teamToTeamDTO(updatedTeam);

        restTeamMockMvc.perform(put("/api/teams")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(teamDTO)))
                .andExpect(status().isOk());

        // Validate the Team in the database
        List<Team> teams = teamRepository.findAll();
        assertThat(teams).hasSize(databaseSizeBeforeUpdate);
        Team testTeam = teams.get(teams.size() - 1);
        assertThat(testTeam.getName()).isEqualTo(UPDATED_NAME);
        assertThat(testTeam.getManagerSid()).isEqualTo(UPDATED_MANAGER_SID);
        assertThat(testTeam.getLeadSid()).isEqualTo(UPDATED_LEAD_SID);
        assertThat(testTeam.getDl()).isEqualTo(UPDATED_DL);
        assertThat(testTeam.isIsActive()).isEqualTo(UPDATED_IS_ACTIVE);
        assertThat(testTeam.getUpdatedDate()).isEqualTo(UPDATED_UPDATED_DATE);

        // Validate the Team in ElasticSearch
        Team teamEs = teamSearchRepository.findOne(testTeam.getId());
        assertThat(teamEs).isEqualToComparingFieldByField(testTeam);
    }

    @Test
    @Transactional
    public void deleteTeam() throws Exception {
        // Initialize the database
        teamRepository.saveAndFlush(team);
        teamSearchRepository.save(team);
        int databaseSizeBeforeDelete = teamRepository.findAll().size();

        // Get the team
        restTeamMockMvc.perform(delete("/api/teams/{id}", team.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate ElasticSearch is empty
        boolean teamExistsInEs = teamSearchRepository.exists(team.getId());
        assertThat(teamExistsInEs).isFalse();

        // Validate the database is empty
        List<Team> teams = teamRepository.findAll();
        assertThat(teams).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void searchTeam() throws Exception {
        // Initialize the database
        teamRepository.saveAndFlush(team);
        teamSearchRepository.save(team);

        // Search the team
        restTeamMockMvc.perform(get("/api/_search/teams?query=id:" + team.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(team.getId().intValue())))
            .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
            .andExpect(jsonPath("$.[*].managerSid").value(hasItem(DEFAULT_MANAGER_SID.toString())))
            .andExpect(jsonPath("$.[*].leadSid").value(hasItem(DEFAULT_LEAD_SID.toString())))
            .andExpect(jsonPath("$.[*].dl").value(hasItem(DEFAULT_DL.toString())))
            .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
            .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }
}
