package com.jpmorgan.am.spectrum.web.rest;

import com.jpmorgan.am.spectrum.HealthCheckApp;

import com.jpmorgan.am.spectrum.domain.Template;
import com.jpmorgan.am.spectrum.repository.TemplateRepository;
import com.jpmorgan.am.spectrum.service.TemplateService;
import com.jpmorgan.am.spectrum.repository.search.TemplateSearchRepository;
import com.jpmorgan.am.spectrum.service.dto.TemplateDTO;
import com.jpmorgan.am.spectrum.service.mapper.TemplateMapper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneId;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.jpmorgan.am.spectrum.domain.enumeration.TemplateType;
/**
 * Test class for the TemplateResource REST controller.
 *
 * @see TemplateResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = HealthCheckApp.class)
public class TemplateResourceIntTest {

    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(ZoneId.of("Z"));

    private static final String DEFAULT_PATH = "AAAAA";
    private static final String UPDATED_PATH = "BBBBB";
    private static final String DEFAULT_NAME = "AAAAA";
    private static final String UPDATED_NAME = "BBBBB";

    private static final TemplateType DEFAULT_TYPE = TemplateType.BATCH_REPORT;
    private static final TemplateType UPDATED_TYPE = TemplateType.RELEASE_NOTE;
    private static final String DEFAULT_DESCRIPTION = "AAAAA";
    private static final String UPDATED_DESCRIPTION = "BBBBB";

    private static final Boolean DEFAULT_IS_ACTIVE = false;
    private static final Boolean UPDATED_IS_ACTIVE = true;

    private static final ZonedDateTime DEFAULT_UPDATED_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneId.systemDefault());
    private static final ZonedDateTime UPDATED_UPDATED_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);
    private static final String DEFAULT_UPDATED_DATE_STR = dateTimeFormatter.format(DEFAULT_UPDATED_DATE);

    @Inject
    private TemplateRepository templateRepository;

    @Inject
    private TemplateMapper templateMapper;

    @Inject
    private TemplateService templateService;

    @Inject
    private TemplateSearchRepository templateSearchRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restTemplateMockMvc;

    private Template template;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        TemplateResource templateResource = new TemplateResource();
        ReflectionTestUtils.setField(templateResource, "templateService", templateService);
        this.restTemplateMockMvc = MockMvcBuilders.standaloneSetup(templateResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Template createEntity(EntityManager em) {
        Template template = new Template();
        template.setPath(DEFAULT_PATH);
        template.setName(DEFAULT_NAME);
        template.setType(DEFAULT_TYPE);
        template.setDescription(DEFAULT_DESCRIPTION);
        template.setIsActive(DEFAULT_IS_ACTIVE);
        template.setUpdatedDate(DEFAULT_UPDATED_DATE);
        return template;
    }

    @Before
    public void initTest() {
        templateSearchRepository.deleteAll();
        template = createEntity(em);
    }

    @Test
    @Transactional
    public void createTemplate() throws Exception {
        int databaseSizeBeforeCreate = templateRepository.findAll().size();

        // Create the Template
        TemplateDTO templateDTO = templateMapper.templateToTemplateDTO(template);

        restTemplateMockMvc.perform(post("/api/templates")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(templateDTO)))
                .andExpect(status().isCreated());

        // Validate the Template in the database
        List<Template> templates = templateRepository.findAll();
        assertThat(templates).hasSize(databaseSizeBeforeCreate + 1);
        Template testTemplate = templates.get(templates.size() - 1);
        assertThat(testTemplate.getPath()).isEqualTo(DEFAULT_PATH);
        assertThat(testTemplate.getName()).isEqualTo(DEFAULT_NAME);
        assertThat(testTemplate.getType()).isEqualTo(DEFAULT_TYPE);
        assertThat(testTemplate.getDescription()).isEqualTo(DEFAULT_DESCRIPTION);
        assertThat(testTemplate.isIsActive()).isEqualTo(DEFAULT_IS_ACTIVE);
        assertThat(testTemplate.getUpdatedDate()).isEqualTo(DEFAULT_UPDATED_DATE);

        // Validate the Template in ElasticSearch
        Template templateEs = templateSearchRepository.findOne(testTemplate.getId());
        assertThat(templateEs).isEqualToComparingFieldByField(testTemplate);
    }

    @Test
    @Transactional
    public void checkPathIsRequired() throws Exception {
        int databaseSizeBeforeTest = templateRepository.findAll().size();
        // set the field null
        template.setPath(null);

        // Create the Template, which fails.
        TemplateDTO templateDTO = templateMapper.templateToTemplateDTO(template);

        restTemplateMockMvc.perform(post("/api/templates")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(templateDTO)))
                .andExpect(status().isBadRequest());

        List<Template> templates = templateRepository.findAll();
        assertThat(templates).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkNameIsRequired() throws Exception {
        int databaseSizeBeforeTest = templateRepository.findAll().size();
        // set the field null
        template.setName(null);

        // Create the Template, which fails.
        TemplateDTO templateDTO = templateMapper.templateToTemplateDTO(template);

        restTemplateMockMvc.perform(post("/api/templates")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(templateDTO)))
                .andExpect(status().isBadRequest());

        List<Template> templates = templateRepository.findAll();
        assertThat(templates).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkTypeIsRequired() throws Exception {
        int databaseSizeBeforeTest = templateRepository.findAll().size();
        // set the field null
        template.setType(null);

        // Create the Template, which fails.
        TemplateDTO templateDTO = templateMapper.templateToTemplateDTO(template);

        restTemplateMockMvc.perform(post("/api/templates")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(templateDTO)))
                .andExpect(status().isBadRequest());

        List<Template> templates = templateRepository.findAll();
        assertThat(templates).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkDescriptionIsRequired() throws Exception {
        int databaseSizeBeforeTest = templateRepository.findAll().size();
        // set the field null
        template.setDescription(null);

        // Create the Template, which fails.
        TemplateDTO templateDTO = templateMapper.templateToTemplateDTO(template);

        restTemplateMockMvc.perform(post("/api/templates")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(templateDTO)))
                .andExpect(status().isBadRequest());

        List<Template> templates = templateRepository.findAll();
        assertThat(templates).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkIsActiveIsRequired() throws Exception {
        int databaseSizeBeforeTest = templateRepository.findAll().size();
        // set the field null
        template.setIsActive(null);

        // Create the Template, which fails.
        TemplateDTO templateDTO = templateMapper.templateToTemplateDTO(template);

        restTemplateMockMvc.perform(post("/api/templates")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(templateDTO)))
                .andExpect(status().isBadRequest());

        List<Template> templates = templateRepository.findAll();
        assertThat(templates).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllTemplates() throws Exception {
        // Initialize the database
        templateRepository.saveAndFlush(template);

        // Get all the templates
        restTemplateMockMvc.perform(get("/api/templates?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andExpect(jsonPath("$.[*].id").value(hasItem(template.getId().intValue())))
                .andExpect(jsonPath("$.[*].path").value(hasItem(DEFAULT_PATH.toString())))
                .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
                .andExpect(jsonPath("$.[*].type").value(hasItem(DEFAULT_TYPE.toString())))
                .andExpect(jsonPath("$.[*].description").value(hasItem(DEFAULT_DESCRIPTION.toString())))
                .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
                .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }

    @Test
    @Transactional
    public void getTemplate() throws Exception {
        // Initialize the database
        templateRepository.saveAndFlush(template);

        // Get the template
        restTemplateMockMvc.perform(get("/api/templates/{id}", template.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(template.getId().intValue()))
            .andExpect(jsonPath("$.path").value(DEFAULT_PATH.toString()))
            .andExpect(jsonPath("$.name").value(DEFAULT_NAME.toString()))
            .andExpect(jsonPath("$.type").value(DEFAULT_TYPE.toString()))
            .andExpect(jsonPath("$.description").value(DEFAULT_DESCRIPTION.toString()))
            .andExpect(jsonPath("$.isActive").value(DEFAULT_IS_ACTIVE.booleanValue()))
            .andExpect(jsonPath("$.updatedDate").value(DEFAULT_UPDATED_DATE_STR));
    }

    @Test
    @Transactional
    public void getNonExistingTemplate() throws Exception {
        // Get the template
        restTemplateMockMvc.perform(get("/api/templates/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateTemplate() throws Exception {
        // Initialize the database
        templateRepository.saveAndFlush(template);
        templateSearchRepository.save(template);
        int databaseSizeBeforeUpdate = templateRepository.findAll().size();

        // Update the template
        Template updatedTemplate = templateRepository.findOne(template.getId());
        updatedTemplate.setPath(UPDATED_PATH);
        updatedTemplate.setName(UPDATED_NAME);
        updatedTemplate.setType(UPDATED_TYPE);
        updatedTemplate.setDescription(UPDATED_DESCRIPTION);
        updatedTemplate.setIsActive(UPDATED_IS_ACTIVE);
        updatedTemplate.setUpdatedDate(UPDATED_UPDATED_DATE);
        TemplateDTO templateDTO = templateMapper.templateToTemplateDTO(updatedTemplate);

        restTemplateMockMvc.perform(put("/api/templates")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(templateDTO)))
                .andExpect(status().isOk());

        // Validate the Template in the database
        List<Template> templates = templateRepository.findAll();
        assertThat(templates).hasSize(databaseSizeBeforeUpdate);
        Template testTemplate = templates.get(templates.size() - 1);
        assertThat(testTemplate.getPath()).isEqualTo(UPDATED_PATH);
        assertThat(testTemplate.getName()).isEqualTo(UPDATED_NAME);
        assertThat(testTemplate.getType()).isEqualTo(UPDATED_TYPE);
        assertThat(testTemplate.getDescription()).isEqualTo(UPDATED_DESCRIPTION);
        assertThat(testTemplate.isIsActive()).isEqualTo(UPDATED_IS_ACTIVE);
        assertThat(testTemplate.getUpdatedDate()).isEqualTo(UPDATED_UPDATED_DATE);

        // Validate the Template in ElasticSearch
        Template templateEs = templateSearchRepository.findOne(testTemplate.getId());
        assertThat(templateEs).isEqualToComparingFieldByField(testTemplate);
    }

    @Test
    @Transactional
    public void deleteTemplate() throws Exception {
        // Initialize the database
        templateRepository.saveAndFlush(template);
        templateSearchRepository.save(template);
        int databaseSizeBeforeDelete = templateRepository.findAll().size();

        // Get the template
        restTemplateMockMvc.perform(delete("/api/templates/{id}", template.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate ElasticSearch is empty
        boolean templateExistsInEs = templateSearchRepository.exists(template.getId());
        assertThat(templateExistsInEs).isFalse();

        // Validate the database is empty
        List<Template> templates = templateRepository.findAll();
        assertThat(templates).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void searchTemplate() throws Exception {
        // Initialize the database
        templateRepository.saveAndFlush(template);
        templateSearchRepository.save(template);

        // Search the template
        restTemplateMockMvc.perform(get("/api/_search/templates?query=id:" + template.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(template.getId().intValue())))
            .andExpect(jsonPath("$.[*].path").value(hasItem(DEFAULT_PATH.toString())))
            .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
            .andExpect(jsonPath("$.[*].type").value(hasItem(DEFAULT_TYPE.toString())))
            .andExpect(jsonPath("$.[*].description").value(hasItem(DEFAULT_DESCRIPTION.toString())))
            .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
            .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }
}
