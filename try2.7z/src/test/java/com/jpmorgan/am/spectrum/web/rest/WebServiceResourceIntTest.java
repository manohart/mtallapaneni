package com.jpmorgan.am.spectrum.web.rest;

import com.jpmorgan.am.spectrum.HealthCheckApp;

import com.jpmorgan.am.spectrum.domain.WebService;
import com.jpmorgan.am.spectrum.repository.WebServiceRepository;
import com.jpmorgan.am.spectrum.service.WebServiceService;
import com.jpmorgan.am.spectrum.repository.search.WebServiceSearchRepository;
import com.jpmorgan.am.spectrum.service.dto.WebServiceDTO;
import com.jpmorgan.am.spectrum.service.mapper.WebServiceMapper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneId;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the WebServiceResource REST controller.
 *
 * @see WebServiceResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = HealthCheckApp.class)
public class WebServiceResourceIntTest {

    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(ZoneId.of("Z"));

    private static final String DEFAULT_NAME = "AAAAA";
    private static final String UPDATED_NAME = "BBBBB";
    private static final String DEFAULT_DESCRIPTION = "AAAAA";
    private static final String UPDATED_DESCRIPTION = "BBBBB";
    private static final String DEFAULT_PATH = "AAAAA";
    private static final String UPDATED_PATH = "BBBBB";
    private static final String DEFAULT_PARAMS = "AAAAA";
    private static final String UPDATED_PARAMS = "BBBBB";
    private static final String DEFAULT_OPTIONAL_PARAMS = "AAAAA";
    private static final String UPDATED_OPTIONAL_PARAMS = "BBBBB";

    private static final Boolean DEFAULT_IS_ACTIVE = false;
    private static final Boolean UPDATED_IS_ACTIVE = true;

    private static final ZonedDateTime DEFAULT_UPDATED_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneId.systemDefault());
    private static final ZonedDateTime UPDATED_UPDATED_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);
    private static final String DEFAULT_UPDATED_DATE_STR = dateTimeFormatter.format(DEFAULT_UPDATED_DATE);

    @Inject
    private WebServiceRepository webServiceRepository;

    @Inject
    private WebServiceMapper webServiceMapper;

    @Inject
    private WebServiceService webServiceService;

    @Inject
    private WebServiceSearchRepository webServiceSearchRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restWebServiceMockMvc;

    private WebService webService;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        WebServiceResource webServiceResource = new WebServiceResource();
        ReflectionTestUtils.setField(webServiceResource, "webServiceService", webServiceService);
        this.restWebServiceMockMvc = MockMvcBuilders.standaloneSetup(webServiceResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static WebService createEntity(EntityManager em) {
        WebService webService = new WebService();
        webService.setName(DEFAULT_NAME);
        webService.setDescription(DEFAULT_DESCRIPTION);
        webService.setPath(DEFAULT_PATH);
        webService.setParams(DEFAULT_PARAMS);
        webService.setOptionalParams(DEFAULT_OPTIONAL_PARAMS);
        webService.setIsActive(DEFAULT_IS_ACTIVE);
        webService.setUpdatedDate(DEFAULT_UPDATED_DATE);
        return webService;
    }

    @Before
    public void initTest() {
        webServiceSearchRepository.deleteAll();
        webService = createEntity(em);
    }

    @Test
    @Transactional
    public void createWebService() throws Exception {
        int databaseSizeBeforeCreate = webServiceRepository.findAll().size();

        // Create the WebService
        WebServiceDTO webServiceDTO = webServiceMapper.webServiceToWebServiceDTO(webService);

        restWebServiceMockMvc.perform(post("/api/web-services")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(webServiceDTO)))
                .andExpect(status().isCreated());

        // Validate the WebService in the database
        List<WebService> webServices = webServiceRepository.findAll();
        assertThat(webServices).hasSize(databaseSizeBeforeCreate + 1);
        WebService testWebService = webServices.get(webServices.size() - 1);
        assertThat(testWebService.getName()).isEqualTo(DEFAULT_NAME);
        assertThat(testWebService.getDescription()).isEqualTo(DEFAULT_DESCRIPTION);
        assertThat(testWebService.getPath()).isEqualTo(DEFAULT_PATH);
        assertThat(testWebService.getParams()).isEqualTo(DEFAULT_PARAMS);
        assertThat(testWebService.getOptionalParams()).isEqualTo(DEFAULT_OPTIONAL_PARAMS);
        assertThat(testWebService.isIsActive()).isEqualTo(DEFAULT_IS_ACTIVE);
        assertThat(testWebService.getUpdatedDate()).isEqualTo(DEFAULT_UPDATED_DATE);

        // Validate the WebService in ElasticSearch
        WebService webServiceEs = webServiceSearchRepository.findOne(testWebService.getId());
        assertThat(webServiceEs).isEqualToComparingFieldByField(testWebService);
    }

    @Test
    @Transactional
    public void checkNameIsRequired() throws Exception {
        int databaseSizeBeforeTest = webServiceRepository.findAll().size();
        // set the field null
        webService.setName(null);

        // Create the WebService, which fails.
        WebServiceDTO webServiceDTO = webServiceMapper.webServiceToWebServiceDTO(webService);

        restWebServiceMockMvc.perform(post("/api/web-services")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(webServiceDTO)))
                .andExpect(status().isBadRequest());

        List<WebService> webServices = webServiceRepository.findAll();
        assertThat(webServices).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkDescriptionIsRequired() throws Exception {
        int databaseSizeBeforeTest = webServiceRepository.findAll().size();
        // set the field null
        webService.setDescription(null);

        // Create the WebService, which fails.
        WebServiceDTO webServiceDTO = webServiceMapper.webServiceToWebServiceDTO(webService);

        restWebServiceMockMvc.perform(post("/api/web-services")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(webServiceDTO)))
                .andExpect(status().isBadRequest());

        List<WebService> webServices = webServiceRepository.findAll();
        assertThat(webServices).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkPathIsRequired() throws Exception {
        int databaseSizeBeforeTest = webServiceRepository.findAll().size();
        // set the field null
        webService.setPath(null);

        // Create the WebService, which fails.
        WebServiceDTO webServiceDTO = webServiceMapper.webServiceToWebServiceDTO(webService);

        restWebServiceMockMvc.perform(post("/api/web-services")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(webServiceDTO)))
                .andExpect(status().isBadRequest());

        List<WebService> webServices = webServiceRepository.findAll();
        assertThat(webServices).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkIsActiveIsRequired() throws Exception {
        int databaseSizeBeforeTest = webServiceRepository.findAll().size();
        // set the field null
        webService.setIsActive(null);

        // Create the WebService, which fails.
        WebServiceDTO webServiceDTO = webServiceMapper.webServiceToWebServiceDTO(webService);

        restWebServiceMockMvc.perform(post("/api/web-services")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(webServiceDTO)))
                .andExpect(status().isBadRequest());

        List<WebService> webServices = webServiceRepository.findAll();
        assertThat(webServices).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllWebServices() throws Exception {
        // Initialize the database
        webServiceRepository.saveAndFlush(webService);

        // Get all the webServices
        restWebServiceMockMvc.perform(get("/api/web-services?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andExpect(jsonPath("$.[*].id").value(hasItem(webService.getId().intValue())))
                .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
                .andExpect(jsonPath("$.[*].description").value(hasItem(DEFAULT_DESCRIPTION.toString())))
                .andExpect(jsonPath("$.[*].path").value(hasItem(DEFAULT_PATH.toString())))
                .andExpect(jsonPath("$.[*].params").value(hasItem(DEFAULT_PARAMS.toString())))
                .andExpect(jsonPath("$.[*].optionalParams").value(hasItem(DEFAULT_OPTIONAL_PARAMS.toString())))
                .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
                .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }

    @Test
    @Transactional
    public void getWebService() throws Exception {
        // Initialize the database
        webServiceRepository.saveAndFlush(webService);

        // Get the webService
        restWebServiceMockMvc.perform(get("/api/web-services/{id}", webService.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(webService.getId().intValue()))
            .andExpect(jsonPath("$.name").value(DEFAULT_NAME.toString()))
            .andExpect(jsonPath("$.description").value(DEFAULT_DESCRIPTION.toString()))
            .andExpect(jsonPath("$.path").value(DEFAULT_PATH.toString()))
            .andExpect(jsonPath("$.params").value(DEFAULT_PARAMS.toString()))
            .andExpect(jsonPath("$.optionalParams").value(DEFAULT_OPTIONAL_PARAMS.toString()))
            .andExpect(jsonPath("$.isActive").value(DEFAULT_IS_ACTIVE.booleanValue()))
            .andExpect(jsonPath("$.updatedDate").value(DEFAULT_UPDATED_DATE_STR));
    }

    @Test
    @Transactional
    public void getNonExistingWebService() throws Exception {
        // Get the webService
        restWebServiceMockMvc.perform(get("/api/web-services/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateWebService() throws Exception {
        // Initialize the database
        webServiceRepository.saveAndFlush(webService);
        webServiceSearchRepository.save(webService);
        int databaseSizeBeforeUpdate = webServiceRepository.findAll().size();

        // Update the webService
        WebService updatedWebService = webServiceRepository.findOne(webService.getId());
        updatedWebService.setName(UPDATED_NAME);
        updatedWebService.setDescription(UPDATED_DESCRIPTION);
        updatedWebService.setPath(UPDATED_PATH);
        updatedWebService.setParams(UPDATED_PARAMS);
        updatedWebService.setOptionalParams(UPDATED_OPTIONAL_PARAMS);
        updatedWebService.setIsActive(UPDATED_IS_ACTIVE);
        updatedWebService.setUpdatedDate(UPDATED_UPDATED_DATE);
        WebServiceDTO webServiceDTO = webServiceMapper.webServiceToWebServiceDTO(updatedWebService);

        restWebServiceMockMvc.perform(put("/api/web-services")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(webServiceDTO)))
                .andExpect(status().isOk());

        // Validate the WebService in the database
        List<WebService> webServices = webServiceRepository.findAll();
        assertThat(webServices).hasSize(databaseSizeBeforeUpdate);
        WebService testWebService = webServices.get(webServices.size() - 1);
        assertThat(testWebService.getName()).isEqualTo(UPDATED_NAME);
        assertThat(testWebService.getDescription()).isEqualTo(UPDATED_DESCRIPTION);
        assertThat(testWebService.getPath()).isEqualTo(UPDATED_PATH);
        assertThat(testWebService.getParams()).isEqualTo(UPDATED_PARAMS);
        assertThat(testWebService.getOptionalParams()).isEqualTo(UPDATED_OPTIONAL_PARAMS);
        assertThat(testWebService.isIsActive()).isEqualTo(UPDATED_IS_ACTIVE);
        assertThat(testWebService.getUpdatedDate()).isEqualTo(UPDATED_UPDATED_DATE);

        // Validate the WebService in ElasticSearch
        WebService webServiceEs = webServiceSearchRepository.findOne(testWebService.getId());
        assertThat(webServiceEs).isEqualToComparingFieldByField(testWebService);
    }

    @Test
    @Transactional
    public void deleteWebService() throws Exception {
        // Initialize the database
        webServiceRepository.saveAndFlush(webService);
        webServiceSearchRepository.save(webService);
        int databaseSizeBeforeDelete = webServiceRepository.findAll().size();

        // Get the webService
        restWebServiceMockMvc.perform(delete("/api/web-services/{id}", webService.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate ElasticSearch is empty
        boolean webServiceExistsInEs = webServiceSearchRepository.exists(webService.getId());
        assertThat(webServiceExistsInEs).isFalse();

        // Validate the database is empty
        List<WebService> webServices = webServiceRepository.findAll();
        assertThat(webServices).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void searchWebService() throws Exception {
        // Initialize the database
        webServiceRepository.saveAndFlush(webService);
        webServiceSearchRepository.save(webService);

        // Search the webService
        restWebServiceMockMvc.perform(get("/api/_search/web-services?query=id:" + webService.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(webService.getId().intValue())))
            .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
            .andExpect(jsonPath("$.[*].description").value(hasItem(DEFAULT_DESCRIPTION.toString())))
            .andExpect(jsonPath("$.[*].path").value(hasItem(DEFAULT_PATH.toString())))
            .andExpect(jsonPath("$.[*].params").value(hasItem(DEFAULT_PARAMS.toString())))
            .andExpect(jsonPath("$.[*].optionalParams").value(hasItem(DEFAULT_OPTIONAL_PARAMS.toString())))
            .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
            .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }
}
