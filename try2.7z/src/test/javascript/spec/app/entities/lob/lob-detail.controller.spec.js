'use strict';

describe('Controller Tests', function() {

    describe('Lob Management Detail Controller', function() {
        var $scope, $rootScope;
        var MockEntity, MockPreviousState, MockLob, MockReleaseNoteHistory, MockServer, MockArchiveLocation, MockTemplate;
        var createController;

        beforeEach(inject(function($injector) {
            $rootScope = $injector.get('$rootScope');
            $scope = $rootScope.$new();
            MockEntity = jasmine.createSpy('MockEntity');
            MockPreviousState = jasmine.createSpy('MockPreviousState');
            MockLob = jasmine.createSpy('MockLob');
            MockReleaseNoteHistory = jasmine.createSpy('MockReleaseNoteHistory');
            MockServer = jasmine.createSpy('MockServer');
            MockArchiveLocation = jasmine.createSpy('MockArchiveLocation');
            MockTemplate = jasmine.createSpy('MockTemplate');
            

            var locals = {
                '$scope': $scope,
                '$rootScope': $rootScope,
                'entity': MockEntity,
                'previousState': MockPreviousState,
                'Lob': MockLob,
                'ReleaseNoteHistory': MockReleaseNoteHistory,
                'Server': MockServer,
                'ArchiveLocation': MockArchiveLocation,
                'Template': MockTemplate
            };
            createController = function() {
                $injector.get('$controller')("LobDetailController", locals);
            };
        }));


        describe('Root Scope Listening', function() {
            it('Unregisters root scope listener upon scope destruction', function() {
                var eventType = 'healthCheckApp:lobUpdate';

                createController();
                expect($rootScope.$$listenerCount[eventType]).toEqual(1);

                $scope.$destroy();
                expect($rootScope.$$listenerCount[eventType]).toBeUndefined();
            });
        });
    });

});
