package com.jpmorgan.am.grt.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.springframework.data.elasticsearch.annotations.Document;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

/**
 * A BatchReportHistory.
 */
@Entity
@Table(name = "batch_report_history")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@Document(indexName = "batchreporthistory")
public class BatchReportHistory implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "initial_status", nullable = false)
    private String initialStatus;

    @NotNull
    @Column(name = "final_status", nullable = false)
    private String finalStatus;

    @NotNull
    @Column(name = "business_date", nullable = false)
    private LocalDate businessDate;

    @Column(name = "comment")
    private String comment;

    @Column(name = "updated_date")
    private ZonedDateTime updatedDate;

    @OneToMany(mappedBy = "summary")
    @JsonIgnore
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<BatchReportDetailHistory> details = new HashSet<>();

    @ManyToOne
    private BatchReport reportConfig;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getInitialStatus() {
        return initialStatus;
    }

    public void setInitialStatus(String initialStatus) {
        this.initialStatus = initialStatus;
    }

    public String getFinalStatus() {
        return finalStatus;
    }

    public void setFinalStatus(String finalStatus) {
        this.finalStatus = finalStatus;
    }

    public LocalDate getBusinessDate() {
        return businessDate;
    }

    public void setBusinessDate(LocalDate businessDate) {
        this.businessDate = businessDate;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public ZonedDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(ZonedDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Set<BatchReportDetailHistory> getDetails() {
        return details;
    }

    public void setDetails(Set<BatchReportDetailHistory> batchReportDetailHistories) {
        this.details = batchReportDetailHistories;
    }

    public BatchReport getReportConfig() {
        return reportConfig;
    }

    public void setReportConfig(BatchReport batchReport) {
        this.reportConfig = batchReport;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        BatchReportHistory batchReportHistory = (BatchReportHistory) o;
        if(batchReportHistory.id == null || id == null) {
            return false;
        }
        return Objects.equals(id, batchReportHistory.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "BatchReportHistory{" +
            "id=" + id +
            ", initialStatus='" + initialStatus + "'" +
            ", finalStatus='" + finalStatus + "'" +
            ", businessDate='" + businessDate + "'" +
            ", comment='" + comment + "'" +
            ", updatedDate='" + updatedDate + "'" +
            '}';
    }
}
