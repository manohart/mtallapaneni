package com.jpmorgan.am.grt.domain.enumeration;

/**
 * The AppScheduler enumeration.
 */
public enum AppScheduler {
    CONTROL_M,AUTOSYS,WINDOWS_TS,OTHERS
}
