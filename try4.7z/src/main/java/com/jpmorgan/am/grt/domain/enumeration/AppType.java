package com.jpmorgan.am.grt.domain.enumeration;

/**
 * The AppType enumeration.
 */
public enum AppType {
    BATCH,WEB,DESKTOP,OTHERS
}
