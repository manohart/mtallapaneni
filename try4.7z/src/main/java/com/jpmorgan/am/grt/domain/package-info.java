/**
 * JPA domain objects.
 */
package com.jpmorgan.am.grt.domain;
