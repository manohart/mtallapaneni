package com.jpmorgan.am.grt.repository;

import com.jpmorgan.am.grt.domain.BatchReportHistory;

import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the BatchReportHistory entity.
 */
@SuppressWarnings("unused")
public interface BatchReportHistoryRepository extends JpaRepository<BatchReportHistory,Long> {

}
