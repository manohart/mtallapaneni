package com.jpmorgan.am.grt.repository;

import com.jpmorgan.am.grt.domain.BatchReport;

import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the BatchReport entity.
 */
@SuppressWarnings("unused")
public interface BatchReportRepository extends JpaRepository<BatchReport,Long> {

}
