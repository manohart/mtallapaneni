package com.jpmorgan.am.grt.repository;

import com.jpmorgan.am.grt.domain.HealthCheckConfig;

import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the HealthCheckConfig entity.
 */
@SuppressWarnings("unused")
public interface HealthCheckConfigRepository extends JpaRepository<HealthCheckConfig,Long> {

}
