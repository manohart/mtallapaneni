package com.jpmorgan.am.grt.repository;

import com.jpmorgan.am.grt.domain.HealthChecker;

import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the HealthChecker entity.
 */
@SuppressWarnings("unused")
public interface HealthCheckerRepository extends JpaRepository<HealthChecker,Long> {

}
