package com.jpmorgan.am.grt.repository;

import com.jpmorgan.am.grt.domain.Server;

import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the Server entity.
 */
@SuppressWarnings("unused")
public interface ServerRepository extends JpaRepository<Server,Long> {

}
