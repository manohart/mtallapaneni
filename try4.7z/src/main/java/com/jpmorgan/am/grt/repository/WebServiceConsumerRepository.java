package com.jpmorgan.am.grt.repository;

import com.jpmorgan.am.grt.domain.WebServiceConsumer;

import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the WebServiceConsumer entity.
 */
@SuppressWarnings("unused")
public interface WebServiceConsumerRepository extends JpaRepository<WebServiceConsumer,Long> {

}
