package com.jpmorgan.am.grt.repository.search;

import com.jpmorgan.am.grt.domain.ArchiveLocation;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * Spring Data ElasticSearch repository for the ArchiveLocation entity.
 */
public interface ArchiveLocationSearchRepository extends ElasticsearchRepository<ArchiveLocation, Long> {
}
