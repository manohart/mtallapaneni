package com.jpmorgan.am.grt.repository.search;

import com.jpmorgan.am.grt.domain.Lob;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * Spring Data ElasticSearch repository for the Lob entity.
 */
public interface LobSearchRepository extends ElasticsearchRepository<Lob, Long> {
}
