package com.jpmorgan.am.grt.repository.search;

import com.jpmorgan.am.grt.domain.NotificationRule;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * Spring Data ElasticSearch repository for the NotificationRule entity.
 */
public interface NotificationRuleSearchRepository extends ElasticsearchRepository<NotificationRule, Long> {
}
