package com.jpmorgan.am.grt.repository.search;

import com.jpmorgan.am.grt.domain.ReleaseNoteHistory;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * Spring Data ElasticSearch repository for the ReleaseNoteHistory entity.
 */
public interface ReleaseNoteHistorySearchRepository extends ElasticsearchRepository<ReleaseNoteHistory, Long> {
}
