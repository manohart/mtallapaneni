package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.service.dto.AppDependencyDTO;

import java.util.LinkedList;
import java.util.List;

/**
 * Service Interface for managing AppDependency.
 */
public interface AppDependencyService {

    /**
     * Save a appDependency.
     *
     * @param appDependencyDTO the entity to save
     * @return the persisted entity
     */
    AppDependencyDTO save(AppDependencyDTO appDependencyDTO);

    /**
     *  Get all the appDependencies.
     *  
     *  @return the list of entities
     */
    List<AppDependencyDTO> findAll();

    /**
     *  Get the "id" appDependency.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    AppDependencyDTO findOne(Long id);

    /**
     *  Delete the "id" appDependency.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the appDependency corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<AppDependencyDTO> search(String query);
}
