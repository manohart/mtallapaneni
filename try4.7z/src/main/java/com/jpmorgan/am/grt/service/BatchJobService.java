package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.service.dto.BatchJobDTO;

import java.util.LinkedList;
import java.util.List;

/**
 * Service Interface for managing BatchJob.
 */
public interface BatchJobService {

    /**
     * Save a batchJob.
     *
     * @param batchJobDTO the entity to save
     * @return the persisted entity
     */
    BatchJobDTO save(BatchJobDTO batchJobDTO);

    /**
     *  Get all the batchJobs.
     *  
     *  @return the list of entities
     */
    List<BatchJobDTO> findAll();

    /**
     *  Get the "id" batchJob.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    BatchJobDTO findOne(Long id);

    /**
     *  Delete the "id" batchJob.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the batchJob corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<BatchJobDTO> search(String query);
}
