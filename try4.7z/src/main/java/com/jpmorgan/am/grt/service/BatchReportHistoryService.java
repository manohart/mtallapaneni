package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.service.dto.BatchReportHistoryDTO;

import java.util.LinkedList;
import java.util.List;

/**
 * Service Interface for managing BatchReportHistory.
 */
public interface BatchReportHistoryService {

    /**
     * Save a batchReportHistory.
     *
     * @param batchReportHistoryDTO the entity to save
     * @return the persisted entity
     */
    BatchReportHistoryDTO save(BatchReportHistoryDTO batchReportHistoryDTO);

    /**
     *  Get all the batchReportHistories.
     *  
     *  @return the list of entities
     */
    List<BatchReportHistoryDTO> findAll();

    /**
     *  Get the "id" batchReportHistory.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    BatchReportHistoryDTO findOne(Long id);

    /**
     *  Delete the "id" batchReportHistory.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the batchReportHistory corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<BatchReportHistoryDTO> search(String query);
}
