package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.service.dto.BatchReportDTO;

import java.util.LinkedList;
import java.util.List;

/**
 * Service Interface for managing BatchReport.
 */
public interface BatchReportService {

    /**
     * Save a batchReport.
     *
     * @param batchReportDTO the entity to save
     * @return the persisted entity
     */
    BatchReportDTO save(BatchReportDTO batchReportDTO);

    /**
     *  Get all the batchReports.
     *  
     *  @return the list of entities
     */
    List<BatchReportDTO> findAll();

    /**
     *  Get the "id" batchReport.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    BatchReportDTO findOne(Long id);

    /**
     *  Delete the "id" batchReport.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the batchReport corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<BatchReportDTO> search(String query);
}
