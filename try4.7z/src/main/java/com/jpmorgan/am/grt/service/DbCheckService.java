package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.service.dto.DbCheckDTO;

import java.util.LinkedList;
import java.util.List;

/**
 * Service Interface for managing DbCheck.
 */
public interface DbCheckService {

    /**
     * Save a dbCheck.
     *
     * @param dbCheckDTO the entity to save
     * @return the persisted entity
     */
    DbCheckDTO save(DbCheckDTO dbCheckDTO);

    /**
     *  Get all the dbChecks.
     *  
     *  @return the list of entities
     */
    List<DbCheckDTO> findAll();

    /**
     *  Get the "id" dbCheck.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    DbCheckDTO findOne(Long id);

    /**
     *  Delete the "id" dbCheck.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the dbCheck corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<DbCheckDTO> search(String query);
}
