package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.service.dto.HealthCheckConfigDTO;

import java.util.LinkedList;
import java.util.List;

/**
 * Service Interface for managing HealthCheckConfig.
 */
public interface HealthCheckConfigService {

    /**
     * Save a healthCheckConfig.
     *
     * @param healthCheckConfigDTO the entity to save
     * @return the persisted entity
     */
    HealthCheckConfigDTO save(HealthCheckConfigDTO healthCheckConfigDTO);

    /**
     *  Get all the healthCheckConfigs.
     *  
     *  @return the list of entities
     */
    List<HealthCheckConfigDTO> findAll();

    /**
     *  Get the "id" healthCheckConfig.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    HealthCheckConfigDTO findOne(Long id);

    /**
     *  Delete the "id" healthCheckConfig.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the healthCheckConfig corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<HealthCheckConfigDTO> search(String query);
}
