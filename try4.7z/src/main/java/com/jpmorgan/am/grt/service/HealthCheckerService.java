package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.service.dto.HealthCheckerDTO;

import java.util.LinkedList;
import java.util.List;

/**
 * Service Interface for managing HealthChecker.
 */
public interface HealthCheckerService {

    /**
     * Save a healthChecker.
     *
     * @param healthCheckerDTO the entity to save
     * @return the persisted entity
     */
    HealthCheckerDTO save(HealthCheckerDTO healthCheckerDTO);

    /**
     *  Get all the healthCheckers.
     *  
     *  @return the list of entities
     */
    List<HealthCheckerDTO> findAll();

    /**
     *  Get the "id" healthChecker.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    HealthCheckerDTO findOne(Long id);

    /**
     *  Delete the "id" healthChecker.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the healthChecker corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<HealthCheckerDTO> search(String query);
}
