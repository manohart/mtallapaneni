package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.service.dto.LobDTO;

import java.util.LinkedList;
import java.util.List;

/**
 * Service Interface for managing Lob.
 */
public interface LobService {

    /**
     * Save a lob.
     *
     * @param lobDTO the entity to save
     * @return the persisted entity
     */
    LobDTO save(LobDTO lobDTO);

    /**
     *  Get all the lobs.
     *  
     *  @return the list of entities
     */
    List<LobDTO> findAll();

    /**
     *  Get the "id" lob.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    LobDTO findOne(Long id);

    /**
     *  Delete the "id" lob.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the lob corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<LobDTO> search(String query);
}
