package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.service.dto.ReleaseNoteHistoryDTO;

import java.util.LinkedList;
import java.util.List;

/**
 * Service Interface for managing ReleaseNoteHistory.
 */
public interface ReleaseNoteHistoryService {

    /**
     * Save a releaseNoteHistory.
     *
     * @param releaseNoteHistoryDTO the entity to save
     * @return the persisted entity
     */
    ReleaseNoteHistoryDTO save(ReleaseNoteHistoryDTO releaseNoteHistoryDTO);

    /**
     *  Get all the releaseNoteHistories.
     *  
     *  @return the list of entities
     */
    List<ReleaseNoteHistoryDTO> findAll();

    /**
     *  Get the "id" releaseNoteHistory.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    ReleaseNoteHistoryDTO findOne(Long id);

    /**
     *  Delete the "id" releaseNoteHistory.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the releaseNoteHistory corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<ReleaseNoteHistoryDTO> search(String query);
}
