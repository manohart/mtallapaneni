package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.service.dto.WebServiceDTO;

import java.util.LinkedList;
import java.util.List;

/**
 * Service Interface for managing WebService.
 */
public interface WebServiceService {

    /**
     * Save a webService.
     *
     * @param webServiceDTO the entity to save
     * @return the persisted entity
     */
    WebServiceDTO save(WebServiceDTO webServiceDTO);

    /**
     *  Get all the webServices.
     *  
     *  @return the list of entities
     */
    List<WebServiceDTO> findAll();

    /**
     *  Get the "id" webService.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    WebServiceDTO findOne(Long id);

    /**
     *  Delete the "id" webService.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the webService corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<WebServiceDTO> search(String query);
}
