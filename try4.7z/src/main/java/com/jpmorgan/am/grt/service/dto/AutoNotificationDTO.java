package com.jpmorgan.am.grt.service.dto;

import java.time.ZonedDateTime;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;


/**
 * A DTO for the AutoNotification entity.
 */
public class AutoNotificationDTO implements Serializable {

    private Long id;

    @NotNull
    private Boolean isActive;

    private ZonedDateTime updatedDate;


    private Long ruleId;
    

    private String ruleName;

    private Long lobId;
    

    private String lobName;

    private Long applicationId;
    

    private String applicationName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }
    public ZonedDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(ZonedDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Long getRuleId() {
        return ruleId;
    }

    public void setRuleId(Long notificationRuleId) {
        this.ruleId = notificationRuleId;
    }


    public String getRuleName() {
        return ruleName;
    }

    public void setRuleName(String notificationRuleName) {
        this.ruleName = notificationRuleName;
    }

    public Long getLobId() {
        return lobId;
    }

    public void setLobId(Long lobId) {
        this.lobId = lobId;
    }


    public String getLobName() {
        return lobName;
    }

    public void setLobName(String lobName) {
        this.lobName = lobName;
    }

    public Long getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(Long applicationId) {
        this.applicationId = applicationId;
    }


    public String getApplicationName() {
        return applicationName;
    }

    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        AutoNotificationDTO autoNotificationDTO = (AutoNotificationDTO) o;

        if ( ! Objects.equals(id, autoNotificationDTO.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "AutoNotificationDTO{" +
            "id=" + id +
            ", isActive='" + isActive + "'" +
            ", updatedDate='" + updatedDate + "'" +
            '}';
    }
}
