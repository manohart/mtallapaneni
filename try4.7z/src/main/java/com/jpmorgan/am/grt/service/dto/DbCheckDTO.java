package com.jpmorgan.am.grt.service.dto;

import java.time.ZonedDateTime;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;


/**
 * A DTO for the DbCheck entity.
 */
public class DbCheckDTO implements Serializable {

    private Long id;

    @NotNull
    private String name;

    @NotNull
    private String sqlQuery;

    @NotNull
    private String description;

    @NotNull
    private String expectation;

    private Boolean reportIssuesOnly;

    private String groupColumns;

    @NotNull
    @Min(value = 0)
    private Integer sequence;

    private Boolean isActive;

    private ZonedDateTime updatedDate;


    private Long executorServiceId;
    

    private String executorServiceName;

    private Long healthCheckerId;
    

    private String healthCheckerName;

    private Long batchReportId;
    

    private String batchReportName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getSqlQuery() {
        return sqlQuery;
    }

    public void setSqlQuery(String sqlQuery) {
        this.sqlQuery = sqlQuery;
    }
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    public String getExpectation() {
        return expectation;
    }

    public void setExpectation(String expectation) {
        this.expectation = expectation;
    }
    public Boolean getReportIssuesOnly() {
        return reportIssuesOnly;
    }

    public void setReportIssuesOnly(Boolean reportIssuesOnly) {
        this.reportIssuesOnly = reportIssuesOnly;
    }
    public String getGroupColumns() {
        return groupColumns;
    }

    public void setGroupColumns(String groupColumns) {
        this.groupColumns = groupColumns;
    }
    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }
    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }
    public ZonedDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(ZonedDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Long getExecutorServiceId() {
        return executorServiceId;
    }

    public void setExecutorServiceId(Long webServiceId) {
        this.executorServiceId = webServiceId;
    }


    public String getExecutorServiceName() {
        return executorServiceName;
    }

    public void setExecutorServiceName(String webServiceName) {
        this.executorServiceName = webServiceName;
    }

    public Long getHealthCheckerId() {
        return healthCheckerId;
    }

    public void setHealthCheckerId(Long healthCheckerId) {
        this.healthCheckerId = healthCheckerId;
    }


    public String getHealthCheckerName() {
        return healthCheckerName;
    }

    public void setHealthCheckerName(String healthCheckerName) {
        this.healthCheckerName = healthCheckerName;
    }

    public Long getBatchReportId() {
        return batchReportId;
    }

    public void setBatchReportId(Long batchReportId) {
        this.batchReportId = batchReportId;
    }


    public String getBatchReportName() {
        return batchReportName;
    }

    public void setBatchReportName(String batchReportName) {
        this.batchReportName = batchReportName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DbCheckDTO dbCheckDTO = (DbCheckDTO) o;

        if ( ! Objects.equals(id, dbCheckDTO.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "DbCheckDTO{" +
            "id=" + id +
            ", name='" + name + "'" +
            ", sqlQuery='" + sqlQuery + "'" +
            ", description='" + description + "'" +
            ", expectation='" + expectation + "'" +
            ", reportIssuesOnly='" + reportIssuesOnly + "'" +
            ", groupColumns='" + groupColumns + "'" +
            ", sequence='" + sequence + "'" +
            ", isActive='" + isActive + "'" +
            ", updatedDate='" + updatedDate + "'" +
            '}';
    }
}
