package com.jpmorgan.am.grt.service.dto;

import java.time.ZonedDateTime;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;


/**
 * A DTO for the DevOps entity.
 */
public class DevOpsDTO implements Serializable {

    private Long id;

    @NotNull
    private String name;

    @NotNull
    @Min(value = 1)
    private Integer sealId;

    @NotNull
    private String codeRepo;

    @NotNull
    private String scrumBoard;

    @NotNull
    private String ciBuild;

    @NotNull
    @Size(min = 4)
    private String techonologyStack;

    private ZonedDateTime updatedDate;


    private Long techonologyId;
    

    private String techonologyName;

    private Long supportId;
    

    private String supportName;

    private Long businessId;
    

    private String businessName;

    private Long lobId;
    

    private String lobName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public Integer getSealId() {
        return sealId;
    }

    public void setSealId(Integer sealId) {
        this.sealId = sealId;
    }
    public String getCodeRepo() {
        return codeRepo;
    }

    public void setCodeRepo(String codeRepo) {
        this.codeRepo = codeRepo;
    }
    public String getScrumBoard() {
        return scrumBoard;
    }

    public void setScrumBoard(String scrumBoard) {
        this.scrumBoard = scrumBoard;
    }
    public String getCiBuild() {
        return ciBuild;
    }

    public void setCiBuild(String ciBuild) {
        this.ciBuild = ciBuild;
    }
    public String getTechonologyStack() {
        return techonologyStack;
    }

    public void setTechonologyStack(String techonologyStack) {
        this.techonologyStack = techonologyStack;
    }
    public ZonedDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(ZonedDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Long getTechonologyId() {
        return techonologyId;
    }

    public void setTechonologyId(Long teamId) {
        this.techonologyId = teamId;
    }


    public String getTechonologyName() {
        return techonologyName;
    }

    public void setTechonologyName(String teamName) {
        this.techonologyName = teamName;
    }

    public Long getSupportId() {
        return supportId;
    }

    public void setSupportId(Long teamId) {
        this.supportId = teamId;
    }


    public String getSupportName() {
        return supportName;
    }

    public void setSupportName(String teamName) {
        this.supportName = teamName;
    }

    public Long getBusinessId() {
        return businessId;
    }

    public void setBusinessId(Long teamId) {
        this.businessId = teamId;
    }


    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String teamName) {
        this.businessName = teamName;
    }

    public Long getLobId() {
        return lobId;
    }

    public void setLobId(Long lobId) {
        this.lobId = lobId;
    }


    public String getLobName() {
        return lobName;
    }

    public void setLobName(String lobName) {
        this.lobName = lobName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DevOpsDTO devOpsDTO = (DevOpsDTO) o;

        if ( ! Objects.equals(id, devOpsDTO.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "DevOpsDTO{" +
            "id=" + id +
            ", name='" + name + "'" +
            ", sealId='" + sealId + "'" +
            ", codeRepo='" + codeRepo + "'" +
            ", scrumBoard='" + scrumBoard + "'" +
            ", ciBuild='" + ciBuild + "'" +
            ", techonologyStack='" + techonologyStack + "'" +
            ", updatedDate='" + updatedDate + "'" +
            '}';
    }
}
