package com.jpmorgan.am.grt.service.dto;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;


/**
 * A DTO for the HealthCheckConfig entity.
 */
public class HealthCheckConfigDTO implements Serializable {

    private Long id;


    private Long dbCheckId;
    

    private String dbCheckName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getDbCheckId() {
        return dbCheckId;
    }

    public void setDbCheckId(Long dbCheckId) {
        this.dbCheckId = dbCheckId;
    }


    public String getDbCheckName() {
        return dbCheckName;
    }

    public void setDbCheckName(String dbCheckName) {
        this.dbCheckName = dbCheckName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        HealthCheckConfigDTO healthCheckConfigDTO = (HealthCheckConfigDTO) o;

        if ( ! Objects.equals(id, healthCheckConfigDTO.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "HealthCheckConfigDTO{" +
            "id=" + id +
            '}';
    }
}
