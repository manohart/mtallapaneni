package com.jpmorgan.am.grt.service.dto;

import java.time.ZonedDateTime;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;


/**
 * A DTO for the Lob entity.
 */
public class LobDTO implements Serializable {

    private Long id;

    @NotNull
    private String name;

    @NotNull
    private String description;

    @NotNull
    @Size(min = 7)
    private String ctoSid;

    @NotNull
    @Size(min = 7)
    private String ownerSid;

    @NotNull
    @Size(min = 7)
    private String businessSponsorSid;

    @NotNull
    private Boolean isActive;

    private ZonedDateTime updatedDate;


    private Long superLobId;
    

    private String superLobName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    public String getCtoSid() {
        return ctoSid;
    }

    public void setCtoSid(String ctoSid) {
        this.ctoSid = ctoSid;
    }
    public String getOwnerSid() {
        return ownerSid;
    }

    public void setOwnerSid(String ownerSid) {
        this.ownerSid = ownerSid;
    }
    public String getBusinessSponsorSid() {
        return businessSponsorSid;
    }

    public void setBusinessSponsorSid(String businessSponsorSid) {
        this.businessSponsorSid = businessSponsorSid;
    }
    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }
    public ZonedDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(ZonedDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Long getSuperLobId() {
        return superLobId;
    }

    public void setSuperLobId(Long lobId) {
        this.superLobId = lobId;
    }


    public String getSuperLobName() {
        return superLobName;
    }

    public void setSuperLobName(String lobName) {
        this.superLobName = lobName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        LobDTO lobDTO = (LobDTO) o;

        if ( ! Objects.equals(id, lobDTO.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "LobDTO{" +
            "id=" + id +
            ", name='" + name + "'" +
            ", description='" + description + "'" +
            ", ctoSid='" + ctoSid + "'" +
            ", ownerSid='" + ownerSid + "'" +
            ", businessSponsorSid='" + businessSponsorSid + "'" +
            ", isActive='" + isActive + "'" +
            ", updatedDate='" + updatedDate + "'" +
            '}';
    }
}
