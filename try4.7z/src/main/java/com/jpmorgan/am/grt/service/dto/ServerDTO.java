package com.jpmorgan.am.grt.service.dto;

import java.time.ZonedDateTime;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

import com.jpmorgan.am.grt.domain.enumeration.Environment;
import com.jpmorgan.am.grt.domain.enumeration.ServerType;
import com.jpmorgan.am.grt.domain.enumeration.OsType;

/**
 * A DTO for the Server entity.
 */
public class ServerDTO implements Serializable {

    private Long id;

    @NotNull
    @Size(min = 7)
    private String hostname;

    @NotNull
    @Size(min = 10)
    private String alias;

    @NotNull
    private Environment environment;

    @NotNull
    private ServerType type;

    @NotNull
    private OsType osType;

    @NotNull
    private String description;

    @NotNull
    private Boolean isActive;

    private ZonedDateTime updatedDate;


    private Long lobId;
    

    private String lobName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getHostname() {
        return hostname;
    }

    public void setHostname(String hostname) {
        this.hostname = hostname;
    }
    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }
    public Environment getEnvironment() {
        return environment;
    }

    public void setEnvironment(Environment environment) {
        this.environment = environment;
    }
    public ServerType getType() {
        return type;
    }

    public void setType(ServerType type) {
        this.type = type;
    }
    public OsType getOsType() {
        return osType;
    }

    public void setOsType(OsType osType) {
        this.osType = osType;
    }
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }
    public ZonedDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(ZonedDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Long getLobId() {
        return lobId;
    }

    public void setLobId(Long lobId) {
        this.lobId = lobId;
    }


    public String getLobName() {
        return lobName;
    }

    public void setLobName(String lobName) {
        this.lobName = lobName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ServerDTO serverDTO = (ServerDTO) o;

        if ( ! Objects.equals(id, serverDTO.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "ServerDTO{" +
            "id=" + id +
            ", hostname='" + hostname + "'" +
            ", alias='" + alias + "'" +
            ", environment='" + environment + "'" +
            ", type='" + type + "'" +
            ", osType='" + osType + "'" +
            ", description='" + description + "'" +
            ", isActive='" + isActive + "'" +
            ", updatedDate='" + updatedDate + "'" +
            '}';
    }
}
