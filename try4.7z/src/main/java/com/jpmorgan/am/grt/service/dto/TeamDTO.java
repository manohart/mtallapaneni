package com.jpmorgan.am.grt.service.dto;

import java.time.ZonedDateTime;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;


/**
 * A DTO for the Team entity.
 */
public class TeamDTO implements Serializable {

    private Long id;

    @NotNull
    private String name;

    @NotNull
    @Size(min = 7)
    private String managerSid;

    @NotNull
    @Size(min = 7)
    private String leadSid;

    @NotNull
    private String dl;

    private Boolean isActive;

    private ZonedDateTime updatedDate;


    private Long lobId;
    

    private String lobName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getManagerSid() {
        return managerSid;
    }

    public void setManagerSid(String managerSid) {
        this.managerSid = managerSid;
    }
    public String getLeadSid() {
        return leadSid;
    }

    public void setLeadSid(String leadSid) {
        this.leadSid = leadSid;
    }
    public String getDl() {
        return dl;
    }

    public void setDl(String dl) {
        this.dl = dl;
    }
    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }
    public ZonedDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(ZonedDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Long getLobId() {
        return lobId;
    }

    public void setLobId(Long lobId) {
        this.lobId = lobId;
    }


    public String getLobName() {
        return lobName;
    }

    public void setLobName(String lobName) {
        this.lobName = lobName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        TeamDTO teamDTO = (TeamDTO) o;

        if ( ! Objects.equals(id, teamDTO.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "TeamDTO{" +
            "id=" + id +
            ", name='" + name + "'" +
            ", managerSid='" + managerSid + "'" +
            ", leadSid='" + leadSid + "'" +
            ", dl='" + dl + "'" +
            ", isActive='" + isActive + "'" +
            ", updatedDate='" + updatedDate + "'" +
            '}';
    }
}
