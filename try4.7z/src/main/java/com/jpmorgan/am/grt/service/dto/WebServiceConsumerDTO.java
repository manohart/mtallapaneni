package com.jpmorgan.am.grt.service.dto;

import java.time.ZonedDateTime;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;


/**
 * A DTO for the WebServiceConsumer entity.
 */
public class WebServiceConsumerDTO implements Serializable {

    private Long id;

    @NotNull
    private Boolean isActive;

    private ZonedDateTime updatedDate;


    private Long consumerId;
    

    private String consumerName;

    private Long prodcuerId;
    

    private String prodcuerName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }
    public ZonedDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(ZonedDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Long getConsumerId() {
        return consumerId;
    }

    public void setConsumerId(Long applicationId) {
        this.consumerId = applicationId;
    }


    public String getConsumerName() {
        return consumerName;
    }

    public void setConsumerName(String applicationName) {
        this.consumerName = applicationName;
    }

    public Long getProdcuerId() {
        return prodcuerId;
    }

    public void setProdcuerId(Long webServiceId) {
        this.prodcuerId = webServiceId;
    }


    public String getProdcuerName() {
        return prodcuerName;
    }

    public void setProdcuerName(String webServiceName) {
        this.prodcuerName = webServiceName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        WebServiceConsumerDTO webServiceConsumerDTO = (WebServiceConsumerDTO) o;

        if ( ! Objects.equals(id, webServiceConsumerDTO.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "WebServiceConsumerDTO{" +
            "id=" + id +
            ", isActive='" + isActive + "'" +
            ", updatedDate='" + updatedDate + "'" +
            '}';
    }
}
