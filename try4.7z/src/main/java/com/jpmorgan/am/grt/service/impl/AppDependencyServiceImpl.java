package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.AppDependencyService;
import com.jpmorgan.am.grt.domain.AppDependency;
import com.jpmorgan.am.grt.repository.AppDependencyRepository;
import com.jpmorgan.am.grt.repository.search.AppDependencySearchRepository;
import com.jpmorgan.am.grt.service.dto.AppDependencyDTO;
import com.jpmorgan.am.grt.service.mapper.AppDependencyMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing AppDependency.
 */
@Service
@Transactional
public class AppDependencyServiceImpl implements AppDependencyService{

    private final Logger log = LoggerFactory.getLogger(AppDependencyServiceImpl.class);
    
    @Inject
    private AppDependencyRepository appDependencyRepository;

    @Inject
    private AppDependencyMapper appDependencyMapper;

    @Inject
    private AppDependencySearchRepository appDependencySearchRepository;

    /**
     * Save a appDependency.
     *
     * @param appDependencyDTO the entity to save
     * @return the persisted entity
     */
    public AppDependencyDTO save(AppDependencyDTO appDependencyDTO) {
        log.debug("Request to save AppDependency : {}", appDependencyDTO);
        AppDependency appDependency = appDependencyMapper.appDependencyDTOToAppDependency(appDependencyDTO);
        appDependency = appDependencyRepository.save(appDependency);
        AppDependencyDTO result = appDependencyMapper.appDependencyToAppDependencyDTO(appDependency);
        appDependencySearchRepository.save(appDependency);
        return result;
    }

    /**
     *  Get all the appDependencies.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<AppDependencyDTO> findAll() {
        log.debug("Request to get all AppDependencies");
        List<AppDependencyDTO> result = appDependencyRepository.findAll().stream()
            .map(appDependencyMapper::appDependencyToAppDependencyDTO)
            .collect(Collectors.toCollection(LinkedList::new));

        return result;
    }

    /**
     *  Get one appDependency by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public AppDependencyDTO findOne(Long id) {
        log.debug("Request to get AppDependency : {}", id);
        AppDependency appDependency = appDependencyRepository.findOne(id);
        AppDependencyDTO appDependencyDTO = appDependencyMapper.appDependencyToAppDependencyDTO(appDependency);
        return appDependencyDTO;
    }

    /**
     *  Delete the  appDependency by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete AppDependency : {}", id);
        appDependencyRepository.delete(id);
        appDependencySearchRepository.delete(id);
    }

    /**
     * Search for the appDependency corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<AppDependencyDTO> search(String query) {
        log.debug("Request to search AppDependencies for query {}", query);
        return StreamSupport
            .stream(appDependencySearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .map(appDependencyMapper::appDependencyToAppDependencyDTO)
            .collect(Collectors.toList());
    }
}
