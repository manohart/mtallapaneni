package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.ArchiveLocationService;
import com.jpmorgan.am.grt.domain.ArchiveLocation;
import com.jpmorgan.am.grt.repository.ArchiveLocationRepository;
import com.jpmorgan.am.grt.repository.search.ArchiveLocationSearchRepository;
import com.jpmorgan.am.grt.service.dto.ArchiveLocationDTO;
import com.jpmorgan.am.grt.service.mapper.ArchiveLocationMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing ArchiveLocation.
 */
@Service
@Transactional
public class ArchiveLocationServiceImpl implements ArchiveLocationService{

    private final Logger log = LoggerFactory.getLogger(ArchiveLocationServiceImpl.class);
    
    @Inject
    private ArchiveLocationRepository archiveLocationRepository;

    @Inject
    private ArchiveLocationMapper archiveLocationMapper;

    @Inject
    private ArchiveLocationSearchRepository archiveLocationSearchRepository;

    /**
     * Save a archiveLocation.
     *
     * @param archiveLocationDTO the entity to save
     * @return the persisted entity
     */
    public ArchiveLocationDTO save(ArchiveLocationDTO archiveLocationDTO) {
        log.debug("Request to save ArchiveLocation : {}", archiveLocationDTO);
        ArchiveLocation archiveLocation = archiveLocationMapper.archiveLocationDTOToArchiveLocation(archiveLocationDTO);
        archiveLocation = archiveLocationRepository.save(archiveLocation);
        ArchiveLocationDTO result = archiveLocationMapper.archiveLocationToArchiveLocationDTO(archiveLocation);
        archiveLocationSearchRepository.save(archiveLocation);
        return result;
    }

    /**
     *  Get all the archiveLocations.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<ArchiveLocationDTO> findAll() {
        log.debug("Request to get all ArchiveLocations");
        List<ArchiveLocationDTO> result = archiveLocationRepository.findAll().stream()
            .map(archiveLocationMapper::archiveLocationToArchiveLocationDTO)
            .collect(Collectors.toCollection(LinkedList::new));

        return result;
    }

    /**
     *  Get one archiveLocation by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public ArchiveLocationDTO findOne(Long id) {
        log.debug("Request to get ArchiveLocation : {}", id);
        ArchiveLocation archiveLocation = archiveLocationRepository.findOne(id);
        ArchiveLocationDTO archiveLocationDTO = archiveLocationMapper.archiveLocationToArchiveLocationDTO(archiveLocation);
        return archiveLocationDTO;
    }

    /**
     *  Delete the  archiveLocation by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete ArchiveLocation : {}", id);
        archiveLocationRepository.delete(id);
        archiveLocationSearchRepository.delete(id);
    }

    /**
     * Search for the archiveLocation corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<ArchiveLocationDTO> search(String query) {
        log.debug("Request to search ArchiveLocations for query {}", query);
        return StreamSupport
            .stream(archiveLocationSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .map(archiveLocationMapper::archiveLocationToArchiveLocationDTO)
            .collect(Collectors.toList());
    }
}
