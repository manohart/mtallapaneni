package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.AutoNotificationService;
import com.jpmorgan.am.grt.domain.AutoNotification;
import com.jpmorgan.am.grt.repository.AutoNotificationRepository;
import com.jpmorgan.am.grt.repository.search.AutoNotificationSearchRepository;
import com.jpmorgan.am.grt.service.dto.AutoNotificationDTO;
import com.jpmorgan.am.grt.service.mapper.AutoNotificationMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing AutoNotification.
 */
@Service
@Transactional
public class AutoNotificationServiceImpl implements AutoNotificationService{

    private final Logger log = LoggerFactory.getLogger(AutoNotificationServiceImpl.class);
    
    @Inject
    private AutoNotificationRepository autoNotificationRepository;

    @Inject
    private AutoNotificationMapper autoNotificationMapper;

    @Inject
    private AutoNotificationSearchRepository autoNotificationSearchRepository;

    /**
     * Save a autoNotification.
     *
     * @param autoNotificationDTO the entity to save
     * @return the persisted entity
     */
    public AutoNotificationDTO save(AutoNotificationDTO autoNotificationDTO) {
        log.debug("Request to save AutoNotification : {}", autoNotificationDTO);
        AutoNotification autoNotification = autoNotificationMapper.autoNotificationDTOToAutoNotification(autoNotificationDTO);
        autoNotification = autoNotificationRepository.save(autoNotification);
        AutoNotificationDTO result = autoNotificationMapper.autoNotificationToAutoNotificationDTO(autoNotification);
        autoNotificationSearchRepository.save(autoNotification);
        return result;
    }

    /**
     *  Get all the autoNotifications.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<AutoNotificationDTO> findAll() {
        log.debug("Request to get all AutoNotifications");
        List<AutoNotificationDTO> result = autoNotificationRepository.findAll().stream()
            .map(autoNotificationMapper::autoNotificationToAutoNotificationDTO)
            .collect(Collectors.toCollection(LinkedList::new));

        return result;
    }

    /**
     *  Get one autoNotification by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public AutoNotificationDTO findOne(Long id) {
        log.debug("Request to get AutoNotification : {}", id);
        AutoNotification autoNotification = autoNotificationRepository.findOne(id);
        AutoNotificationDTO autoNotificationDTO = autoNotificationMapper.autoNotificationToAutoNotificationDTO(autoNotification);
        return autoNotificationDTO;
    }

    /**
     *  Delete the  autoNotification by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete AutoNotification : {}", id);
        autoNotificationRepository.delete(id);
        autoNotificationSearchRepository.delete(id);
    }

    /**
     * Search for the autoNotification corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<AutoNotificationDTO> search(String query) {
        log.debug("Request to search AutoNotifications for query {}", query);
        return StreamSupport
            .stream(autoNotificationSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .map(autoNotificationMapper::autoNotificationToAutoNotificationDTO)
            .collect(Collectors.toList());
    }
}
