package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.BatchReportService;
import com.jpmorgan.am.grt.domain.BatchReport;
import com.jpmorgan.am.grt.repository.BatchReportRepository;
import com.jpmorgan.am.grt.repository.search.BatchReportSearchRepository;
import com.jpmorgan.am.grt.service.dto.BatchReportDTO;
import com.jpmorgan.am.grt.service.mapper.BatchReportMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing BatchReport.
 */
@Service
@Transactional
public class BatchReportServiceImpl implements BatchReportService{

    private final Logger log = LoggerFactory.getLogger(BatchReportServiceImpl.class);
    
    @Inject
    private BatchReportRepository batchReportRepository;

    @Inject
    private BatchReportMapper batchReportMapper;

    @Inject
    private BatchReportSearchRepository batchReportSearchRepository;

    /**
     * Save a batchReport.
     *
     * @param batchReportDTO the entity to save
     * @return the persisted entity
     */
    public BatchReportDTO save(BatchReportDTO batchReportDTO) {
        log.debug("Request to save BatchReport : {}", batchReportDTO);
        BatchReport batchReport = batchReportMapper.batchReportDTOToBatchReport(batchReportDTO);
        batchReport = batchReportRepository.save(batchReport);
        BatchReportDTO result = batchReportMapper.batchReportToBatchReportDTO(batchReport);
        batchReportSearchRepository.save(batchReport);
        return result;
    }

    /**
     *  Get all the batchReports.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<BatchReportDTO> findAll() {
        log.debug("Request to get all BatchReports");
        List<BatchReportDTO> result = batchReportRepository.findAll().stream()
            .map(batchReportMapper::batchReportToBatchReportDTO)
            .collect(Collectors.toCollection(LinkedList::new));

        return result;
    }

    /**
     *  Get one batchReport by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public BatchReportDTO findOne(Long id) {
        log.debug("Request to get BatchReport : {}", id);
        BatchReport batchReport = batchReportRepository.findOne(id);
        BatchReportDTO batchReportDTO = batchReportMapper.batchReportToBatchReportDTO(batchReport);
        return batchReportDTO;
    }

    /**
     *  Delete the  batchReport by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete BatchReport : {}", id);
        batchReportRepository.delete(id);
        batchReportSearchRepository.delete(id);
    }

    /**
     * Search for the batchReport corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<BatchReportDTO> search(String query) {
        log.debug("Request to search BatchReports for query {}", query);
        return StreamSupport
            .stream(batchReportSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .map(batchReportMapper::batchReportToBatchReportDTO)
            .collect(Collectors.toList());
    }
}
