package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.DbCheckService;
import com.jpmorgan.am.grt.domain.DbCheck;
import com.jpmorgan.am.grt.repository.DbCheckRepository;
import com.jpmorgan.am.grt.repository.search.DbCheckSearchRepository;
import com.jpmorgan.am.grt.service.dto.DbCheckDTO;
import com.jpmorgan.am.grt.service.mapper.DbCheckMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing DbCheck.
 */
@Service
@Transactional
public class DbCheckServiceImpl implements DbCheckService{

    private final Logger log = LoggerFactory.getLogger(DbCheckServiceImpl.class);
    
    @Inject
    private DbCheckRepository dbCheckRepository;

    @Inject
    private DbCheckMapper dbCheckMapper;

    @Inject
    private DbCheckSearchRepository dbCheckSearchRepository;

    /**
     * Save a dbCheck.
     *
     * @param dbCheckDTO the entity to save
     * @return the persisted entity
     */
    public DbCheckDTO save(DbCheckDTO dbCheckDTO) {
        log.debug("Request to save DbCheck : {}", dbCheckDTO);
        DbCheck dbCheck = dbCheckMapper.dbCheckDTOToDbCheck(dbCheckDTO);
        dbCheck = dbCheckRepository.save(dbCheck);
        DbCheckDTO result = dbCheckMapper.dbCheckToDbCheckDTO(dbCheck);
        dbCheckSearchRepository.save(dbCheck);
        return result;
    }

    /**
     *  Get all the dbChecks.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<DbCheckDTO> findAll() {
        log.debug("Request to get all DbChecks");
        List<DbCheckDTO> result = dbCheckRepository.findAll().stream()
            .map(dbCheckMapper::dbCheckToDbCheckDTO)
            .collect(Collectors.toCollection(LinkedList::new));

        return result;
    }

    /**
     *  Get one dbCheck by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public DbCheckDTO findOne(Long id) {
        log.debug("Request to get DbCheck : {}", id);
        DbCheck dbCheck = dbCheckRepository.findOne(id);
        DbCheckDTO dbCheckDTO = dbCheckMapper.dbCheckToDbCheckDTO(dbCheck);
        return dbCheckDTO;
    }

    /**
     *  Delete the  dbCheck by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete DbCheck : {}", id);
        dbCheckRepository.delete(id);
        dbCheckSearchRepository.delete(id);
    }

    /**
     * Search for the dbCheck corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<DbCheckDTO> search(String query) {
        log.debug("Request to search DbChecks for query {}", query);
        return StreamSupport
            .stream(dbCheckSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .map(dbCheckMapper::dbCheckToDbCheckDTO)
            .collect(Collectors.toList());
    }
}
