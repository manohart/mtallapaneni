package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.HealthCheckerService;
import com.jpmorgan.am.grt.domain.HealthChecker;
import com.jpmorgan.am.grt.repository.HealthCheckerRepository;
import com.jpmorgan.am.grt.repository.search.HealthCheckerSearchRepository;
import com.jpmorgan.am.grt.service.dto.HealthCheckerDTO;
import com.jpmorgan.am.grt.service.mapper.HealthCheckerMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing HealthChecker.
 */
@Service
@Transactional
public class HealthCheckerServiceImpl implements HealthCheckerService{

    private final Logger log = LoggerFactory.getLogger(HealthCheckerServiceImpl.class);
    
    @Inject
    private HealthCheckerRepository healthCheckerRepository;

    @Inject
    private HealthCheckerMapper healthCheckerMapper;

    @Inject
    private HealthCheckerSearchRepository healthCheckerSearchRepository;

    /**
     * Save a healthChecker.
     *
     * @param healthCheckerDTO the entity to save
     * @return the persisted entity
     */
    public HealthCheckerDTO save(HealthCheckerDTO healthCheckerDTO) {
        log.debug("Request to save HealthChecker : {}", healthCheckerDTO);
        HealthChecker healthChecker = healthCheckerMapper.healthCheckerDTOToHealthChecker(healthCheckerDTO);
        healthChecker = healthCheckerRepository.save(healthChecker);
        HealthCheckerDTO result = healthCheckerMapper.healthCheckerToHealthCheckerDTO(healthChecker);
        healthCheckerSearchRepository.save(healthChecker);
        return result;
    }

    /**
     *  Get all the healthCheckers.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<HealthCheckerDTO> findAll() {
        log.debug("Request to get all HealthCheckers");
        List<HealthCheckerDTO> result = healthCheckerRepository.findAll().stream()
            .map(healthCheckerMapper::healthCheckerToHealthCheckerDTO)
            .collect(Collectors.toCollection(LinkedList::new));

        return result;
    }

    /**
     *  Get one healthChecker by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public HealthCheckerDTO findOne(Long id) {
        log.debug("Request to get HealthChecker : {}", id);
        HealthChecker healthChecker = healthCheckerRepository.findOne(id);
        HealthCheckerDTO healthCheckerDTO = healthCheckerMapper.healthCheckerToHealthCheckerDTO(healthChecker);
        return healthCheckerDTO;
    }

    /**
     *  Delete the  healthChecker by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete HealthChecker : {}", id);
        healthCheckerRepository.delete(id);
        healthCheckerSearchRepository.delete(id);
    }

    /**
     * Search for the healthChecker corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<HealthCheckerDTO> search(String query) {
        log.debug("Request to search HealthCheckers for query {}", query);
        return StreamSupport
            .stream(healthCheckerSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .map(healthCheckerMapper::healthCheckerToHealthCheckerDTO)
            .collect(Collectors.toList());
    }
}
