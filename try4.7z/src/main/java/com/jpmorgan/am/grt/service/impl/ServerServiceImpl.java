package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.ServerService;
import com.jpmorgan.am.grt.domain.Server;
import com.jpmorgan.am.grt.repository.ServerRepository;
import com.jpmorgan.am.grt.repository.search.ServerSearchRepository;
import com.jpmorgan.am.grt.service.dto.ServerDTO;
import com.jpmorgan.am.grt.service.mapper.ServerMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing Server.
 */
@Service
@Transactional
public class ServerServiceImpl implements ServerService{

    private final Logger log = LoggerFactory.getLogger(ServerServiceImpl.class);
    
    @Inject
    private ServerRepository serverRepository;

    @Inject
    private ServerMapper serverMapper;

    @Inject
    private ServerSearchRepository serverSearchRepository;

    /**
     * Save a server.
     *
     * @param serverDTO the entity to save
     * @return the persisted entity
     */
    public ServerDTO save(ServerDTO serverDTO) {
        log.debug("Request to save Server : {}", serverDTO);
        Server server = serverMapper.serverDTOToServer(serverDTO);
        server = serverRepository.save(server);
        ServerDTO result = serverMapper.serverToServerDTO(server);
        serverSearchRepository.save(server);
        return result;
    }

    /**
     *  Get all the servers.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<ServerDTO> findAll() {
        log.debug("Request to get all Servers");
        List<ServerDTO> result = serverRepository.findAll().stream()
            .map(serverMapper::serverToServerDTO)
            .collect(Collectors.toCollection(LinkedList::new));

        return result;
    }

    /**
     *  Get one server by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public ServerDTO findOne(Long id) {
        log.debug("Request to get Server : {}", id);
        Server server = serverRepository.findOne(id);
        ServerDTO serverDTO = serverMapper.serverToServerDTO(server);
        return serverDTO;
    }

    /**
     *  Delete the  server by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete Server : {}", id);
        serverRepository.delete(id);
        serverSearchRepository.delete(id);
    }

    /**
     * Search for the server corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<ServerDTO> search(String query) {
        log.debug("Request to search Servers for query {}", query);
        return StreamSupport
            .stream(serverSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .map(serverMapper::serverToServerDTO)
            .collect(Collectors.toList());
    }
}
