package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.WebServiceConsumerService;
import com.jpmorgan.am.grt.domain.WebServiceConsumer;
import com.jpmorgan.am.grt.repository.WebServiceConsumerRepository;
import com.jpmorgan.am.grt.repository.search.WebServiceConsumerSearchRepository;
import com.jpmorgan.am.grt.service.dto.WebServiceConsumerDTO;
import com.jpmorgan.am.grt.service.mapper.WebServiceConsumerMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing WebServiceConsumer.
 */
@Service
@Transactional
public class WebServiceConsumerServiceImpl implements WebServiceConsumerService{

    private final Logger log = LoggerFactory.getLogger(WebServiceConsumerServiceImpl.class);
    
    @Inject
    private WebServiceConsumerRepository webServiceConsumerRepository;

    @Inject
    private WebServiceConsumerMapper webServiceConsumerMapper;

    @Inject
    private WebServiceConsumerSearchRepository webServiceConsumerSearchRepository;

    /**
     * Save a webServiceConsumer.
     *
     * @param webServiceConsumerDTO the entity to save
     * @return the persisted entity
     */
    public WebServiceConsumerDTO save(WebServiceConsumerDTO webServiceConsumerDTO) {
        log.debug("Request to save WebServiceConsumer : {}", webServiceConsumerDTO);
        WebServiceConsumer webServiceConsumer = webServiceConsumerMapper.webServiceConsumerDTOToWebServiceConsumer(webServiceConsumerDTO);
        webServiceConsumer = webServiceConsumerRepository.save(webServiceConsumer);
        WebServiceConsumerDTO result = webServiceConsumerMapper.webServiceConsumerToWebServiceConsumerDTO(webServiceConsumer);
        webServiceConsumerSearchRepository.save(webServiceConsumer);
        return result;
    }

    /**
     *  Get all the webServiceConsumers.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<WebServiceConsumerDTO> findAll() {
        log.debug("Request to get all WebServiceConsumers");
        List<WebServiceConsumerDTO> result = webServiceConsumerRepository.findAll().stream()
            .map(webServiceConsumerMapper::webServiceConsumerToWebServiceConsumerDTO)
            .collect(Collectors.toCollection(LinkedList::new));

        return result;
    }

    /**
     *  Get one webServiceConsumer by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public WebServiceConsumerDTO findOne(Long id) {
        log.debug("Request to get WebServiceConsumer : {}", id);
        WebServiceConsumer webServiceConsumer = webServiceConsumerRepository.findOne(id);
        WebServiceConsumerDTO webServiceConsumerDTO = webServiceConsumerMapper.webServiceConsumerToWebServiceConsumerDTO(webServiceConsumer);
        return webServiceConsumerDTO;
    }

    /**
     *  Delete the  webServiceConsumer by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete WebServiceConsumer : {}", id);
        webServiceConsumerRepository.delete(id);
        webServiceConsumerSearchRepository.delete(id);
    }

    /**
     * Search for the webServiceConsumer corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<WebServiceConsumerDTO> search(String query) {
        log.debug("Request to search WebServiceConsumers for query {}", query);
        return StreamSupport
            .stream(webServiceConsumerSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .map(webServiceConsumerMapper::webServiceConsumerToWebServiceConsumerDTO)
            .collect(Collectors.toList());
    }
}
