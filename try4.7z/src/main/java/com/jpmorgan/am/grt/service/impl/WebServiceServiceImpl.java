package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.WebServiceService;
import com.jpmorgan.am.grt.domain.WebService;
import com.jpmorgan.am.grt.repository.WebServiceRepository;
import com.jpmorgan.am.grt.repository.search.WebServiceSearchRepository;
import com.jpmorgan.am.grt.service.dto.WebServiceDTO;
import com.jpmorgan.am.grt.service.mapper.WebServiceMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing WebService.
 */
@Service
@Transactional
public class WebServiceServiceImpl implements WebServiceService{

    private final Logger log = LoggerFactory.getLogger(WebServiceServiceImpl.class);
    
    @Inject
    private WebServiceRepository webServiceRepository;

    @Inject
    private WebServiceMapper webServiceMapper;

    @Inject
    private WebServiceSearchRepository webServiceSearchRepository;

    /**
     * Save a webService.
     *
     * @param webServiceDTO the entity to save
     * @return the persisted entity
     */
    public WebServiceDTO save(WebServiceDTO webServiceDTO) {
        log.debug("Request to save WebService : {}", webServiceDTO);
        WebService webService = webServiceMapper.webServiceDTOToWebService(webServiceDTO);
        webService = webServiceRepository.save(webService);
        WebServiceDTO result = webServiceMapper.webServiceToWebServiceDTO(webService);
        webServiceSearchRepository.save(webService);
        return result;
    }

    /**
     *  Get all the webServices.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<WebServiceDTO> findAll() {
        log.debug("Request to get all WebServices");
        List<WebServiceDTO> result = webServiceRepository.findAll().stream()
            .map(webServiceMapper::webServiceToWebServiceDTO)
            .collect(Collectors.toCollection(LinkedList::new));

        return result;
    }

    /**
     *  Get one webService by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public WebServiceDTO findOne(Long id) {
        log.debug("Request to get WebService : {}", id);
        WebService webService = webServiceRepository.findOne(id);
        WebServiceDTO webServiceDTO = webServiceMapper.webServiceToWebServiceDTO(webService);
        return webServiceDTO;
    }

    /**
     *  Delete the  webService by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete WebService : {}", id);
        webServiceRepository.delete(id);
        webServiceSearchRepository.delete(id);
    }

    /**
     * Search for the webService corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<WebServiceDTO> search(String query) {
        log.debug("Request to search WebServices for query {}", query);
        return StreamSupport
            .stream(webServiceSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .map(webServiceMapper::webServiceToWebServiceDTO)
            .collect(Collectors.toList());
    }
}
