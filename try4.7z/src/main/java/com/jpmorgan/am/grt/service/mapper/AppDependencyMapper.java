package com.jpmorgan.am.grt.service.mapper;

import com.jpmorgan.am.grt.domain.*;
import com.jpmorgan.am.grt.service.dto.AppDependencyDTO;

import org.mapstruct.*;
import java.util.List;

/**
 * Mapper for the entity AppDependency and its DTO AppDependencyDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface AppDependencyMapper {

    @Mapping(source = "application.id", target = "applicationId")
    @Mapping(source = "application.name", target = "applicationName")
    @Mapping(source = "dependOn.id", target = "dependOnId")
    @Mapping(source = "dependOn.name", target = "dependOnName")
    AppDependencyDTO appDependencyToAppDependencyDTO(AppDependency appDependency);

    List<AppDependencyDTO> appDependenciesToAppDependencyDTOs(List<AppDependency> appDependencies);

    @Mapping(source = "applicationId", target = "application")
    @Mapping(source = "dependOnId", target = "dependOn")
    AppDependency appDependencyDTOToAppDependency(AppDependencyDTO appDependencyDTO);

    List<AppDependency> appDependencyDTOsToAppDependencies(List<AppDependencyDTO> appDependencyDTOs);

    default Application applicationFromId(Long id) {
        if (id == null) {
            return null;
        }
        Application application = new Application();
        application.setId(id);
        return application;
    }
}
