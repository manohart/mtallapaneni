package com.jpmorgan.am.grt.service.mapper;

import com.jpmorgan.am.grt.domain.*;
import com.jpmorgan.am.grt.service.dto.ArchiveLocationDTO;

import org.mapstruct.*;
import java.util.List;

/**
 * Mapper for the entity ArchiveLocation and its DTO ArchiveLocationDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface ArchiveLocationMapper {

    @Mapping(source = "lob.id", target = "lobId")
    @Mapping(source = "lob.name", target = "lobName")
    ArchiveLocationDTO archiveLocationToArchiveLocationDTO(ArchiveLocation archiveLocation);

    List<ArchiveLocationDTO> archiveLocationsToArchiveLocationDTOs(List<ArchiveLocation> archiveLocations);

    @Mapping(source = "lobId", target = "lob")
    ArchiveLocation archiveLocationDTOToArchiveLocation(ArchiveLocationDTO archiveLocationDTO);

    List<ArchiveLocation> archiveLocationDTOsToArchiveLocations(List<ArchiveLocationDTO> archiveLocationDTOs);

    default Lob lobFromId(Long id) {
        if (id == null) {
            return null;
        }
        Lob lob = new Lob();
        lob.setId(id);
        return lob;
    }
}
