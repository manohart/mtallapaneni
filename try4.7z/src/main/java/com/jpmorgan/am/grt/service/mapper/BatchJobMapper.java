package com.jpmorgan.am.grt.service.mapper;

import com.jpmorgan.am.grt.domain.*;
import com.jpmorgan.am.grt.service.dto.BatchJobDTO;

import org.mapstruct.*;
import java.util.List;

/**
 * Mapper for the entity BatchJob and its DTO BatchJobDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface BatchJobMapper {

    @Mapping(source = "application.id", target = "applicationId")
    @Mapping(source = "application.name", target = "applicationName")
    BatchJobDTO batchJobToBatchJobDTO(BatchJob batchJob);

    List<BatchJobDTO> batchJobsToBatchJobDTOs(List<BatchJob> batchJobs);

    @Mapping(target = "reports", ignore = true)
    @Mapping(target = "distributions", ignore = true)
    @Mapping(source = "applicationId", target = "application")
    BatchJob batchJobDTOToBatchJob(BatchJobDTO batchJobDTO);

    List<BatchJob> batchJobDTOsToBatchJobs(List<BatchJobDTO> batchJobDTOs);

    default Application applicationFromId(Long id) {
        if (id == null) {
            return null;
        }
        Application application = new Application();
        application.setId(id);
        return application;
    }
}
