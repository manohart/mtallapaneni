package com.jpmorgan.am.grt.service.mapper;

import com.jpmorgan.am.grt.domain.*;
import com.jpmorgan.am.grt.service.dto.BatchReportDTO;

import org.mapstruct.*;
import java.util.List;

/**
 * Mapper for the entity BatchReport and its DTO BatchReportDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface BatchReportMapper {

    @Mapping(source = "batchJob.id", target = "batchJobId")
    BatchReportDTO batchReportToBatchReportDTO(BatchReport batchReport);

    List<BatchReportDTO> batchReportsToBatchReportDTOs(List<BatchReport> batchReports);

    @Mapping(target = "dbChecks", ignore = true)
    @Mapping(target = "generatedReports", ignore = true)
    @Mapping(source = "batchJobId", target = "batchJob")
    BatchReport batchReportDTOToBatchReport(BatchReportDTO batchReportDTO);

    List<BatchReport> batchReportDTOsToBatchReports(List<BatchReportDTO> batchReportDTOs);

    default BatchJob batchJobFromId(Long id) {
        if (id == null) {
            return null;
        }
        BatchJob batchJob = new BatchJob();
        batchJob.setId(id);
        return batchJob;
    }
}
