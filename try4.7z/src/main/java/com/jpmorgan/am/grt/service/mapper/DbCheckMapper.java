package com.jpmorgan.am.grt.service.mapper;

import com.jpmorgan.am.grt.domain.*;
import com.jpmorgan.am.grt.service.dto.DbCheckDTO;

import org.mapstruct.*;
import java.util.List;

/**
 * Mapper for the entity DbCheck and its DTO DbCheckDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface DbCheckMapper {

    @Mapping(source = "executorService.id", target = "executorServiceId")
    @Mapping(source = "executorService.name", target = "executorServiceName")
    @Mapping(source = "healthChecker.id", target = "healthCheckerId")
    @Mapping(source = "healthChecker.name", target = "healthCheckerName")
    @Mapping(source = "batchReport.id", target = "batchReportId")
    @Mapping(source = "batchReport.name", target = "batchReportName")
    DbCheckDTO dbCheckToDbCheckDTO(DbCheck dbCheck);

    List<DbCheckDTO> dbChecksToDbCheckDTOs(List<DbCheck> dbChecks);

    @Mapping(target = "healthCheckConfigs", ignore = true)
    @Mapping(source = "executorServiceId", target = "executorService")
    @Mapping(source = "healthCheckerId", target = "healthChecker")
    @Mapping(source = "batchReportId", target = "batchReport")
    DbCheck dbCheckDTOToDbCheck(DbCheckDTO dbCheckDTO);

    List<DbCheck> dbCheckDTOsToDbChecks(List<DbCheckDTO> dbCheckDTOs);

    default WebService webServiceFromId(Long id) {
        if (id == null) {
            return null;
        }
        WebService webService = new WebService();
        webService.setId(id);
        return webService;
    }

    default HealthChecker healthCheckerFromId(Long id) {
        if (id == null) {
            return null;
        }
        HealthChecker healthChecker = new HealthChecker();
        healthChecker.setId(id);
        return healthChecker;
    }

    default BatchReport batchReportFromId(Long id) {
        if (id == null) {
            return null;
        }
        BatchReport batchReport = new BatchReport();
        batchReport.setId(id);
        return batchReport;
    }
}
