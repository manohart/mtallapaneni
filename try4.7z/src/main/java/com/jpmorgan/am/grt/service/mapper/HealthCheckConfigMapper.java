package com.jpmorgan.am.grt.service.mapper;

import com.jpmorgan.am.grt.domain.*;
import com.jpmorgan.am.grt.service.dto.HealthCheckConfigDTO;

import org.mapstruct.*;
import java.util.List;

/**
 * Mapper for the entity HealthCheckConfig and its DTO HealthCheckConfigDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface HealthCheckConfigMapper {

    @Mapping(source = "dbCheck.id", target = "dbCheckId")
    @Mapping(source = "dbCheck.name", target = "dbCheckName")
    HealthCheckConfigDTO healthCheckConfigToHealthCheckConfigDTO(HealthCheckConfig healthCheckConfig);

    List<HealthCheckConfigDTO> healthCheckConfigsToHealthCheckConfigDTOs(List<HealthCheckConfig> healthCheckConfigs);

    @Mapping(source = "dbCheckId", target = "dbCheck")
    HealthCheckConfig healthCheckConfigDTOToHealthCheckConfig(HealthCheckConfigDTO healthCheckConfigDTO);

    List<HealthCheckConfig> healthCheckConfigDTOsToHealthCheckConfigs(List<HealthCheckConfigDTO> healthCheckConfigDTOs);

    default DbCheck dbCheckFromId(Long id) {
        if (id == null) {
            return null;
        }
        DbCheck dbCheck = new DbCheck();
        dbCheck.setId(id);
        return dbCheck;
    }
}
