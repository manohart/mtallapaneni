package com.jpmorgan.am.grt.service.mapper;

import com.jpmorgan.am.grt.domain.*;
import com.jpmorgan.am.grt.service.dto.LobDTO;

import org.mapstruct.*;
import java.util.List;

/**
 * Mapper for the entity Lob and its DTO LobDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface LobMapper {

    @Mapping(source = "superLob.id", target = "superLobId")
    @Mapping(source = "superLob.name", target = "superLobName")
    LobDTO lobToLobDTO(Lob lob);

    List<LobDTO> lobsToLobDTOs(List<Lob> lobs);

    @Mapping(target = "subLobs", ignore = true)
    @Mapping(target = "applications", ignore = true)
    @Mapping(target = "archives", ignore = true)
    @Mapping(target = "notificationRules", ignore = true)
    @Mapping(target = "releaseNotes", ignore = true)
    @Mapping(target = "devOps", ignore = true)
    @Mapping(target = "templates", ignore = true)
    @Mapping(target = "teams", ignore = true)
    @Mapping(source = "superLobId", target = "superLob")
    Lob lobDTOToLob(LobDTO lobDTO);

    List<Lob> lobDTOsToLobs(List<LobDTO> lobDTOs);

    default Lob lobFromId(Long id) {
        if (id == null) {
            return null;
        }
        Lob lob = new Lob();
        lob.setId(id);
        return lob;
    }
}
