package com.jpmorgan.am.grt.service.mapper;

import com.jpmorgan.am.grt.domain.*;
import com.jpmorgan.am.grt.service.dto.ReleaseNoteHistoryDTO;

import org.mapstruct.*;
import java.util.List;

/**
 * Mapper for the entity ReleaseNoteHistory and its DTO ReleaseNoteHistoryDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface ReleaseNoteHistoryMapper {

    @Mapping(source = "lob.id", target = "lobId")
    @Mapping(source = "template.id", target = "templateId")
    @Mapping(source = "template.name", target = "templateName")
    ReleaseNoteHistoryDTO releaseNoteHistoryToReleaseNoteHistoryDTO(ReleaseNoteHistory releaseNoteHistory);

    List<ReleaseNoteHistoryDTO> releaseNoteHistoriesToReleaseNoteHistoryDTOs(List<ReleaseNoteHistory> releaseNoteHistories);

    @Mapping(source = "lobId", target = "lob")
    @Mapping(source = "templateId", target = "template")
    ReleaseNoteHistory releaseNoteHistoryDTOToReleaseNoteHistory(ReleaseNoteHistoryDTO releaseNoteHistoryDTO);

    List<ReleaseNoteHistory> releaseNoteHistoryDTOsToReleaseNoteHistories(List<ReleaseNoteHistoryDTO> releaseNoteHistoryDTOs);

    default Lob lobFromId(Long id) {
        if (id == null) {
            return null;
        }
        Lob lob = new Lob();
        lob.setId(id);
        return lob;
    }

    default Template templateFromId(Long id) {
        if (id == null) {
            return null;
        }
        Template template = new Template();
        template.setId(id);
        return template;
    }
}
