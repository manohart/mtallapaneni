package com.jpmorgan.am.grt.service.mapper;

import com.jpmorgan.am.grt.domain.*;
import com.jpmorgan.am.grt.service.dto.TemplateDTO;

import org.mapstruct.*;
import java.util.List;

/**
 * Mapper for the entity Template and its DTO TemplateDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface TemplateMapper {

    @Mapping(source = "lob.id", target = "lobId")
    @Mapping(source = "lob.name", target = "lobName")
    TemplateDTO templateToTemplateDTO(Template template);

    List<TemplateDTO> templatesToTemplateDTOs(List<Template> templates);

    @Mapping(source = "lobId", target = "lob")
    Template templateDTOToTemplate(TemplateDTO templateDTO);

    List<Template> templateDTOsToTemplates(List<TemplateDTO> templateDTOs);

    default Lob lobFromId(Long id) {
        if (id == null) {
            return null;
        }
        Lob lob = new Lob();
        lob.setId(id);
        return lob;
    }
}
