package com.jpmorgan.am.grt.service.mapper;

import com.jpmorgan.am.grt.domain.*;
import com.jpmorgan.am.grt.service.dto.WebAppDTO;

import org.mapstruct.*;
import java.util.List;

/**
 * Mapper for the entity WebApp and its DTO WebAppDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface WebAppMapper {

    @Mapping(source = "application.id", target = "applicationId")
    @Mapping(source = "application.name", target = "applicationName")
    WebAppDTO webAppToWebAppDTO(WebApp webApp);

    List<WebAppDTO> webAppsToWebAppDTOs(List<WebApp> webApps);

    @Mapping(target = "services", ignore = true)
    @Mapping(source = "applicationId", target = "application")
    WebApp webAppDTOToWebApp(WebAppDTO webAppDTO);

    List<WebApp> webAppDTOsToWebApps(List<WebAppDTO> webAppDTOs);

    default Application applicationFromId(Long id) {
        if (id == null) {
            return null;
        }
        Application application = new Application();
        application.setId(id);
        return application;
    }
}
