package com.jpmorgan.am.grt.service.mapper;

import com.jpmorgan.am.grt.domain.*;
import com.jpmorgan.am.grt.service.dto.WebServiceConsumerDTO;

import org.mapstruct.*;
import java.util.List;

/**
 * Mapper for the entity WebServiceConsumer and its DTO WebServiceConsumerDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface WebServiceConsumerMapper {

    @Mapping(source = "consumer.id", target = "consumerId")
    @Mapping(source = "consumer.name", target = "consumerName")
    @Mapping(source = "prodcuer.id", target = "prodcuerId")
    @Mapping(source = "prodcuer.name", target = "prodcuerName")
    WebServiceConsumerDTO webServiceConsumerToWebServiceConsumerDTO(WebServiceConsumer webServiceConsumer);

    List<WebServiceConsumerDTO> webServiceConsumersToWebServiceConsumerDTOs(List<WebServiceConsumer> webServiceConsumers);

    @Mapping(source = "consumerId", target = "consumer")
    @Mapping(source = "prodcuerId", target = "prodcuer")
    WebServiceConsumer webServiceConsumerDTOToWebServiceConsumer(WebServiceConsumerDTO webServiceConsumerDTO);

    List<WebServiceConsumer> webServiceConsumerDTOsToWebServiceConsumers(List<WebServiceConsumerDTO> webServiceConsumerDTOs);

    default Application applicationFromId(Long id) {
        if (id == null) {
            return null;
        }
        Application application = new Application();
        application.setId(id);
        return application;
    }

    default WebService webServiceFromId(Long id) {
        if (id == null) {
            return null;
        }
        WebService webService = new WebService();
        webService.setId(id);
        return webService;
    }
}
