package com.jpmorgan.am.grt.service.mapper;

import com.jpmorgan.am.grt.domain.*;
import com.jpmorgan.am.grt.service.dto.WebServiceDTO;

import org.mapstruct.*;
import java.util.List;

/**
 * Mapper for the entity WebService and its DTO WebServiceDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface WebServiceMapper {

    @Mapping(source = "application.id", target = "applicationId")
    WebServiceDTO webServiceToWebServiceDTO(WebService webService);

    List<WebServiceDTO> webServicesToWebServiceDTOs(List<WebService> webServices);

    @Mapping(target = "consumers", ignore = true)
    @Mapping(source = "applicationId", target = "application")
    WebService webServiceDTOToWebService(WebServiceDTO webServiceDTO);

    List<WebService> webServiceDTOsToWebServices(List<WebServiceDTO> webServiceDTOs);

    default WebApp webAppFromId(Long id) {
        if (id == null) {
            return null;
        }
        WebApp webApp = new WebApp();
        webApp.setId(id);
        return webApp;
    }
}
