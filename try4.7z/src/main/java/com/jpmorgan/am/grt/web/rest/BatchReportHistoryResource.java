package com.jpmorgan.am.grt.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.jpmorgan.am.grt.service.BatchReportHistoryService;
import com.jpmorgan.am.grt.web.rest.util.HeaderUtil;
import com.jpmorgan.am.grt.service.dto.BatchReportHistoryDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * REST controller for managing BatchReportHistory.
 */
@RestController
@RequestMapping("/api")
public class BatchReportHistoryResource {

    private final Logger log = LoggerFactory.getLogger(BatchReportHistoryResource.class);
        
    @Inject
    private BatchReportHistoryService batchReportHistoryService;

    /**
     * POST  /batch-report-histories : Create a new batchReportHistory.
     *
     * @param batchReportHistoryDTO the batchReportHistoryDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new batchReportHistoryDTO, or with status 400 (Bad Request) if the batchReportHistory has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/batch-report-histories",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<BatchReportHistoryDTO> createBatchReportHistory(@Valid @RequestBody BatchReportHistoryDTO batchReportHistoryDTO) throws URISyntaxException {
        log.debug("REST request to save BatchReportHistory : {}", batchReportHistoryDTO);
        if (batchReportHistoryDTO.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("batchReportHistory", "idexists", "A new batchReportHistory cannot already have an ID")).body(null);
        }
        BatchReportHistoryDTO result = batchReportHistoryService.save(batchReportHistoryDTO);
        return ResponseEntity.created(new URI("/api/batch-report-histories/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("batchReportHistory", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /batch-report-histories : Updates an existing batchReportHistory.
     *
     * @param batchReportHistoryDTO the batchReportHistoryDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated batchReportHistoryDTO,
     * or with status 400 (Bad Request) if the batchReportHistoryDTO is not valid,
     * or with status 500 (Internal Server Error) if the batchReportHistoryDTO couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/batch-report-histories",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<BatchReportHistoryDTO> updateBatchReportHistory(@Valid @RequestBody BatchReportHistoryDTO batchReportHistoryDTO) throws URISyntaxException {
        log.debug("REST request to update BatchReportHistory : {}", batchReportHistoryDTO);
        if (batchReportHistoryDTO.getId() == null) {
            return createBatchReportHistory(batchReportHistoryDTO);
        }
        BatchReportHistoryDTO result = batchReportHistoryService.save(batchReportHistoryDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("batchReportHistory", batchReportHistoryDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /batch-report-histories : get all the batchReportHistories.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of batchReportHistories in body
     */
    @RequestMapping(value = "/batch-report-histories",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<BatchReportHistoryDTO> getAllBatchReportHistories() {
        log.debug("REST request to get all BatchReportHistories");
        return batchReportHistoryService.findAll();
    }

    /**
     * GET  /batch-report-histories/:id : get the "id" batchReportHistory.
     *
     * @param id the id of the batchReportHistoryDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the batchReportHistoryDTO, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/batch-report-histories/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<BatchReportHistoryDTO> getBatchReportHistory(@PathVariable Long id) {
        log.debug("REST request to get BatchReportHistory : {}", id);
        BatchReportHistoryDTO batchReportHistoryDTO = batchReportHistoryService.findOne(id);
        return Optional.ofNullable(batchReportHistoryDTO)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /batch-report-histories/:id : delete the "id" batchReportHistory.
     *
     * @param id the id of the batchReportHistoryDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/batch-report-histories/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteBatchReportHistory(@PathVariable Long id) {
        log.debug("REST request to delete BatchReportHistory : {}", id);
        batchReportHistoryService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("batchReportHistory", id.toString())).build();
    }

    /**
     * SEARCH  /_search/batch-report-histories?query=:query : search for the batchReportHistory corresponding
     * to the query.
     *
     * @param query the query of the batchReportHistory search 
     * @return the result of the search
     */
    @RequestMapping(value = "/_search/batch-report-histories",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<BatchReportHistoryDTO> searchBatchReportHistories(@RequestParam String query) {
        log.debug("REST request to search BatchReportHistories for query {}", query);
        return batchReportHistoryService.search(query);
    }


}
