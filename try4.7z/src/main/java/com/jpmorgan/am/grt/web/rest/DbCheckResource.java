package com.jpmorgan.am.grt.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.jpmorgan.am.grt.service.DbCheckService;
import com.jpmorgan.am.grt.web.rest.util.HeaderUtil;
import com.jpmorgan.am.grt.service.dto.DbCheckDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * REST controller for managing DbCheck.
 */
@RestController
@RequestMapping("/api")
public class DbCheckResource {

    private final Logger log = LoggerFactory.getLogger(DbCheckResource.class);
        
    @Inject
    private DbCheckService dbCheckService;

    /**
     * POST  /db-checks : Create a new dbCheck.
     *
     * @param dbCheckDTO the dbCheckDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new dbCheckDTO, or with status 400 (Bad Request) if the dbCheck has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/db-checks",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<DbCheckDTO> createDbCheck(@Valid @RequestBody DbCheckDTO dbCheckDTO) throws URISyntaxException {
        log.debug("REST request to save DbCheck : {}", dbCheckDTO);
        if (dbCheckDTO.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("dbCheck", "idexists", "A new dbCheck cannot already have an ID")).body(null);
        }
        DbCheckDTO result = dbCheckService.save(dbCheckDTO);
        return ResponseEntity.created(new URI("/api/db-checks/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("dbCheck", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /db-checks : Updates an existing dbCheck.
     *
     * @param dbCheckDTO the dbCheckDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated dbCheckDTO,
     * or with status 400 (Bad Request) if the dbCheckDTO is not valid,
     * or with status 500 (Internal Server Error) if the dbCheckDTO couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/db-checks",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<DbCheckDTO> updateDbCheck(@Valid @RequestBody DbCheckDTO dbCheckDTO) throws URISyntaxException {
        log.debug("REST request to update DbCheck : {}", dbCheckDTO);
        if (dbCheckDTO.getId() == null) {
            return createDbCheck(dbCheckDTO);
        }
        DbCheckDTO result = dbCheckService.save(dbCheckDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("dbCheck", dbCheckDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /db-checks : get all the dbChecks.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of dbChecks in body
     */
    @RequestMapping(value = "/db-checks",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<DbCheckDTO> getAllDbChecks() {
        log.debug("REST request to get all DbChecks");
        return dbCheckService.findAll();
    }

    /**
     * GET  /db-checks/:id : get the "id" dbCheck.
     *
     * @param id the id of the dbCheckDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the dbCheckDTO, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/db-checks/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<DbCheckDTO> getDbCheck(@PathVariable Long id) {
        log.debug("REST request to get DbCheck : {}", id);
        DbCheckDTO dbCheckDTO = dbCheckService.findOne(id);
        return Optional.ofNullable(dbCheckDTO)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /db-checks/:id : delete the "id" dbCheck.
     *
     * @param id the id of the dbCheckDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/db-checks/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteDbCheck(@PathVariable Long id) {
        log.debug("REST request to delete DbCheck : {}", id);
        dbCheckService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("dbCheck", id.toString())).build();
    }

    /**
     * SEARCH  /_search/db-checks?query=:query : search for the dbCheck corresponding
     * to the query.
     *
     * @param query the query of the dbCheck search 
     * @return the result of the search
     */
    @RequestMapping(value = "/_search/db-checks",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<DbCheckDTO> searchDbChecks(@RequestParam String query) {
        log.debug("REST request to search DbChecks for query {}", query);
        return dbCheckService.search(query);
    }


}
