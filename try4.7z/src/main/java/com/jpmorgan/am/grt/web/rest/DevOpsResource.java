package com.jpmorgan.am.grt.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.jpmorgan.am.grt.service.DevOpsService;
import com.jpmorgan.am.grt.web.rest.util.HeaderUtil;
import com.jpmorgan.am.grt.service.dto.DevOpsDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * REST controller for managing DevOps.
 */
@RestController
@RequestMapping("/api")
public class DevOpsResource {

    private final Logger log = LoggerFactory.getLogger(DevOpsResource.class);
        
    @Inject
    private DevOpsService devOpsService;

    /**
     * POST  /dev-ops : Create a new devOps.
     *
     * @param devOpsDTO the devOpsDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new devOpsDTO, or with status 400 (Bad Request) if the devOps has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/dev-ops",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<DevOpsDTO> createDevOps(@Valid @RequestBody DevOpsDTO devOpsDTO) throws URISyntaxException {
        log.debug("REST request to save DevOps : {}", devOpsDTO);
        if (devOpsDTO.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("devOps", "idexists", "A new devOps cannot already have an ID")).body(null);
        }
        DevOpsDTO result = devOpsService.save(devOpsDTO);
        return ResponseEntity.created(new URI("/api/dev-ops/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("devOps", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /dev-ops : Updates an existing devOps.
     *
     * @param devOpsDTO the devOpsDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated devOpsDTO,
     * or with status 400 (Bad Request) if the devOpsDTO is not valid,
     * or with status 500 (Internal Server Error) if the devOpsDTO couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/dev-ops",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<DevOpsDTO> updateDevOps(@Valid @RequestBody DevOpsDTO devOpsDTO) throws URISyntaxException {
        log.debug("REST request to update DevOps : {}", devOpsDTO);
        if (devOpsDTO.getId() == null) {
            return createDevOps(devOpsDTO);
        }
        DevOpsDTO result = devOpsService.save(devOpsDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("devOps", devOpsDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /dev-ops : get all the devOps.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of devOps in body
     */
    @RequestMapping(value = "/dev-ops",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<DevOpsDTO> getAllDevOps() {
        log.debug("REST request to get all DevOps");
        return devOpsService.findAll();
    }

    /**
     * GET  /dev-ops/:id : get the "id" devOps.
     *
     * @param id the id of the devOpsDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the devOpsDTO, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/dev-ops/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<DevOpsDTO> getDevOps(@PathVariable Long id) {
        log.debug("REST request to get DevOps : {}", id);
        DevOpsDTO devOpsDTO = devOpsService.findOne(id);
        return Optional.ofNullable(devOpsDTO)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /dev-ops/:id : delete the "id" devOps.
     *
     * @param id the id of the devOpsDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/dev-ops/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteDevOps(@PathVariable Long id) {
        log.debug("REST request to delete DevOps : {}", id);
        devOpsService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("devOps", id.toString())).build();
    }

    /**
     * SEARCH  /_search/dev-ops?query=:query : search for the devOps corresponding
     * to the query.
     *
     * @param query the query of the devOps search 
     * @return the result of the search
     */
    @RequestMapping(value = "/_search/dev-ops",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<DevOpsDTO> searchDevOps(@RequestParam String query) {
        log.debug("REST request to search DevOps for query {}", query);
        return devOpsService.search(query);
    }


}
