package com.jpmorgan.am.grt.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.jpmorgan.am.grt.service.DistributionService;
import com.jpmorgan.am.grt.web.rest.util.HeaderUtil;
import com.jpmorgan.am.grt.service.dto.DistributionDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * REST controller for managing Distribution.
 */
@RestController
@RequestMapping("/api")
public class DistributionResource {

    private final Logger log = LoggerFactory.getLogger(DistributionResource.class);
        
    @Inject
    private DistributionService distributionService;

    /**
     * POST  /distributions : Create a new distribution.
     *
     * @param distributionDTO the distributionDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new distributionDTO, or with status 400 (Bad Request) if the distribution has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/distributions",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<DistributionDTO> createDistribution(@Valid @RequestBody DistributionDTO distributionDTO) throws URISyntaxException {
        log.debug("REST request to save Distribution : {}", distributionDTO);
        if (distributionDTO.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("distribution", "idexists", "A new distribution cannot already have an ID")).body(null);
        }
        DistributionDTO result = distributionService.save(distributionDTO);
        return ResponseEntity.created(new URI("/api/distributions/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("distribution", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /distributions : Updates an existing distribution.
     *
     * @param distributionDTO the distributionDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated distributionDTO,
     * or with status 400 (Bad Request) if the distributionDTO is not valid,
     * or with status 500 (Internal Server Error) if the distributionDTO couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/distributions",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<DistributionDTO> updateDistribution(@Valid @RequestBody DistributionDTO distributionDTO) throws URISyntaxException {
        log.debug("REST request to update Distribution : {}", distributionDTO);
        if (distributionDTO.getId() == null) {
            return createDistribution(distributionDTO);
        }
        DistributionDTO result = distributionService.save(distributionDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("distribution", distributionDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /distributions : get all the distributions.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of distributions in body
     */
    @RequestMapping(value = "/distributions",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<DistributionDTO> getAllDistributions() {
        log.debug("REST request to get all Distributions");
        return distributionService.findAll();
    }

    /**
     * GET  /distributions/:id : get the "id" distribution.
     *
     * @param id the id of the distributionDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the distributionDTO, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/distributions/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<DistributionDTO> getDistribution(@PathVariable Long id) {
        log.debug("REST request to get Distribution : {}", id);
        DistributionDTO distributionDTO = distributionService.findOne(id);
        return Optional.ofNullable(distributionDTO)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /distributions/:id : delete the "id" distribution.
     *
     * @param id the id of the distributionDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/distributions/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteDistribution(@PathVariable Long id) {
        log.debug("REST request to delete Distribution : {}", id);
        distributionService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("distribution", id.toString())).build();
    }

    /**
     * SEARCH  /_search/distributions?query=:query : search for the distribution corresponding
     * to the query.
     *
     * @param query the query of the distribution search 
     * @return the result of the search
     */
    @RequestMapping(value = "/_search/distributions",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<DistributionDTO> searchDistributions(@RequestParam String query) {
        log.debug("REST request to search Distributions for query {}", query);
        return distributionService.search(query);
    }


}
