package com.jpmorgan.am.grt.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.jpmorgan.am.grt.service.NotificationRuleService;
import com.jpmorgan.am.grt.web.rest.util.HeaderUtil;
import com.jpmorgan.am.grt.service.dto.NotificationRuleDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * REST controller for managing NotificationRule.
 */
@RestController
@RequestMapping("/api")
public class NotificationRuleResource {

    private final Logger log = LoggerFactory.getLogger(NotificationRuleResource.class);
        
    @Inject
    private NotificationRuleService notificationRuleService;

    /**
     * POST  /notification-rules : Create a new notificationRule.
     *
     * @param notificationRuleDTO the notificationRuleDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new notificationRuleDTO, or with status 400 (Bad Request) if the notificationRule has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/notification-rules",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<NotificationRuleDTO> createNotificationRule(@Valid @RequestBody NotificationRuleDTO notificationRuleDTO) throws URISyntaxException {
        log.debug("REST request to save NotificationRule : {}", notificationRuleDTO);
        if (notificationRuleDTO.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("notificationRule", "idexists", "A new notificationRule cannot already have an ID")).body(null);
        }
        NotificationRuleDTO result = notificationRuleService.save(notificationRuleDTO);
        return ResponseEntity.created(new URI("/api/notification-rules/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("notificationRule", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /notification-rules : Updates an existing notificationRule.
     *
     * @param notificationRuleDTO the notificationRuleDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated notificationRuleDTO,
     * or with status 400 (Bad Request) if the notificationRuleDTO is not valid,
     * or with status 500 (Internal Server Error) if the notificationRuleDTO couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/notification-rules",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<NotificationRuleDTO> updateNotificationRule(@Valid @RequestBody NotificationRuleDTO notificationRuleDTO) throws URISyntaxException {
        log.debug("REST request to update NotificationRule : {}", notificationRuleDTO);
        if (notificationRuleDTO.getId() == null) {
            return createNotificationRule(notificationRuleDTO);
        }
        NotificationRuleDTO result = notificationRuleService.save(notificationRuleDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("notificationRule", notificationRuleDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /notification-rules : get all the notificationRules.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of notificationRules in body
     */
    @RequestMapping(value = "/notification-rules",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<NotificationRuleDTO> getAllNotificationRules() {
        log.debug("REST request to get all NotificationRules");
        return notificationRuleService.findAll();
    }

    /**
     * GET  /notification-rules/:id : get the "id" notificationRule.
     *
     * @param id the id of the notificationRuleDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the notificationRuleDTO, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/notification-rules/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<NotificationRuleDTO> getNotificationRule(@PathVariable Long id) {
        log.debug("REST request to get NotificationRule : {}", id);
        NotificationRuleDTO notificationRuleDTO = notificationRuleService.findOne(id);
        return Optional.ofNullable(notificationRuleDTO)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /notification-rules/:id : delete the "id" notificationRule.
     *
     * @param id the id of the notificationRuleDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/notification-rules/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteNotificationRule(@PathVariable Long id) {
        log.debug("REST request to delete NotificationRule : {}", id);
        notificationRuleService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("notificationRule", id.toString())).build();
    }

    /**
     * SEARCH  /_search/notification-rules?query=:query : search for the notificationRule corresponding
     * to the query.
     *
     * @param query the query of the notificationRule search 
     * @return the result of the search
     */
    @RequestMapping(value = "/_search/notification-rules",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<NotificationRuleDTO> searchNotificationRules(@RequestParam String query) {
        log.debug("REST request to search NotificationRules for query {}", query);
        return notificationRuleService.search(query);
    }


}
