package com.jpmorgan.am.grt.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.jpmorgan.am.grt.service.WebServiceService;
import com.jpmorgan.am.grt.web.rest.util.HeaderUtil;
import com.jpmorgan.am.grt.service.dto.WebServiceDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * REST controller for managing WebService.
 */
@RestController
@RequestMapping("/api")
public class WebServiceResource {

    private final Logger log = LoggerFactory.getLogger(WebServiceResource.class);
        
    @Inject
    private WebServiceService webServiceService;

    /**
     * POST  /web-services : Create a new webService.
     *
     * @param webServiceDTO the webServiceDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new webServiceDTO, or with status 400 (Bad Request) if the webService has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/web-services",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<WebServiceDTO> createWebService(@Valid @RequestBody WebServiceDTO webServiceDTO) throws URISyntaxException {
        log.debug("REST request to save WebService : {}", webServiceDTO);
        if (webServiceDTO.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("webService", "idexists", "A new webService cannot already have an ID")).body(null);
        }
        WebServiceDTO result = webServiceService.save(webServiceDTO);
        return ResponseEntity.created(new URI("/api/web-services/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("webService", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /web-services : Updates an existing webService.
     *
     * @param webServiceDTO the webServiceDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated webServiceDTO,
     * or with status 400 (Bad Request) if the webServiceDTO is not valid,
     * or with status 500 (Internal Server Error) if the webServiceDTO couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/web-services",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<WebServiceDTO> updateWebService(@Valid @RequestBody WebServiceDTO webServiceDTO) throws URISyntaxException {
        log.debug("REST request to update WebService : {}", webServiceDTO);
        if (webServiceDTO.getId() == null) {
            return createWebService(webServiceDTO);
        }
        WebServiceDTO result = webServiceService.save(webServiceDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("webService", webServiceDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /web-services : get all the webServices.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of webServices in body
     */
    @RequestMapping(value = "/web-services",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<WebServiceDTO> getAllWebServices() {
        log.debug("REST request to get all WebServices");
        return webServiceService.findAll();
    }

    /**
     * GET  /web-services/:id : get the "id" webService.
     *
     * @param id the id of the webServiceDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the webServiceDTO, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/web-services/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<WebServiceDTO> getWebService(@PathVariable Long id) {
        log.debug("REST request to get WebService : {}", id);
        WebServiceDTO webServiceDTO = webServiceService.findOne(id);
        return Optional.ofNullable(webServiceDTO)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /web-services/:id : delete the "id" webService.
     *
     * @param id the id of the webServiceDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/web-services/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteWebService(@PathVariable Long id) {
        log.debug("REST request to delete WebService : {}", id);
        webServiceService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("webService", id.toString())).build();
    }

    /**
     * SEARCH  /_search/web-services?query=:query : search for the webService corresponding
     * to the query.
     *
     * @param query the query of the webService search 
     * @return the result of the search
     */
    @RequestMapping(value = "/_search/web-services",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<WebServiceDTO> searchWebServices(@RequestParam String query) {
        log.debug("REST request to search WebServices for query {}", query);
        return webServiceService.search(query);
    }


}
