package com.jpmorgan.am.grt.web.rest;

import com.jpmorgan.am.grt.HealthCheckApp;

import com.jpmorgan.am.grt.domain.AutoNotification;
import com.jpmorgan.am.grt.repository.AutoNotificationRepository;
import com.jpmorgan.am.grt.service.AutoNotificationService;
import com.jpmorgan.am.grt.repository.search.AutoNotificationSearchRepository;
import com.jpmorgan.am.grt.service.dto.AutoNotificationDTO;
import com.jpmorgan.am.grt.service.mapper.AutoNotificationMapper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneId;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the AutoNotificationResource REST controller.
 *
 * @see AutoNotificationResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = HealthCheckApp.class)
public class AutoNotificationResourceIntTest {

    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(ZoneId.of("Z"));


    private static final Boolean DEFAULT_IS_ACTIVE = false;
    private static final Boolean UPDATED_IS_ACTIVE = true;

    private static final ZonedDateTime DEFAULT_UPDATED_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneId.systemDefault());
    private static final ZonedDateTime UPDATED_UPDATED_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);
    private static final String DEFAULT_UPDATED_DATE_STR = dateTimeFormatter.format(DEFAULT_UPDATED_DATE);

    @Inject
    private AutoNotificationRepository autoNotificationRepository;

    @Inject
    private AutoNotificationMapper autoNotificationMapper;

    @Inject
    private AutoNotificationService autoNotificationService;

    @Inject
    private AutoNotificationSearchRepository autoNotificationSearchRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restAutoNotificationMockMvc;

    private AutoNotification autoNotification;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        AutoNotificationResource autoNotificationResource = new AutoNotificationResource();
        ReflectionTestUtils.setField(autoNotificationResource, "autoNotificationService", autoNotificationService);
        this.restAutoNotificationMockMvc = MockMvcBuilders.standaloneSetup(autoNotificationResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static AutoNotification createEntity(EntityManager em) {
        AutoNotification autoNotification = new AutoNotification();
        autoNotification.setIsActive(DEFAULT_IS_ACTIVE);
        autoNotification.setUpdatedDate(DEFAULT_UPDATED_DATE);
        return autoNotification;
    }

    @Before
    public void initTest() {
        autoNotificationSearchRepository.deleteAll();
        autoNotification = createEntity(em);
    }

    @Test
    @Transactional
    public void createAutoNotification() throws Exception {
        int databaseSizeBeforeCreate = autoNotificationRepository.findAll().size();

        // Create the AutoNotification
        AutoNotificationDTO autoNotificationDTO = autoNotificationMapper.autoNotificationToAutoNotificationDTO(autoNotification);

        restAutoNotificationMockMvc.perform(post("/api/auto-notifications")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(autoNotificationDTO)))
                .andExpect(status().isCreated());

        // Validate the AutoNotification in the database
        List<AutoNotification> autoNotifications = autoNotificationRepository.findAll();
        assertThat(autoNotifications).hasSize(databaseSizeBeforeCreate + 1);
        AutoNotification testAutoNotification = autoNotifications.get(autoNotifications.size() - 1);
        assertThat(testAutoNotification.isIsActive()).isEqualTo(DEFAULT_IS_ACTIVE);
        assertThat(testAutoNotification.getUpdatedDate()).isEqualTo(DEFAULT_UPDATED_DATE);

        // Validate the AutoNotification in ElasticSearch
        AutoNotification autoNotificationEs = autoNotificationSearchRepository.findOne(testAutoNotification.getId());
        assertThat(autoNotificationEs).isEqualToComparingFieldByField(testAutoNotification);
    }

    @Test
    @Transactional
    public void checkIsActiveIsRequired() throws Exception {
        int databaseSizeBeforeTest = autoNotificationRepository.findAll().size();
        // set the field null
        autoNotification.setIsActive(null);

        // Create the AutoNotification, which fails.
        AutoNotificationDTO autoNotificationDTO = autoNotificationMapper.autoNotificationToAutoNotificationDTO(autoNotification);

        restAutoNotificationMockMvc.perform(post("/api/auto-notifications")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(autoNotificationDTO)))
                .andExpect(status().isBadRequest());

        List<AutoNotification> autoNotifications = autoNotificationRepository.findAll();
        assertThat(autoNotifications).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllAutoNotifications() throws Exception {
        // Initialize the database
        autoNotificationRepository.saveAndFlush(autoNotification);

        // Get all the autoNotifications
        restAutoNotificationMockMvc.perform(get("/api/auto-notifications?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andExpect(jsonPath("$.[*].id").value(hasItem(autoNotification.getId().intValue())))
                .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
                .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }

    @Test
    @Transactional
    public void getAutoNotification() throws Exception {
        // Initialize the database
        autoNotificationRepository.saveAndFlush(autoNotification);

        // Get the autoNotification
        restAutoNotificationMockMvc.perform(get("/api/auto-notifications/{id}", autoNotification.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(autoNotification.getId().intValue()))
            .andExpect(jsonPath("$.isActive").value(DEFAULT_IS_ACTIVE.booleanValue()))
            .andExpect(jsonPath("$.updatedDate").value(DEFAULT_UPDATED_DATE_STR));
    }

    @Test
    @Transactional
    public void getNonExistingAutoNotification() throws Exception {
        // Get the autoNotification
        restAutoNotificationMockMvc.perform(get("/api/auto-notifications/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateAutoNotification() throws Exception {
        // Initialize the database
        autoNotificationRepository.saveAndFlush(autoNotification);
        autoNotificationSearchRepository.save(autoNotification);
        int databaseSizeBeforeUpdate = autoNotificationRepository.findAll().size();

        // Update the autoNotification
        AutoNotification updatedAutoNotification = autoNotificationRepository.findOne(autoNotification.getId());
        updatedAutoNotification.setIsActive(UPDATED_IS_ACTIVE);
        updatedAutoNotification.setUpdatedDate(UPDATED_UPDATED_DATE);
        AutoNotificationDTO autoNotificationDTO = autoNotificationMapper.autoNotificationToAutoNotificationDTO(updatedAutoNotification);

        restAutoNotificationMockMvc.perform(put("/api/auto-notifications")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(autoNotificationDTO)))
                .andExpect(status().isOk());

        // Validate the AutoNotification in the database
        List<AutoNotification> autoNotifications = autoNotificationRepository.findAll();
        assertThat(autoNotifications).hasSize(databaseSizeBeforeUpdate);
        AutoNotification testAutoNotification = autoNotifications.get(autoNotifications.size() - 1);
        assertThat(testAutoNotification.isIsActive()).isEqualTo(UPDATED_IS_ACTIVE);
        assertThat(testAutoNotification.getUpdatedDate()).isEqualTo(UPDATED_UPDATED_DATE);

        // Validate the AutoNotification in ElasticSearch
        AutoNotification autoNotificationEs = autoNotificationSearchRepository.findOne(testAutoNotification.getId());
        assertThat(autoNotificationEs).isEqualToComparingFieldByField(testAutoNotification);
    }

    @Test
    @Transactional
    public void deleteAutoNotification() throws Exception {
        // Initialize the database
        autoNotificationRepository.saveAndFlush(autoNotification);
        autoNotificationSearchRepository.save(autoNotification);
        int databaseSizeBeforeDelete = autoNotificationRepository.findAll().size();

        // Get the autoNotification
        restAutoNotificationMockMvc.perform(delete("/api/auto-notifications/{id}", autoNotification.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate ElasticSearch is empty
        boolean autoNotificationExistsInEs = autoNotificationSearchRepository.exists(autoNotification.getId());
        assertThat(autoNotificationExistsInEs).isFalse();

        // Validate the database is empty
        List<AutoNotification> autoNotifications = autoNotificationRepository.findAll();
        assertThat(autoNotifications).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void searchAutoNotification() throws Exception {
        // Initialize the database
        autoNotificationRepository.saveAndFlush(autoNotification);
        autoNotificationSearchRepository.save(autoNotification);

        // Search the autoNotification
        restAutoNotificationMockMvc.perform(get("/api/_search/auto-notifications?query=id:" + autoNotification.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(autoNotification.getId().intValue())))
            .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
            .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }
}
