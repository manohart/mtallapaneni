package com.jpmorgan.am.grt.web.rest;

import com.jpmorgan.am.grt.HealthCheckApp;

import com.jpmorgan.am.grt.domain.HealthCheckConfig;
import com.jpmorgan.am.grt.repository.HealthCheckConfigRepository;
import com.jpmorgan.am.grt.service.HealthCheckConfigService;
import com.jpmorgan.am.grt.repository.search.HealthCheckConfigSearchRepository;
import com.jpmorgan.am.grt.service.dto.HealthCheckConfigDTO;
import com.jpmorgan.am.grt.service.mapper.HealthCheckConfigMapper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the HealthCheckConfigResource REST controller.
 *
 * @see HealthCheckConfigResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = HealthCheckApp.class)
public class HealthCheckConfigResourceIntTest {


    @Inject
    private HealthCheckConfigRepository healthCheckConfigRepository;

    @Inject
    private HealthCheckConfigMapper healthCheckConfigMapper;

    @Inject
    private HealthCheckConfigService healthCheckConfigService;

    @Inject
    private HealthCheckConfigSearchRepository healthCheckConfigSearchRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restHealthCheckConfigMockMvc;

    private HealthCheckConfig healthCheckConfig;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        HealthCheckConfigResource healthCheckConfigResource = new HealthCheckConfigResource();
        ReflectionTestUtils.setField(healthCheckConfigResource, "healthCheckConfigService", healthCheckConfigService);
        this.restHealthCheckConfigMockMvc = MockMvcBuilders.standaloneSetup(healthCheckConfigResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static HealthCheckConfig createEntity(EntityManager em) {
        HealthCheckConfig healthCheckConfig = new HealthCheckConfig();
        return healthCheckConfig;
    }

    @Before
    public void initTest() {
        healthCheckConfigSearchRepository.deleteAll();
        healthCheckConfig = createEntity(em);
    }

    @Test
    @Transactional
    public void createHealthCheckConfig() throws Exception {
        int databaseSizeBeforeCreate = healthCheckConfigRepository.findAll().size();

        // Create the HealthCheckConfig
        HealthCheckConfigDTO healthCheckConfigDTO = healthCheckConfigMapper.healthCheckConfigToHealthCheckConfigDTO(healthCheckConfig);

        restHealthCheckConfigMockMvc.perform(post("/api/health-check-configs")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(healthCheckConfigDTO)))
                .andExpect(status().isCreated());

        // Validate the HealthCheckConfig in the database
        List<HealthCheckConfig> healthCheckConfigs = healthCheckConfigRepository.findAll();
        assertThat(healthCheckConfigs).hasSize(databaseSizeBeforeCreate + 1);
        HealthCheckConfig testHealthCheckConfig = healthCheckConfigs.get(healthCheckConfigs.size() - 1);

        // Validate the HealthCheckConfig in ElasticSearch
        HealthCheckConfig healthCheckConfigEs = healthCheckConfigSearchRepository.findOne(testHealthCheckConfig.getId());
        assertThat(healthCheckConfigEs).isEqualToComparingFieldByField(testHealthCheckConfig);
    }

    @Test
    @Transactional
    public void getAllHealthCheckConfigs() throws Exception {
        // Initialize the database
        healthCheckConfigRepository.saveAndFlush(healthCheckConfig);

        // Get all the healthCheckConfigs
        restHealthCheckConfigMockMvc.perform(get("/api/health-check-configs?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andExpect(jsonPath("$.[*].id").value(hasItem(healthCheckConfig.getId().intValue())));
    }

    @Test
    @Transactional
    public void getHealthCheckConfig() throws Exception {
        // Initialize the database
        healthCheckConfigRepository.saveAndFlush(healthCheckConfig);

        // Get the healthCheckConfig
        restHealthCheckConfigMockMvc.perform(get("/api/health-check-configs/{id}", healthCheckConfig.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(healthCheckConfig.getId().intValue()));
    }

    @Test
    @Transactional
    public void getNonExistingHealthCheckConfig() throws Exception {
        // Get the healthCheckConfig
        restHealthCheckConfigMockMvc.perform(get("/api/health-check-configs/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateHealthCheckConfig() throws Exception {
        // Initialize the database
        healthCheckConfigRepository.saveAndFlush(healthCheckConfig);
        healthCheckConfigSearchRepository.save(healthCheckConfig);
        int databaseSizeBeforeUpdate = healthCheckConfigRepository.findAll().size();

        // Update the healthCheckConfig
        HealthCheckConfig updatedHealthCheckConfig = healthCheckConfigRepository.findOne(healthCheckConfig.getId());
        HealthCheckConfigDTO healthCheckConfigDTO = healthCheckConfigMapper.healthCheckConfigToHealthCheckConfigDTO(updatedHealthCheckConfig);

        restHealthCheckConfigMockMvc.perform(put("/api/health-check-configs")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(healthCheckConfigDTO)))
                .andExpect(status().isOk());

        // Validate the HealthCheckConfig in the database
        List<HealthCheckConfig> healthCheckConfigs = healthCheckConfigRepository.findAll();
        assertThat(healthCheckConfigs).hasSize(databaseSizeBeforeUpdate);
        HealthCheckConfig testHealthCheckConfig = healthCheckConfigs.get(healthCheckConfigs.size() - 1);

        // Validate the HealthCheckConfig in ElasticSearch
        HealthCheckConfig healthCheckConfigEs = healthCheckConfigSearchRepository.findOne(testHealthCheckConfig.getId());
        assertThat(healthCheckConfigEs).isEqualToComparingFieldByField(testHealthCheckConfig);
    }

    @Test
    @Transactional
    public void deleteHealthCheckConfig() throws Exception {
        // Initialize the database
        healthCheckConfigRepository.saveAndFlush(healthCheckConfig);
        healthCheckConfigSearchRepository.save(healthCheckConfig);
        int databaseSizeBeforeDelete = healthCheckConfigRepository.findAll().size();

        // Get the healthCheckConfig
        restHealthCheckConfigMockMvc.perform(delete("/api/health-check-configs/{id}", healthCheckConfig.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate ElasticSearch is empty
        boolean healthCheckConfigExistsInEs = healthCheckConfigSearchRepository.exists(healthCheckConfig.getId());
        assertThat(healthCheckConfigExistsInEs).isFalse();

        // Validate the database is empty
        List<HealthCheckConfig> healthCheckConfigs = healthCheckConfigRepository.findAll();
        assertThat(healthCheckConfigs).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void searchHealthCheckConfig() throws Exception {
        // Initialize the database
        healthCheckConfigRepository.saveAndFlush(healthCheckConfig);
        healthCheckConfigSearchRepository.save(healthCheckConfig);

        // Search the healthCheckConfig
        restHealthCheckConfigMockMvc.perform(get("/api/_search/health-check-configs?query=id:" + healthCheckConfig.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(healthCheckConfig.getId().intValue())));
    }
}
