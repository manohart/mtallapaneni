package com.jpmorgan.am.grt.web.rest;

import com.jpmorgan.am.grt.HealthCheckApp;

import com.jpmorgan.am.grt.domain.ReleaseNoteHistory;
import com.jpmorgan.am.grt.repository.ReleaseNoteHistoryRepository;
import com.jpmorgan.am.grt.service.ReleaseNoteHistoryService;
import com.jpmorgan.am.grt.repository.search.ReleaseNoteHistorySearchRepository;
import com.jpmorgan.am.grt.service.dto.ReleaseNoteHistoryDTO;
import com.jpmorgan.am.grt.service.mapper.ReleaseNoteHistoryMapper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneId;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the ReleaseNoteHistoryResource REST controller.
 *
 * @see ReleaseNoteHistoryResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = HealthCheckApp.class)
public class ReleaseNoteHistoryResourceIntTest {

    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(ZoneId.of("Z"));

    private static final String DEFAULT_NAME = "AAAAA";
    private static final String UPDATED_NAME = "BBBBB";
    private static final String DEFAULT_COMMENT = "AAAAA";
    private static final String UPDATED_COMMENT = "BBBBB";

    private static final ZonedDateTime DEFAULT_UPDATED_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneId.systemDefault());
    private static final ZonedDateTime UPDATED_UPDATED_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);
    private static final String DEFAULT_UPDATED_DATE_STR = dateTimeFormatter.format(DEFAULT_UPDATED_DATE);

    @Inject
    private ReleaseNoteHistoryRepository releaseNoteHistoryRepository;

    @Inject
    private ReleaseNoteHistoryMapper releaseNoteHistoryMapper;

    @Inject
    private ReleaseNoteHistoryService releaseNoteHistoryService;

    @Inject
    private ReleaseNoteHistorySearchRepository releaseNoteHistorySearchRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restReleaseNoteHistoryMockMvc;

    private ReleaseNoteHistory releaseNoteHistory;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        ReleaseNoteHistoryResource releaseNoteHistoryResource = new ReleaseNoteHistoryResource();
        ReflectionTestUtils.setField(releaseNoteHistoryResource, "releaseNoteHistoryService", releaseNoteHistoryService);
        this.restReleaseNoteHistoryMockMvc = MockMvcBuilders.standaloneSetup(releaseNoteHistoryResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static ReleaseNoteHistory createEntity(EntityManager em) {
        ReleaseNoteHistory releaseNoteHistory = new ReleaseNoteHistory();
        releaseNoteHistory.setName(DEFAULT_NAME);
        releaseNoteHistory.setComment(DEFAULT_COMMENT);
        releaseNoteHistory.setUpdatedDate(DEFAULT_UPDATED_DATE);
        return releaseNoteHistory;
    }

    @Before
    public void initTest() {
        releaseNoteHistorySearchRepository.deleteAll();
        releaseNoteHistory = createEntity(em);
    }

    @Test
    @Transactional
    public void createReleaseNoteHistory() throws Exception {
        int databaseSizeBeforeCreate = releaseNoteHistoryRepository.findAll().size();

        // Create the ReleaseNoteHistory
        ReleaseNoteHistoryDTO releaseNoteHistoryDTO = releaseNoteHistoryMapper.releaseNoteHistoryToReleaseNoteHistoryDTO(releaseNoteHistory);

        restReleaseNoteHistoryMockMvc.perform(post("/api/release-note-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(releaseNoteHistoryDTO)))
                .andExpect(status().isCreated());

        // Validate the ReleaseNoteHistory in the database
        List<ReleaseNoteHistory> releaseNoteHistories = releaseNoteHistoryRepository.findAll();
        assertThat(releaseNoteHistories).hasSize(databaseSizeBeforeCreate + 1);
        ReleaseNoteHistory testReleaseNoteHistory = releaseNoteHistories.get(releaseNoteHistories.size() - 1);
        assertThat(testReleaseNoteHistory.getName()).isEqualTo(DEFAULT_NAME);
        assertThat(testReleaseNoteHistory.getComment()).isEqualTo(DEFAULT_COMMENT);
        assertThat(testReleaseNoteHistory.getUpdatedDate()).isEqualTo(DEFAULT_UPDATED_DATE);

        // Validate the ReleaseNoteHistory in ElasticSearch
        ReleaseNoteHistory releaseNoteHistoryEs = releaseNoteHistorySearchRepository.findOne(testReleaseNoteHistory.getId());
        assertThat(releaseNoteHistoryEs).isEqualToComparingFieldByField(testReleaseNoteHistory);
    }

    @Test
    @Transactional
    public void checkNameIsRequired() throws Exception {
        int databaseSizeBeforeTest = releaseNoteHistoryRepository.findAll().size();
        // set the field null
        releaseNoteHistory.setName(null);

        // Create the ReleaseNoteHistory, which fails.
        ReleaseNoteHistoryDTO releaseNoteHistoryDTO = releaseNoteHistoryMapper.releaseNoteHistoryToReleaseNoteHistoryDTO(releaseNoteHistory);

        restReleaseNoteHistoryMockMvc.perform(post("/api/release-note-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(releaseNoteHistoryDTO)))
                .andExpect(status().isBadRequest());

        List<ReleaseNoteHistory> releaseNoteHistories = releaseNoteHistoryRepository.findAll();
        assertThat(releaseNoteHistories).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllReleaseNoteHistories() throws Exception {
        // Initialize the database
        releaseNoteHistoryRepository.saveAndFlush(releaseNoteHistory);

        // Get all the releaseNoteHistories
        restReleaseNoteHistoryMockMvc.perform(get("/api/release-note-histories?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andExpect(jsonPath("$.[*].id").value(hasItem(releaseNoteHistory.getId().intValue())))
                .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
                .andExpect(jsonPath("$.[*].comment").value(hasItem(DEFAULT_COMMENT.toString())))
                .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }

    @Test
    @Transactional
    public void getReleaseNoteHistory() throws Exception {
        // Initialize the database
        releaseNoteHistoryRepository.saveAndFlush(releaseNoteHistory);

        // Get the releaseNoteHistory
        restReleaseNoteHistoryMockMvc.perform(get("/api/release-note-histories/{id}", releaseNoteHistory.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(releaseNoteHistory.getId().intValue()))
            .andExpect(jsonPath("$.name").value(DEFAULT_NAME.toString()))
            .andExpect(jsonPath("$.comment").value(DEFAULT_COMMENT.toString()))
            .andExpect(jsonPath("$.updatedDate").value(DEFAULT_UPDATED_DATE_STR));
    }

    @Test
    @Transactional
    public void getNonExistingReleaseNoteHistory() throws Exception {
        // Get the releaseNoteHistory
        restReleaseNoteHistoryMockMvc.perform(get("/api/release-note-histories/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateReleaseNoteHistory() throws Exception {
        // Initialize the database
        releaseNoteHistoryRepository.saveAndFlush(releaseNoteHistory);
        releaseNoteHistorySearchRepository.save(releaseNoteHistory);
        int databaseSizeBeforeUpdate = releaseNoteHistoryRepository.findAll().size();

        // Update the releaseNoteHistory
        ReleaseNoteHistory updatedReleaseNoteHistory = releaseNoteHistoryRepository.findOne(releaseNoteHistory.getId());
        updatedReleaseNoteHistory.setName(UPDATED_NAME);
        updatedReleaseNoteHistory.setComment(UPDATED_COMMENT);
        updatedReleaseNoteHistory.setUpdatedDate(UPDATED_UPDATED_DATE);
        ReleaseNoteHistoryDTO releaseNoteHistoryDTO = releaseNoteHistoryMapper.releaseNoteHistoryToReleaseNoteHistoryDTO(updatedReleaseNoteHistory);

        restReleaseNoteHistoryMockMvc.perform(put("/api/release-note-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(releaseNoteHistoryDTO)))
                .andExpect(status().isOk());

        // Validate the ReleaseNoteHistory in the database
        List<ReleaseNoteHistory> releaseNoteHistories = releaseNoteHistoryRepository.findAll();
        assertThat(releaseNoteHistories).hasSize(databaseSizeBeforeUpdate);
        ReleaseNoteHistory testReleaseNoteHistory = releaseNoteHistories.get(releaseNoteHistories.size() - 1);
        assertThat(testReleaseNoteHistory.getName()).isEqualTo(UPDATED_NAME);
        assertThat(testReleaseNoteHistory.getComment()).isEqualTo(UPDATED_COMMENT);
        assertThat(testReleaseNoteHistory.getUpdatedDate()).isEqualTo(UPDATED_UPDATED_DATE);

        // Validate the ReleaseNoteHistory in ElasticSearch
        ReleaseNoteHistory releaseNoteHistoryEs = releaseNoteHistorySearchRepository.findOne(testReleaseNoteHistory.getId());
        assertThat(releaseNoteHistoryEs).isEqualToComparingFieldByField(testReleaseNoteHistory);
    }

    @Test
    @Transactional
    public void deleteReleaseNoteHistory() throws Exception {
        // Initialize the database
        releaseNoteHistoryRepository.saveAndFlush(releaseNoteHistory);
        releaseNoteHistorySearchRepository.save(releaseNoteHistory);
        int databaseSizeBeforeDelete = releaseNoteHistoryRepository.findAll().size();

        // Get the releaseNoteHistory
        restReleaseNoteHistoryMockMvc.perform(delete("/api/release-note-histories/{id}", releaseNoteHistory.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate ElasticSearch is empty
        boolean releaseNoteHistoryExistsInEs = releaseNoteHistorySearchRepository.exists(releaseNoteHistory.getId());
        assertThat(releaseNoteHistoryExistsInEs).isFalse();

        // Validate the database is empty
        List<ReleaseNoteHistory> releaseNoteHistories = releaseNoteHistoryRepository.findAll();
        assertThat(releaseNoteHistories).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void searchReleaseNoteHistory() throws Exception {
        // Initialize the database
        releaseNoteHistoryRepository.saveAndFlush(releaseNoteHistory);
        releaseNoteHistorySearchRepository.save(releaseNoteHistory);

        // Search the releaseNoteHistory
        restReleaseNoteHistoryMockMvc.perform(get("/api/_search/release-note-histories?query=id:" + releaseNoteHistory.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(releaseNoteHistory.getId().intValue())))
            .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
            .andExpect(jsonPath("$.[*].comment").value(hasItem(DEFAULT_COMMENT.toString())))
            .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }
}
