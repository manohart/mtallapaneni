'use strict';

describe('Controller Tests', function() {

    describe('BatchReportHistory Management Detail Controller', function() {
        var $scope, $rootScope;
        var MockEntity, MockPreviousState, MockBatchReportHistory, MockBatchReportDetailHistory, MockBatchReport;
        var createController;

        beforeEach(inject(function($injector) {
            $rootScope = $injector.get('$rootScope');
            $scope = $rootScope.$new();
            MockEntity = jasmine.createSpy('MockEntity');
            MockPreviousState = jasmine.createSpy('MockPreviousState');
            MockBatchReportHistory = jasmine.createSpy('MockBatchReportHistory');
            MockBatchReportDetailHistory = jasmine.createSpy('MockBatchReportDetailHistory');
            MockBatchReport = jasmine.createSpy('MockBatchReport');
            

            var locals = {
                '$scope': $scope,
                '$rootScope': $rootScope,
                'entity': MockEntity,
                'previousState': MockPreviousState,
                'BatchReportHistory': MockBatchReportHistory,
                'BatchReportDetailHistory': MockBatchReportDetailHistory,
                'BatchReport': MockBatchReport
            };
            createController = function() {
                $injector.get('$controller')("BatchReportHistoryDetailController", locals);
            };
        }));


        describe('Root Scope Listening', function() {
            it('Unregisters root scope listener upon scope destruction', function() {
                var eventType = 'healthCheckApp:batchReportHistoryUpdate';

                createController();
                expect($rootScope.$$listenerCount[eventType]).toEqual(1);

                $scope.$destroy();
                expect($rootScope.$$listenerCount[eventType]).toBeUndefined();
            });
        });
    });

});
