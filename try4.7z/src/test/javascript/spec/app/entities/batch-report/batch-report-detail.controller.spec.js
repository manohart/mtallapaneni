'use strict';

describe('Controller Tests', function() {

    describe('BatchReport Management Detail Controller', function() {
        var $scope, $rootScope;
        var MockEntity, MockPreviousState, MockBatchReport, MockDbCheck, MockBatchReportHistory, MockBatchJob;
        var createController;

        beforeEach(inject(function($injector) {
            $rootScope = $injector.get('$rootScope');
            $scope = $rootScope.$new();
            MockEntity = jasmine.createSpy('MockEntity');
            MockPreviousState = jasmine.createSpy('MockPreviousState');
            MockBatchReport = jasmine.createSpy('MockBatchReport');
            MockDbCheck = jasmine.createSpy('MockDbCheck');
            MockBatchReportHistory = jasmine.createSpy('MockBatchReportHistory');
            MockBatchJob = jasmine.createSpy('MockBatchJob');
            

            var locals = {
                '$scope': $scope,
                '$rootScope': $rootScope,
                'entity': MockEntity,
                'previousState': MockPreviousState,
                'BatchReport': MockBatchReport,
                'DbCheck': MockDbCheck,
                'BatchReportHistory': MockBatchReportHistory,
                'BatchJob': MockBatchJob
            };
            createController = function() {
                $injector.get('$controller')("BatchReportDetailController", locals);
            };
        }));


        describe('Root Scope Listening', function() {
            it('Unregisters root scope listener upon scope destruction', function() {
                var eventType = 'healthCheckApp:batchReportUpdate';

                createController();
                expect($rootScope.$$listenerCount[eventType]).toEqual(1);

                $scope.$destroy();
                expect($rootScope.$$listenerCount[eventType]).toBeUndefined();
            });
        });
    });

});
