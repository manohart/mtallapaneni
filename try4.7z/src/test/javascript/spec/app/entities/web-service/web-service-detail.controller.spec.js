'use strict';

describe('Controller Tests', function() {

    describe('WebService Management Detail Controller', function() {
        var $scope, $rootScope;
        var MockEntity, MockPreviousState, MockWebService, MockWebServiceConsumer, MockWebApp;
        var createController;

        beforeEach(inject(function($injector) {
            $rootScope = $injector.get('$rootScope');
            $scope = $rootScope.$new();
            MockEntity = jasmine.createSpy('MockEntity');
            MockPreviousState = jasmine.createSpy('MockPreviousState');
            MockWebService = jasmine.createSpy('MockWebService');
            MockWebServiceConsumer = jasmine.createSpy('MockWebServiceConsumer');
            MockWebApp = jasmine.createSpy('MockWebApp');
            

            var locals = {
                '$scope': $scope,
                '$rootScope': $rootScope,
                'entity': MockEntity,
                'previousState': MockPreviousState,
                'WebService': MockWebService,
                'WebServiceConsumer': MockWebServiceConsumer,
                'WebApp': MockWebApp
            };
            createController = function() {
                $injector.get('$controller')("WebServiceDetailController", locals);
            };
        }));


        describe('Root Scope Listening', function() {
            it('Unregisters root scope listener upon scope destruction', function() {
                var eventType = 'healthCheckApp:webServiceUpdate';

                createController();
                expect($rootScope.$$listenerCount[eventType]).toEqual(1);

                $scope.$destroy();
                expect($rootScope.$$listenerCount[eventType]).toBeUndefined();
            });
        });
    });

});
