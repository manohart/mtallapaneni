package com.jpmorgan.am.grt.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.springframework.data.elasticsearch.annotations.Document;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A HealthCheckConfig.
 */
@Entity
@Table(name = "health_check_config")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@Document(indexName = "healthcheckconfig")
public class HealthCheckConfig implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @ManyToOne
    private DbCheck dbCheck;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public DbCheck getDbCheck() {
        return dbCheck;
    }

    public void setDbCheck(DbCheck dbCheck) {
        this.dbCheck = dbCheck;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        HealthCheckConfig healthCheckConfig = (HealthCheckConfig) o;
        if(healthCheckConfig.id == null || id == null) {
            return false;
        }
        return Objects.equals(id, healthCheckConfig.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "HealthCheckConfig{" +
            "id=" + id +
            '}';
    }
}
