package com.jpmorgan.am.grt.domain.enumeration;

/**
 * The Environment enumeration.
 */
public enum Environment {
    PRODUCTION,RESEARCH
}
