package com.jpmorgan.am.grt.domain.enumeration;

/**
 * The TemplateType enumeration.
 */
public enum TemplateType {
    BATCH_REPORT,RELEASE_NOTE
}
