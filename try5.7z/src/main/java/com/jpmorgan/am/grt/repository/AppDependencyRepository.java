package com.jpmorgan.am.grt.repository;

import com.jpmorgan.am.grt.domain.AppDependency;

import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the AppDependency entity.
 */
@SuppressWarnings("unused")
public interface AppDependencyRepository extends JpaRepository<AppDependency,Long> {

}
