package com.jpmorgan.am.grt.repository;

import com.jpmorgan.am.grt.domain.ArchiveLocation;

import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the ArchiveLocation entity.
 */
@SuppressWarnings("unused")
public interface ArchiveLocationRepository extends JpaRepository<ArchiveLocation,Long> {

}
