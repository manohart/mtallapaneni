/**
 * Spring Data JPA repositories.
 */
package com.jpmorgan.am.grt.repository;
