package com.jpmorgan.am.grt.repository.search;

import com.jpmorgan.am.grt.domain.BatchReport;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * Spring Data ElasticSearch repository for the BatchReport entity.
 */
public interface BatchReportSearchRepository extends ElasticsearchRepository<BatchReport, Long> {
}
