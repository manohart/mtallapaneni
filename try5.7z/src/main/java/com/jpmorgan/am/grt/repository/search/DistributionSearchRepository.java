package com.jpmorgan.am.grt.repository.search;

import com.jpmorgan.am.grt.domain.Distribution;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * Spring Data ElasticSearch repository for the Distribution entity.
 */
public interface DistributionSearchRepository extends ElasticsearchRepository<Distribution, Long> {
}
