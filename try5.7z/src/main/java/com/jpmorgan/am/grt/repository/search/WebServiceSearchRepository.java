package com.jpmorgan.am.grt.repository.search;

import com.jpmorgan.am.grt.domain.WebService;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * Spring Data ElasticSearch repository for the WebService entity.
 */
public interface WebServiceSearchRepository extends ElasticsearchRepository<WebService, Long> {
}
