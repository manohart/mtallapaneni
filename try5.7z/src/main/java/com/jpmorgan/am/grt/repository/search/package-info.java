/**
 * Spring Data ElasticSearch repositories.
 */
package com.jpmorgan.am.grt.repository.search;
