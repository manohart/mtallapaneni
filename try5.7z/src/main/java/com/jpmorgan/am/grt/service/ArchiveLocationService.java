package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.service.dto.ArchiveLocationDTO;

import java.util.LinkedList;
import java.util.List;

/**
 * Service Interface for managing ArchiveLocation.
 */
public interface ArchiveLocationService {

    /**
     * Save a archiveLocation.
     *
     * @param archiveLocationDTO the entity to save
     * @return the persisted entity
     */
    ArchiveLocationDTO save(ArchiveLocationDTO archiveLocationDTO);

    /**
     *  Get all the archiveLocations.
     *  
     *  @return the list of entities
     */
    List<ArchiveLocationDTO> findAll();

    /**
     *  Get the "id" archiveLocation.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    ArchiveLocationDTO findOne(Long id);

    /**
     *  Delete the "id" archiveLocation.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the archiveLocation corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<ArchiveLocationDTO> search(String query);
}
