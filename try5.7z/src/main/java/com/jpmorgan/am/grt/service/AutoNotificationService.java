package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.service.dto.AutoNotificationDTO;

import java.util.LinkedList;
import java.util.List;

/**
 * Service Interface for managing AutoNotification.
 */
public interface AutoNotificationService {

    /**
     * Save a autoNotification.
     *
     * @param autoNotificationDTO the entity to save
     * @return the persisted entity
     */
    AutoNotificationDTO save(AutoNotificationDTO autoNotificationDTO);

    /**
     *  Get all the autoNotifications.
     *  
     *  @return the list of entities
     */
    List<AutoNotificationDTO> findAll();

    /**
     *  Get the "id" autoNotification.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    AutoNotificationDTO findOne(Long id);

    /**
     *  Delete the "id" autoNotification.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the autoNotification corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<AutoNotificationDTO> search(String query);
}
