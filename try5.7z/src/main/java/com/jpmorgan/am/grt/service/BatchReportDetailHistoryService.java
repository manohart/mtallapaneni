package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.service.dto.BatchReportDetailHistoryDTO;

import java.util.LinkedList;
import java.util.List;

/**
 * Service Interface for managing BatchReportDetailHistory.
 */
public interface BatchReportDetailHistoryService {

    /**
     * Save a batchReportDetailHistory.
     *
     * @param batchReportDetailHistoryDTO the entity to save
     * @return the persisted entity
     */
    BatchReportDetailHistoryDTO save(BatchReportDetailHistoryDTO batchReportDetailHistoryDTO);

    /**
     *  Get all the batchReportDetailHistories.
     *  
     *  @return the list of entities
     */
    List<BatchReportDetailHistoryDTO> findAll();

    /**
     *  Get the "id" batchReportDetailHistory.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    BatchReportDetailHistoryDTO findOne(Long id);

    /**
     *  Delete the "id" batchReportDetailHistory.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the batchReportDetailHistory corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<BatchReportDetailHistoryDTO> search(String query);
}
