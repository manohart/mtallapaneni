package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.service.dto.DevOpsDTO;

import java.util.LinkedList;
import java.util.List;

/**
 * Service Interface for managing DevOps.
 */
public interface DevOpsService {

    /**
     * Save a devOps.
     *
     * @param devOpsDTO the entity to save
     * @return the persisted entity
     */
    DevOpsDTO save(DevOpsDTO devOpsDTO);

    /**
     *  Get all the devOps.
     *  
     *  @return the list of entities
     */
    List<DevOpsDTO> findAll();

    /**
     *  Get the "id" devOps.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    DevOpsDTO findOne(Long id);

    /**
     *  Delete the "id" devOps.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the devOps corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<DevOpsDTO> search(String query);
}
