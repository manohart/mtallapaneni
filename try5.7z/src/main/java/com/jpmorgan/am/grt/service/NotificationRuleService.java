package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.service.dto.NotificationRuleDTO;

import java.util.LinkedList;
import java.util.List;

/**
 * Service Interface for managing NotificationRule.
 */
public interface NotificationRuleService {

    /**
     * Save a notificationRule.
     *
     * @param notificationRuleDTO the entity to save
     * @return the persisted entity
     */
    NotificationRuleDTO save(NotificationRuleDTO notificationRuleDTO);

    /**
     *  Get all the notificationRules.
     *  
     *  @return the list of entities
     */
    List<NotificationRuleDTO> findAll();

    /**
     *  Get the "id" notificationRule.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    NotificationRuleDTO findOne(Long id);

    /**
     *  Delete the "id" notificationRule.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the notificationRule corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<NotificationRuleDTO> search(String query);
}
