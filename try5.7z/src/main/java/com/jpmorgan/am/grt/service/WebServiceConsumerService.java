package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.service.dto.WebServiceConsumerDTO;

import java.util.LinkedList;
import java.util.List;

/**
 * Service Interface for managing WebServiceConsumer.
 */
public interface WebServiceConsumerService {

    /**
     * Save a webServiceConsumer.
     *
     * @param webServiceConsumerDTO the entity to save
     * @return the persisted entity
     */
    WebServiceConsumerDTO save(WebServiceConsumerDTO webServiceConsumerDTO);

    /**
     *  Get all the webServiceConsumers.
     *  
     *  @return the list of entities
     */
    List<WebServiceConsumerDTO> findAll();

    /**
     *  Get the "id" webServiceConsumer.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    WebServiceConsumerDTO findOne(Long id);

    /**
     *  Delete the "id" webServiceConsumer.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the webServiceConsumer corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<WebServiceConsumerDTO> search(String query);
}
