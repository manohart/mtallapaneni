package com.jpmorgan.am.grt.service.dto;

import java.time.ZonedDateTime;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;


/**
 * A DTO for the AppDependency entity.
 */
public class AppDependencyDTO implements Serializable {

    private Long id;

    @NotNull
    private Boolean isActive;

    private ZonedDateTime updatedDate;


    private Long applicationId;
    

    private String applicationName;

    private Long dependOnId;
    

    private String dependOnName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }
    public ZonedDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(ZonedDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Long getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(Long applicationId) {
        this.applicationId = applicationId;
    }


    public String getApplicationName() {
        return applicationName;
    }

    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }

    public Long getDependOnId() {
        return dependOnId;
    }

    public void setDependOnId(Long applicationId) {
        this.dependOnId = applicationId;
    }


    public String getDependOnName() {
        return dependOnName;
    }

    public void setDependOnName(String applicationName) {
        this.dependOnName = applicationName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        AppDependencyDTO appDependencyDTO = (AppDependencyDTO) o;

        if ( ! Objects.equals(id, appDependencyDTO.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "AppDependencyDTO{" +
            "id=" + id +
            ", isActive='" + isActive + "'" +
            ", updatedDate='" + updatedDate + "'" +
            '}';
    }
}
