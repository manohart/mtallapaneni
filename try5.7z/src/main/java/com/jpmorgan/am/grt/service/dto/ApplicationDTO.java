package com.jpmorgan.am.grt.service.dto;

import java.time.ZonedDateTime;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

import com.jpmorgan.am.grt.domain.enumeration.InfraCategory;
import com.jpmorgan.am.grt.domain.enumeration.AppType;

/**
 * A DTO for the Application entity.
 */
public class ApplicationDTO implements Serializable {

    private Long id;

    @NotNull
    @Size(min = 5)
    private String name;

    @NotNull
    @Size(min = 20)
    private String description;

    @NotNull
    private InfraCategory category;

    @NotNull
    private AppType type;

    @NotNull
    private String sla;

    @NotNull
    private String documenation;

    @NotNull
    private String rootDirectory;

    @NotNull
    private Boolean isActive;

    private ZonedDateTime updatedDate;


    private Long lobId;
    

    private String lobName;

    private Long devOpsId;
    

    private String devOpsName;

    private Long appServerId;
    

    private String appServerHostname;

    private Long dbServerId;
    

    private String dbServerHostname;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    public InfraCategory getCategory() {
        return category;
    }

    public void setCategory(InfraCategory category) {
        this.category = category;
    }
    public AppType getType() {
        return type;
    }

    public void setType(AppType type) {
        this.type = type;
    }
    public String getSla() {
        return sla;
    }

    public void setSla(String sla) {
        this.sla = sla;
    }
    public String getDocumenation() {
        return documenation;
    }

    public void setDocumenation(String documenation) {
        this.documenation = documenation;
    }
    public String getRootDirectory() {
        return rootDirectory;
    }

    public void setRootDirectory(String rootDirectory) {
        this.rootDirectory = rootDirectory;
    }
    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }
    public ZonedDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(ZonedDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Long getLobId() {
        return lobId;
    }

    public void setLobId(Long lobId) {
        this.lobId = lobId;
    }


    public String getLobName() {
        return lobName;
    }

    public void setLobName(String lobName) {
        this.lobName = lobName;
    }

    public Long getDevOpsId() {
        return devOpsId;
    }

    public void setDevOpsId(Long devOpsId) {
        this.devOpsId = devOpsId;
    }


    public String getDevOpsName() {
        return devOpsName;
    }

    public void setDevOpsName(String devOpsName) {
        this.devOpsName = devOpsName;
    }

    public Long getAppServerId() {
        return appServerId;
    }

    public void setAppServerId(Long serverId) {
        this.appServerId = serverId;
    }


    public String getAppServerHostname() {
        return appServerHostname;
    }

    public void setAppServerHostname(String serverHostname) {
        this.appServerHostname = serverHostname;
    }

    public Long getDbServerId() {
        return dbServerId;
    }

    public void setDbServerId(Long serverId) {
        this.dbServerId = serverId;
    }


    public String getDbServerHostname() {
        return dbServerHostname;
    }

    public void setDbServerHostname(String serverHostname) {
        this.dbServerHostname = serverHostname;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ApplicationDTO applicationDTO = (ApplicationDTO) o;

        if ( ! Objects.equals(id, applicationDTO.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "ApplicationDTO{" +
            "id=" + id +
            ", name='" + name + "'" +
            ", description='" + description + "'" +
            ", category='" + category + "'" +
            ", type='" + type + "'" +
            ", sla='" + sla + "'" +
            ", documenation='" + documenation + "'" +
            ", rootDirectory='" + rootDirectory + "'" +
            ", isActive='" + isActive + "'" +
            ", updatedDate='" + updatedDate + "'" +
            '}';
    }
}
