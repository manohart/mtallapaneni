package com.jpmorgan.am.grt.service.dto;

import java.time.ZonedDateTime;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

import com.jpmorgan.am.grt.domain.enumeration.AppScheduler;

/**
 * A DTO for the BatchJob entity.
 */
public class BatchJobDTO implements Serializable {

    private Long id;

    @NotNull
    private AppScheduler scheduler;

    @NotNull
    private Boolean isActive;

    private ZonedDateTime updatedDate;


    private Long applicationId;
    

    private String applicationName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public AppScheduler getScheduler() {
        return scheduler;
    }

    public void setScheduler(AppScheduler scheduler) {
        this.scheduler = scheduler;
    }
    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }
    public ZonedDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(ZonedDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Long getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(Long applicationId) {
        this.applicationId = applicationId;
    }


    public String getApplicationName() {
        return applicationName;
    }

    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        BatchJobDTO batchJobDTO = (BatchJobDTO) o;

        if ( ! Objects.equals(id, batchJobDTO.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "BatchJobDTO{" +
            "id=" + id +
            ", scheduler='" + scheduler + "'" +
            ", isActive='" + isActive + "'" +
            ", updatedDate='" + updatedDate + "'" +
            '}';
    }
}
