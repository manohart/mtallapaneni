package com.jpmorgan.am.grt.service.dto;

import java.time.ZonedDateTime;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;


/**
 * A DTO for the BatchReportDetailHistory entity.
 */
public class BatchReportDetailHistoryDTO implements Serializable {

    private Long id;

    @NotNull
    private Integer records;

    @NotNull
    private Integer issues;

    @NotNull
    private String initialStatus;

    @NotNull
    private String finalStatus;

    private String comment;

    private ZonedDateTime updatedDate;


    private Long summaryId;
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public Integer getRecords() {
        return records;
    }

    public void setRecords(Integer records) {
        this.records = records;
    }
    public Integer getIssues() {
        return issues;
    }

    public void setIssues(Integer issues) {
        this.issues = issues;
    }
    public String getInitialStatus() {
        return initialStatus;
    }

    public void setInitialStatus(String initialStatus) {
        this.initialStatus = initialStatus;
    }
    public String getFinalStatus() {
        return finalStatus;
    }

    public void setFinalStatus(String finalStatus) {
        this.finalStatus = finalStatus;
    }
    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
    public ZonedDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(ZonedDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Long getSummaryId() {
        return summaryId;
    }

    public void setSummaryId(Long batchReportHistoryId) {
        this.summaryId = batchReportHistoryId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        BatchReportDetailHistoryDTO batchReportDetailHistoryDTO = (BatchReportDetailHistoryDTO) o;

        if ( ! Objects.equals(id, batchReportDetailHistoryDTO.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "BatchReportDetailHistoryDTO{" +
            "id=" + id +
            ", records='" + records + "'" +
            ", issues='" + issues + "'" +
            ", initialStatus='" + initialStatus + "'" +
            ", finalStatus='" + finalStatus + "'" +
            ", comment='" + comment + "'" +
            ", updatedDate='" + updatedDate + "'" +
            '}';
    }
}
