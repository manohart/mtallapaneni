package com.jpmorgan.am.grt.service.dto;

import java.time.LocalDate;
import java.time.ZonedDateTime;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;


/**
 * A DTO for the BatchReportHistory entity.
 */
public class BatchReportHistoryDTO implements Serializable {

    private Long id;

    @NotNull
    private String initialStatus;

    @NotNull
    private String finalStatus;

    private String comment;

    @NotNull
    private LocalDate businessDate;

    private ZonedDateTime updatedDate;


    private Long reportConfigId;
    

    private String reportConfigName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getInitialStatus() {
        return initialStatus;
    }

    public void setInitialStatus(String initialStatus) {
        this.initialStatus = initialStatus;
    }
    public String getFinalStatus() {
        return finalStatus;
    }

    public void setFinalStatus(String finalStatus) {
        this.finalStatus = finalStatus;
    }
    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
    public LocalDate getBusinessDate() {
        return businessDate;
    }

    public void setBusinessDate(LocalDate businessDate) {
        this.businessDate = businessDate;
    }
    public ZonedDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(ZonedDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Long getReportConfigId() {
        return reportConfigId;
    }

    public void setReportConfigId(Long batchReportId) {
        this.reportConfigId = batchReportId;
    }


    public String getReportConfigName() {
        return reportConfigName;
    }

    public void setReportConfigName(String batchReportName) {
        this.reportConfigName = batchReportName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        BatchReportHistoryDTO batchReportHistoryDTO = (BatchReportHistoryDTO) o;

        if ( ! Objects.equals(id, batchReportHistoryDTO.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "BatchReportHistoryDTO{" +
            "id=" + id +
            ", initialStatus='" + initialStatus + "'" +
            ", finalStatus='" + finalStatus + "'" +
            ", comment='" + comment + "'" +
            ", businessDate='" + businessDate + "'" +
            ", updatedDate='" + updatedDate + "'" +
            '}';
    }
}
