package com.jpmorgan.am.grt.service.dto;

import java.time.ZonedDateTime;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;


/**
 * A DTO for the Distribution entity.
 */
public class DistributionDTO implements Serializable {

    private Long id;

    @NotNull
    private String name;

    @NotNull
    private String fromAddress;

    @NotNull
    private String toAddress;

    @NotNull
    private String ccAddress;

    @NotNull
    private Boolean skipEmpty;

    @NotNull
    private Boolean isActive;

    private ZonedDateTime updatedDate;


    private Long batchJobId;
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getFromAddress() {
        return fromAddress;
    }

    public void setFromAddress(String fromAddress) {
        this.fromAddress = fromAddress;
    }
    public String getToAddress() {
        return toAddress;
    }

    public void setToAddress(String toAddress) {
        this.toAddress = toAddress;
    }
    public String getCcAddress() {
        return ccAddress;
    }

    public void setCcAddress(String ccAddress) {
        this.ccAddress = ccAddress;
    }
    public Boolean getSkipEmpty() {
        return skipEmpty;
    }

    public void setSkipEmpty(Boolean skipEmpty) {
        this.skipEmpty = skipEmpty;
    }
    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }
    public ZonedDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(ZonedDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Long getBatchJobId() {
        return batchJobId;
    }

    public void setBatchJobId(Long batchJobId) {
        this.batchJobId = batchJobId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DistributionDTO distributionDTO = (DistributionDTO) o;

        if ( ! Objects.equals(id, distributionDTO.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "DistributionDTO{" +
            "id=" + id +
            ", name='" + name + "'" +
            ", fromAddress='" + fromAddress + "'" +
            ", toAddress='" + toAddress + "'" +
            ", ccAddress='" + ccAddress + "'" +
            ", skipEmpty='" + skipEmpty + "'" +
            ", isActive='" + isActive + "'" +
            ", updatedDate='" + updatedDate + "'" +
            '}';
    }
}
