package com.jpmorgan.am.grt.service.dto;

import java.time.ZonedDateTime;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;


/**
 * A DTO for the WebApp entity.
 */
public class WebAppDTO implements Serializable {

    private Long id;

    @NotNull
    private String container;

    @NotNull
    private String hostname;

    @NotNull
    @Min(value = 1000)
    private Integer portNumber;

    @NotNull
    private String context;

    private String healthUrl;

    private String healthContains;

    @NotNull
    private Boolean isActive;

    private ZonedDateTime updatedDate;


    private Long applicationId;
    

    private String applicationName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getContainer() {
        return container;
    }

    public void setContainer(String container) {
        this.container = container;
    }
    public String getHostname() {
        return hostname;
    }

    public void setHostname(String hostname) {
        this.hostname = hostname;
    }
    public Integer getPortNumber() {
        return portNumber;
    }

    public void setPortNumber(Integer portNumber) {
        this.portNumber = portNumber;
    }
    public String getContext() {
        return context;
    }

    public void setContext(String context) {
        this.context = context;
    }
    public String getHealthUrl() {
        return healthUrl;
    }

    public void setHealthUrl(String healthUrl) {
        this.healthUrl = healthUrl;
    }
    public String getHealthContains() {
        return healthContains;
    }

    public void setHealthContains(String healthContains) {
        this.healthContains = healthContains;
    }
    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }
    public ZonedDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(ZonedDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Long getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(Long applicationId) {
        this.applicationId = applicationId;
    }


    public String getApplicationName() {
        return applicationName;
    }

    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        WebAppDTO webAppDTO = (WebAppDTO) o;

        if ( ! Objects.equals(id, webAppDTO.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "WebAppDTO{" +
            "id=" + id +
            ", container='" + container + "'" +
            ", hostname='" + hostname + "'" +
            ", portNumber='" + portNumber + "'" +
            ", context='" + context + "'" +
            ", healthUrl='" + healthUrl + "'" +
            ", healthContains='" + healthContains + "'" +
            ", isActive='" + isActive + "'" +
            ", updatedDate='" + updatedDate + "'" +
            '}';
    }
}
