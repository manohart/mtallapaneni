package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.ApplicationService;
import com.jpmorgan.am.grt.domain.Application;
import com.jpmorgan.am.grt.repository.ApplicationRepository;
import com.jpmorgan.am.grt.repository.search.ApplicationSearchRepository;
import com.jpmorgan.am.grt.service.dto.ApplicationDTO;
import com.jpmorgan.am.grt.service.mapper.ApplicationMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing Application.
 */
@Service
@Transactional
public class ApplicationServiceImpl implements ApplicationService{

    private final Logger log = LoggerFactory.getLogger(ApplicationServiceImpl.class);
    
    @Inject
    private ApplicationRepository applicationRepository;

    @Inject
    private ApplicationMapper applicationMapper;

    @Inject
    private ApplicationSearchRepository applicationSearchRepository;

    /**
     * Save a application.
     *
     * @param applicationDTO the entity to save
     * @return the persisted entity
     */
    public ApplicationDTO save(ApplicationDTO applicationDTO) {
        log.debug("Request to save Application : {}", applicationDTO);
        Application application = applicationMapper.applicationDTOToApplication(applicationDTO);
        application = applicationRepository.save(application);
        ApplicationDTO result = applicationMapper.applicationToApplicationDTO(application);
        applicationSearchRepository.save(application);
        return result;
    }

    /**
     *  Get all the applications.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<ApplicationDTO> findAll() {
        log.debug("Request to get all Applications");
        List<ApplicationDTO> result = applicationRepository.findAll().stream()
            .map(applicationMapper::applicationToApplicationDTO)
            .collect(Collectors.toCollection(LinkedList::new));

        return result;
    }

    /**
     *  Get one application by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public ApplicationDTO findOne(Long id) {
        log.debug("Request to get Application : {}", id);
        Application application = applicationRepository.findOne(id);
        ApplicationDTO applicationDTO = applicationMapper.applicationToApplicationDTO(application);
        return applicationDTO;
    }

    /**
     *  Delete the  application by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete Application : {}", id);
        applicationRepository.delete(id);
        applicationSearchRepository.delete(id);
    }

    /**
     * Search for the application corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<ApplicationDTO> search(String query) {
        log.debug("Request to search Applications for query {}", query);
        return StreamSupport
            .stream(applicationSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .map(applicationMapper::applicationToApplicationDTO)
            .collect(Collectors.toList());
    }
}
