package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.BatchJobService;
import com.jpmorgan.am.grt.domain.BatchJob;
import com.jpmorgan.am.grt.repository.BatchJobRepository;
import com.jpmorgan.am.grt.repository.search.BatchJobSearchRepository;
import com.jpmorgan.am.grt.service.dto.BatchJobDTO;
import com.jpmorgan.am.grt.service.mapper.BatchJobMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing BatchJob.
 */
@Service
@Transactional
public class BatchJobServiceImpl implements BatchJobService{

    private final Logger log = LoggerFactory.getLogger(BatchJobServiceImpl.class);
    
    @Inject
    private BatchJobRepository batchJobRepository;

    @Inject
    private BatchJobMapper batchJobMapper;

    @Inject
    private BatchJobSearchRepository batchJobSearchRepository;

    /**
     * Save a batchJob.
     *
     * @param batchJobDTO the entity to save
     * @return the persisted entity
     */
    public BatchJobDTO save(BatchJobDTO batchJobDTO) {
        log.debug("Request to save BatchJob : {}", batchJobDTO);
        BatchJob batchJob = batchJobMapper.batchJobDTOToBatchJob(batchJobDTO);
        batchJob = batchJobRepository.save(batchJob);
        BatchJobDTO result = batchJobMapper.batchJobToBatchJobDTO(batchJob);
        batchJobSearchRepository.save(batchJob);
        return result;
    }

    /**
     *  Get all the batchJobs.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<BatchJobDTO> findAll() {
        log.debug("Request to get all BatchJobs");
        List<BatchJobDTO> result = batchJobRepository.findAll().stream()
            .map(batchJobMapper::batchJobToBatchJobDTO)
            .collect(Collectors.toCollection(LinkedList::new));

        return result;
    }

    /**
     *  Get one batchJob by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public BatchJobDTO findOne(Long id) {
        log.debug("Request to get BatchJob : {}", id);
        BatchJob batchJob = batchJobRepository.findOne(id);
        BatchJobDTO batchJobDTO = batchJobMapper.batchJobToBatchJobDTO(batchJob);
        return batchJobDTO;
    }

    /**
     *  Delete the  batchJob by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete BatchJob : {}", id);
        batchJobRepository.delete(id);
        batchJobSearchRepository.delete(id);
    }

    /**
     * Search for the batchJob corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<BatchJobDTO> search(String query) {
        log.debug("Request to search BatchJobs for query {}", query);
        return StreamSupport
            .stream(batchJobSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .map(batchJobMapper::batchJobToBatchJobDTO)
            .collect(Collectors.toList());
    }
}
