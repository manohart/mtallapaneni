package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.DistributionService;
import com.jpmorgan.am.grt.domain.Distribution;
import com.jpmorgan.am.grt.repository.DistributionRepository;
import com.jpmorgan.am.grt.repository.search.DistributionSearchRepository;
import com.jpmorgan.am.grt.service.dto.DistributionDTO;
import com.jpmorgan.am.grt.service.mapper.DistributionMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing Distribution.
 */
@Service
@Transactional
public class DistributionServiceImpl implements DistributionService{

    private final Logger log = LoggerFactory.getLogger(DistributionServiceImpl.class);
    
    @Inject
    private DistributionRepository distributionRepository;

    @Inject
    private DistributionMapper distributionMapper;

    @Inject
    private DistributionSearchRepository distributionSearchRepository;

    /**
     * Save a distribution.
     *
     * @param distributionDTO the entity to save
     * @return the persisted entity
     */
    public DistributionDTO save(DistributionDTO distributionDTO) {
        log.debug("Request to save Distribution : {}", distributionDTO);
        Distribution distribution = distributionMapper.distributionDTOToDistribution(distributionDTO);
        distribution = distributionRepository.save(distribution);
        DistributionDTO result = distributionMapper.distributionToDistributionDTO(distribution);
        distributionSearchRepository.save(distribution);
        return result;
    }

    /**
     *  Get all the distributions.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<DistributionDTO> findAll() {
        log.debug("Request to get all Distributions");
        List<DistributionDTO> result = distributionRepository.findAll().stream()
            .map(distributionMapper::distributionToDistributionDTO)
            .collect(Collectors.toCollection(LinkedList::new));

        return result;
    }

    /**
     *  Get one distribution by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public DistributionDTO findOne(Long id) {
        log.debug("Request to get Distribution : {}", id);
        Distribution distribution = distributionRepository.findOne(id);
        DistributionDTO distributionDTO = distributionMapper.distributionToDistributionDTO(distribution);
        return distributionDTO;
    }

    /**
     *  Delete the  distribution by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete Distribution : {}", id);
        distributionRepository.delete(id);
        distributionSearchRepository.delete(id);
    }

    /**
     * Search for the distribution corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<DistributionDTO> search(String query) {
        log.debug("Request to search Distributions for query {}", query);
        return StreamSupport
            .stream(distributionSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .map(distributionMapper::distributionToDistributionDTO)
            .collect(Collectors.toList());
    }
}
