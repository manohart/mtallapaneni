package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.HealthCheckConfigService;
import com.jpmorgan.am.grt.domain.HealthCheckConfig;
import com.jpmorgan.am.grt.repository.HealthCheckConfigRepository;
import com.jpmorgan.am.grt.repository.search.HealthCheckConfigSearchRepository;
import com.jpmorgan.am.grt.service.dto.HealthCheckConfigDTO;
import com.jpmorgan.am.grt.service.mapper.HealthCheckConfigMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing HealthCheckConfig.
 */
@Service
@Transactional
public class HealthCheckConfigServiceImpl implements HealthCheckConfigService{

    private final Logger log = LoggerFactory.getLogger(HealthCheckConfigServiceImpl.class);
    
    @Inject
    private HealthCheckConfigRepository healthCheckConfigRepository;

    @Inject
    private HealthCheckConfigMapper healthCheckConfigMapper;

    @Inject
    private HealthCheckConfigSearchRepository healthCheckConfigSearchRepository;

    /**
     * Save a healthCheckConfig.
     *
     * @param healthCheckConfigDTO the entity to save
     * @return the persisted entity
     */
    public HealthCheckConfigDTO save(HealthCheckConfigDTO healthCheckConfigDTO) {
        log.debug("Request to save HealthCheckConfig : {}", healthCheckConfigDTO);
        HealthCheckConfig healthCheckConfig = healthCheckConfigMapper.healthCheckConfigDTOToHealthCheckConfig(healthCheckConfigDTO);
        healthCheckConfig = healthCheckConfigRepository.save(healthCheckConfig);
        HealthCheckConfigDTO result = healthCheckConfigMapper.healthCheckConfigToHealthCheckConfigDTO(healthCheckConfig);
        healthCheckConfigSearchRepository.save(healthCheckConfig);
        return result;
    }

    /**
     *  Get all the healthCheckConfigs.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<HealthCheckConfigDTO> findAll() {
        log.debug("Request to get all HealthCheckConfigs");
        List<HealthCheckConfigDTO> result = healthCheckConfigRepository.findAll().stream()
            .map(healthCheckConfigMapper::healthCheckConfigToHealthCheckConfigDTO)
            .collect(Collectors.toCollection(LinkedList::new));

        return result;
    }

    /**
     *  Get one healthCheckConfig by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public HealthCheckConfigDTO findOne(Long id) {
        log.debug("Request to get HealthCheckConfig : {}", id);
        HealthCheckConfig healthCheckConfig = healthCheckConfigRepository.findOne(id);
        HealthCheckConfigDTO healthCheckConfigDTO = healthCheckConfigMapper.healthCheckConfigToHealthCheckConfigDTO(healthCheckConfig);
        return healthCheckConfigDTO;
    }

    /**
     *  Delete the  healthCheckConfig by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete HealthCheckConfig : {}", id);
        healthCheckConfigRepository.delete(id);
        healthCheckConfigSearchRepository.delete(id);
    }

    /**
     * Search for the healthCheckConfig corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<HealthCheckConfigDTO> search(String query) {
        log.debug("Request to search HealthCheckConfigs for query {}", query);
        return StreamSupport
            .stream(healthCheckConfigSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .map(healthCheckConfigMapper::healthCheckConfigToHealthCheckConfigDTO)
            .collect(Collectors.toList());
    }
}
