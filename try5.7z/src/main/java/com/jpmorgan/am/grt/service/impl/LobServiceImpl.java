package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.LobService;
import com.jpmorgan.am.grt.domain.Lob;
import com.jpmorgan.am.grt.repository.LobRepository;
import com.jpmorgan.am.grt.repository.search.LobSearchRepository;
import com.jpmorgan.am.grt.service.dto.LobDTO;
import com.jpmorgan.am.grt.service.mapper.LobMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing Lob.
 */
@Service
@Transactional
public class LobServiceImpl implements LobService{

    private final Logger log = LoggerFactory.getLogger(LobServiceImpl.class);
    
    @Inject
    private LobRepository lobRepository;

    @Inject
    private LobMapper lobMapper;

    @Inject
    private LobSearchRepository lobSearchRepository;

    /**
     * Save a lob.
     *
     * @param lobDTO the entity to save
     * @return the persisted entity
     */
    public LobDTO save(LobDTO lobDTO) {
        log.debug("Request to save Lob : {}", lobDTO);
        Lob lob = lobMapper.lobDTOToLob(lobDTO);
        lob = lobRepository.save(lob);
        LobDTO result = lobMapper.lobToLobDTO(lob);
        lobSearchRepository.save(lob);
        return result;
    }

    /**
     *  Get all the lobs.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<LobDTO> findAll() {
        log.debug("Request to get all Lobs");
        List<LobDTO> result = lobRepository.findAll().stream()
            .map(lobMapper::lobToLobDTO)
            .collect(Collectors.toCollection(LinkedList::new));

        return result;
    }

    /**
     *  Get one lob by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public LobDTO findOne(Long id) {
        log.debug("Request to get Lob : {}", id);
        Lob lob = lobRepository.findOne(id);
        LobDTO lobDTO = lobMapper.lobToLobDTO(lob);
        return lobDTO;
    }

    /**
     *  Delete the  lob by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete Lob : {}", id);
        lobRepository.delete(id);
        lobSearchRepository.delete(id);
    }

    /**
     * Search for the lob corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<LobDTO> search(String query) {
        log.debug("Request to search Lobs for query {}", query);
        return StreamSupport
            .stream(lobSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .map(lobMapper::lobToLobDTO)
            .collect(Collectors.toList());
    }
}
