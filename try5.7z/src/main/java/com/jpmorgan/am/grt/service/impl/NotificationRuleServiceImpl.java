package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.NotificationRuleService;
import com.jpmorgan.am.grt.domain.NotificationRule;
import com.jpmorgan.am.grt.repository.NotificationRuleRepository;
import com.jpmorgan.am.grt.repository.search.NotificationRuleSearchRepository;
import com.jpmorgan.am.grt.service.dto.NotificationRuleDTO;
import com.jpmorgan.am.grt.service.mapper.NotificationRuleMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing NotificationRule.
 */
@Service
@Transactional
public class NotificationRuleServiceImpl implements NotificationRuleService{

    private final Logger log = LoggerFactory.getLogger(NotificationRuleServiceImpl.class);
    
    @Inject
    private NotificationRuleRepository notificationRuleRepository;

    @Inject
    private NotificationRuleMapper notificationRuleMapper;

    @Inject
    private NotificationRuleSearchRepository notificationRuleSearchRepository;

    /**
     * Save a notificationRule.
     *
     * @param notificationRuleDTO the entity to save
     * @return the persisted entity
     */
    public NotificationRuleDTO save(NotificationRuleDTO notificationRuleDTO) {
        log.debug("Request to save NotificationRule : {}", notificationRuleDTO);
        NotificationRule notificationRule = notificationRuleMapper.notificationRuleDTOToNotificationRule(notificationRuleDTO);
        notificationRule = notificationRuleRepository.save(notificationRule);
        NotificationRuleDTO result = notificationRuleMapper.notificationRuleToNotificationRuleDTO(notificationRule);
        notificationRuleSearchRepository.save(notificationRule);
        return result;
    }

    /**
     *  Get all the notificationRules.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<NotificationRuleDTO> findAll() {
        log.debug("Request to get all NotificationRules");
        List<NotificationRuleDTO> result = notificationRuleRepository.findAll().stream()
            .map(notificationRuleMapper::notificationRuleToNotificationRuleDTO)
            .collect(Collectors.toCollection(LinkedList::new));

        return result;
    }

    /**
     *  Get one notificationRule by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public NotificationRuleDTO findOne(Long id) {
        log.debug("Request to get NotificationRule : {}", id);
        NotificationRule notificationRule = notificationRuleRepository.findOne(id);
        NotificationRuleDTO notificationRuleDTO = notificationRuleMapper.notificationRuleToNotificationRuleDTO(notificationRule);
        return notificationRuleDTO;
    }

    /**
     *  Delete the  notificationRule by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete NotificationRule : {}", id);
        notificationRuleRepository.delete(id);
        notificationRuleSearchRepository.delete(id);
    }

    /**
     * Search for the notificationRule corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<NotificationRuleDTO> search(String query) {
        log.debug("Request to search NotificationRules for query {}", query);
        return StreamSupport
            .stream(notificationRuleSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .map(notificationRuleMapper::notificationRuleToNotificationRuleDTO)
            .collect(Collectors.toList());
    }
}
