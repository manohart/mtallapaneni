package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.WebAppService;
import com.jpmorgan.am.grt.domain.WebApp;
import com.jpmorgan.am.grt.repository.WebAppRepository;
import com.jpmorgan.am.grt.repository.search.WebAppSearchRepository;
import com.jpmorgan.am.grt.service.dto.WebAppDTO;
import com.jpmorgan.am.grt.service.mapper.WebAppMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing WebApp.
 */
@Service
@Transactional
public class WebAppServiceImpl implements WebAppService{

    private final Logger log = LoggerFactory.getLogger(WebAppServiceImpl.class);
    
    @Inject
    private WebAppRepository webAppRepository;

    @Inject
    private WebAppMapper webAppMapper;

    @Inject
    private WebAppSearchRepository webAppSearchRepository;

    /**
     * Save a webApp.
     *
     * @param webAppDTO the entity to save
     * @return the persisted entity
     */
    public WebAppDTO save(WebAppDTO webAppDTO) {
        log.debug("Request to save WebApp : {}", webAppDTO);
        WebApp webApp = webAppMapper.webAppDTOToWebApp(webAppDTO);
        webApp = webAppRepository.save(webApp);
        WebAppDTO result = webAppMapper.webAppToWebAppDTO(webApp);
        webAppSearchRepository.save(webApp);
        return result;
    }

    /**
     *  Get all the webApps.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<WebAppDTO> findAll() {
        log.debug("Request to get all WebApps");
        List<WebAppDTO> result = webAppRepository.findAll().stream()
            .map(webAppMapper::webAppToWebAppDTO)
            .collect(Collectors.toCollection(LinkedList::new));

        return result;
    }

    /**
     *  Get one webApp by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public WebAppDTO findOne(Long id) {
        log.debug("Request to get WebApp : {}", id);
        WebApp webApp = webAppRepository.findOne(id);
        WebAppDTO webAppDTO = webAppMapper.webAppToWebAppDTO(webApp);
        return webAppDTO;
    }

    /**
     *  Delete the  webApp by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete WebApp : {}", id);
        webAppRepository.delete(id);
        webAppSearchRepository.delete(id);
    }

    /**
     * Search for the webApp corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<WebAppDTO> search(String query) {
        log.debug("Request to search WebApps for query {}", query);
        return StreamSupport
            .stream(webAppSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .map(webAppMapper::webAppToWebAppDTO)
            .collect(Collectors.toList());
    }
}
