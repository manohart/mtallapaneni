package com.jpmorgan.am.grt.service.mapper;

import com.jpmorgan.am.grt.domain.*;
import com.jpmorgan.am.grt.service.dto.ApplicationDTO;

import org.mapstruct.*;
import java.util.List;

/**
 * Mapper for the entity Application and its DTO ApplicationDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface ApplicationMapper {

    @Mapping(source = "lob.id", target = "lobId")
    @Mapping(source = "lob.name", target = "lobName")
    @Mapping(source = "devOps.id", target = "devOpsId")
    @Mapping(source = "devOps.name", target = "devOpsName")
    @Mapping(source = "appServer.id", target = "appServerId")
    @Mapping(source = "appServer.hostname", target = "appServerHostname")
    @Mapping(source = "dbServer.id", target = "dbServerId")
    @Mapping(source = "dbServer.hostname", target = "dbServerHostname")
    ApplicationDTO applicationToApplicationDTO(Application application);

    List<ApplicationDTO> applicationsToApplicationDTOs(List<Application> applications);

    @Mapping(target = "notificationRules", ignore = true)
    @Mapping(target = "dependents", ignore = true)
    @Mapping(source = "lobId", target = "lob")
    @Mapping(source = "devOpsId", target = "devOps")
    @Mapping(source = "appServerId", target = "appServer")
    @Mapping(source = "dbServerId", target = "dbServer")
    Application applicationDTOToApplication(ApplicationDTO applicationDTO);

    List<Application> applicationDTOsToApplications(List<ApplicationDTO> applicationDTOs);

    default Lob lobFromId(Long id) {
        if (id == null) {
            return null;
        }
        Lob lob = new Lob();
        lob.setId(id);
        return lob;
    }

    default DevOps devOpsFromId(Long id) {
        if (id == null) {
            return null;
        }
        DevOps devOps = new DevOps();
        devOps.setId(id);
        return devOps;
    }

    default Server serverFromId(Long id) {
        if (id == null) {
            return null;
        }
        Server server = new Server();
        server.setId(id);
        return server;
    }
}
