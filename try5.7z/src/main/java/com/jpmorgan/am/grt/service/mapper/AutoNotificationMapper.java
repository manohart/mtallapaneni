package com.jpmorgan.am.grt.service.mapper;

import com.jpmorgan.am.grt.domain.*;
import com.jpmorgan.am.grt.service.dto.AutoNotificationDTO;

import org.mapstruct.*;
import java.util.List;

/**
 * Mapper for the entity AutoNotification and its DTO AutoNotificationDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface AutoNotificationMapper {

    @Mapping(source = "rule.id", target = "ruleId")
    @Mapping(source = "rule.name", target = "ruleName")
    @Mapping(source = "lob.id", target = "lobId")
    @Mapping(source = "lob.name", target = "lobName")
    @Mapping(source = "application.id", target = "applicationId")
    @Mapping(source = "application.name", target = "applicationName")
    AutoNotificationDTO autoNotificationToAutoNotificationDTO(AutoNotification autoNotification);

    List<AutoNotificationDTO> autoNotificationsToAutoNotificationDTOs(List<AutoNotification> autoNotifications);

    @Mapping(source = "ruleId", target = "rule")
    @Mapping(source = "lobId", target = "lob")
    @Mapping(source = "applicationId", target = "application")
    AutoNotification autoNotificationDTOToAutoNotification(AutoNotificationDTO autoNotificationDTO);

    List<AutoNotification> autoNotificationDTOsToAutoNotifications(List<AutoNotificationDTO> autoNotificationDTOs);

    default NotificationRule notificationRuleFromId(Long id) {
        if (id == null) {
            return null;
        }
        NotificationRule notificationRule = new NotificationRule();
        notificationRule.setId(id);
        return notificationRule;
    }

    default Lob lobFromId(Long id) {
        if (id == null) {
            return null;
        }
        Lob lob = new Lob();
        lob.setId(id);
        return lob;
    }

    default Application applicationFromId(Long id) {
        if (id == null) {
            return null;
        }
        Application application = new Application();
        application.setId(id);
        return application;
    }
}
