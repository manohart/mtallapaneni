package com.jpmorgan.am.grt.service.mapper;

import com.jpmorgan.am.grt.domain.*;
import com.jpmorgan.am.grt.service.dto.BatchReportDetailHistoryDTO;

import org.mapstruct.*;
import java.util.List;

/**
 * Mapper for the entity BatchReportDetailHistory and its DTO BatchReportDetailHistoryDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface BatchReportDetailHistoryMapper {

    @Mapping(source = "summary.id", target = "summaryId")
    BatchReportDetailHistoryDTO batchReportDetailHistoryToBatchReportDetailHistoryDTO(BatchReportDetailHistory batchReportDetailHistory);

    List<BatchReportDetailHistoryDTO> batchReportDetailHistoriesToBatchReportDetailHistoryDTOs(List<BatchReportDetailHistory> batchReportDetailHistories);

    @Mapping(source = "summaryId", target = "summary")
    BatchReportDetailHistory batchReportDetailHistoryDTOToBatchReportDetailHistory(BatchReportDetailHistoryDTO batchReportDetailHistoryDTO);

    List<BatchReportDetailHistory> batchReportDetailHistoryDTOsToBatchReportDetailHistories(List<BatchReportDetailHistoryDTO> batchReportDetailHistoryDTOs);

    default BatchReportHistory batchReportHistoryFromId(Long id) {
        if (id == null) {
            return null;
        }
        BatchReportHistory batchReportHistory = new BatchReportHistory();
        batchReportHistory.setId(id);
        return batchReportHistory;
    }
}
