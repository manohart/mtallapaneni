package com.jpmorgan.am.grt.service.mapper;

import com.jpmorgan.am.grt.domain.*;
import com.jpmorgan.am.grt.service.dto.BatchReportHistoryDTO;

import org.mapstruct.*;
import java.util.List;

/**
 * Mapper for the entity BatchReportHistory and its DTO BatchReportHistoryDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface BatchReportHistoryMapper {

    @Mapping(source = "reportConfig.id", target = "reportConfigId")
    @Mapping(source = "reportConfig.name", target = "reportConfigName")
    BatchReportHistoryDTO batchReportHistoryToBatchReportHistoryDTO(BatchReportHistory batchReportHistory);

    List<BatchReportHistoryDTO> batchReportHistoriesToBatchReportHistoryDTOs(List<BatchReportHistory> batchReportHistories);

    @Mapping(target = "details", ignore = true)
    @Mapping(source = "reportConfigId", target = "reportConfig")
    BatchReportHistory batchReportHistoryDTOToBatchReportHistory(BatchReportHistoryDTO batchReportHistoryDTO);

    List<BatchReportHistory> batchReportHistoryDTOsToBatchReportHistories(List<BatchReportHistoryDTO> batchReportHistoryDTOs);

    default BatchReport batchReportFromId(Long id) {
        if (id == null) {
            return null;
        }
        BatchReport batchReport = new BatchReport();
        batchReport.setId(id);
        return batchReport;
    }
}
