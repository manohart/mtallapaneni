package com.jpmorgan.am.grt.service.mapper;

import com.jpmorgan.am.grt.domain.*;
import com.jpmorgan.am.grt.service.dto.DevOpsDTO;

import org.mapstruct.*;
import java.util.List;

/**
 * Mapper for the entity DevOps and its DTO DevOpsDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface DevOpsMapper {

    @Mapping(source = "techonology.id", target = "techonologyId")
    @Mapping(source = "techonology.name", target = "techonologyName")
    @Mapping(source = "support.id", target = "supportId")
    @Mapping(source = "support.name", target = "supportName")
    @Mapping(source = "business.id", target = "businessId")
    @Mapping(source = "business.name", target = "businessName")
    @Mapping(source = "lob.id", target = "lobId")
    @Mapping(source = "lob.name", target = "lobName")
    DevOpsDTO devOpsToDevOpsDTO(DevOps devOps);

    List<DevOpsDTO> devOpsToDevOpsDTOs(List<DevOps> devOps);

    @Mapping(target = "applications", ignore = true)
    @Mapping(source = "techonologyId", target = "techonology")
    @Mapping(source = "supportId", target = "support")
    @Mapping(source = "businessId", target = "business")
    @Mapping(source = "lobId", target = "lob")
    DevOps devOpsDTOToDevOps(DevOpsDTO devOpsDTO);

    List<DevOps> devOpsDTOsToDevOps(List<DevOpsDTO> devOpsDTOs);

    default Team teamFromId(Long id) {
        if (id == null) {
            return null;
        }
        Team team = new Team();
        team.setId(id);
        return team;
    }

    default Lob lobFromId(Long id) {
        if (id == null) {
            return null;
        }
        Lob lob = new Lob();
        lob.setId(id);
        return lob;
    }
}
