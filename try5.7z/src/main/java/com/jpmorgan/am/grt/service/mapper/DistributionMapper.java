package com.jpmorgan.am.grt.service.mapper;

import com.jpmorgan.am.grt.domain.*;
import com.jpmorgan.am.grt.service.dto.DistributionDTO;

import org.mapstruct.*;
import java.util.List;

/**
 * Mapper for the entity Distribution and its DTO DistributionDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface DistributionMapper {

    @Mapping(source = "batchJob.id", target = "batchJobId")
    DistributionDTO distributionToDistributionDTO(Distribution distribution);

    List<DistributionDTO> distributionsToDistributionDTOs(List<Distribution> distributions);

    @Mapping(source = "batchJobId", target = "batchJob")
    Distribution distributionDTOToDistribution(DistributionDTO distributionDTO);

    List<Distribution> distributionDTOsToDistributions(List<DistributionDTO> distributionDTOs);

    default BatchJob batchJobFromId(Long id) {
        if (id == null) {
            return null;
        }
        BatchJob batchJob = new BatchJob();
        batchJob.setId(id);
        return batchJob;
    }
}
