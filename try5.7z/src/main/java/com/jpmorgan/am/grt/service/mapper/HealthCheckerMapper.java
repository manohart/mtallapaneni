package com.jpmorgan.am.grt.service.mapper;

import com.jpmorgan.am.grt.domain.*;
import com.jpmorgan.am.grt.service.dto.HealthCheckerDTO;

import org.mapstruct.*;
import java.util.List;

/**
 * Mapper for the entity HealthChecker and its DTO HealthCheckerDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface HealthCheckerMapper {

    HealthCheckerDTO healthCheckerToHealthCheckerDTO(HealthChecker healthChecker);

    List<HealthCheckerDTO> healthCheckersToHealthCheckerDTOs(List<HealthChecker> healthCheckers);

    HealthChecker healthCheckerDTOToHealthChecker(HealthCheckerDTO healthCheckerDTO);

    List<HealthChecker> healthCheckerDTOsToHealthCheckers(List<HealthCheckerDTO> healthCheckerDTOs);
}
