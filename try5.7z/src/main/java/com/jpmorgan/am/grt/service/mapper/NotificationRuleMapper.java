package com.jpmorgan.am.grt.service.mapper;

import com.jpmorgan.am.grt.domain.*;
import com.jpmorgan.am.grt.service.dto.NotificationRuleDTO;

import org.mapstruct.*;
import java.util.List;

/**
 * Mapper for the entity NotificationRule and its DTO NotificationRuleDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface NotificationRuleMapper {

    NotificationRuleDTO notificationRuleToNotificationRuleDTO(NotificationRule notificationRule);

    List<NotificationRuleDTO> notificationRulesToNotificationRuleDTOs(List<NotificationRule> notificationRules);

    NotificationRule notificationRuleDTOToNotificationRule(NotificationRuleDTO notificationRuleDTO);

    List<NotificationRule> notificationRuleDTOsToNotificationRules(List<NotificationRuleDTO> notificationRuleDTOs);
}
