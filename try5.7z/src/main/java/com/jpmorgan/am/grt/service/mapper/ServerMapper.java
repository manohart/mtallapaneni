package com.jpmorgan.am.grt.service.mapper;

import com.jpmorgan.am.grt.domain.*;
import com.jpmorgan.am.grt.service.dto.ServerDTO;

import org.mapstruct.*;
import java.util.List;

/**
 * Mapper for the entity Server and its DTO ServerDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface ServerMapper {

    @Mapping(source = "lob.id", target = "lobId")
    @Mapping(source = "lob.name", target = "lobName")
    ServerDTO serverToServerDTO(Server server);

    List<ServerDTO> serversToServerDTOs(List<Server> servers);

    @Mapping(target = "appApps", ignore = true)
    @Mapping(target = "dbApps", ignore = true)
    @Mapping(source = "lobId", target = "lob")
    Server serverDTOToServer(ServerDTO serverDTO);

    List<Server> serverDTOsToServers(List<ServerDTO> serverDTOs);

    default Lob lobFromId(Long id) {
        if (id == null) {
            return null;
        }
        Lob lob = new Lob();
        lob.setId(id);
        return lob;
    }
}
