package com.jpmorgan.am.grt.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.jpmorgan.am.grt.service.AutoNotificationService;
import com.jpmorgan.am.grt.web.rest.util.HeaderUtil;
import com.jpmorgan.am.grt.service.dto.AutoNotificationDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * REST controller for managing AutoNotification.
 */
@RestController
@RequestMapping("/api")
public class AutoNotificationResource {

    private final Logger log = LoggerFactory.getLogger(AutoNotificationResource.class);
        
    @Inject
    private AutoNotificationService autoNotificationService;

    /**
     * POST  /auto-notifications : Create a new autoNotification.
     *
     * @param autoNotificationDTO the autoNotificationDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new autoNotificationDTO, or with status 400 (Bad Request) if the autoNotification has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/auto-notifications",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<AutoNotificationDTO> createAutoNotification(@Valid @RequestBody AutoNotificationDTO autoNotificationDTO) throws URISyntaxException {
        log.debug("REST request to save AutoNotification : {}", autoNotificationDTO);
        if (autoNotificationDTO.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("autoNotification", "idexists", "A new autoNotification cannot already have an ID")).body(null);
        }
        AutoNotificationDTO result = autoNotificationService.save(autoNotificationDTO);
        return ResponseEntity.created(new URI("/api/auto-notifications/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("autoNotification", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /auto-notifications : Updates an existing autoNotification.
     *
     * @param autoNotificationDTO the autoNotificationDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated autoNotificationDTO,
     * or with status 400 (Bad Request) if the autoNotificationDTO is not valid,
     * or with status 500 (Internal Server Error) if the autoNotificationDTO couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/auto-notifications",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<AutoNotificationDTO> updateAutoNotification(@Valid @RequestBody AutoNotificationDTO autoNotificationDTO) throws URISyntaxException {
        log.debug("REST request to update AutoNotification : {}", autoNotificationDTO);
        if (autoNotificationDTO.getId() == null) {
            return createAutoNotification(autoNotificationDTO);
        }
        AutoNotificationDTO result = autoNotificationService.save(autoNotificationDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("autoNotification", autoNotificationDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /auto-notifications : get all the autoNotifications.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of autoNotifications in body
     */
    @RequestMapping(value = "/auto-notifications",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<AutoNotificationDTO> getAllAutoNotifications() {
        log.debug("REST request to get all AutoNotifications");
        return autoNotificationService.findAll();
    }

    /**
     * GET  /auto-notifications/:id : get the "id" autoNotification.
     *
     * @param id the id of the autoNotificationDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the autoNotificationDTO, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/auto-notifications/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<AutoNotificationDTO> getAutoNotification(@PathVariable Long id) {
        log.debug("REST request to get AutoNotification : {}", id);
        AutoNotificationDTO autoNotificationDTO = autoNotificationService.findOne(id);
        return Optional.ofNullable(autoNotificationDTO)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /auto-notifications/:id : delete the "id" autoNotification.
     *
     * @param id the id of the autoNotificationDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/auto-notifications/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteAutoNotification(@PathVariable Long id) {
        log.debug("REST request to delete AutoNotification : {}", id);
        autoNotificationService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("autoNotification", id.toString())).build();
    }

    /**
     * SEARCH  /_search/auto-notifications?query=:query : search for the autoNotification corresponding
     * to the query.
     *
     * @param query the query of the autoNotification search 
     * @return the result of the search
     */
    @RequestMapping(value = "/_search/auto-notifications",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<AutoNotificationDTO> searchAutoNotifications(@RequestParam String query) {
        log.debug("REST request to search AutoNotifications for query {}", query);
        return autoNotificationService.search(query);
    }


}
