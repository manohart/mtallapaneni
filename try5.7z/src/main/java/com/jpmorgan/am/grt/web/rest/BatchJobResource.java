package com.jpmorgan.am.grt.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.jpmorgan.am.grt.service.BatchJobService;
import com.jpmorgan.am.grt.web.rest.util.HeaderUtil;
import com.jpmorgan.am.grt.service.dto.BatchJobDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * REST controller for managing BatchJob.
 */
@RestController
@RequestMapping("/api")
public class BatchJobResource {

    private final Logger log = LoggerFactory.getLogger(BatchJobResource.class);
        
    @Inject
    private BatchJobService batchJobService;

    /**
     * POST  /batch-jobs : Create a new batchJob.
     *
     * @param batchJobDTO the batchJobDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new batchJobDTO, or with status 400 (Bad Request) if the batchJob has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/batch-jobs",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<BatchJobDTO> createBatchJob(@Valid @RequestBody BatchJobDTO batchJobDTO) throws URISyntaxException {
        log.debug("REST request to save BatchJob : {}", batchJobDTO);
        if (batchJobDTO.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("batchJob", "idexists", "A new batchJob cannot already have an ID")).body(null);
        }
        BatchJobDTO result = batchJobService.save(batchJobDTO);
        return ResponseEntity.created(new URI("/api/batch-jobs/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("batchJob", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /batch-jobs : Updates an existing batchJob.
     *
     * @param batchJobDTO the batchJobDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated batchJobDTO,
     * or with status 400 (Bad Request) if the batchJobDTO is not valid,
     * or with status 500 (Internal Server Error) if the batchJobDTO couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/batch-jobs",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<BatchJobDTO> updateBatchJob(@Valid @RequestBody BatchJobDTO batchJobDTO) throws URISyntaxException {
        log.debug("REST request to update BatchJob : {}", batchJobDTO);
        if (batchJobDTO.getId() == null) {
            return createBatchJob(batchJobDTO);
        }
        BatchJobDTO result = batchJobService.save(batchJobDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("batchJob", batchJobDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /batch-jobs : get all the batchJobs.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of batchJobs in body
     */
    @RequestMapping(value = "/batch-jobs",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<BatchJobDTO> getAllBatchJobs() {
        log.debug("REST request to get all BatchJobs");
        return batchJobService.findAll();
    }

    /**
     * GET  /batch-jobs/:id : get the "id" batchJob.
     *
     * @param id the id of the batchJobDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the batchJobDTO, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/batch-jobs/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<BatchJobDTO> getBatchJob(@PathVariable Long id) {
        log.debug("REST request to get BatchJob : {}", id);
        BatchJobDTO batchJobDTO = batchJobService.findOne(id);
        return Optional.ofNullable(batchJobDTO)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /batch-jobs/:id : delete the "id" batchJob.
     *
     * @param id the id of the batchJobDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/batch-jobs/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteBatchJob(@PathVariable Long id) {
        log.debug("REST request to delete BatchJob : {}", id);
        batchJobService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("batchJob", id.toString())).build();
    }

    /**
     * SEARCH  /_search/batch-jobs?query=:query : search for the batchJob corresponding
     * to the query.
     *
     * @param query the query of the batchJob search 
     * @return the result of the search
     */
    @RequestMapping(value = "/_search/batch-jobs",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<BatchJobDTO> searchBatchJobs(@RequestParam String query) {
        log.debug("REST request to search BatchJobs for query {}", query);
        return batchJobService.search(query);
    }


}
