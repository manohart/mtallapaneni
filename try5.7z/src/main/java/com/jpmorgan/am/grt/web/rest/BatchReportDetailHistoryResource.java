package com.jpmorgan.am.grt.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.jpmorgan.am.grt.service.BatchReportDetailHistoryService;
import com.jpmorgan.am.grt.web.rest.util.HeaderUtil;
import com.jpmorgan.am.grt.service.dto.BatchReportDetailHistoryDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * REST controller for managing BatchReportDetailHistory.
 */
@RestController
@RequestMapping("/api")
public class BatchReportDetailHistoryResource {

    private final Logger log = LoggerFactory.getLogger(BatchReportDetailHistoryResource.class);
        
    @Inject
    private BatchReportDetailHistoryService batchReportDetailHistoryService;

    /**
     * POST  /batch-report-detail-histories : Create a new batchReportDetailHistory.
     *
     * @param batchReportDetailHistoryDTO the batchReportDetailHistoryDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new batchReportDetailHistoryDTO, or with status 400 (Bad Request) if the batchReportDetailHistory has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/batch-report-detail-histories",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<BatchReportDetailHistoryDTO> createBatchReportDetailHistory(@Valid @RequestBody BatchReportDetailHistoryDTO batchReportDetailHistoryDTO) throws URISyntaxException {
        log.debug("REST request to save BatchReportDetailHistory : {}", batchReportDetailHistoryDTO);
        if (batchReportDetailHistoryDTO.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("batchReportDetailHistory", "idexists", "A new batchReportDetailHistory cannot already have an ID")).body(null);
        }
        BatchReportDetailHistoryDTO result = batchReportDetailHistoryService.save(batchReportDetailHistoryDTO);
        return ResponseEntity.created(new URI("/api/batch-report-detail-histories/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("batchReportDetailHistory", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /batch-report-detail-histories : Updates an existing batchReportDetailHistory.
     *
     * @param batchReportDetailHistoryDTO the batchReportDetailHistoryDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated batchReportDetailHistoryDTO,
     * or with status 400 (Bad Request) if the batchReportDetailHistoryDTO is not valid,
     * or with status 500 (Internal Server Error) if the batchReportDetailHistoryDTO couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/batch-report-detail-histories",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<BatchReportDetailHistoryDTO> updateBatchReportDetailHistory(@Valid @RequestBody BatchReportDetailHistoryDTO batchReportDetailHistoryDTO) throws URISyntaxException {
        log.debug("REST request to update BatchReportDetailHistory : {}", batchReportDetailHistoryDTO);
        if (batchReportDetailHistoryDTO.getId() == null) {
            return createBatchReportDetailHistory(batchReportDetailHistoryDTO);
        }
        BatchReportDetailHistoryDTO result = batchReportDetailHistoryService.save(batchReportDetailHistoryDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("batchReportDetailHistory", batchReportDetailHistoryDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /batch-report-detail-histories : get all the batchReportDetailHistories.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of batchReportDetailHistories in body
     */
    @RequestMapping(value = "/batch-report-detail-histories",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<BatchReportDetailHistoryDTO> getAllBatchReportDetailHistories() {
        log.debug("REST request to get all BatchReportDetailHistories");
        return batchReportDetailHistoryService.findAll();
    }

    /**
     * GET  /batch-report-detail-histories/:id : get the "id" batchReportDetailHistory.
     *
     * @param id the id of the batchReportDetailHistoryDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the batchReportDetailHistoryDTO, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/batch-report-detail-histories/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<BatchReportDetailHistoryDTO> getBatchReportDetailHistory(@PathVariable Long id) {
        log.debug("REST request to get BatchReportDetailHistory : {}", id);
        BatchReportDetailHistoryDTO batchReportDetailHistoryDTO = batchReportDetailHistoryService.findOne(id);
        return Optional.ofNullable(batchReportDetailHistoryDTO)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /batch-report-detail-histories/:id : delete the "id" batchReportDetailHistory.
     *
     * @param id the id of the batchReportDetailHistoryDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/batch-report-detail-histories/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteBatchReportDetailHistory(@PathVariable Long id) {
        log.debug("REST request to delete BatchReportDetailHistory : {}", id);
        batchReportDetailHistoryService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("batchReportDetailHistory", id.toString())).build();
    }

    /**
     * SEARCH  /_search/batch-report-detail-histories?query=:query : search for the batchReportDetailHistory corresponding
     * to the query.
     *
     * @param query the query of the batchReportDetailHistory search 
     * @return the result of the search
     */
    @RequestMapping(value = "/_search/batch-report-detail-histories",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<BatchReportDetailHistoryDTO> searchBatchReportDetailHistories(@RequestParam String query) {
        log.debug("REST request to search BatchReportDetailHistories for query {}", query);
        return batchReportDetailHistoryService.search(query);
    }


}
