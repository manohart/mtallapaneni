package com.jpmorgan.am.grt.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.jpmorgan.am.grt.service.WebAppService;
import com.jpmorgan.am.grt.web.rest.util.HeaderUtil;
import com.jpmorgan.am.grt.service.dto.WebAppDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * REST controller for managing WebApp.
 */
@RestController
@RequestMapping("/api")
public class WebAppResource {

    private final Logger log = LoggerFactory.getLogger(WebAppResource.class);
        
    @Inject
    private WebAppService webAppService;

    /**
     * POST  /web-apps : Create a new webApp.
     *
     * @param webAppDTO the webAppDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new webAppDTO, or with status 400 (Bad Request) if the webApp has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/web-apps",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<WebAppDTO> createWebApp(@Valid @RequestBody WebAppDTO webAppDTO) throws URISyntaxException {
        log.debug("REST request to save WebApp : {}", webAppDTO);
        if (webAppDTO.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("webApp", "idexists", "A new webApp cannot already have an ID")).body(null);
        }
        WebAppDTO result = webAppService.save(webAppDTO);
        return ResponseEntity.created(new URI("/api/web-apps/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("webApp", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /web-apps : Updates an existing webApp.
     *
     * @param webAppDTO the webAppDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated webAppDTO,
     * or with status 400 (Bad Request) if the webAppDTO is not valid,
     * or with status 500 (Internal Server Error) if the webAppDTO couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/web-apps",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<WebAppDTO> updateWebApp(@Valid @RequestBody WebAppDTO webAppDTO) throws URISyntaxException {
        log.debug("REST request to update WebApp : {}", webAppDTO);
        if (webAppDTO.getId() == null) {
            return createWebApp(webAppDTO);
        }
        WebAppDTO result = webAppService.save(webAppDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("webApp", webAppDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /web-apps : get all the webApps.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of webApps in body
     */
    @RequestMapping(value = "/web-apps",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<WebAppDTO> getAllWebApps() {
        log.debug("REST request to get all WebApps");
        return webAppService.findAll();
    }

    /**
     * GET  /web-apps/:id : get the "id" webApp.
     *
     * @param id the id of the webAppDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the webAppDTO, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/web-apps/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<WebAppDTO> getWebApp(@PathVariable Long id) {
        log.debug("REST request to get WebApp : {}", id);
        WebAppDTO webAppDTO = webAppService.findOne(id);
        return Optional.ofNullable(webAppDTO)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /web-apps/:id : delete the "id" webApp.
     *
     * @param id the id of the webAppDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/web-apps/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteWebApp(@PathVariable Long id) {
        log.debug("REST request to delete WebApp : {}", id);
        webAppService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("webApp", id.toString())).build();
    }

    /**
     * SEARCH  /_search/web-apps?query=:query : search for the webApp corresponding
     * to the query.
     *
     * @param query the query of the webApp search 
     * @return the result of the search
     */
    @RequestMapping(value = "/_search/web-apps",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<WebAppDTO> searchWebApps(@RequestParam String query) {
        log.debug("REST request to search WebApps for query {}", query);
        return webAppService.search(query);
    }


}
