package com.jpmorgan.am.grt.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.springframework.data.elasticsearch.annotations.Document;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

import com.jpmorgan.am.grt.domain.enumeration.DbCheckExpectation;

/**
 * A DbCheck.
 */
@Entity
@Table(name = "db_check")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@Document(indexName = "dbcheck")
public class DbCheck implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "name", nullable = false)
    private String name;

    @NotNull
    @Column(name = "description", nullable = false)
    private String description;

    @NotNull
    @Column(name = "sql_query", nullable = false)
    private String sqlQuery;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "expectation", nullable = false)
    private DbCheckExpectation expectation;

    @Column(name = "report_issues_only")
    private Boolean reportIssuesOnly;

    @Column(name = "group_columns")
    private String groupColumns;

    @NotNull
    @Min(value = 0)
    @Column(name = "sequence", nullable = false)
    private Integer sequence;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "updated_date")
    private ZonedDateTime updatedDate;

    @OneToMany(mappedBy = "dbCheck")
    @JsonIgnore
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<HealthCheckConfig> healthCheckConfigs = new HashSet<>();

    @ManyToOne
    private WebService executorService;

    @ManyToOne
    private HealthChecker healthChecker;

    @ManyToOne
    private BatchReport batchReport;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSqlQuery() {
        return sqlQuery;
    }

    public void setSqlQuery(String sqlQuery) {
        this.sqlQuery = sqlQuery;
    }

    public DbCheckExpectation getExpectation() {
        return expectation;
    }

    public void setExpectation(DbCheckExpectation expectation) {
        this.expectation = expectation;
    }

    public Boolean isReportIssuesOnly() {
        return reportIssuesOnly;
    }

    public void setReportIssuesOnly(Boolean reportIssuesOnly) {
        this.reportIssuesOnly = reportIssuesOnly;
    }

    public String getGroupColumns() {
        return groupColumns;
    }

    public void setGroupColumns(String groupColumns) {
        this.groupColumns = groupColumns;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public Boolean isIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public ZonedDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(ZonedDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Set<HealthCheckConfig> getHealthCheckConfigs() {
        return healthCheckConfigs;
    }

    public void setHealthCheckConfigs(Set<HealthCheckConfig> healthCheckConfigs) {
        this.healthCheckConfigs = healthCheckConfigs;
    }

    public WebService getExecutorService() {
        return executorService;
    }

    public void setExecutorService(WebService webService) {
        this.executorService = webService;
    }

    public HealthChecker getHealthChecker() {
        return healthChecker;
    }

    public void setHealthChecker(HealthChecker healthChecker) {
        this.healthChecker = healthChecker;
    }

    public BatchReport getBatchReport() {
        return batchReport;
    }

    public void setBatchReport(BatchReport batchReport) {
        this.batchReport = batchReport;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        DbCheck dbCheck = (DbCheck) o;
        if(dbCheck.id == null || id == null) {
            return false;
        }
        return Objects.equals(id, dbCheck.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "DbCheck{" +
            "id=" + id +
            ", name='" + name + "'" +
            ", description='" + description + "'" +
            ", sqlQuery='" + sqlQuery + "'" +
            ", expectation='" + expectation + "'" +
            ", reportIssuesOnly='" + reportIssuesOnly + "'" +
            ", groupColumns='" + groupColumns + "'" +
            ", sequence='" + sequence + "'" +
            ", isActive='" + isActive + "'" +
            ", updatedDate='" + updatedDate + "'" +
            '}';
    }
}
