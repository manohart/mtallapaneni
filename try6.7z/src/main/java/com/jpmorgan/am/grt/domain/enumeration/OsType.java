package com.jpmorgan.am.grt.domain.enumeration;

/**
 * The OsType enumeration.
 */
public enum OsType {
    WINDOWS,LINUX,UNIX,OTHERS
}
