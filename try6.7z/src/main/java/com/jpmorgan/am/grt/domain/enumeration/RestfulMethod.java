package com.jpmorgan.am.grt.domain.enumeration;

/**
 * The RestfulMethod enumeration.
 */
public enum RestfulMethod {
    GET,POST,PUT,DELETE
}
