package com.jpmorgan.am.grt.domain.enumeration;

/**
 * The ServerType enumeration.
 */
public enum ServerType {
    APP,DB,BOTH
}
