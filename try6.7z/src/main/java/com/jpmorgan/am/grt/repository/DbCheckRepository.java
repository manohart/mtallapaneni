package com.jpmorgan.am.grt.repository;

import com.jpmorgan.am.grt.domain.DbCheck;

import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the DbCheck entity.
 */
@SuppressWarnings("unused")
public interface DbCheckRepository extends JpaRepository<DbCheck,Long> {

}
