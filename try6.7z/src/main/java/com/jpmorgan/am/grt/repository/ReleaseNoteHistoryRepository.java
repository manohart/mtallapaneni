package com.jpmorgan.am.grt.repository;

import com.jpmorgan.am.grt.domain.ReleaseNoteHistory;

import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the ReleaseNoteHistory entity.
 */
@SuppressWarnings("unused")
public interface ReleaseNoteHistoryRepository extends JpaRepository<ReleaseNoteHistory,Long> {

}
