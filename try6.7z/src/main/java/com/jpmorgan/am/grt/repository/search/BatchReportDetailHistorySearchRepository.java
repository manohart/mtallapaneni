package com.jpmorgan.am.grt.repository.search;

import com.jpmorgan.am.grt.domain.BatchReportDetailHistory;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * Spring Data ElasticSearch repository for the BatchReportDetailHistory entity.
 */
public interface BatchReportDetailHistorySearchRepository extends ElasticsearchRepository<BatchReportDetailHistory, Long> {
}
