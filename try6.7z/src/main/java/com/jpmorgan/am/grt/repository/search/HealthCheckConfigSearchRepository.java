package com.jpmorgan.am.grt.repository.search;

import com.jpmorgan.am.grt.domain.HealthCheckConfig;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * Spring Data ElasticSearch repository for the HealthCheckConfig entity.
 */
public interface HealthCheckConfigSearchRepository extends ElasticsearchRepository<HealthCheckConfig, Long> {
}
