package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.domain.AppDependency;

import java.util.List;

/**
 * Service Interface for managing AppDependency.
 */
public interface AppDependencyService {

    /**
     * Save a appDependency.
     *
     * @param appDependency the entity to save
     * @return the persisted entity
     */
    AppDependency save(AppDependency appDependency);

    /**
     *  Get all the appDependencies.
     *  
     *  @return the list of entities
     */
    List<AppDependency> findAll();

    /**
     *  Get the "id" appDependency.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    AppDependency findOne(Long id);

    /**
     *  Delete the "id" appDependency.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the appDependency corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<AppDependency> search(String query);
}
