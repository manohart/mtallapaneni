package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.domain.AutoNotification;

import java.util.List;

/**
 * Service Interface for managing AutoNotification.
 */
public interface AutoNotificationService {

    /**
     * Save a autoNotification.
     *
     * @param autoNotification the entity to save
     * @return the persisted entity
     */
    AutoNotification save(AutoNotification autoNotification);

    /**
     *  Get all the autoNotifications.
     *  
     *  @return the list of entities
     */
    List<AutoNotification> findAll();

    /**
     *  Get the "id" autoNotification.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    AutoNotification findOne(Long id);

    /**
     *  Delete the "id" autoNotification.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the autoNotification corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<AutoNotification> search(String query);
}
