package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.domain.BatchReport;

import java.util.List;

/**
 * Service Interface for managing BatchReport.
 */
public interface BatchReportService {

    /**
     * Save a batchReport.
     *
     * @param batchReport the entity to save
     * @return the persisted entity
     */
    BatchReport save(BatchReport batchReport);

    /**
     *  Get all the batchReports.
     *  
     *  @return the list of entities
     */
    List<BatchReport> findAll();

    /**
     *  Get the "id" batchReport.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    BatchReport findOne(Long id);

    /**
     *  Delete the "id" batchReport.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the batchReport corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<BatchReport> search(String query);
}
