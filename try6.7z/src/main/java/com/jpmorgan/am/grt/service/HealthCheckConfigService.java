package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.domain.HealthCheckConfig;

import java.util.List;

/**
 * Service Interface for managing HealthCheckConfig.
 */
public interface HealthCheckConfigService {

    /**
     * Save a healthCheckConfig.
     *
     * @param healthCheckConfig the entity to save
     * @return the persisted entity
     */
    HealthCheckConfig save(HealthCheckConfig healthCheckConfig);

    /**
     *  Get all the healthCheckConfigs.
     *  
     *  @return the list of entities
     */
    List<HealthCheckConfig> findAll();

    /**
     *  Get the "id" healthCheckConfig.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    HealthCheckConfig findOne(Long id);

    /**
     *  Delete the "id" healthCheckConfig.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the healthCheckConfig corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<HealthCheckConfig> search(String query);
}
