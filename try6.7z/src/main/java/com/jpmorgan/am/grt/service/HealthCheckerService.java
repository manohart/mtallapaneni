package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.domain.HealthChecker;

import java.util.List;

/**
 * Service Interface for managing HealthChecker.
 */
public interface HealthCheckerService {

    /**
     * Save a healthChecker.
     *
     * @param healthChecker the entity to save
     * @return the persisted entity
     */
    HealthChecker save(HealthChecker healthChecker);

    /**
     *  Get all the healthCheckers.
     *  
     *  @return the list of entities
     */
    List<HealthChecker> findAll();

    /**
     *  Get the "id" healthChecker.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    HealthChecker findOne(Long id);

    /**
     *  Delete the "id" healthChecker.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the healthChecker corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<HealthChecker> search(String query);
}
