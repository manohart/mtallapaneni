package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.domain.NotificationRule;

import java.util.List;

/**
 * Service Interface for managing NotificationRule.
 */
public interface NotificationRuleService {

    /**
     * Save a notificationRule.
     *
     * @param notificationRule the entity to save
     * @return the persisted entity
     */
    NotificationRule save(NotificationRule notificationRule);

    /**
     *  Get all the notificationRules.
     *  
     *  @return the list of entities
     */
    List<NotificationRule> findAll();

    /**
     *  Get the "id" notificationRule.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    NotificationRule findOne(Long id);

    /**
     *  Delete the "id" notificationRule.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the notificationRule corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<NotificationRule> search(String query);
}
