package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.domain.ReleaseNoteHistory;

import java.util.List;

/**
 * Service Interface for managing ReleaseNoteHistory.
 */
public interface ReleaseNoteHistoryService {

    /**
     * Save a releaseNoteHistory.
     *
     * @param releaseNoteHistory the entity to save
     * @return the persisted entity
     */
    ReleaseNoteHistory save(ReleaseNoteHistory releaseNoteHistory);

    /**
     *  Get all the releaseNoteHistories.
     *  
     *  @return the list of entities
     */
    List<ReleaseNoteHistory> findAll();

    /**
     *  Get the "id" releaseNoteHistory.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    ReleaseNoteHistory findOne(Long id);

    /**
     *  Delete the "id" releaseNoteHistory.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the releaseNoteHistory corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<ReleaseNoteHistory> search(String query);
}
