package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.domain.Server;

import java.util.List;

/**
 * Service Interface for managing Server.
 */
public interface ServerService {

    /**
     * Save a server.
     *
     * @param server the entity to save
     * @return the persisted entity
     */
    Server save(Server server);

    /**
     *  Get all the servers.
     *  
     *  @return the list of entities
     */
    List<Server> findAll();

    /**
     *  Get the "id" server.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    Server findOne(Long id);

    /**
     *  Delete the "id" server.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the server corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<Server> search(String query);
}
