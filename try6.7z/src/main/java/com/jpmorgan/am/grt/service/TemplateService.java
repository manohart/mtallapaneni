package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.domain.Template;

import java.util.List;

/**
 * Service Interface for managing Template.
 */
public interface TemplateService {

    /**
     * Save a template.
     *
     * @param template the entity to save
     * @return the persisted entity
     */
    Template save(Template template);

    /**
     *  Get all the templates.
     *  
     *  @return the list of entities
     */
    List<Template> findAll();

    /**
     *  Get the "id" template.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    Template findOne(Long id);

    /**
     *  Delete the "id" template.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the template corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<Template> search(String query);
}
