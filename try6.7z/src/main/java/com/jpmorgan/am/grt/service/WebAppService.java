package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.domain.WebApp;

import java.util.List;

/**
 * Service Interface for managing WebApp.
 */
public interface WebAppService {

    /**
     * Save a webApp.
     *
     * @param webApp the entity to save
     * @return the persisted entity
     */
    WebApp save(WebApp webApp);

    /**
     *  Get all the webApps.
     *  
     *  @return the list of entities
     */
    List<WebApp> findAll();

    /**
     *  Get the "id" webApp.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    WebApp findOne(Long id);

    /**
     *  Delete the "id" webApp.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the webApp corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<WebApp> search(String query);
}
