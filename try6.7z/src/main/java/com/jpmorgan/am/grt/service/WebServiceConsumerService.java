package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.domain.WebServiceConsumer;

import java.util.List;

/**
 * Service Interface for managing WebServiceConsumer.
 */
public interface WebServiceConsumerService {

    /**
     * Save a webServiceConsumer.
     *
     * @param webServiceConsumer the entity to save
     * @return the persisted entity
     */
    WebServiceConsumer save(WebServiceConsumer webServiceConsumer);

    /**
     *  Get all the webServiceConsumers.
     *  
     *  @return the list of entities
     */
    List<WebServiceConsumer> findAll();

    /**
     *  Get the "id" webServiceConsumer.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    WebServiceConsumer findOne(Long id);

    /**
     *  Delete the "id" webServiceConsumer.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the webServiceConsumer corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<WebServiceConsumer> search(String query);
}
