package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.domain.WebService;

import java.util.List;

/**
 * Service Interface for managing WebService.
 */
public interface WebServiceService {

    /**
     * Save a webService.
     *
     * @param webService the entity to save
     * @return the persisted entity
     */
    WebService save(WebService webService);

    /**
     *  Get all the webServices.
     *  
     *  @return the list of entities
     */
    List<WebService> findAll();

    /**
     *  Get the "id" webService.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    WebService findOne(Long id);

    /**
     *  Delete the "id" webService.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the webService corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<WebService> search(String query);
}
