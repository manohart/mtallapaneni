package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.ApplicationService;
import com.jpmorgan.am.grt.domain.Application;
import com.jpmorgan.am.grt.repository.ApplicationRepository;
import com.jpmorgan.am.grt.repository.search.ApplicationSearchRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing Application.
 */
@Service
@Transactional
public class ApplicationServiceImpl implements ApplicationService{

    private final Logger log = LoggerFactory.getLogger(ApplicationServiceImpl.class);
    
    @Inject
    private ApplicationRepository applicationRepository;

    @Inject
    private ApplicationSearchRepository applicationSearchRepository;

    /**
     * Save a application.
     *
     * @param application the entity to save
     * @return the persisted entity
     */
    public Application save(Application application) {
        log.debug("Request to save Application : {}", application);
        Application result = applicationRepository.save(application);
        applicationSearchRepository.save(result);
        return result;
    }

    /**
     *  Get all the applications.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<Application> findAll() {
        log.debug("Request to get all Applications");
        List<Application> result = applicationRepository.findAll();

        return result;
    }

    /**
     *  Get one application by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public Application findOne(Long id) {
        log.debug("Request to get Application : {}", id);
        Application application = applicationRepository.findOne(id);
        return application;
    }

    /**
     *  Delete the  application by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete Application : {}", id);
        applicationRepository.delete(id);
        applicationSearchRepository.delete(id);
    }

    /**
     * Search for the application corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<Application> search(String query) {
        log.debug("Request to search Applications for query {}", query);
        return StreamSupport
            .stream(applicationSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .collect(Collectors.toList());
    }
}
