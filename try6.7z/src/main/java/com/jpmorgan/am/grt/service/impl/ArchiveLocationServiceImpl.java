package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.ArchiveLocationService;
import com.jpmorgan.am.grt.domain.ArchiveLocation;
import com.jpmorgan.am.grt.repository.ArchiveLocationRepository;
import com.jpmorgan.am.grt.repository.search.ArchiveLocationSearchRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing ArchiveLocation.
 */
@Service
@Transactional
public class ArchiveLocationServiceImpl implements ArchiveLocationService{

    private final Logger log = LoggerFactory.getLogger(ArchiveLocationServiceImpl.class);
    
    @Inject
    private ArchiveLocationRepository archiveLocationRepository;

    @Inject
    private ArchiveLocationSearchRepository archiveLocationSearchRepository;

    /**
     * Save a archiveLocation.
     *
     * @param archiveLocation the entity to save
     * @return the persisted entity
     */
    public ArchiveLocation save(ArchiveLocation archiveLocation) {
        log.debug("Request to save ArchiveLocation : {}", archiveLocation);
        ArchiveLocation result = archiveLocationRepository.save(archiveLocation);
        archiveLocationSearchRepository.save(result);
        return result;
    }

    /**
     *  Get all the archiveLocations.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<ArchiveLocation> findAll() {
        log.debug("Request to get all ArchiveLocations");
        List<ArchiveLocation> result = archiveLocationRepository.findAll();

        return result;
    }

    /**
     *  Get one archiveLocation by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public ArchiveLocation findOne(Long id) {
        log.debug("Request to get ArchiveLocation : {}", id);
        ArchiveLocation archiveLocation = archiveLocationRepository.findOne(id);
        return archiveLocation;
    }

    /**
     *  Delete the  archiveLocation by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete ArchiveLocation : {}", id);
        archiveLocationRepository.delete(id);
        archiveLocationSearchRepository.delete(id);
    }

    /**
     * Search for the archiveLocation corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<ArchiveLocation> search(String query) {
        log.debug("Request to search ArchiveLocations for query {}", query);
        return StreamSupport
            .stream(archiveLocationSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .collect(Collectors.toList());
    }
}
