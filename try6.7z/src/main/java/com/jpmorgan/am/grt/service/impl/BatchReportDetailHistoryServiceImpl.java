package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.BatchReportDetailHistoryService;
import com.jpmorgan.am.grt.domain.BatchReportDetailHistory;
import com.jpmorgan.am.grt.repository.BatchReportDetailHistoryRepository;
import com.jpmorgan.am.grt.repository.search.BatchReportDetailHistorySearchRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing BatchReportDetailHistory.
 */
@Service
@Transactional
public class BatchReportDetailHistoryServiceImpl implements BatchReportDetailHistoryService{

    private final Logger log = LoggerFactory.getLogger(BatchReportDetailHistoryServiceImpl.class);
    
    @Inject
    private BatchReportDetailHistoryRepository batchReportDetailHistoryRepository;

    @Inject
    private BatchReportDetailHistorySearchRepository batchReportDetailHistorySearchRepository;

    /**
     * Save a batchReportDetailHistory.
     *
     * @param batchReportDetailHistory the entity to save
     * @return the persisted entity
     */
    public BatchReportDetailHistory save(BatchReportDetailHistory batchReportDetailHistory) {
        log.debug("Request to save BatchReportDetailHistory : {}", batchReportDetailHistory);
        BatchReportDetailHistory result = batchReportDetailHistoryRepository.save(batchReportDetailHistory);
        batchReportDetailHistorySearchRepository.save(result);
        return result;
    }

    /**
     *  Get all the batchReportDetailHistories.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<BatchReportDetailHistory> findAll() {
        log.debug("Request to get all BatchReportDetailHistories");
        List<BatchReportDetailHistory> result = batchReportDetailHistoryRepository.findAll();

        return result;
    }

    /**
     *  Get one batchReportDetailHistory by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public BatchReportDetailHistory findOne(Long id) {
        log.debug("Request to get BatchReportDetailHistory : {}", id);
        BatchReportDetailHistory batchReportDetailHistory = batchReportDetailHistoryRepository.findOne(id);
        return batchReportDetailHistory;
    }

    /**
     *  Delete the  batchReportDetailHistory by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete BatchReportDetailHistory : {}", id);
        batchReportDetailHistoryRepository.delete(id);
        batchReportDetailHistorySearchRepository.delete(id);
    }

    /**
     * Search for the batchReportDetailHistory corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<BatchReportDetailHistory> search(String query) {
        log.debug("Request to search BatchReportDetailHistories for query {}", query);
        return StreamSupport
            .stream(batchReportDetailHistorySearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .collect(Collectors.toList());
    }
}
