package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.DbCheckService;
import com.jpmorgan.am.grt.domain.DbCheck;
import com.jpmorgan.am.grt.repository.DbCheckRepository;
import com.jpmorgan.am.grt.repository.search.DbCheckSearchRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing DbCheck.
 */
@Service
@Transactional
public class DbCheckServiceImpl implements DbCheckService{

    private final Logger log = LoggerFactory.getLogger(DbCheckServiceImpl.class);
    
    @Inject
    private DbCheckRepository dbCheckRepository;

    @Inject
    private DbCheckSearchRepository dbCheckSearchRepository;

    /**
     * Save a dbCheck.
     *
     * @param dbCheck the entity to save
     * @return the persisted entity
     */
    public DbCheck save(DbCheck dbCheck) {
        log.debug("Request to save DbCheck : {}", dbCheck);
        DbCheck result = dbCheckRepository.save(dbCheck);
        dbCheckSearchRepository.save(result);
        return result;
    }

    /**
     *  Get all the dbChecks.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<DbCheck> findAll() {
        log.debug("Request to get all DbChecks");
        List<DbCheck> result = dbCheckRepository.findAll();

        return result;
    }

    /**
     *  Get one dbCheck by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public DbCheck findOne(Long id) {
        log.debug("Request to get DbCheck : {}", id);
        DbCheck dbCheck = dbCheckRepository.findOne(id);
        return dbCheck;
    }

    /**
     *  Delete the  dbCheck by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete DbCheck : {}", id);
        dbCheckRepository.delete(id);
        dbCheckSearchRepository.delete(id);
    }

    /**
     * Search for the dbCheck corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<DbCheck> search(String query) {
        log.debug("Request to search DbChecks for query {}", query);
        return StreamSupport
            .stream(dbCheckSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .collect(Collectors.toList());
    }
}
