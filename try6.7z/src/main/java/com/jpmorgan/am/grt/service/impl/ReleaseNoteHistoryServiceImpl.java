package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.ReleaseNoteHistoryService;
import com.jpmorgan.am.grt.domain.ReleaseNoteHistory;
import com.jpmorgan.am.grt.repository.ReleaseNoteHistoryRepository;
import com.jpmorgan.am.grt.repository.search.ReleaseNoteHistorySearchRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing ReleaseNoteHistory.
 */
@Service
@Transactional
public class ReleaseNoteHistoryServiceImpl implements ReleaseNoteHistoryService{

    private final Logger log = LoggerFactory.getLogger(ReleaseNoteHistoryServiceImpl.class);
    
    @Inject
    private ReleaseNoteHistoryRepository releaseNoteHistoryRepository;

    @Inject
    private ReleaseNoteHistorySearchRepository releaseNoteHistorySearchRepository;

    /**
     * Save a releaseNoteHistory.
     *
     * @param releaseNoteHistory the entity to save
     * @return the persisted entity
     */
    public ReleaseNoteHistory save(ReleaseNoteHistory releaseNoteHistory) {
        log.debug("Request to save ReleaseNoteHistory : {}", releaseNoteHistory);
        ReleaseNoteHistory result = releaseNoteHistoryRepository.save(releaseNoteHistory);
        releaseNoteHistorySearchRepository.save(result);
        return result;
    }

    /**
     *  Get all the releaseNoteHistories.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<ReleaseNoteHistory> findAll() {
        log.debug("Request to get all ReleaseNoteHistories");
        List<ReleaseNoteHistory> result = releaseNoteHistoryRepository.findAll();

        return result;
    }

    /**
     *  Get one releaseNoteHistory by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public ReleaseNoteHistory findOne(Long id) {
        log.debug("Request to get ReleaseNoteHistory : {}", id);
        ReleaseNoteHistory releaseNoteHistory = releaseNoteHistoryRepository.findOne(id);
        return releaseNoteHistory;
    }

    /**
     *  Delete the  releaseNoteHistory by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete ReleaseNoteHistory : {}", id);
        releaseNoteHistoryRepository.delete(id);
        releaseNoteHistorySearchRepository.delete(id);
    }

    /**
     * Search for the releaseNoteHistory corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<ReleaseNoteHistory> search(String query) {
        log.debug("Request to search ReleaseNoteHistories for query {}", query);
        return StreamSupport
            .stream(releaseNoteHistorySearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .collect(Collectors.toList());
    }
}
