package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.ServerService;
import com.jpmorgan.am.grt.domain.Server;
import com.jpmorgan.am.grt.repository.ServerRepository;
import com.jpmorgan.am.grt.repository.search.ServerSearchRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing Server.
 */
@Service
@Transactional
public class ServerServiceImpl implements ServerService{

    private final Logger log = LoggerFactory.getLogger(ServerServiceImpl.class);
    
    @Inject
    private ServerRepository serverRepository;

    @Inject
    private ServerSearchRepository serverSearchRepository;

    /**
     * Save a server.
     *
     * @param server the entity to save
     * @return the persisted entity
     */
    public Server save(Server server) {
        log.debug("Request to save Server : {}", server);
        Server result = serverRepository.save(server);
        serverSearchRepository.save(result);
        return result;
    }

    /**
     *  Get all the servers.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<Server> findAll() {
        log.debug("Request to get all Servers");
        List<Server> result = serverRepository.findAll();

        return result;
    }

    /**
     *  Get one server by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public Server findOne(Long id) {
        log.debug("Request to get Server : {}", id);
        Server server = serverRepository.findOne(id);
        return server;
    }

    /**
     *  Delete the  server by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete Server : {}", id);
        serverRepository.delete(id);
        serverSearchRepository.delete(id);
    }

    /**
     * Search for the server corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<Server> search(String query) {
        log.debug("Request to search Servers for query {}", query);
        return StreamSupport
            .stream(serverSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .collect(Collectors.toList());
    }
}
