package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.TemplateService;
import com.jpmorgan.am.grt.domain.Template;
import com.jpmorgan.am.grt.repository.TemplateRepository;
import com.jpmorgan.am.grt.repository.search.TemplateSearchRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing Template.
 */
@Service
@Transactional
public class TemplateServiceImpl implements TemplateService{

    private final Logger log = LoggerFactory.getLogger(TemplateServiceImpl.class);
    
    @Inject
    private TemplateRepository templateRepository;

    @Inject
    private TemplateSearchRepository templateSearchRepository;

    /**
     * Save a template.
     *
     * @param template the entity to save
     * @return the persisted entity
     */
    public Template save(Template template) {
        log.debug("Request to save Template : {}", template);
        Template result = templateRepository.save(template);
        templateSearchRepository.save(result);
        return result;
    }

    /**
     *  Get all the templates.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<Template> findAll() {
        log.debug("Request to get all Templates");
        List<Template> result = templateRepository.findAll();

        return result;
    }

    /**
     *  Get one template by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public Template findOne(Long id) {
        log.debug("Request to get Template : {}", id);
        Template template = templateRepository.findOne(id);
        return template;
    }

    /**
     *  Delete the  template by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete Template : {}", id);
        templateRepository.delete(id);
        templateSearchRepository.delete(id);
    }

    /**
     * Search for the template corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<Template> search(String query) {
        log.debug("Request to search Templates for query {}", query);
        return StreamSupport
            .stream(templateSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .collect(Collectors.toList());
    }
}
