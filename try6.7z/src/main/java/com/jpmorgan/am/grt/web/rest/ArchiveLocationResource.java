package com.jpmorgan.am.grt.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.jpmorgan.am.grt.domain.ArchiveLocation;
import com.jpmorgan.am.grt.service.ArchiveLocationService;
import com.jpmorgan.am.grt.web.rest.util.HeaderUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * REST controller for managing ArchiveLocation.
 */
@RestController
@RequestMapping("/api")
public class ArchiveLocationResource {

    private final Logger log = LoggerFactory.getLogger(ArchiveLocationResource.class);
        
    @Inject
    private ArchiveLocationService archiveLocationService;

    /**
     * POST  /archive-locations : Create a new archiveLocation.
     *
     * @param archiveLocation the archiveLocation to create
     * @return the ResponseEntity with status 201 (Created) and with body the new archiveLocation, or with status 400 (Bad Request) if the archiveLocation has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/archive-locations",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<ArchiveLocation> createArchiveLocation(@Valid @RequestBody ArchiveLocation archiveLocation) throws URISyntaxException {
        log.debug("REST request to save ArchiveLocation : {}", archiveLocation);
        if (archiveLocation.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("archiveLocation", "idexists", "A new archiveLocation cannot already have an ID")).body(null);
        }
        ArchiveLocation result = archiveLocationService.save(archiveLocation);
        return ResponseEntity.created(new URI("/api/archive-locations/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("archiveLocation", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /archive-locations : Updates an existing archiveLocation.
     *
     * @param archiveLocation the archiveLocation to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated archiveLocation,
     * or with status 400 (Bad Request) if the archiveLocation is not valid,
     * or with status 500 (Internal Server Error) if the archiveLocation couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/archive-locations",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<ArchiveLocation> updateArchiveLocation(@Valid @RequestBody ArchiveLocation archiveLocation) throws URISyntaxException {
        log.debug("REST request to update ArchiveLocation : {}", archiveLocation);
        if (archiveLocation.getId() == null) {
            return createArchiveLocation(archiveLocation);
        }
        ArchiveLocation result = archiveLocationService.save(archiveLocation);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("archiveLocation", archiveLocation.getId().toString()))
            .body(result);
    }

    /**
     * GET  /archive-locations : get all the archiveLocations.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of archiveLocations in body
     */
    @RequestMapping(value = "/archive-locations",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<ArchiveLocation> getAllArchiveLocations() {
        log.debug("REST request to get all ArchiveLocations");
        return archiveLocationService.findAll();
    }

    /**
     * GET  /archive-locations/:id : get the "id" archiveLocation.
     *
     * @param id the id of the archiveLocation to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the archiveLocation, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/archive-locations/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<ArchiveLocation> getArchiveLocation(@PathVariable Long id) {
        log.debug("REST request to get ArchiveLocation : {}", id);
        ArchiveLocation archiveLocation = archiveLocationService.findOne(id);
        return Optional.ofNullable(archiveLocation)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /archive-locations/:id : delete the "id" archiveLocation.
     *
     * @param id the id of the archiveLocation to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/archive-locations/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteArchiveLocation(@PathVariable Long id) {
        log.debug("REST request to delete ArchiveLocation : {}", id);
        archiveLocationService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("archiveLocation", id.toString())).build();
    }

    /**
     * SEARCH  /_search/archive-locations?query=:query : search for the archiveLocation corresponding
     * to the query.
     *
     * @param query the query of the archiveLocation search 
     * @return the result of the search
     */
    @RequestMapping(value = "/_search/archive-locations",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<ArchiveLocation> searchArchiveLocations(@RequestParam String query) {
        log.debug("REST request to search ArchiveLocations for query {}", query);
        return archiveLocationService.search(query);
    }


}
