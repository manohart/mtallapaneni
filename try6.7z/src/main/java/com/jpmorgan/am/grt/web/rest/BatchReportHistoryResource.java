package com.jpmorgan.am.grt.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.jpmorgan.am.grt.domain.BatchReportHistory;
import com.jpmorgan.am.grt.service.BatchReportHistoryService;
import com.jpmorgan.am.grt.web.rest.util.HeaderUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * REST controller for managing BatchReportHistory.
 */
@RestController
@RequestMapping("/api")
public class BatchReportHistoryResource {

    private final Logger log = LoggerFactory.getLogger(BatchReportHistoryResource.class);
        
    @Inject
    private BatchReportHistoryService batchReportHistoryService;

    /**
     * POST  /batch-report-histories : Create a new batchReportHistory.
     *
     * @param batchReportHistory the batchReportHistory to create
     * @return the ResponseEntity with status 201 (Created) and with body the new batchReportHistory, or with status 400 (Bad Request) if the batchReportHistory has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/batch-report-histories",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<BatchReportHistory> createBatchReportHistory(@Valid @RequestBody BatchReportHistory batchReportHistory) throws URISyntaxException {
        log.debug("REST request to save BatchReportHistory : {}", batchReportHistory);
        if (batchReportHistory.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("batchReportHistory", "idexists", "A new batchReportHistory cannot already have an ID")).body(null);
        }
        BatchReportHistory result = batchReportHistoryService.save(batchReportHistory);
        return ResponseEntity.created(new URI("/api/batch-report-histories/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("batchReportHistory", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /batch-report-histories : Updates an existing batchReportHistory.
     *
     * @param batchReportHistory the batchReportHistory to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated batchReportHistory,
     * or with status 400 (Bad Request) if the batchReportHistory is not valid,
     * or with status 500 (Internal Server Error) if the batchReportHistory couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/batch-report-histories",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<BatchReportHistory> updateBatchReportHistory(@Valid @RequestBody BatchReportHistory batchReportHistory) throws URISyntaxException {
        log.debug("REST request to update BatchReportHistory : {}", batchReportHistory);
        if (batchReportHistory.getId() == null) {
            return createBatchReportHistory(batchReportHistory);
        }
        BatchReportHistory result = batchReportHistoryService.save(batchReportHistory);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("batchReportHistory", batchReportHistory.getId().toString()))
            .body(result);
    }

    /**
     * GET  /batch-report-histories : get all the batchReportHistories.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of batchReportHistories in body
     */
    @RequestMapping(value = "/batch-report-histories",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<BatchReportHistory> getAllBatchReportHistories() {
        log.debug("REST request to get all BatchReportHistories");
        return batchReportHistoryService.findAll();
    }

    /**
     * GET  /batch-report-histories/:id : get the "id" batchReportHistory.
     *
     * @param id the id of the batchReportHistory to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the batchReportHistory, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/batch-report-histories/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<BatchReportHistory> getBatchReportHistory(@PathVariable Long id) {
        log.debug("REST request to get BatchReportHistory : {}", id);
        BatchReportHistory batchReportHistory = batchReportHistoryService.findOne(id);
        return Optional.ofNullable(batchReportHistory)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /batch-report-histories/:id : delete the "id" batchReportHistory.
     *
     * @param id the id of the batchReportHistory to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/batch-report-histories/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteBatchReportHistory(@PathVariable Long id) {
        log.debug("REST request to delete BatchReportHistory : {}", id);
        batchReportHistoryService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("batchReportHistory", id.toString())).build();
    }

    /**
     * SEARCH  /_search/batch-report-histories?query=:query : search for the batchReportHistory corresponding
     * to the query.
     *
     * @param query the query of the batchReportHistory search 
     * @return the result of the search
     */
    @RequestMapping(value = "/_search/batch-report-histories",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<BatchReportHistory> searchBatchReportHistories(@RequestParam String query) {
        log.debug("REST request to search BatchReportHistories for query {}", query);
        return batchReportHistoryService.search(query);
    }


}
