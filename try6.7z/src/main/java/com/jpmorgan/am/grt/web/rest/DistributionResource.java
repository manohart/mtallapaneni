package com.jpmorgan.am.grt.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.jpmorgan.am.grt.domain.Distribution;
import com.jpmorgan.am.grt.service.DistributionService;
import com.jpmorgan.am.grt.web.rest.util.HeaderUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * REST controller for managing Distribution.
 */
@RestController
@RequestMapping("/api")
public class DistributionResource {

    private final Logger log = LoggerFactory.getLogger(DistributionResource.class);
        
    @Inject
    private DistributionService distributionService;

    /**
     * POST  /distributions : Create a new distribution.
     *
     * @param distribution the distribution to create
     * @return the ResponseEntity with status 201 (Created) and with body the new distribution, or with status 400 (Bad Request) if the distribution has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/distributions",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Distribution> createDistribution(@Valid @RequestBody Distribution distribution) throws URISyntaxException {
        log.debug("REST request to save Distribution : {}", distribution);
        if (distribution.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("distribution", "idexists", "A new distribution cannot already have an ID")).body(null);
        }
        Distribution result = distributionService.save(distribution);
        return ResponseEntity.created(new URI("/api/distributions/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("distribution", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /distributions : Updates an existing distribution.
     *
     * @param distribution the distribution to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated distribution,
     * or with status 400 (Bad Request) if the distribution is not valid,
     * or with status 500 (Internal Server Error) if the distribution couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/distributions",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Distribution> updateDistribution(@Valid @RequestBody Distribution distribution) throws URISyntaxException {
        log.debug("REST request to update Distribution : {}", distribution);
        if (distribution.getId() == null) {
            return createDistribution(distribution);
        }
        Distribution result = distributionService.save(distribution);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("distribution", distribution.getId().toString()))
            .body(result);
    }

    /**
     * GET  /distributions : get all the distributions.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of distributions in body
     */
    @RequestMapping(value = "/distributions",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<Distribution> getAllDistributions() {
        log.debug("REST request to get all Distributions");
        return distributionService.findAll();
    }

    /**
     * GET  /distributions/:id : get the "id" distribution.
     *
     * @param id the id of the distribution to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the distribution, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/distributions/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Distribution> getDistribution(@PathVariable Long id) {
        log.debug("REST request to get Distribution : {}", id);
        Distribution distribution = distributionService.findOne(id);
        return Optional.ofNullable(distribution)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /distributions/:id : delete the "id" distribution.
     *
     * @param id the id of the distribution to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/distributions/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteDistribution(@PathVariable Long id) {
        log.debug("REST request to delete Distribution : {}", id);
        distributionService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("distribution", id.toString())).build();
    }

    /**
     * SEARCH  /_search/distributions?query=:query : search for the distribution corresponding
     * to the query.
     *
     * @param query the query of the distribution search 
     * @return the result of the search
     */
    @RequestMapping(value = "/_search/distributions",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<Distribution> searchDistributions(@RequestParam String query) {
        log.debug("REST request to search Distributions for query {}", query);
        return distributionService.search(query);
    }


}
