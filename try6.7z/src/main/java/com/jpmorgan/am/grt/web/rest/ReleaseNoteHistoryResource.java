package com.jpmorgan.am.grt.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.jpmorgan.am.grt.domain.ReleaseNoteHistory;
import com.jpmorgan.am.grt.service.ReleaseNoteHistoryService;
import com.jpmorgan.am.grt.web.rest.util.HeaderUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * REST controller for managing ReleaseNoteHistory.
 */
@RestController
@RequestMapping("/api")
public class ReleaseNoteHistoryResource {

    private final Logger log = LoggerFactory.getLogger(ReleaseNoteHistoryResource.class);
        
    @Inject
    private ReleaseNoteHistoryService releaseNoteHistoryService;

    /**
     * POST  /release-note-histories : Create a new releaseNoteHistory.
     *
     * @param releaseNoteHistory the releaseNoteHistory to create
     * @return the ResponseEntity with status 201 (Created) and with body the new releaseNoteHistory, or with status 400 (Bad Request) if the releaseNoteHistory has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/release-note-histories",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<ReleaseNoteHistory> createReleaseNoteHistory(@Valid @RequestBody ReleaseNoteHistory releaseNoteHistory) throws URISyntaxException {
        log.debug("REST request to save ReleaseNoteHistory : {}", releaseNoteHistory);
        if (releaseNoteHistory.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("releaseNoteHistory", "idexists", "A new releaseNoteHistory cannot already have an ID")).body(null);
        }
        ReleaseNoteHistory result = releaseNoteHistoryService.save(releaseNoteHistory);
        return ResponseEntity.created(new URI("/api/release-note-histories/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("releaseNoteHistory", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /release-note-histories : Updates an existing releaseNoteHistory.
     *
     * @param releaseNoteHistory the releaseNoteHistory to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated releaseNoteHistory,
     * or with status 400 (Bad Request) if the releaseNoteHistory is not valid,
     * or with status 500 (Internal Server Error) if the releaseNoteHistory couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/release-note-histories",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<ReleaseNoteHistory> updateReleaseNoteHistory(@Valid @RequestBody ReleaseNoteHistory releaseNoteHistory) throws URISyntaxException {
        log.debug("REST request to update ReleaseNoteHistory : {}", releaseNoteHistory);
        if (releaseNoteHistory.getId() == null) {
            return createReleaseNoteHistory(releaseNoteHistory);
        }
        ReleaseNoteHistory result = releaseNoteHistoryService.save(releaseNoteHistory);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("releaseNoteHistory", releaseNoteHistory.getId().toString()))
            .body(result);
    }

    /**
     * GET  /release-note-histories : get all the releaseNoteHistories.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of releaseNoteHistories in body
     */
    @RequestMapping(value = "/release-note-histories",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<ReleaseNoteHistory> getAllReleaseNoteHistories() {
        log.debug("REST request to get all ReleaseNoteHistories");
        return releaseNoteHistoryService.findAll();
    }

    /**
     * GET  /release-note-histories/:id : get the "id" releaseNoteHistory.
     *
     * @param id the id of the releaseNoteHistory to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the releaseNoteHistory, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/release-note-histories/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<ReleaseNoteHistory> getReleaseNoteHistory(@PathVariable Long id) {
        log.debug("REST request to get ReleaseNoteHistory : {}", id);
        ReleaseNoteHistory releaseNoteHistory = releaseNoteHistoryService.findOne(id);
        return Optional.ofNullable(releaseNoteHistory)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /release-note-histories/:id : delete the "id" releaseNoteHistory.
     *
     * @param id the id of the releaseNoteHistory to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/release-note-histories/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteReleaseNoteHistory(@PathVariable Long id) {
        log.debug("REST request to delete ReleaseNoteHistory : {}", id);
        releaseNoteHistoryService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("releaseNoteHistory", id.toString())).build();
    }

    /**
     * SEARCH  /_search/release-note-histories?query=:query : search for the releaseNoteHistory corresponding
     * to the query.
     *
     * @param query the query of the releaseNoteHistory search 
     * @return the result of the search
     */
    @RequestMapping(value = "/_search/release-note-histories",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<ReleaseNoteHistory> searchReleaseNoteHistories(@RequestParam String query) {
        log.debug("REST request to search ReleaseNoteHistories for query {}", query);
        return releaseNoteHistoryService.search(query);
    }


}
