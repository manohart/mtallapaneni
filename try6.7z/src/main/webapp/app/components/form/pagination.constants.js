(function() {
    'use strict';

    angular
        .module('grtDashboardApp')
        .constant('paginationConstants', {
            'itemsPerPage': 20
        });
})();
