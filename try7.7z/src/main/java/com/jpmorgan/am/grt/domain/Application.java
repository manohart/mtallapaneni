package com.jpmorgan.am.grt.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.springframework.data.elasticsearch.annotations.Document;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

import com.jpmorgan.am.grt.domain.enumeration.InfraCategory;

import com.jpmorgan.am.grt.domain.enumeration.AppType;

import com.jpmorgan.am.grt.domain.enumeration.HolidayCalendar;

/**
 * A Application.
 */
@Entity
@Table(name = "application")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@Document(indexName = "application")
public class Application implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Size(min = 5)
    @Column(name = "name", nullable = false)
    private String name;

    @NotNull
    @Size(min = 20)
    @Column(name = "description", nullable = false)
    private String description;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "category", nullable = false)
    private InfraCategory category;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "type", nullable = false)
    private AppType type;

    @Column(name = "sla")
    private String sla;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "holiday_calendar", nullable = false)
    private HolidayCalendar holidayCalendar;

    @NotNull
    @Column(name = "documenation", nullable = false)
    private String documenation;

    @NotNull
    @Column(name = "deployed_path", nullable = false)
    private String deployedPath;

    @Column(name = "metrics_path")
    private String metricsPath;

    @NotNull
    @Column(name = "is_active", nullable = false)
    private Boolean isActive;

    @Column(name = "updated_date")
    private ZonedDateTime updatedDate;

    @OneToMany(mappedBy = "application")
    @JsonIgnore
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<AutoNotification> notificationRules = new HashSet<>();

    @OneToMany(mappedBy = "application")
    @JsonIgnore
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<SoftwareReleaseNote> releases = new HashSet<>();

    @OneToMany(mappedBy = "dependOn")
    @JsonIgnore
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<AppDependency> dependents = new HashSet<>();

    @ManyToOne
    private Lob lob;

    @ManyToOne
    private DevOps devOps;

    @ManyToOne
    private Server appServer;

    @ManyToOne
    private Server dbServer;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public InfraCategory getCategory() {
        return category;
    }

    public void setCategory(InfraCategory category) {
        this.category = category;
    }

    public AppType getType() {
        return type;
    }

    public void setType(AppType type) {
        this.type = type;
    }

    public String getSla() {
        return sla;
    }

    public void setSla(String sla) {
        this.sla = sla;
    }

    public HolidayCalendar getHolidayCalendar() {
        return holidayCalendar;
    }

    public void setHolidayCalendar(HolidayCalendar holidayCalendar) {
        this.holidayCalendar = holidayCalendar;
    }

    public String getDocumenation() {
        return documenation;
    }

    public void setDocumenation(String documenation) {
        this.documenation = documenation;
    }

    public String getDeployedPath() {
        return deployedPath;
    }

    public void setDeployedPath(String deployedPath) {
        this.deployedPath = deployedPath;
    }

    public String getMetricsPath() {
        return metricsPath;
    }

    public void setMetricsPath(String metricsPath) {
        this.metricsPath = metricsPath;
    }

    public Boolean isIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public ZonedDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(ZonedDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Set<AutoNotification> getNotificationRules() {
        return notificationRules;
    }

    public void setNotificationRules(Set<AutoNotification> autoNotifications) {
        this.notificationRules = autoNotifications;
    }

    public Set<SoftwareReleaseNote> getReleases() {
        return releases;
    }

    public void setReleases(Set<SoftwareReleaseNote> softwareReleaseNotes) {
        this.releases = softwareReleaseNotes;
    }

    public Set<AppDependency> getDependents() {
        return dependents;
    }

    public void setDependents(Set<AppDependency> appDependencies) {
        this.dependents = appDependencies;
    }

    public Lob getLob() {
        return lob;
    }

    public void setLob(Lob lob) {
        this.lob = lob;
    }

    public DevOps getDevOps() {
        return devOps;
    }

    public void setDevOps(DevOps devOps) {
        this.devOps = devOps;
    }

    public Server getAppServer() {
        return appServer;
    }

    public void setAppServer(Server server) {
        this.appServer = server;
    }

    public Server getDbServer() {
        return dbServer;
    }

    public void setDbServer(Server server) {
        this.dbServer = server;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Application application = (Application) o;
        if(application.id == null || id == null) {
            return false;
        }
        return Objects.equals(id, application.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "Application{" +
            "id=" + id +
            ", name='" + name + "'" +
            ", description='" + description + "'" +
            ", category='" + category + "'" +
            ", type='" + type + "'" +
            ", sla='" + sla + "'" +
            ", holidayCalendar='" + holidayCalendar + "'" +
            ", documenation='" + documenation + "'" +
            ", deployedPath='" + deployedPath + "'" +
            ", metricsPath='" + metricsPath + "'" +
            ", isActive='" + isActive + "'" +
            ", updatedDate='" + updatedDate + "'" +
            '}';
    }
}
