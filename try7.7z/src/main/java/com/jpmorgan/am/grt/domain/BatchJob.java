package com.jpmorgan.am.grt.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.springframework.data.elasticsearch.annotations.Document;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

import com.jpmorgan.am.grt.domain.enumeration.AppScheduler;

/**
 * A BatchJob.
 */
@Entity
@Table(name = "batch_job")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@Document(indexName = "batchjob")
public class BatchJob implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "scheduler", nullable = false)
    private AppScheduler scheduler;

    @Column(name = "cron_expression")
    private String cronExpression;

    @Column(name = "auto_schedule")
    private Boolean autoSchedule;

    @NotNull
    @Column(name = "is_active", nullable = false)
    private Boolean isActive;

    @Column(name = "updated_date")
    private ZonedDateTime updatedDate;

    @OneToMany(mappedBy = "batchJob")
    @JsonIgnore
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<BatchJobHistory> histories = new HashSet<>();

    @OneToMany(mappedBy = "batchJob")
    @JsonIgnore
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<BatchReport> reports = new HashSet<>();

    @OneToMany(mappedBy = "batchJob")
    @JsonIgnore
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<Distribution> distributions = new HashSet<>();

    @OneToOne
    @JoinColumn(unique = true)
    private Application application;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public AppScheduler getScheduler() {
        return scheduler;
    }

    public void setScheduler(AppScheduler scheduler) {
        this.scheduler = scheduler;
    }

    public String getCronExpression() {
        return cronExpression;
    }

    public void setCronExpression(String cronExpression) {
        this.cronExpression = cronExpression;
    }

    public Boolean isAutoSchedule() {
        return autoSchedule;
    }

    public void setAutoSchedule(Boolean autoSchedule) {
        this.autoSchedule = autoSchedule;
    }

    public Boolean isIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public ZonedDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(ZonedDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Set<BatchJobHistory> getHistories() {
        return histories;
    }

    public void setHistories(Set<BatchJobHistory> batchJobHistories) {
        this.histories = batchJobHistories;
    }

    public Set<BatchReport> getReports() {
        return reports;
    }

    public void setReports(Set<BatchReport> batchReports) {
        this.reports = batchReports;
    }

    public Set<Distribution> getDistributions() {
        return distributions;
    }

    public void setDistributions(Set<Distribution> distributions) {
        this.distributions = distributions;
    }

    public Application getApplication() {
        return application;
    }

    public void setApplication(Application application) {
        this.application = application;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        BatchJob batchJob = (BatchJob) o;
        if(batchJob.id == null || id == null) {
            return false;
        }
        return Objects.equals(id, batchJob.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "BatchJob{" +
            "id=" + id +
            ", scheduler='" + scheduler + "'" +
            ", cronExpression='" + cronExpression + "'" +
            ", autoSchedule='" + autoSchedule + "'" +
            ", isActive='" + isActive + "'" +
            ", updatedDate='" + updatedDate + "'" +
            '}';
    }
}
