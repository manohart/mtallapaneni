package com.jpmorgan.am.grt.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.springframework.data.elasticsearch.annotations.Document;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.Objects;

/**
 * A BatchReportDetailHistory.
 */
@Entity
@Table(name = "batch_report_detail_history")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@Document(indexName = "batchreportdetailhistory")
public class BatchReportDetailHistory implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "records", nullable = false)
    private Integer records;

    @NotNull
    @Column(name = "issues", nullable = false)
    private Integer issues;

    @NotNull
    @Column(name = "initial_status", nullable = false)
    private String initialStatus;

    @Column(name = "comment")
    private String comment;

    @Column(name = "final_status")
    private String finalStatus;

    @Column(name = "updated_date")
    private ZonedDateTime updatedDate;

    @ManyToOne
    private BatchReportHistory mainStatus;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getRecords() {
        return records;
    }

    public void setRecords(Integer records) {
        this.records = records;
    }

    public Integer getIssues() {
        return issues;
    }

    public void setIssues(Integer issues) {
        this.issues = issues;
    }

    public String getInitialStatus() {
        return initialStatus;
    }

    public void setInitialStatus(String initialStatus) {
        this.initialStatus = initialStatus;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getFinalStatus() {
        return finalStatus;
    }

    public void setFinalStatus(String finalStatus) {
        this.finalStatus = finalStatus;
    }

    public ZonedDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(ZonedDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public BatchReportHistory getMainStatus() {
        return mainStatus;
    }

    public void setMainStatus(BatchReportHistory batchReportHistory) {
        this.mainStatus = batchReportHistory;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        BatchReportDetailHistory batchReportDetailHistory = (BatchReportDetailHistory) o;
        if(batchReportDetailHistory.id == null || id == null) {
            return false;
        }
        return Objects.equals(id, batchReportDetailHistory.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "BatchReportDetailHistory{" +
            "id=" + id +
            ", records='" + records + "'" +
            ", issues='" + issues + "'" +
            ", initialStatus='" + initialStatus + "'" +
            ", comment='" + comment + "'" +
            ", finalStatus='" + finalStatus + "'" +
            ", updatedDate='" + updatedDate + "'" +
            '}';
    }
}
