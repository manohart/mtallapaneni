package com.jpmorgan.am.grt.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.springframework.data.elasticsearch.annotations.Document;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

/**
 * A DevOps.
 */
@Entity
@Table(name = "dev_ops")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@Document(indexName = "devops")
public class DevOps implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "name", nullable = false)
    private String name;

    @NotNull
    @Min(value = 1)
    @Column(name = "seal_id", nullable = false)
    private Integer sealId;

    @NotNull
    @Column(name = "code_repo", nullable = false)
    private String codeRepo;

    @NotNull
    @Column(name = "scrum_board", nullable = false)
    private String scrumBoard;

    @NotNull
    @Column(name = "ci_build", nullable = false)
    private String ciBuild;

    @NotNull
    @Size(min = 4)
    @Column(name = "techonology_stack", nullable = false)
    private String techonologyStack;

    @NotNull
    @Column(name = "is_active", nullable = false)
    private Boolean isActive;

    @Column(name = "updated_date")
    private ZonedDateTime updatedDate;

    @OneToMany(mappedBy = "devOps")
    @JsonIgnore
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<Application> applications = new HashSet<>();

    @ManyToOne
    private Team techonology;

    @ManyToOne
    private Team support;

    @ManyToOne
    private Team business;

    @ManyToOne
    private Lob lob;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getSealId() {
        return sealId;
    }

    public void setSealId(Integer sealId) {
        this.sealId = sealId;
    }

    public String getCodeRepo() {
        return codeRepo;
    }

    public void setCodeRepo(String codeRepo) {
        this.codeRepo = codeRepo;
    }

    public String getScrumBoard() {
        return scrumBoard;
    }

    public void setScrumBoard(String scrumBoard) {
        this.scrumBoard = scrumBoard;
    }

    public String getCiBuild() {
        return ciBuild;
    }

    public void setCiBuild(String ciBuild) {
        this.ciBuild = ciBuild;
    }

    public String getTechonologyStack() {
        return techonologyStack;
    }

    public void setTechonologyStack(String techonologyStack) {
        this.techonologyStack = techonologyStack;
    }

    public Boolean isIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public ZonedDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(ZonedDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Set<Application> getApplications() {
        return applications;
    }

    public void setApplications(Set<Application> applications) {
        this.applications = applications;
    }

    public Team getTechonology() {
        return techonology;
    }

    public void setTechonology(Team team) {
        this.techonology = team;
    }

    public Team getSupport() {
        return support;
    }

    public void setSupport(Team team) {
        this.support = team;
    }

    public Team getBusiness() {
        return business;
    }

    public void setBusiness(Team team) {
        this.business = team;
    }

    public Lob getLob() {
        return lob;
    }

    public void setLob(Lob lob) {
        this.lob = lob;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        DevOps devOps = (DevOps) o;
        if(devOps.id == null || id == null) {
            return false;
        }
        return Objects.equals(id, devOps.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "DevOps{" +
            "id=" + id +
            ", name='" + name + "'" +
            ", sealId='" + sealId + "'" +
            ", codeRepo='" + codeRepo + "'" +
            ", scrumBoard='" + scrumBoard + "'" +
            ", ciBuild='" + ciBuild + "'" +
            ", techonologyStack='" + techonologyStack + "'" +
            ", isActive='" + isActive + "'" +
            ", updatedDate='" + updatedDate + "'" +
            '}';
    }
}
