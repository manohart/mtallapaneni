package com.jpmorgan.am.grt.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.springframework.data.elasticsearch.annotations.Document;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

/**
 * A Lob.
 */
@Entity
@Table(name = "lob")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@Document(indexName = "lob")
public class Lob implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "name", nullable = false)
    private String name;

    @NotNull
    @Column(name = "description", nullable = false)
    private String description;

    @NotNull
    @Size(min = 7)
    @Column(name = "cto_sid", nullable = false)
    private String ctoSid;

    @NotNull
    @Size(min = 7)
    @Column(name = "owner_sid", nullable = false)
    private String ownerSid;

    @NotNull
    @Column(name = "is_active", nullable = false)
    private Boolean isActive;

    @Column(name = "updated_date")
    private ZonedDateTime updatedDate;

    @OneToMany(mappedBy = "superLob")
    @JsonIgnore
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<Lob> subLobs = new HashSet<>();

    @OneToMany(mappedBy = "lob")
    @JsonIgnore
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<Application> applications = new HashSet<>();

    @OneToMany(mappedBy = "lob")
    @JsonIgnore
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<ArchiveLocation> archives = new HashSet<>();

    @OneToMany(mappedBy = "lob")
    @JsonIgnore
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<AutoNotification> notificationRules = new HashSet<>();

    @OneToMany(mappedBy = "lob")
    @JsonIgnore
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<DevOps> devOps = new HashSet<>();

    @OneToMany(mappedBy = "lob")
    @JsonIgnore
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<Template> templates = new HashSet<>();

    @OneToMany(mappedBy = "lob")
    @JsonIgnore
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<Team> teams = new HashSet<>();

    @ManyToOne
    private Lob superLob;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCtoSid() {
        return ctoSid;
    }

    public void setCtoSid(String ctoSid) {
        this.ctoSid = ctoSid;
    }

    public String getOwnerSid() {
        return ownerSid;
    }

    public void setOwnerSid(String ownerSid) {
        this.ownerSid = ownerSid;
    }

    public Boolean isIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public ZonedDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(ZonedDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Set<Lob> getSubLobs() {
        return subLobs;
    }

    public void setSubLobs(Set<Lob> lobs) {
        this.subLobs = lobs;
    }

    public Set<Application> getApplications() {
        return applications;
    }

    public void setApplications(Set<Application> applications) {
        this.applications = applications;
    }

    public Set<ArchiveLocation> getArchives() {
        return archives;
    }

    public void setArchives(Set<ArchiveLocation> archiveLocations) {
        this.archives = archiveLocations;
    }

    public Set<AutoNotification> getNotificationRules() {
        return notificationRules;
    }

    public void setNotificationRules(Set<AutoNotification> autoNotifications) {
        this.notificationRules = autoNotifications;
    }

    public Set<DevOps> getDevOps() {
        return devOps;
    }

    public void setDevOps(Set<DevOps> devOps) {
        this.devOps = devOps;
    }

    public Set<Template> getTemplates() {
        return templates;
    }

    public void setTemplates(Set<Template> templates) {
        this.templates = templates;
    }

    public Set<Team> getTeams() {
        return teams;
    }

    public void setTeams(Set<Team> teams) {
        this.teams = teams;
    }

    public Lob getSuperLob() {
        return superLob;
    }

    public void setSuperLob(Lob lob) {
        this.superLob = lob;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Lob lob = (Lob) o;
        if(lob.id == null || id == null) {
            return false;
        }
        return Objects.equals(id, lob.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "Lob{" +
            "id=" + id +
            ", name='" + name + "'" +
            ", description='" + description + "'" +
            ", ctoSid='" + ctoSid + "'" +
            ", ownerSid='" + ownerSid + "'" +
            ", isActive='" + isActive + "'" +
            ", updatedDate='" + updatedDate + "'" +
            '}';
    }
}
