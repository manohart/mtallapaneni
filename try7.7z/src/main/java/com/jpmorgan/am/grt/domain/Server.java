package com.jpmorgan.am.grt.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.springframework.data.elasticsearch.annotations.Document;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

import com.jpmorgan.am.grt.domain.enumeration.ServerType;

import com.jpmorgan.am.grt.domain.enumeration.Environment;

import com.jpmorgan.am.grt.domain.enumeration.OsType;

import com.jpmorgan.am.grt.domain.enumeration.InfraCategory;

/**
 * A Server.
 */
@Entity
@Table(name = "server")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@Document(indexName = "server")
public class Server implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Size(min = 7)
    @Column(name = "hostname", nullable = false)
    private String hostname;

    @NotNull
    @Size(min = 10)
    @Column(name = "alias", nullable = false)
    private String alias;

    @NotNull
    @Column(name = "description", nullable = false)
    private String description;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "type", nullable = false)
    private ServerType type;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "environment", nullable = false)
    private Environment environment;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "os_type", nullable = false)
    private OsType osType;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "category", nullable = false)
    private InfraCategory category;

    @NotNull
    @Column(name = "is_active", nullable = false)
    private Boolean isActive;

    @Column(name = "updated_date")
    private ZonedDateTime updatedDate;

    @OneToMany(mappedBy = "appServer")
    @JsonIgnore
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<Application> appApps = new HashSet<>();

    @OneToMany(mappedBy = "dbServer")
    @JsonIgnore
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<Application> dbApps = new HashSet<>();

    @ManyToOne
    private Lob lob;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getHostname() {
        return hostname;
    }

    public void setHostname(String hostname) {
        this.hostname = hostname;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public ServerType getType() {
        return type;
    }

    public void setType(ServerType type) {
        this.type = type;
    }

    public Environment getEnvironment() {
        return environment;
    }

    public void setEnvironment(Environment environment) {
        this.environment = environment;
    }

    public OsType getOsType() {
        return osType;
    }

    public void setOsType(OsType osType) {
        this.osType = osType;
    }

    public InfraCategory getCategory() {
        return category;
    }

    public void setCategory(InfraCategory category) {
        this.category = category;
    }

    public Boolean isIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public ZonedDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(ZonedDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Set<Application> getAppApps() {
        return appApps;
    }

    public void setAppApps(Set<Application> applications) {
        this.appApps = applications;
    }

    public Set<Application> getDbApps() {
        return dbApps;
    }

    public void setDbApps(Set<Application> applications) {
        this.dbApps = applications;
    }

    public Lob getLob() {
        return lob;
    }

    public void setLob(Lob lob) {
        this.lob = lob;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Server server = (Server) o;
        if(server.id == null || id == null) {
            return false;
        }
        return Objects.equals(id, server.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "Server{" +
            "id=" + id +
            ", hostname='" + hostname + "'" +
            ", alias='" + alias + "'" +
            ", description='" + description + "'" +
            ", type='" + type + "'" +
            ", environment='" + environment + "'" +
            ", osType='" + osType + "'" +
            ", category='" + category + "'" +
            ", isActive='" + isActive + "'" +
            ", updatedDate='" + updatedDate + "'" +
            '}';
    }
}
