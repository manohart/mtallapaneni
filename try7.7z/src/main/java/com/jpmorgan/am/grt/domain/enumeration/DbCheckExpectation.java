package com.jpmorgan.am.grt.domain.enumeration;

/**
 * The DbCheckExpectation enumeration.
 */
public enum DbCheckExpectation {
    NONE,ISSUE_IF_RECORDS_FOUND,ISSUE_IF_NO_RECORDS_FOUND,WARN_IF_RECORDS_FOUND,WARN_IF_NO_RECORDS_FOUND,GOOD_IF_NO_RECORDS_FOUND,GOOD_IF_RECORDS_FOUND
}
