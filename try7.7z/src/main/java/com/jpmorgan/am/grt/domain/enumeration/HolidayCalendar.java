package com.jpmorgan.am.grt.domain.enumeration;

/**
 * The HolidayCalendar enumeration.
 */
public enum HolidayCalendar {
    NYU,LON,TOK
}
