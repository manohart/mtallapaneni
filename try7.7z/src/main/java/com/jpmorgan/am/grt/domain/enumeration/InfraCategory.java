package com.jpmorgan.am.grt.domain.enumeration;

/**
 * The InfraCategory enumeration.
 */
public enum InfraCategory {
    INVEST,MAINTAIN,DIVEST
}
