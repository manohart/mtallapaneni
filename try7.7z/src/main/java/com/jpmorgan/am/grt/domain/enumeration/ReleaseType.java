package com.jpmorgan.am.grt.domain.enumeration;

/**
 * The ReleaseType enumeration.
 */
public enum ReleaseType {
    MAJOR,MINOR,MAINTENANCE,EMMERGENCY
}
