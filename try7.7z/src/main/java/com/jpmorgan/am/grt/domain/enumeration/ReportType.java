package com.jpmorgan.am.grt.domain.enumeration;

/**
 * The ReportType enumeration.
 */
public enum ReportType {
    HTML,EXCEL,PDF,JSON,CSV
}
