package com.jpmorgan.am.grt.repository;

import com.jpmorgan.am.grt.domain.AutoNotification;

import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the AutoNotification entity.
 */
@SuppressWarnings("unused")
public interface AutoNotificationRepository extends JpaRepository<AutoNotification,Long> {

}
