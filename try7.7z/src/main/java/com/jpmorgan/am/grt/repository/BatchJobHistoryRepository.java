package com.jpmorgan.am.grt.repository;

import com.jpmorgan.am.grt.domain.BatchJobHistory;

import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the BatchJobHistory entity.
 */
@SuppressWarnings("unused")
public interface BatchJobHistoryRepository extends JpaRepository<BatchJobHistory,Long> {

}
