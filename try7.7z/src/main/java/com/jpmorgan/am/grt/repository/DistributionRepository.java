package com.jpmorgan.am.grt.repository;

import com.jpmorgan.am.grt.domain.Distribution;

import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the Distribution entity.
 */
@SuppressWarnings("unused")
public interface DistributionRepository extends JpaRepository<Distribution,Long> {

}
