package com.jpmorgan.am.grt.repository;

import com.jpmorgan.am.grt.domain.SoftwareReleaseNote;

import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the SoftwareReleaseNote entity.
 */
@SuppressWarnings("unused")
public interface SoftwareReleaseNoteRepository extends JpaRepository<SoftwareReleaseNote,Long> {

}
