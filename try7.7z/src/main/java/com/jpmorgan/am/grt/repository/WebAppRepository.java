package com.jpmorgan.am.grt.repository;

import com.jpmorgan.am.grt.domain.WebApp;

import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the WebApp entity.
 */
@SuppressWarnings("unused")
public interface WebAppRepository extends JpaRepository<WebApp,Long> {

}
