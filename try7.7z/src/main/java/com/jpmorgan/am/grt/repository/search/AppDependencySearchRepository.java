package com.jpmorgan.am.grt.repository.search;

import com.jpmorgan.am.grt.domain.AppDependency;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * Spring Data ElasticSearch repository for the AppDependency entity.
 */
public interface AppDependencySearchRepository extends ElasticsearchRepository<AppDependency, Long> {
}
