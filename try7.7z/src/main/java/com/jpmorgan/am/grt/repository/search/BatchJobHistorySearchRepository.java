package com.jpmorgan.am.grt.repository.search;

import com.jpmorgan.am.grt.domain.BatchJobHistory;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * Spring Data ElasticSearch repository for the BatchJobHistory entity.
 */
public interface BatchJobHistorySearchRepository extends ElasticsearchRepository<BatchJobHistory, Long> {
}
