package com.jpmorgan.am.grt.repository.search;

import com.jpmorgan.am.grt.domain.DbCheck;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * Spring Data ElasticSearch repository for the DbCheck entity.
 */
public interface DbCheckSearchRepository extends ElasticsearchRepository<DbCheck, Long> {
}
