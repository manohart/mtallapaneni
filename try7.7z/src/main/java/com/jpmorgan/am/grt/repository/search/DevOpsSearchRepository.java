package com.jpmorgan.am.grt.repository.search;

import com.jpmorgan.am.grt.domain.DevOps;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * Spring Data ElasticSearch repository for the DevOps entity.
 */
public interface DevOpsSearchRepository extends ElasticsearchRepository<DevOps, Long> {
}
