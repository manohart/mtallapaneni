package com.jpmorgan.am.grt.repository.search;

import com.jpmorgan.am.grt.domain.Server;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * Spring Data ElasticSearch repository for the Server entity.
 */
public interface ServerSearchRepository extends ElasticsearchRepository<Server, Long> {
}
