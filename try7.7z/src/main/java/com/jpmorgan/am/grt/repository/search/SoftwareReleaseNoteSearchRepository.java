package com.jpmorgan.am.grt.repository.search;

import com.jpmorgan.am.grt.domain.SoftwareReleaseNote;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * Spring Data ElasticSearch repository for the SoftwareReleaseNote entity.
 */
public interface SoftwareReleaseNoteSearchRepository extends ElasticsearchRepository<SoftwareReleaseNote, Long> {
}
