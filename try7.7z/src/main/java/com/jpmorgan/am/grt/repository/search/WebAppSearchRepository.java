package com.jpmorgan.am.grt.repository.search;

import com.jpmorgan.am.grt.domain.WebApp;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * Spring Data ElasticSearch repository for the WebApp entity.
 */
public interface WebAppSearchRepository extends ElasticsearchRepository<WebApp, Long> {
}
