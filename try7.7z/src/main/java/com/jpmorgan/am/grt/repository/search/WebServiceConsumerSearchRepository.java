package com.jpmorgan.am.grt.repository.search;

import com.jpmorgan.am.grt.domain.WebServiceConsumer;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

/**
 * Spring Data ElasticSearch repository for the WebServiceConsumer entity.
 */
public interface WebServiceConsumerSearchRepository extends ElasticsearchRepository<WebServiceConsumer, Long> {
}
