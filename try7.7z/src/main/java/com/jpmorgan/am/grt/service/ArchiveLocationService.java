package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.domain.ArchiveLocation;

import java.util.List;

/**
 * Service Interface for managing ArchiveLocation.
 */
public interface ArchiveLocationService {

    /**
     * Save a archiveLocation.
     *
     * @param archiveLocation the entity to save
     * @return the persisted entity
     */
    ArchiveLocation save(ArchiveLocation archiveLocation);

    /**
     *  Get all the archiveLocations.
     *  
     *  @return the list of entities
     */
    List<ArchiveLocation> findAll();

    /**
     *  Get the "id" archiveLocation.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    ArchiveLocation findOne(Long id);

    /**
     *  Delete the "id" archiveLocation.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the archiveLocation corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<ArchiveLocation> search(String query);
}
