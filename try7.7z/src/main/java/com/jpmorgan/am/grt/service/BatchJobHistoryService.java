package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.domain.BatchJobHistory;

import java.util.List;

/**
 * Service Interface for managing BatchJobHistory.
 */
public interface BatchJobHistoryService {

    /**
     * Save a batchJobHistory.
     *
     * @param batchJobHistory the entity to save
     * @return the persisted entity
     */
    BatchJobHistory save(BatchJobHistory batchJobHistory);

    /**
     *  Get all the batchJobHistories.
     *  
     *  @return the list of entities
     */
    List<BatchJobHistory> findAll();

    /**
     *  Get the "id" batchJobHistory.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    BatchJobHistory findOne(Long id);

    /**
     *  Delete the "id" batchJobHistory.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the batchJobHistory corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<BatchJobHistory> search(String query);
}
