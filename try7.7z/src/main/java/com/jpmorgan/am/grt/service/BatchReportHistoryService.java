package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.domain.BatchReportHistory;

import java.util.List;

/**
 * Service Interface for managing BatchReportHistory.
 */
public interface BatchReportHistoryService {

    /**
     * Save a batchReportHistory.
     *
     * @param batchReportHistory the entity to save
     * @return the persisted entity
     */
    BatchReportHistory save(BatchReportHistory batchReportHistory);

    /**
     *  Get all the batchReportHistories.
     *  
     *  @return the list of entities
     */
    List<BatchReportHistory> findAll();

    /**
     *  Get the "id" batchReportHistory.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    BatchReportHistory findOne(Long id);

    /**
     *  Delete the "id" batchReportHistory.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the batchReportHistory corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<BatchReportHistory> search(String query);
}
