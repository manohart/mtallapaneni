package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.domain.DbCheck;

import java.util.List;

/**
 * Service Interface for managing DbCheck.
 */
public interface DbCheckService {

    /**
     * Save a dbCheck.
     *
     * @param dbCheck the entity to save
     * @return the persisted entity
     */
    DbCheck save(DbCheck dbCheck);

    /**
     *  Get all the dbChecks.
     *  
     *  @return the list of entities
     */
    List<DbCheck> findAll();

    /**
     *  Get the "id" dbCheck.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    DbCheck findOne(Long id);

    /**
     *  Delete the "id" dbCheck.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the dbCheck corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<DbCheck> search(String query);
}
