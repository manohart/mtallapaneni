package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.domain.Distribution;

import java.util.List;

/**
 * Service Interface for managing Distribution.
 */
public interface DistributionService {

    /**
     * Save a distribution.
     *
     * @param distribution the entity to save
     * @return the persisted entity
     */
    Distribution save(Distribution distribution);

    /**
     *  Get all the distributions.
     *  
     *  @return the list of entities
     */
    List<Distribution> findAll();

    /**
     *  Get the "id" distribution.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    Distribution findOne(Long id);

    /**
     *  Delete the "id" distribution.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the distribution corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<Distribution> search(String query);
}
