package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.domain.Lob;

import java.util.List;

/**
 * Service Interface for managing Lob.
 */
public interface LobService {

    /**
     * Save a lob.
     *
     * @param lob the entity to save
     * @return the persisted entity
     */
    Lob save(Lob lob);

    /**
     *  Get all the lobs.
     *  
     *  @return the list of entities
     */
    List<Lob> findAll();

    /**
     *  Get the "id" lob.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    Lob findOne(Long id);

    /**
     *  Delete the "id" lob.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the lob corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<Lob> search(String query);
}
