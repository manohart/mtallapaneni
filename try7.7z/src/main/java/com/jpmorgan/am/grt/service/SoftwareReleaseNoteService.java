package com.jpmorgan.am.grt.service;

import com.jpmorgan.am.grt.domain.SoftwareReleaseNote;

import java.util.List;

/**
 * Service Interface for managing SoftwareReleaseNote.
 */
public interface SoftwareReleaseNoteService {

    /**
     * Save a softwareReleaseNote.
     *
     * @param softwareReleaseNote the entity to save
     * @return the persisted entity
     */
    SoftwareReleaseNote save(SoftwareReleaseNote softwareReleaseNote);

    /**
     *  Get all the softwareReleaseNotes.
     *  
     *  @return the list of entities
     */
    List<SoftwareReleaseNote> findAll();

    /**
     *  Get the "id" softwareReleaseNote.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    SoftwareReleaseNote findOne(Long id);

    /**
     *  Delete the "id" softwareReleaseNote.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);

    /**
     * Search for the softwareReleaseNote corresponding to the query.
     *
     *  @param query the query of the search
     *  
     *  @return the list of entities
     */
    List<SoftwareReleaseNote> search(String query);
}
