/**
 * Data Transfer Objects.
 */
package com.jpmorgan.am.grt.service.dto;
