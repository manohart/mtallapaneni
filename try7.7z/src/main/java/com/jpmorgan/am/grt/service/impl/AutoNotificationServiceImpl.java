package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.AutoNotificationService;
import com.jpmorgan.am.grt.domain.AutoNotification;
import com.jpmorgan.am.grt.repository.AutoNotificationRepository;
import com.jpmorgan.am.grt.repository.search.AutoNotificationSearchRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing AutoNotification.
 */
@Service
@Transactional
public class AutoNotificationServiceImpl implements AutoNotificationService{

    private final Logger log = LoggerFactory.getLogger(AutoNotificationServiceImpl.class);
    
    @Inject
    private AutoNotificationRepository autoNotificationRepository;

    @Inject
    private AutoNotificationSearchRepository autoNotificationSearchRepository;

    /**
     * Save a autoNotification.
     *
     * @param autoNotification the entity to save
     * @return the persisted entity
     */
    public AutoNotification save(AutoNotification autoNotification) {
        log.debug("Request to save AutoNotification : {}", autoNotification);
        AutoNotification result = autoNotificationRepository.save(autoNotification);
        autoNotificationSearchRepository.save(result);
        return result;
    }

    /**
     *  Get all the autoNotifications.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<AutoNotification> findAll() {
        log.debug("Request to get all AutoNotifications");
        List<AutoNotification> result = autoNotificationRepository.findAll();

        return result;
    }

    /**
     *  Get one autoNotification by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public AutoNotification findOne(Long id) {
        log.debug("Request to get AutoNotification : {}", id);
        AutoNotification autoNotification = autoNotificationRepository.findOne(id);
        return autoNotification;
    }

    /**
     *  Delete the  autoNotification by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete AutoNotification : {}", id);
        autoNotificationRepository.delete(id);
        autoNotificationSearchRepository.delete(id);
    }

    /**
     * Search for the autoNotification corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<AutoNotification> search(String query) {
        log.debug("Request to search AutoNotifications for query {}", query);
        return StreamSupport
            .stream(autoNotificationSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .collect(Collectors.toList());
    }
}
