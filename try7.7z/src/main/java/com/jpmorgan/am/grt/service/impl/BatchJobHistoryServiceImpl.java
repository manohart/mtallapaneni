package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.BatchJobHistoryService;
import com.jpmorgan.am.grt.domain.BatchJobHistory;
import com.jpmorgan.am.grt.repository.BatchJobHistoryRepository;
import com.jpmorgan.am.grt.repository.search.BatchJobHistorySearchRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing BatchJobHistory.
 */
@Service
@Transactional
public class BatchJobHistoryServiceImpl implements BatchJobHistoryService{

    private final Logger log = LoggerFactory.getLogger(BatchJobHistoryServiceImpl.class);
    
    @Inject
    private BatchJobHistoryRepository batchJobHistoryRepository;

    @Inject
    private BatchJobHistorySearchRepository batchJobHistorySearchRepository;

    /**
     * Save a batchJobHistory.
     *
     * @param batchJobHistory the entity to save
     * @return the persisted entity
     */
    public BatchJobHistory save(BatchJobHistory batchJobHistory) {
        log.debug("Request to save BatchJobHistory : {}", batchJobHistory);
        BatchJobHistory result = batchJobHistoryRepository.save(batchJobHistory);
        batchJobHistorySearchRepository.save(result);
        return result;
    }

    /**
     *  Get all the batchJobHistories.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<BatchJobHistory> findAll() {
        log.debug("Request to get all BatchJobHistories");
        List<BatchJobHistory> result = batchJobHistoryRepository.findAll();

        return result;
    }

    /**
     *  Get one batchJobHistory by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public BatchJobHistory findOne(Long id) {
        log.debug("Request to get BatchJobHistory : {}", id);
        BatchJobHistory batchJobHistory = batchJobHistoryRepository.findOne(id);
        return batchJobHistory;
    }

    /**
     *  Delete the  batchJobHistory by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete BatchJobHistory : {}", id);
        batchJobHistoryRepository.delete(id);
        batchJobHistorySearchRepository.delete(id);
    }

    /**
     * Search for the batchJobHistory corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<BatchJobHistory> search(String query) {
        log.debug("Request to search BatchJobHistories for query {}", query);
        return StreamSupport
            .stream(batchJobHistorySearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .collect(Collectors.toList());
    }
}
