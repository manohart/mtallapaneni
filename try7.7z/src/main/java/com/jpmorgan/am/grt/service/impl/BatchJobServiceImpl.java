package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.BatchJobService;
import com.jpmorgan.am.grt.domain.BatchJob;
import com.jpmorgan.am.grt.repository.BatchJobRepository;
import com.jpmorgan.am.grt.repository.search.BatchJobSearchRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing BatchJob.
 */
@Service
@Transactional
public class BatchJobServiceImpl implements BatchJobService{

    private final Logger log = LoggerFactory.getLogger(BatchJobServiceImpl.class);
    
    @Inject
    private BatchJobRepository batchJobRepository;

    @Inject
    private BatchJobSearchRepository batchJobSearchRepository;

    /**
     * Save a batchJob.
     *
     * @param batchJob the entity to save
     * @return the persisted entity
     */
    public BatchJob save(BatchJob batchJob) {
        log.debug("Request to save BatchJob : {}", batchJob);
        BatchJob result = batchJobRepository.save(batchJob);
        batchJobSearchRepository.save(result);
        return result;
    }

    /**
     *  Get all the batchJobs.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<BatchJob> findAll() {
        log.debug("Request to get all BatchJobs");
        List<BatchJob> result = batchJobRepository.findAll();

        return result;
    }

    /**
     *  Get one batchJob by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public BatchJob findOne(Long id) {
        log.debug("Request to get BatchJob : {}", id);
        BatchJob batchJob = batchJobRepository.findOne(id);
        return batchJob;
    }

    /**
     *  Delete the  batchJob by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete BatchJob : {}", id);
        batchJobRepository.delete(id);
        batchJobSearchRepository.delete(id);
    }

    /**
     * Search for the batchJob corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<BatchJob> search(String query) {
        log.debug("Request to search BatchJobs for query {}", query);
        return StreamSupport
            .stream(batchJobSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .collect(Collectors.toList());
    }
}
