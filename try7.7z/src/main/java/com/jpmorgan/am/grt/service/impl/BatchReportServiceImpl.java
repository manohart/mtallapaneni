package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.BatchReportService;
import com.jpmorgan.am.grt.domain.BatchReport;
import com.jpmorgan.am.grt.repository.BatchReportRepository;
import com.jpmorgan.am.grt.repository.search.BatchReportSearchRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing BatchReport.
 */
@Service
@Transactional
public class BatchReportServiceImpl implements BatchReportService{

    private final Logger log = LoggerFactory.getLogger(BatchReportServiceImpl.class);
    
    @Inject
    private BatchReportRepository batchReportRepository;

    @Inject
    private BatchReportSearchRepository batchReportSearchRepository;

    /**
     * Save a batchReport.
     *
     * @param batchReport the entity to save
     * @return the persisted entity
     */
    public BatchReport save(BatchReport batchReport) {
        log.debug("Request to save BatchReport : {}", batchReport);
        BatchReport result = batchReportRepository.save(batchReport);
        batchReportSearchRepository.save(result);
        return result;
    }

    /**
     *  Get all the batchReports.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<BatchReport> findAll() {
        log.debug("Request to get all BatchReports");
        List<BatchReport> result = batchReportRepository.findAll();

        return result;
    }

    /**
     *  Get one batchReport by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public BatchReport findOne(Long id) {
        log.debug("Request to get BatchReport : {}", id);
        BatchReport batchReport = batchReportRepository.findOne(id);
        return batchReport;
    }

    /**
     *  Delete the  batchReport by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete BatchReport : {}", id);
        batchReportRepository.delete(id);
        batchReportSearchRepository.delete(id);
    }

    /**
     * Search for the batchReport corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<BatchReport> search(String query) {
        log.debug("Request to search BatchReports for query {}", query);
        return StreamSupport
            .stream(batchReportSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .collect(Collectors.toList());
    }
}
