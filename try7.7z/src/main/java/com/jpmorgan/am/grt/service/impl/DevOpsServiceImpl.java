package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.DevOpsService;
import com.jpmorgan.am.grt.domain.DevOps;
import com.jpmorgan.am.grt.repository.DevOpsRepository;
import com.jpmorgan.am.grt.repository.search.DevOpsSearchRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing DevOps.
 */
@Service
@Transactional
public class DevOpsServiceImpl implements DevOpsService{

    private final Logger log = LoggerFactory.getLogger(DevOpsServiceImpl.class);
    
    @Inject
    private DevOpsRepository devOpsRepository;

    @Inject
    private DevOpsSearchRepository devOpsSearchRepository;

    /**
     * Save a devOps.
     *
     * @param devOps the entity to save
     * @return the persisted entity
     */
    public DevOps save(DevOps devOps) {
        log.debug("Request to save DevOps : {}", devOps);
        DevOps result = devOpsRepository.save(devOps);
        devOpsSearchRepository.save(result);
        return result;
    }

    /**
     *  Get all the devOps.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<DevOps> findAll() {
        log.debug("Request to get all DevOps");
        List<DevOps> result = devOpsRepository.findAll();

        return result;
    }

    /**
     *  Get one devOps by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public DevOps findOne(Long id) {
        log.debug("Request to get DevOps : {}", id);
        DevOps devOps = devOpsRepository.findOne(id);
        return devOps;
    }

    /**
     *  Delete the  devOps by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete DevOps : {}", id);
        devOpsRepository.delete(id);
        devOpsSearchRepository.delete(id);
    }

    /**
     * Search for the devOps corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<DevOps> search(String query) {
        log.debug("Request to search DevOps for query {}", query);
        return StreamSupport
            .stream(devOpsSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .collect(Collectors.toList());
    }
}
