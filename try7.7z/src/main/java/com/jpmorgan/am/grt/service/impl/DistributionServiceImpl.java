package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.DistributionService;
import com.jpmorgan.am.grt.domain.Distribution;
import com.jpmorgan.am.grt.repository.DistributionRepository;
import com.jpmorgan.am.grt.repository.search.DistributionSearchRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing Distribution.
 */
@Service
@Transactional
public class DistributionServiceImpl implements DistributionService{

    private final Logger log = LoggerFactory.getLogger(DistributionServiceImpl.class);
    
    @Inject
    private DistributionRepository distributionRepository;

    @Inject
    private DistributionSearchRepository distributionSearchRepository;

    /**
     * Save a distribution.
     *
     * @param distribution the entity to save
     * @return the persisted entity
     */
    public Distribution save(Distribution distribution) {
        log.debug("Request to save Distribution : {}", distribution);
        Distribution result = distributionRepository.save(distribution);
        distributionSearchRepository.save(result);
        return result;
    }

    /**
     *  Get all the distributions.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<Distribution> findAll() {
        log.debug("Request to get all Distributions");
        List<Distribution> result = distributionRepository.findAll();

        return result;
    }

    /**
     *  Get one distribution by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public Distribution findOne(Long id) {
        log.debug("Request to get Distribution : {}", id);
        Distribution distribution = distributionRepository.findOne(id);
        return distribution;
    }

    /**
     *  Delete the  distribution by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete Distribution : {}", id);
        distributionRepository.delete(id);
        distributionSearchRepository.delete(id);
    }

    /**
     * Search for the distribution corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<Distribution> search(String query) {
        log.debug("Request to search Distributions for query {}", query);
        return StreamSupport
            .stream(distributionSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .collect(Collectors.toList());
    }
}
