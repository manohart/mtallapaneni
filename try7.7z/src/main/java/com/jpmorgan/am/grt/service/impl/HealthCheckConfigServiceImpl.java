package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.HealthCheckConfigService;
import com.jpmorgan.am.grt.domain.HealthCheckConfig;
import com.jpmorgan.am.grt.repository.HealthCheckConfigRepository;
import com.jpmorgan.am.grt.repository.search.HealthCheckConfigSearchRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing HealthCheckConfig.
 */
@Service
@Transactional
public class HealthCheckConfigServiceImpl implements HealthCheckConfigService{

    private final Logger log = LoggerFactory.getLogger(HealthCheckConfigServiceImpl.class);
    
    @Inject
    private HealthCheckConfigRepository healthCheckConfigRepository;

    @Inject
    private HealthCheckConfigSearchRepository healthCheckConfigSearchRepository;

    /**
     * Save a healthCheckConfig.
     *
     * @param healthCheckConfig the entity to save
     * @return the persisted entity
     */
    public HealthCheckConfig save(HealthCheckConfig healthCheckConfig) {
        log.debug("Request to save HealthCheckConfig : {}", healthCheckConfig);
        HealthCheckConfig result = healthCheckConfigRepository.save(healthCheckConfig);
        healthCheckConfigSearchRepository.save(result);
        return result;
    }

    /**
     *  Get all the healthCheckConfigs.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<HealthCheckConfig> findAll() {
        log.debug("Request to get all HealthCheckConfigs");
        List<HealthCheckConfig> result = healthCheckConfigRepository.findAll();

        return result;
    }

    /**
     *  Get one healthCheckConfig by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public HealthCheckConfig findOne(Long id) {
        log.debug("Request to get HealthCheckConfig : {}", id);
        HealthCheckConfig healthCheckConfig = healthCheckConfigRepository.findOne(id);
        return healthCheckConfig;
    }

    /**
     *  Delete the  healthCheckConfig by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete HealthCheckConfig : {}", id);
        healthCheckConfigRepository.delete(id);
        healthCheckConfigSearchRepository.delete(id);
    }

    /**
     * Search for the healthCheckConfig corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<HealthCheckConfig> search(String query) {
        log.debug("Request to search HealthCheckConfigs for query {}", query);
        return StreamSupport
            .stream(healthCheckConfigSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .collect(Collectors.toList());
    }
}
