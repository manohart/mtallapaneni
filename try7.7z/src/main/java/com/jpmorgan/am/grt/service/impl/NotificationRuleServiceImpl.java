package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.NotificationRuleService;
import com.jpmorgan.am.grt.domain.NotificationRule;
import com.jpmorgan.am.grt.repository.NotificationRuleRepository;
import com.jpmorgan.am.grt.repository.search.NotificationRuleSearchRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing NotificationRule.
 */
@Service
@Transactional
public class NotificationRuleServiceImpl implements NotificationRuleService{

    private final Logger log = LoggerFactory.getLogger(NotificationRuleServiceImpl.class);
    
    @Inject
    private NotificationRuleRepository notificationRuleRepository;

    @Inject
    private NotificationRuleSearchRepository notificationRuleSearchRepository;

    /**
     * Save a notificationRule.
     *
     * @param notificationRule the entity to save
     * @return the persisted entity
     */
    public NotificationRule save(NotificationRule notificationRule) {
        log.debug("Request to save NotificationRule : {}", notificationRule);
        NotificationRule result = notificationRuleRepository.save(notificationRule);
        notificationRuleSearchRepository.save(result);
        return result;
    }

    /**
     *  Get all the notificationRules.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<NotificationRule> findAll() {
        log.debug("Request to get all NotificationRules");
        List<NotificationRule> result = notificationRuleRepository.findAll();

        return result;
    }

    /**
     *  Get one notificationRule by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public NotificationRule findOne(Long id) {
        log.debug("Request to get NotificationRule : {}", id);
        NotificationRule notificationRule = notificationRuleRepository.findOne(id);
        return notificationRule;
    }

    /**
     *  Delete the  notificationRule by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete NotificationRule : {}", id);
        notificationRuleRepository.delete(id);
        notificationRuleSearchRepository.delete(id);
    }

    /**
     * Search for the notificationRule corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<NotificationRule> search(String query) {
        log.debug("Request to search NotificationRules for query {}", query);
        return StreamSupport
            .stream(notificationRuleSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .collect(Collectors.toList());
    }
}
