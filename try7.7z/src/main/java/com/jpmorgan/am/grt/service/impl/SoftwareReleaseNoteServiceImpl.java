package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.SoftwareReleaseNoteService;
import com.jpmorgan.am.grt.domain.SoftwareReleaseNote;
import com.jpmorgan.am.grt.repository.SoftwareReleaseNoteRepository;
import com.jpmorgan.am.grt.repository.search.SoftwareReleaseNoteSearchRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing SoftwareReleaseNote.
 */
@Service
@Transactional
public class SoftwareReleaseNoteServiceImpl implements SoftwareReleaseNoteService{

    private final Logger log = LoggerFactory.getLogger(SoftwareReleaseNoteServiceImpl.class);
    
    @Inject
    private SoftwareReleaseNoteRepository softwareReleaseNoteRepository;

    @Inject
    private SoftwareReleaseNoteSearchRepository softwareReleaseNoteSearchRepository;

    /**
     * Save a softwareReleaseNote.
     *
     * @param softwareReleaseNote the entity to save
     * @return the persisted entity
     */
    public SoftwareReleaseNote save(SoftwareReleaseNote softwareReleaseNote) {
        log.debug("Request to save SoftwareReleaseNote : {}", softwareReleaseNote);
        SoftwareReleaseNote result = softwareReleaseNoteRepository.save(softwareReleaseNote);
        softwareReleaseNoteSearchRepository.save(result);
        return result;
    }

    /**
     *  Get all the softwareReleaseNotes.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<SoftwareReleaseNote> findAll() {
        log.debug("Request to get all SoftwareReleaseNotes");
        List<SoftwareReleaseNote> result = softwareReleaseNoteRepository.findAll();

        return result;
    }

    /**
     *  Get one softwareReleaseNote by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public SoftwareReleaseNote findOne(Long id) {
        log.debug("Request to get SoftwareReleaseNote : {}", id);
        SoftwareReleaseNote softwareReleaseNote = softwareReleaseNoteRepository.findOne(id);
        return softwareReleaseNote;
    }

    /**
     *  Delete the  softwareReleaseNote by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete SoftwareReleaseNote : {}", id);
        softwareReleaseNoteRepository.delete(id);
        softwareReleaseNoteSearchRepository.delete(id);
    }

    /**
     * Search for the softwareReleaseNote corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<SoftwareReleaseNote> search(String query) {
        log.debug("Request to search SoftwareReleaseNotes for query {}", query);
        return StreamSupport
            .stream(softwareReleaseNoteSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .collect(Collectors.toList());
    }
}
