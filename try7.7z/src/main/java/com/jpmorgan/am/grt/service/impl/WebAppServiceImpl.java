package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.WebAppService;
import com.jpmorgan.am.grt.domain.WebApp;
import com.jpmorgan.am.grt.repository.WebAppRepository;
import com.jpmorgan.am.grt.repository.search.WebAppSearchRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing WebApp.
 */
@Service
@Transactional
public class WebAppServiceImpl implements WebAppService{

    private final Logger log = LoggerFactory.getLogger(WebAppServiceImpl.class);
    
    @Inject
    private WebAppRepository webAppRepository;

    @Inject
    private WebAppSearchRepository webAppSearchRepository;

    /**
     * Save a webApp.
     *
     * @param webApp the entity to save
     * @return the persisted entity
     */
    public WebApp save(WebApp webApp) {
        log.debug("Request to save WebApp : {}", webApp);
        WebApp result = webAppRepository.save(webApp);
        webAppSearchRepository.save(result);
        return result;
    }

    /**
     *  Get all the webApps.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<WebApp> findAll() {
        log.debug("Request to get all WebApps");
        List<WebApp> result = webAppRepository.findAll();

        return result;
    }

    /**
     *  Get one webApp by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public WebApp findOne(Long id) {
        log.debug("Request to get WebApp : {}", id);
        WebApp webApp = webAppRepository.findOne(id);
        return webApp;
    }

    /**
     *  Delete the  webApp by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete WebApp : {}", id);
        webAppRepository.delete(id);
        webAppSearchRepository.delete(id);
    }

    /**
     * Search for the webApp corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<WebApp> search(String query) {
        log.debug("Request to search WebApps for query {}", query);
        return StreamSupport
            .stream(webAppSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .collect(Collectors.toList());
    }
}
