package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.WebServiceConsumerService;
import com.jpmorgan.am.grt.domain.WebServiceConsumer;
import com.jpmorgan.am.grt.repository.WebServiceConsumerRepository;
import com.jpmorgan.am.grt.repository.search.WebServiceConsumerSearchRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing WebServiceConsumer.
 */
@Service
@Transactional
public class WebServiceConsumerServiceImpl implements WebServiceConsumerService{

    private final Logger log = LoggerFactory.getLogger(WebServiceConsumerServiceImpl.class);
    
    @Inject
    private WebServiceConsumerRepository webServiceConsumerRepository;

    @Inject
    private WebServiceConsumerSearchRepository webServiceConsumerSearchRepository;

    /**
     * Save a webServiceConsumer.
     *
     * @param webServiceConsumer the entity to save
     * @return the persisted entity
     */
    public WebServiceConsumer save(WebServiceConsumer webServiceConsumer) {
        log.debug("Request to save WebServiceConsumer : {}", webServiceConsumer);
        WebServiceConsumer result = webServiceConsumerRepository.save(webServiceConsumer);
        webServiceConsumerSearchRepository.save(result);
        return result;
    }

    /**
     *  Get all the webServiceConsumers.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<WebServiceConsumer> findAll() {
        log.debug("Request to get all WebServiceConsumers");
        List<WebServiceConsumer> result = webServiceConsumerRepository.findAll();

        return result;
    }

    /**
     *  Get one webServiceConsumer by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public WebServiceConsumer findOne(Long id) {
        log.debug("Request to get WebServiceConsumer : {}", id);
        WebServiceConsumer webServiceConsumer = webServiceConsumerRepository.findOne(id);
        return webServiceConsumer;
    }

    /**
     *  Delete the  webServiceConsumer by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete WebServiceConsumer : {}", id);
        webServiceConsumerRepository.delete(id);
        webServiceConsumerSearchRepository.delete(id);
    }

    /**
     * Search for the webServiceConsumer corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<WebServiceConsumer> search(String query) {
        log.debug("Request to search WebServiceConsumers for query {}", query);
        return StreamSupport
            .stream(webServiceConsumerSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .collect(Collectors.toList());
    }
}
