package com.jpmorgan.am.grt.service.impl;

import com.jpmorgan.am.grt.service.WebServiceService;
import com.jpmorgan.am.grt.domain.WebService;
import com.jpmorgan.am.grt.repository.WebServiceRepository;
import com.jpmorgan.am.grt.repository.search.WebServiceSearchRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * Service Implementation for managing WebService.
 */
@Service
@Transactional
public class WebServiceServiceImpl implements WebServiceService{

    private final Logger log = LoggerFactory.getLogger(WebServiceServiceImpl.class);
    
    @Inject
    private WebServiceRepository webServiceRepository;

    @Inject
    private WebServiceSearchRepository webServiceSearchRepository;

    /**
     * Save a webService.
     *
     * @param webService the entity to save
     * @return the persisted entity
     */
    public WebService save(WebService webService) {
        log.debug("Request to save WebService : {}", webService);
        WebService result = webServiceRepository.save(webService);
        webServiceSearchRepository.save(result);
        return result;
    }

    /**
     *  Get all the webServices.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<WebService> findAll() {
        log.debug("Request to get all WebServices");
        List<WebService> result = webServiceRepository.findAll();

        return result;
    }

    /**
     *  Get one webService by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public WebService findOne(Long id) {
        log.debug("Request to get WebService : {}", id);
        WebService webService = webServiceRepository.findOne(id);
        return webService;
    }

    /**
     *  Delete the  webService by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete WebService : {}", id);
        webServiceRepository.delete(id);
        webServiceSearchRepository.delete(id);
    }

    /**
     * Search for the webService corresponding to the query.
     *
     *  @param query the query of the search
     *  @return the list of entities
     */
    @Transactional(readOnly = true)
    public List<WebService> search(String query) {
        log.debug("Request to search WebServices for query {}", query);
        return StreamSupport
            .stream(webServiceSearchRepository.search(queryStringQuery(query)).spliterator(), false)
            .collect(Collectors.toList());
    }
}
