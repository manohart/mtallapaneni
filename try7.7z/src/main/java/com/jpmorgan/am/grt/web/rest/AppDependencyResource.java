package com.jpmorgan.am.grt.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.jpmorgan.am.grt.domain.AppDependency;
import com.jpmorgan.am.grt.service.AppDependencyService;
import com.jpmorgan.am.grt.web.rest.util.HeaderUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * REST controller for managing AppDependency.
 */
@RestController
@RequestMapping("/api")
public class AppDependencyResource {

    private final Logger log = LoggerFactory.getLogger(AppDependencyResource.class);
        
    @Inject
    private AppDependencyService appDependencyService;

    /**
     * POST  /app-dependencies : Create a new appDependency.
     *
     * @param appDependency the appDependency to create
     * @return the ResponseEntity with status 201 (Created) and with body the new appDependency, or with status 400 (Bad Request) if the appDependency has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/app-dependencies",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<AppDependency> createAppDependency(@Valid @RequestBody AppDependency appDependency) throws URISyntaxException {
        log.debug("REST request to save AppDependency : {}", appDependency);
        if (appDependency.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("appDependency", "idexists", "A new appDependency cannot already have an ID")).body(null);
        }
        AppDependency result = appDependencyService.save(appDependency);
        return ResponseEntity.created(new URI("/api/app-dependencies/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("appDependency", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /app-dependencies : Updates an existing appDependency.
     *
     * @param appDependency the appDependency to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated appDependency,
     * or with status 400 (Bad Request) if the appDependency is not valid,
     * or with status 500 (Internal Server Error) if the appDependency couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/app-dependencies",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<AppDependency> updateAppDependency(@Valid @RequestBody AppDependency appDependency) throws URISyntaxException {
        log.debug("REST request to update AppDependency : {}", appDependency);
        if (appDependency.getId() == null) {
            return createAppDependency(appDependency);
        }
        AppDependency result = appDependencyService.save(appDependency);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("appDependency", appDependency.getId().toString()))
            .body(result);
    }

    /**
     * GET  /app-dependencies : get all the appDependencies.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of appDependencies in body
     */
    @RequestMapping(value = "/app-dependencies",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<AppDependency> getAllAppDependencies() {
        log.debug("REST request to get all AppDependencies");
        return appDependencyService.findAll();
    }

    /**
     * GET  /app-dependencies/:id : get the "id" appDependency.
     *
     * @param id the id of the appDependency to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the appDependency, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/app-dependencies/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<AppDependency> getAppDependency(@PathVariable Long id) {
        log.debug("REST request to get AppDependency : {}", id);
        AppDependency appDependency = appDependencyService.findOne(id);
        return Optional.ofNullable(appDependency)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /app-dependencies/:id : delete the "id" appDependency.
     *
     * @param id the id of the appDependency to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/app-dependencies/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteAppDependency(@PathVariable Long id) {
        log.debug("REST request to delete AppDependency : {}", id);
        appDependencyService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("appDependency", id.toString())).build();
    }

    /**
     * SEARCH  /_search/app-dependencies?query=:query : search for the appDependency corresponding
     * to the query.
     *
     * @param query the query of the appDependency search 
     * @return the result of the search
     */
    @RequestMapping(value = "/_search/app-dependencies",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<AppDependency> searchAppDependencies(@RequestParam String query) {
        log.debug("REST request to search AppDependencies for query {}", query);
        return appDependencyService.search(query);
    }


}
