package com.jpmorgan.am.grt.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.jpmorgan.am.grt.domain.BatchJobHistory;
import com.jpmorgan.am.grt.service.BatchJobHistoryService;
import com.jpmorgan.am.grt.web.rest.util.HeaderUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * REST controller for managing BatchJobHistory.
 */
@RestController
@RequestMapping("/api")
public class BatchJobHistoryResource {

    private final Logger log = LoggerFactory.getLogger(BatchJobHistoryResource.class);
        
    @Inject
    private BatchJobHistoryService batchJobHistoryService;

    /**
     * POST  /batch-job-histories : Create a new batchJobHistory.
     *
     * @param batchJobHistory the batchJobHistory to create
     * @return the ResponseEntity with status 201 (Created) and with body the new batchJobHistory, or with status 400 (Bad Request) if the batchJobHistory has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/batch-job-histories",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<BatchJobHistory> createBatchJobHistory(@Valid @RequestBody BatchJobHistory batchJobHistory) throws URISyntaxException {
        log.debug("REST request to save BatchJobHistory : {}", batchJobHistory);
        if (batchJobHistory.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("batchJobHistory", "idexists", "A new batchJobHistory cannot already have an ID")).body(null);
        }
        BatchJobHistory result = batchJobHistoryService.save(batchJobHistory);
        return ResponseEntity.created(new URI("/api/batch-job-histories/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("batchJobHistory", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /batch-job-histories : Updates an existing batchJobHistory.
     *
     * @param batchJobHistory the batchJobHistory to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated batchJobHistory,
     * or with status 400 (Bad Request) if the batchJobHistory is not valid,
     * or with status 500 (Internal Server Error) if the batchJobHistory couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/batch-job-histories",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<BatchJobHistory> updateBatchJobHistory(@Valid @RequestBody BatchJobHistory batchJobHistory) throws URISyntaxException {
        log.debug("REST request to update BatchJobHistory : {}", batchJobHistory);
        if (batchJobHistory.getId() == null) {
            return createBatchJobHistory(batchJobHistory);
        }
        BatchJobHistory result = batchJobHistoryService.save(batchJobHistory);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("batchJobHistory", batchJobHistory.getId().toString()))
            .body(result);
    }

    /**
     * GET  /batch-job-histories : get all the batchJobHistories.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of batchJobHistories in body
     */
    @RequestMapping(value = "/batch-job-histories",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<BatchJobHistory> getAllBatchJobHistories() {
        log.debug("REST request to get all BatchJobHistories");
        return batchJobHistoryService.findAll();
    }

    /**
     * GET  /batch-job-histories/:id : get the "id" batchJobHistory.
     *
     * @param id the id of the batchJobHistory to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the batchJobHistory, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/batch-job-histories/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<BatchJobHistory> getBatchJobHistory(@PathVariable Long id) {
        log.debug("REST request to get BatchJobHistory : {}", id);
        BatchJobHistory batchJobHistory = batchJobHistoryService.findOne(id);
        return Optional.ofNullable(batchJobHistory)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /batch-job-histories/:id : delete the "id" batchJobHistory.
     *
     * @param id the id of the batchJobHistory to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/batch-job-histories/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteBatchJobHistory(@PathVariable Long id) {
        log.debug("REST request to delete BatchJobHistory : {}", id);
        batchJobHistoryService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("batchJobHistory", id.toString())).build();
    }

    /**
     * SEARCH  /_search/batch-job-histories?query=:query : search for the batchJobHistory corresponding
     * to the query.
     *
     * @param query the query of the batchJobHistory search 
     * @return the result of the search
     */
    @RequestMapping(value = "/_search/batch-job-histories",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<BatchJobHistory> searchBatchJobHistories(@RequestParam String query) {
        log.debug("REST request to search BatchJobHistories for query {}", query);
        return batchJobHistoryService.search(query);
    }


}
