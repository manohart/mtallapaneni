package com.jpmorgan.am.grt.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.jpmorgan.am.grt.domain.BatchReportDetailHistory;
import com.jpmorgan.am.grt.service.BatchReportDetailHistoryService;
import com.jpmorgan.am.grt.web.rest.util.HeaderUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * REST controller for managing BatchReportDetailHistory.
 */
@RestController
@RequestMapping("/api")
public class BatchReportDetailHistoryResource {

    private final Logger log = LoggerFactory.getLogger(BatchReportDetailHistoryResource.class);
        
    @Inject
    private BatchReportDetailHistoryService batchReportDetailHistoryService;

    /**
     * POST  /batch-report-detail-histories : Create a new batchReportDetailHistory.
     *
     * @param batchReportDetailHistory the batchReportDetailHistory to create
     * @return the ResponseEntity with status 201 (Created) and with body the new batchReportDetailHistory, or with status 400 (Bad Request) if the batchReportDetailHistory has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/batch-report-detail-histories",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<BatchReportDetailHistory> createBatchReportDetailHistory(@Valid @RequestBody BatchReportDetailHistory batchReportDetailHistory) throws URISyntaxException {
        log.debug("REST request to save BatchReportDetailHistory : {}", batchReportDetailHistory);
        if (batchReportDetailHistory.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("batchReportDetailHistory", "idexists", "A new batchReportDetailHistory cannot already have an ID")).body(null);
        }
        BatchReportDetailHistory result = batchReportDetailHistoryService.save(batchReportDetailHistory);
        return ResponseEntity.created(new URI("/api/batch-report-detail-histories/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("batchReportDetailHistory", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /batch-report-detail-histories : Updates an existing batchReportDetailHistory.
     *
     * @param batchReportDetailHistory the batchReportDetailHistory to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated batchReportDetailHistory,
     * or with status 400 (Bad Request) if the batchReportDetailHistory is not valid,
     * or with status 500 (Internal Server Error) if the batchReportDetailHistory couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/batch-report-detail-histories",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<BatchReportDetailHistory> updateBatchReportDetailHistory(@Valid @RequestBody BatchReportDetailHistory batchReportDetailHistory) throws URISyntaxException {
        log.debug("REST request to update BatchReportDetailHistory : {}", batchReportDetailHistory);
        if (batchReportDetailHistory.getId() == null) {
            return createBatchReportDetailHistory(batchReportDetailHistory);
        }
        BatchReportDetailHistory result = batchReportDetailHistoryService.save(batchReportDetailHistory);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("batchReportDetailHistory", batchReportDetailHistory.getId().toString()))
            .body(result);
    }

    /**
     * GET  /batch-report-detail-histories : get all the batchReportDetailHistories.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of batchReportDetailHistories in body
     */
    @RequestMapping(value = "/batch-report-detail-histories",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<BatchReportDetailHistory> getAllBatchReportDetailHistories() {
        log.debug("REST request to get all BatchReportDetailHistories");
        return batchReportDetailHistoryService.findAll();
    }

    /**
     * GET  /batch-report-detail-histories/:id : get the "id" batchReportDetailHistory.
     *
     * @param id the id of the batchReportDetailHistory to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the batchReportDetailHistory, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/batch-report-detail-histories/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<BatchReportDetailHistory> getBatchReportDetailHistory(@PathVariable Long id) {
        log.debug("REST request to get BatchReportDetailHistory : {}", id);
        BatchReportDetailHistory batchReportDetailHistory = batchReportDetailHistoryService.findOne(id);
        return Optional.ofNullable(batchReportDetailHistory)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /batch-report-detail-histories/:id : delete the "id" batchReportDetailHistory.
     *
     * @param id the id of the batchReportDetailHistory to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/batch-report-detail-histories/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteBatchReportDetailHistory(@PathVariable Long id) {
        log.debug("REST request to delete BatchReportDetailHistory : {}", id);
        batchReportDetailHistoryService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("batchReportDetailHistory", id.toString())).build();
    }

    /**
     * SEARCH  /_search/batch-report-detail-histories?query=:query : search for the batchReportDetailHistory corresponding
     * to the query.
     *
     * @param query the query of the batchReportDetailHistory search 
     * @return the result of the search
     */
    @RequestMapping(value = "/_search/batch-report-detail-histories",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<BatchReportDetailHistory> searchBatchReportDetailHistories(@RequestParam String query) {
        log.debug("REST request to search BatchReportDetailHistories for query {}", query);
        return batchReportDetailHistoryService.search(query);
    }


}
