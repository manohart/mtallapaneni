package com.jpmorgan.am.grt.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.jpmorgan.am.grt.domain.HealthCheckConfig;
import com.jpmorgan.am.grt.service.HealthCheckConfigService;
import com.jpmorgan.am.grt.web.rest.util.HeaderUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * REST controller for managing HealthCheckConfig.
 */
@RestController
@RequestMapping("/api")
public class HealthCheckConfigResource {

    private final Logger log = LoggerFactory.getLogger(HealthCheckConfigResource.class);
        
    @Inject
    private HealthCheckConfigService healthCheckConfigService;

    /**
     * POST  /health-check-configs : Create a new healthCheckConfig.
     *
     * @param healthCheckConfig the healthCheckConfig to create
     * @return the ResponseEntity with status 201 (Created) and with body the new healthCheckConfig, or with status 400 (Bad Request) if the healthCheckConfig has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/health-check-configs",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<HealthCheckConfig> createHealthCheckConfig(@Valid @RequestBody HealthCheckConfig healthCheckConfig) throws URISyntaxException {
        log.debug("REST request to save HealthCheckConfig : {}", healthCheckConfig);
        if (healthCheckConfig.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("healthCheckConfig", "idexists", "A new healthCheckConfig cannot already have an ID")).body(null);
        }
        HealthCheckConfig result = healthCheckConfigService.save(healthCheckConfig);
        return ResponseEntity.created(new URI("/api/health-check-configs/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("healthCheckConfig", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /health-check-configs : Updates an existing healthCheckConfig.
     *
     * @param healthCheckConfig the healthCheckConfig to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated healthCheckConfig,
     * or with status 400 (Bad Request) if the healthCheckConfig is not valid,
     * or with status 500 (Internal Server Error) if the healthCheckConfig couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/health-check-configs",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<HealthCheckConfig> updateHealthCheckConfig(@Valid @RequestBody HealthCheckConfig healthCheckConfig) throws URISyntaxException {
        log.debug("REST request to update HealthCheckConfig : {}", healthCheckConfig);
        if (healthCheckConfig.getId() == null) {
            return createHealthCheckConfig(healthCheckConfig);
        }
        HealthCheckConfig result = healthCheckConfigService.save(healthCheckConfig);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("healthCheckConfig", healthCheckConfig.getId().toString()))
            .body(result);
    }

    /**
     * GET  /health-check-configs : get all the healthCheckConfigs.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of healthCheckConfigs in body
     */
    @RequestMapping(value = "/health-check-configs",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<HealthCheckConfig> getAllHealthCheckConfigs() {
        log.debug("REST request to get all HealthCheckConfigs");
        return healthCheckConfigService.findAll();
    }

    /**
     * GET  /health-check-configs/:id : get the "id" healthCheckConfig.
     *
     * @param id the id of the healthCheckConfig to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the healthCheckConfig, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/health-check-configs/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<HealthCheckConfig> getHealthCheckConfig(@PathVariable Long id) {
        log.debug("REST request to get HealthCheckConfig : {}", id);
        HealthCheckConfig healthCheckConfig = healthCheckConfigService.findOne(id);
        return Optional.ofNullable(healthCheckConfig)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /health-check-configs/:id : delete the "id" healthCheckConfig.
     *
     * @param id the id of the healthCheckConfig to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/health-check-configs/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteHealthCheckConfig(@PathVariable Long id) {
        log.debug("REST request to delete HealthCheckConfig : {}", id);
        healthCheckConfigService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("healthCheckConfig", id.toString())).build();
    }

    /**
     * SEARCH  /_search/health-check-configs?query=:query : search for the healthCheckConfig corresponding
     * to the query.
     *
     * @param query the query of the healthCheckConfig search 
     * @return the result of the search
     */
    @RequestMapping(value = "/_search/health-check-configs",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<HealthCheckConfig> searchHealthCheckConfigs(@RequestParam String query) {
        log.debug("REST request to search HealthCheckConfigs for query {}", query);
        return healthCheckConfigService.search(query);
    }


}
