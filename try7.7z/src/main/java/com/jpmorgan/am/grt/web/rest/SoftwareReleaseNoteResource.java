package com.jpmorgan.am.grt.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.jpmorgan.am.grt.domain.SoftwareReleaseNote;
import com.jpmorgan.am.grt.service.SoftwareReleaseNoteService;
import com.jpmorgan.am.grt.web.rest.util.HeaderUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * REST controller for managing SoftwareReleaseNote.
 */
@RestController
@RequestMapping("/api")
public class SoftwareReleaseNoteResource {

    private final Logger log = LoggerFactory.getLogger(SoftwareReleaseNoteResource.class);
        
    @Inject
    private SoftwareReleaseNoteService softwareReleaseNoteService;

    /**
     * POST  /software-release-notes : Create a new softwareReleaseNote.
     *
     * @param softwareReleaseNote the softwareReleaseNote to create
     * @return the ResponseEntity with status 201 (Created) and with body the new softwareReleaseNote, or with status 400 (Bad Request) if the softwareReleaseNote has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/software-release-notes",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<SoftwareReleaseNote> createSoftwareReleaseNote(@Valid @RequestBody SoftwareReleaseNote softwareReleaseNote) throws URISyntaxException {
        log.debug("REST request to save SoftwareReleaseNote : {}", softwareReleaseNote);
        if (softwareReleaseNote.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("softwareReleaseNote", "idexists", "A new softwareReleaseNote cannot already have an ID")).body(null);
        }
        SoftwareReleaseNote result = softwareReleaseNoteService.save(softwareReleaseNote);
        return ResponseEntity.created(new URI("/api/software-release-notes/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("softwareReleaseNote", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /software-release-notes : Updates an existing softwareReleaseNote.
     *
     * @param softwareReleaseNote the softwareReleaseNote to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated softwareReleaseNote,
     * or with status 400 (Bad Request) if the softwareReleaseNote is not valid,
     * or with status 500 (Internal Server Error) if the softwareReleaseNote couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/software-release-notes",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<SoftwareReleaseNote> updateSoftwareReleaseNote(@Valid @RequestBody SoftwareReleaseNote softwareReleaseNote) throws URISyntaxException {
        log.debug("REST request to update SoftwareReleaseNote : {}", softwareReleaseNote);
        if (softwareReleaseNote.getId() == null) {
            return createSoftwareReleaseNote(softwareReleaseNote);
        }
        SoftwareReleaseNote result = softwareReleaseNoteService.save(softwareReleaseNote);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("softwareReleaseNote", softwareReleaseNote.getId().toString()))
            .body(result);
    }

    /**
     * GET  /software-release-notes : get all the softwareReleaseNotes.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of softwareReleaseNotes in body
     */
    @RequestMapping(value = "/software-release-notes",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<SoftwareReleaseNote> getAllSoftwareReleaseNotes() {
        log.debug("REST request to get all SoftwareReleaseNotes");
        return softwareReleaseNoteService.findAll();
    }

    /**
     * GET  /software-release-notes/:id : get the "id" softwareReleaseNote.
     *
     * @param id the id of the softwareReleaseNote to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the softwareReleaseNote, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/software-release-notes/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<SoftwareReleaseNote> getSoftwareReleaseNote(@PathVariable Long id) {
        log.debug("REST request to get SoftwareReleaseNote : {}", id);
        SoftwareReleaseNote softwareReleaseNote = softwareReleaseNoteService.findOne(id);
        return Optional.ofNullable(softwareReleaseNote)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /software-release-notes/:id : delete the "id" softwareReleaseNote.
     *
     * @param id the id of the softwareReleaseNote to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/software-release-notes/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteSoftwareReleaseNote(@PathVariable Long id) {
        log.debug("REST request to delete SoftwareReleaseNote : {}", id);
        softwareReleaseNoteService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("softwareReleaseNote", id.toString())).build();
    }

    /**
     * SEARCH  /_search/software-release-notes?query=:query : search for the softwareReleaseNote corresponding
     * to the query.
     *
     * @param query the query of the softwareReleaseNote search 
     * @return the result of the search
     */
    @RequestMapping(value = "/_search/software-release-notes",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public List<SoftwareReleaseNote> searchSoftwareReleaseNotes(@RequestParam String query) {
        log.debug("REST request to search SoftwareReleaseNotes for query {}", query);
        return softwareReleaseNoteService.search(query);
    }


}
