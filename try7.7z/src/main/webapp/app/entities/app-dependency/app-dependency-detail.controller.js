(function() {
    'use strict';

    angular
        .module('grtDashboardApp')
        .controller('AppDependencyDetailController', AppDependencyDetailController);

    AppDependencyDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'AppDependency', 'Application'];

    function AppDependencyDetailController($scope, $rootScope, $stateParams, previousState, entity, AppDependency, Application) {
        var vm = this;

        vm.appDependency = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('grtDashboardApp:appDependencyUpdate', function(event, result) {
            vm.appDependency = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
