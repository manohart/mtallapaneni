(function() {
    'use strict';

    angular
        .module('grtDashboardApp')
        .controller('AppDependencyController', AppDependencyController);

    AppDependencyController.$inject = ['$scope', '$state', 'AppDependency', 'AppDependencySearch'];

    function AppDependencyController ($scope, $state, AppDependency, AppDependencySearch) {
        var vm = this;
        
        vm.appDependencies = [];
        vm.search = search;
        vm.loadAll = loadAll;

        loadAll();

        function loadAll() {
            AppDependency.query(function(result) {
                vm.appDependencies = result;
            });
        }

        function search () {
            if (!vm.searchQuery) {
                return vm.loadAll();
            }
            AppDependencySearch.query({query: vm.searchQuery}, function(result) {
                vm.appDependencies = result;
            });
        }    }
})();
