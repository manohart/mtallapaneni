(function() {
    'use strict';

    angular
        .module('grtDashboardApp')
        .controller('HealthCheckerDeleteController',HealthCheckerDeleteController);

    HealthCheckerDeleteController.$inject = ['$uibModalInstance', 'entity', 'HealthChecker'];

    function HealthCheckerDeleteController($uibModalInstance, entity, HealthChecker) {
        var vm = this;

        vm.healthChecker = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;
        
        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            HealthChecker.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
