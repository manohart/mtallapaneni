(function() {
    'use strict';

    angular
        .module('grtDashboardApp')
        .controller('HealthCheckerDetailController', HealthCheckerDetailController);

    HealthCheckerDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'HealthChecker'];

    function HealthCheckerDetailController($scope, $rootScope, $stateParams, previousState, entity, HealthChecker) {
        var vm = this;

        vm.healthChecker = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('grtDashboardApp:healthCheckerUpdate', function(event, result) {
            vm.healthChecker = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
