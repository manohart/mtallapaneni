(function() {
    'use strict';

    angular
        .module('grtDashboardApp')
        .controller('HealthCheckerController', HealthCheckerController);

    HealthCheckerController.$inject = ['$scope', '$state', 'HealthChecker', 'HealthCheckerSearch'];

    function HealthCheckerController ($scope, $state, HealthChecker, HealthCheckerSearch) {
        var vm = this;
        
        vm.healthCheckers = [];
        vm.search = search;
        vm.loadAll = loadAll;

        loadAll();

        function loadAll() {
            HealthChecker.query(function(result) {
                vm.healthCheckers = result;
            });
        }

        function search () {
            if (!vm.searchQuery) {
                return vm.loadAll();
            }
            HealthCheckerSearch.query({query: vm.searchQuery}, function(result) {
                vm.healthCheckers = result;
            });
        }    }
})();
