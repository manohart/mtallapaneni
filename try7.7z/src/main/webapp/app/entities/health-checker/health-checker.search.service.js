(function() {
    'use strict';

    angular
        .module('grtDashboardApp')
        .factory('HealthCheckerSearch', HealthCheckerSearch);

    HealthCheckerSearch.$inject = ['$resource'];

    function HealthCheckerSearch($resource) {
        var resourceUrl =  'api/_search/health-checkers/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true}
        });
    }
})();
