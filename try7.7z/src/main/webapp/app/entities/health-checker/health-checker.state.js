(function() {
    'use strict';

    angular
        .module('grtDashboardApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('health-checker', {
            parent: 'entity',
            url: '/health-checker',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'HealthCheckers'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/health-checker/health-checkers.html',
                    controller: 'HealthCheckerController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
            }
        })
        .state('health-checker-detail', {
            parent: 'entity',
            url: '/health-checker/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'HealthChecker'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/health-checker/health-checker-detail.html',
                    controller: 'HealthCheckerDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'HealthChecker', function($stateParams, HealthChecker) {
                    return HealthChecker.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'health-checker',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('health-checker-detail.edit', {
            parent: 'health-checker-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/health-checker/health-checker-dialog.html',
                    controller: 'HealthCheckerDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['HealthChecker', function(HealthChecker) {
                            return HealthChecker.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('health-checker.new', {
            parent: 'health-checker',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/health-checker/health-checker-dialog.html',
                    controller: 'HealthCheckerDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                name: null,
                                javaClass: null,
                                isActive: false,
                                updatedDate: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('health-checker', null, { reload: 'health-checker' });
                }, function() {
                    $state.go('health-checker');
                });
            }]
        })
        .state('health-checker.edit', {
            parent: 'health-checker',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/health-checker/health-checker-dialog.html',
                    controller: 'HealthCheckerDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['HealthChecker', function(HealthChecker) {
                            return HealthChecker.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('health-checker', null, { reload: 'health-checker' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('health-checker.delete', {
            parent: 'health-checker',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/health-checker/health-checker-delete-dialog.html',
                    controller: 'HealthCheckerDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['HealthChecker', function(HealthChecker) {
                            return HealthChecker.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('health-checker', null, { reload: 'health-checker' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
