(function() {
    'use strict';

    angular
        .module('grtDashboardApp')
        .controller('ServerDetailController', ServerDetailController);

    ServerDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'Server', 'Application', 'Lob'];

    function ServerDetailController($scope, $rootScope, $stateParams, previousState, entity, Server, Application, Lob) {
        var vm = this;

        vm.server = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('grtDashboardApp:serverUpdate', function(event, result) {
            vm.server = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
