(function() {
    'use strict';

    angular
        .module('grtDashboardApp')
        .controller('TemplateDetailController', TemplateDetailController);

    TemplateDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'Template', 'Lob'];

    function TemplateDetailController($scope, $rootScope, $stateParams, previousState, entity, Template, Lob) {
        var vm = this;

        vm.template = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('grtDashboardApp:templateUpdate', function(event, result) {
            vm.template = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
