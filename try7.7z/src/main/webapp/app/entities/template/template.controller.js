(function() {
    'use strict';

    angular
        .module('grtDashboardApp')
        .controller('TemplateController', TemplateController);

    TemplateController.$inject = ['$scope', '$state', 'Template', 'TemplateSearch'];

    function TemplateController ($scope, $state, Template, TemplateSearch) {
        var vm = this;
        
        vm.templates = [];
        vm.search = search;
        vm.loadAll = loadAll;

        loadAll();

        function loadAll() {
            Template.query(function(result) {
                vm.templates = result;
            });
        }

        function search () {
            if (!vm.searchQuery) {
                return vm.loadAll();
            }
            TemplateSearch.query({query: vm.searchQuery}, function(result) {
                vm.templates = result;
            });
        }    }
})();
