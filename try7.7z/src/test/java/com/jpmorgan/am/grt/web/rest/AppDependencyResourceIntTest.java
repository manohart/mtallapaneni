package com.jpmorgan.am.grt.web.rest;

import com.jpmorgan.am.grt.GrtDashboardApp;

import com.jpmorgan.am.grt.domain.AppDependency;
import com.jpmorgan.am.grt.repository.AppDependencyRepository;
import com.jpmorgan.am.grt.service.AppDependencyService;
import com.jpmorgan.am.grt.repository.search.AppDependencySearchRepository;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneId;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the AppDependencyResource REST controller.
 *
 * @see AppDependencyResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = GrtDashboardApp.class)
public class AppDependencyResourceIntTest {

    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(ZoneId.of("Z"));


    private static final Boolean DEFAULT_IS_ACTIVE = false;
    private static final Boolean UPDATED_IS_ACTIVE = true;

    private static final ZonedDateTime DEFAULT_UPDATED_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneId.systemDefault());
    private static final ZonedDateTime UPDATED_UPDATED_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);
    private static final String DEFAULT_UPDATED_DATE_STR = dateTimeFormatter.format(DEFAULT_UPDATED_DATE);

    @Inject
    private AppDependencyRepository appDependencyRepository;

    @Inject
    private AppDependencyService appDependencyService;

    @Inject
    private AppDependencySearchRepository appDependencySearchRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restAppDependencyMockMvc;

    private AppDependency appDependency;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        AppDependencyResource appDependencyResource = new AppDependencyResource();
        ReflectionTestUtils.setField(appDependencyResource, "appDependencyService", appDependencyService);
        this.restAppDependencyMockMvc = MockMvcBuilders.standaloneSetup(appDependencyResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static AppDependency createEntity(EntityManager em) {
        AppDependency appDependency = new AppDependency();
        appDependency.setIsActive(DEFAULT_IS_ACTIVE);
        appDependency.setUpdatedDate(DEFAULT_UPDATED_DATE);
        return appDependency;
    }

    @Before
    public void initTest() {
        appDependencySearchRepository.deleteAll();
        appDependency = createEntity(em);
    }

    @Test
    @Transactional
    public void createAppDependency() throws Exception {
        int databaseSizeBeforeCreate = appDependencyRepository.findAll().size();

        // Create the AppDependency

        restAppDependencyMockMvc.perform(post("/api/app-dependencies")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(appDependency)))
                .andExpect(status().isCreated());

        // Validate the AppDependency in the database
        List<AppDependency> appDependencies = appDependencyRepository.findAll();
        assertThat(appDependencies).hasSize(databaseSizeBeforeCreate + 1);
        AppDependency testAppDependency = appDependencies.get(appDependencies.size() - 1);
        assertThat(testAppDependency.isIsActive()).isEqualTo(DEFAULT_IS_ACTIVE);
        assertThat(testAppDependency.getUpdatedDate()).isEqualTo(DEFAULT_UPDATED_DATE);

        // Validate the AppDependency in ElasticSearch
        AppDependency appDependencyEs = appDependencySearchRepository.findOne(testAppDependency.getId());
        assertThat(appDependencyEs).isEqualToComparingFieldByField(testAppDependency);
    }

    @Test
    @Transactional
    public void checkIsActiveIsRequired() throws Exception {
        int databaseSizeBeforeTest = appDependencyRepository.findAll().size();
        // set the field null
        appDependency.setIsActive(null);

        // Create the AppDependency, which fails.

        restAppDependencyMockMvc.perform(post("/api/app-dependencies")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(appDependency)))
                .andExpect(status().isBadRequest());

        List<AppDependency> appDependencies = appDependencyRepository.findAll();
        assertThat(appDependencies).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllAppDependencies() throws Exception {
        // Initialize the database
        appDependencyRepository.saveAndFlush(appDependency);

        // Get all the appDependencies
        restAppDependencyMockMvc.perform(get("/api/app-dependencies?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andExpect(jsonPath("$.[*].id").value(hasItem(appDependency.getId().intValue())))
                .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
                .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }

    @Test
    @Transactional
    public void getAppDependency() throws Exception {
        // Initialize the database
        appDependencyRepository.saveAndFlush(appDependency);

        // Get the appDependency
        restAppDependencyMockMvc.perform(get("/api/app-dependencies/{id}", appDependency.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(appDependency.getId().intValue()))
            .andExpect(jsonPath("$.isActive").value(DEFAULT_IS_ACTIVE.booleanValue()))
            .andExpect(jsonPath("$.updatedDate").value(DEFAULT_UPDATED_DATE_STR));
    }

    @Test
    @Transactional
    public void getNonExistingAppDependency() throws Exception {
        // Get the appDependency
        restAppDependencyMockMvc.perform(get("/api/app-dependencies/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateAppDependency() throws Exception {
        // Initialize the database
        appDependencyService.save(appDependency);

        int databaseSizeBeforeUpdate = appDependencyRepository.findAll().size();

        // Update the appDependency
        AppDependency updatedAppDependency = appDependencyRepository.findOne(appDependency.getId());
        updatedAppDependency.setIsActive(UPDATED_IS_ACTIVE);
        updatedAppDependency.setUpdatedDate(UPDATED_UPDATED_DATE);

        restAppDependencyMockMvc.perform(put("/api/app-dependencies")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(updatedAppDependency)))
                .andExpect(status().isOk());

        // Validate the AppDependency in the database
        List<AppDependency> appDependencies = appDependencyRepository.findAll();
        assertThat(appDependencies).hasSize(databaseSizeBeforeUpdate);
        AppDependency testAppDependency = appDependencies.get(appDependencies.size() - 1);
        assertThat(testAppDependency.isIsActive()).isEqualTo(UPDATED_IS_ACTIVE);
        assertThat(testAppDependency.getUpdatedDate()).isEqualTo(UPDATED_UPDATED_DATE);

        // Validate the AppDependency in ElasticSearch
        AppDependency appDependencyEs = appDependencySearchRepository.findOne(testAppDependency.getId());
        assertThat(appDependencyEs).isEqualToComparingFieldByField(testAppDependency);
    }

    @Test
    @Transactional
    public void deleteAppDependency() throws Exception {
        // Initialize the database
        appDependencyService.save(appDependency);

        int databaseSizeBeforeDelete = appDependencyRepository.findAll().size();

        // Get the appDependency
        restAppDependencyMockMvc.perform(delete("/api/app-dependencies/{id}", appDependency.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate ElasticSearch is empty
        boolean appDependencyExistsInEs = appDependencySearchRepository.exists(appDependency.getId());
        assertThat(appDependencyExistsInEs).isFalse();

        // Validate the database is empty
        List<AppDependency> appDependencies = appDependencyRepository.findAll();
        assertThat(appDependencies).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void searchAppDependency() throws Exception {
        // Initialize the database
        appDependencyService.save(appDependency);

        // Search the appDependency
        restAppDependencyMockMvc.perform(get("/api/_search/app-dependencies?query=id:" + appDependency.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(appDependency.getId().intValue())))
            .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
            .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }
}
