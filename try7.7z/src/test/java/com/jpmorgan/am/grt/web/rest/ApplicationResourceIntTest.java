package com.jpmorgan.am.grt.web.rest;

import com.jpmorgan.am.grt.GrtDashboardApp;

import com.jpmorgan.am.grt.domain.Application;
import com.jpmorgan.am.grt.repository.ApplicationRepository;
import com.jpmorgan.am.grt.service.ApplicationService;
import com.jpmorgan.am.grt.repository.search.ApplicationSearchRepository;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneId;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.jpmorgan.am.grt.domain.enumeration.InfraCategory;
import com.jpmorgan.am.grt.domain.enumeration.AppType;
import com.jpmorgan.am.grt.domain.enumeration.HolidayCalendar;
/**
 * Test class for the ApplicationResource REST controller.
 *
 * @see ApplicationResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = GrtDashboardApp.class)
public class ApplicationResourceIntTest {

    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(ZoneId.of("Z"));

    private static final String DEFAULT_NAME = "AAAAA";
    private static final String UPDATED_NAME = "BBBBB";
    private static final String DEFAULT_DESCRIPTION = "AAAAAAAAAAAAAAAAAAAA";
    private static final String UPDATED_DESCRIPTION = "BBBBBBBBBBBBBBBBBBBB";

    private static final InfraCategory DEFAULT_CATEGORY = InfraCategory.INVEST;
    private static final InfraCategory UPDATED_CATEGORY = InfraCategory.MAINTAIN;

    private static final AppType DEFAULT_TYPE = AppType.BATCH;
    private static final AppType UPDATED_TYPE = AppType.WEB;
    private static final String DEFAULT_SLA = "AAAAA";
    private static final String UPDATED_SLA = "BBBBB";

    private static final HolidayCalendar DEFAULT_HOLIDAY_CALENDAR = HolidayCalendar.NYU;
    private static final HolidayCalendar UPDATED_HOLIDAY_CALENDAR = HolidayCalendar.LON;
    private static final String DEFAULT_DOCUMENATION = "AAAAA";
    private static final String UPDATED_DOCUMENATION = "BBBBB";
    private static final String DEFAULT_DEPLOYED_PATH = "AAAAA";
    private static final String UPDATED_DEPLOYED_PATH = "BBBBB";
    private static final String DEFAULT_METRICS_PATH = "AAAAA";
    private static final String UPDATED_METRICS_PATH = "BBBBB";

    private static final Boolean DEFAULT_IS_ACTIVE = false;
    private static final Boolean UPDATED_IS_ACTIVE = true;

    private static final ZonedDateTime DEFAULT_UPDATED_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneId.systemDefault());
    private static final ZonedDateTime UPDATED_UPDATED_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);
    private static final String DEFAULT_UPDATED_DATE_STR = dateTimeFormatter.format(DEFAULT_UPDATED_DATE);

    @Inject
    private ApplicationRepository applicationRepository;

    @Inject
    private ApplicationService applicationService;

    @Inject
    private ApplicationSearchRepository applicationSearchRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restApplicationMockMvc;

    private Application application;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        ApplicationResource applicationResource = new ApplicationResource();
        ReflectionTestUtils.setField(applicationResource, "applicationService", applicationService);
        this.restApplicationMockMvc = MockMvcBuilders.standaloneSetup(applicationResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Application createEntity(EntityManager em) {
        Application application = new Application();
        application.setName(DEFAULT_NAME);
        application.setDescription(DEFAULT_DESCRIPTION);
        application.setCategory(DEFAULT_CATEGORY);
        application.setType(DEFAULT_TYPE);
        application.setSla(DEFAULT_SLA);
        application.setHolidayCalendar(DEFAULT_HOLIDAY_CALENDAR);
        application.setDocumenation(DEFAULT_DOCUMENATION);
        application.setDeployedPath(DEFAULT_DEPLOYED_PATH);
        application.setMetricsPath(DEFAULT_METRICS_PATH);
        application.setIsActive(DEFAULT_IS_ACTIVE);
        application.setUpdatedDate(DEFAULT_UPDATED_DATE);
        return application;
    }

    @Before
    public void initTest() {
        applicationSearchRepository.deleteAll();
        application = createEntity(em);
    }

    @Test
    @Transactional
    public void createApplication() throws Exception {
        int databaseSizeBeforeCreate = applicationRepository.findAll().size();

        // Create the Application

        restApplicationMockMvc.perform(post("/api/applications")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(application)))
                .andExpect(status().isCreated());

        // Validate the Application in the database
        List<Application> applications = applicationRepository.findAll();
        assertThat(applications).hasSize(databaseSizeBeforeCreate + 1);
        Application testApplication = applications.get(applications.size() - 1);
        assertThat(testApplication.getName()).isEqualTo(DEFAULT_NAME);
        assertThat(testApplication.getDescription()).isEqualTo(DEFAULT_DESCRIPTION);
        assertThat(testApplication.getCategory()).isEqualTo(DEFAULT_CATEGORY);
        assertThat(testApplication.getType()).isEqualTo(DEFAULT_TYPE);
        assertThat(testApplication.getSla()).isEqualTo(DEFAULT_SLA);
        assertThat(testApplication.getHolidayCalendar()).isEqualTo(DEFAULT_HOLIDAY_CALENDAR);
        assertThat(testApplication.getDocumenation()).isEqualTo(DEFAULT_DOCUMENATION);
        assertThat(testApplication.getDeployedPath()).isEqualTo(DEFAULT_DEPLOYED_PATH);
        assertThat(testApplication.getMetricsPath()).isEqualTo(DEFAULT_METRICS_PATH);
        assertThat(testApplication.isIsActive()).isEqualTo(DEFAULT_IS_ACTIVE);
        assertThat(testApplication.getUpdatedDate()).isEqualTo(DEFAULT_UPDATED_DATE);

        // Validate the Application in ElasticSearch
        Application applicationEs = applicationSearchRepository.findOne(testApplication.getId());
        assertThat(applicationEs).isEqualToComparingFieldByField(testApplication);
    }

    @Test
    @Transactional
    public void checkNameIsRequired() throws Exception {
        int databaseSizeBeforeTest = applicationRepository.findAll().size();
        // set the field null
        application.setName(null);

        // Create the Application, which fails.

        restApplicationMockMvc.perform(post("/api/applications")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(application)))
                .andExpect(status().isBadRequest());

        List<Application> applications = applicationRepository.findAll();
        assertThat(applications).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkDescriptionIsRequired() throws Exception {
        int databaseSizeBeforeTest = applicationRepository.findAll().size();
        // set the field null
        application.setDescription(null);

        // Create the Application, which fails.

        restApplicationMockMvc.perform(post("/api/applications")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(application)))
                .andExpect(status().isBadRequest());

        List<Application> applications = applicationRepository.findAll();
        assertThat(applications).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkCategoryIsRequired() throws Exception {
        int databaseSizeBeforeTest = applicationRepository.findAll().size();
        // set the field null
        application.setCategory(null);

        // Create the Application, which fails.

        restApplicationMockMvc.perform(post("/api/applications")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(application)))
                .andExpect(status().isBadRequest());

        List<Application> applications = applicationRepository.findAll();
        assertThat(applications).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkTypeIsRequired() throws Exception {
        int databaseSizeBeforeTest = applicationRepository.findAll().size();
        // set the field null
        application.setType(null);

        // Create the Application, which fails.

        restApplicationMockMvc.perform(post("/api/applications")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(application)))
                .andExpect(status().isBadRequest());

        List<Application> applications = applicationRepository.findAll();
        assertThat(applications).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkHolidayCalendarIsRequired() throws Exception {
        int databaseSizeBeforeTest = applicationRepository.findAll().size();
        // set the field null
        application.setHolidayCalendar(null);

        // Create the Application, which fails.

        restApplicationMockMvc.perform(post("/api/applications")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(application)))
                .andExpect(status().isBadRequest());

        List<Application> applications = applicationRepository.findAll();
        assertThat(applications).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkDocumenationIsRequired() throws Exception {
        int databaseSizeBeforeTest = applicationRepository.findAll().size();
        // set the field null
        application.setDocumenation(null);

        // Create the Application, which fails.

        restApplicationMockMvc.perform(post("/api/applications")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(application)))
                .andExpect(status().isBadRequest());

        List<Application> applications = applicationRepository.findAll();
        assertThat(applications).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkDeployedPathIsRequired() throws Exception {
        int databaseSizeBeforeTest = applicationRepository.findAll().size();
        // set the field null
        application.setDeployedPath(null);

        // Create the Application, which fails.

        restApplicationMockMvc.perform(post("/api/applications")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(application)))
                .andExpect(status().isBadRequest());

        List<Application> applications = applicationRepository.findAll();
        assertThat(applications).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkIsActiveIsRequired() throws Exception {
        int databaseSizeBeforeTest = applicationRepository.findAll().size();
        // set the field null
        application.setIsActive(null);

        // Create the Application, which fails.

        restApplicationMockMvc.perform(post("/api/applications")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(application)))
                .andExpect(status().isBadRequest());

        List<Application> applications = applicationRepository.findAll();
        assertThat(applications).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllApplications() throws Exception {
        // Initialize the database
        applicationRepository.saveAndFlush(application);

        // Get all the applications
        restApplicationMockMvc.perform(get("/api/applications?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andExpect(jsonPath("$.[*].id").value(hasItem(application.getId().intValue())))
                .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
                .andExpect(jsonPath("$.[*].description").value(hasItem(DEFAULT_DESCRIPTION.toString())))
                .andExpect(jsonPath("$.[*].category").value(hasItem(DEFAULT_CATEGORY.toString())))
                .andExpect(jsonPath("$.[*].type").value(hasItem(DEFAULT_TYPE.toString())))
                .andExpect(jsonPath("$.[*].sla").value(hasItem(DEFAULT_SLA.toString())))
                .andExpect(jsonPath("$.[*].holidayCalendar").value(hasItem(DEFAULT_HOLIDAY_CALENDAR.toString())))
                .andExpect(jsonPath("$.[*].documenation").value(hasItem(DEFAULT_DOCUMENATION.toString())))
                .andExpect(jsonPath("$.[*].deployedPath").value(hasItem(DEFAULT_DEPLOYED_PATH.toString())))
                .andExpect(jsonPath("$.[*].metricsPath").value(hasItem(DEFAULT_METRICS_PATH.toString())))
                .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
                .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }

    @Test
    @Transactional
    public void getApplication() throws Exception {
        // Initialize the database
        applicationRepository.saveAndFlush(application);

        // Get the application
        restApplicationMockMvc.perform(get("/api/applications/{id}", application.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(application.getId().intValue()))
            .andExpect(jsonPath("$.name").value(DEFAULT_NAME.toString()))
            .andExpect(jsonPath("$.description").value(DEFAULT_DESCRIPTION.toString()))
            .andExpect(jsonPath("$.category").value(DEFAULT_CATEGORY.toString()))
            .andExpect(jsonPath("$.type").value(DEFAULT_TYPE.toString()))
            .andExpect(jsonPath("$.sla").value(DEFAULT_SLA.toString()))
            .andExpect(jsonPath("$.holidayCalendar").value(DEFAULT_HOLIDAY_CALENDAR.toString()))
            .andExpect(jsonPath("$.documenation").value(DEFAULT_DOCUMENATION.toString()))
            .andExpect(jsonPath("$.deployedPath").value(DEFAULT_DEPLOYED_PATH.toString()))
            .andExpect(jsonPath("$.metricsPath").value(DEFAULT_METRICS_PATH.toString()))
            .andExpect(jsonPath("$.isActive").value(DEFAULT_IS_ACTIVE.booleanValue()))
            .andExpect(jsonPath("$.updatedDate").value(DEFAULT_UPDATED_DATE_STR));
    }

    @Test
    @Transactional
    public void getNonExistingApplication() throws Exception {
        // Get the application
        restApplicationMockMvc.perform(get("/api/applications/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateApplication() throws Exception {
        // Initialize the database
        applicationService.save(application);

        int databaseSizeBeforeUpdate = applicationRepository.findAll().size();

        // Update the application
        Application updatedApplication = applicationRepository.findOne(application.getId());
        updatedApplication.setName(UPDATED_NAME);
        updatedApplication.setDescription(UPDATED_DESCRIPTION);
        updatedApplication.setCategory(UPDATED_CATEGORY);
        updatedApplication.setType(UPDATED_TYPE);
        updatedApplication.setSla(UPDATED_SLA);
        updatedApplication.setHolidayCalendar(UPDATED_HOLIDAY_CALENDAR);
        updatedApplication.setDocumenation(UPDATED_DOCUMENATION);
        updatedApplication.setDeployedPath(UPDATED_DEPLOYED_PATH);
        updatedApplication.setMetricsPath(UPDATED_METRICS_PATH);
        updatedApplication.setIsActive(UPDATED_IS_ACTIVE);
        updatedApplication.setUpdatedDate(UPDATED_UPDATED_DATE);

        restApplicationMockMvc.perform(put("/api/applications")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(updatedApplication)))
                .andExpect(status().isOk());

        // Validate the Application in the database
        List<Application> applications = applicationRepository.findAll();
        assertThat(applications).hasSize(databaseSizeBeforeUpdate);
        Application testApplication = applications.get(applications.size() - 1);
        assertThat(testApplication.getName()).isEqualTo(UPDATED_NAME);
        assertThat(testApplication.getDescription()).isEqualTo(UPDATED_DESCRIPTION);
        assertThat(testApplication.getCategory()).isEqualTo(UPDATED_CATEGORY);
        assertThat(testApplication.getType()).isEqualTo(UPDATED_TYPE);
        assertThat(testApplication.getSla()).isEqualTo(UPDATED_SLA);
        assertThat(testApplication.getHolidayCalendar()).isEqualTo(UPDATED_HOLIDAY_CALENDAR);
        assertThat(testApplication.getDocumenation()).isEqualTo(UPDATED_DOCUMENATION);
        assertThat(testApplication.getDeployedPath()).isEqualTo(UPDATED_DEPLOYED_PATH);
        assertThat(testApplication.getMetricsPath()).isEqualTo(UPDATED_METRICS_PATH);
        assertThat(testApplication.isIsActive()).isEqualTo(UPDATED_IS_ACTIVE);
        assertThat(testApplication.getUpdatedDate()).isEqualTo(UPDATED_UPDATED_DATE);

        // Validate the Application in ElasticSearch
        Application applicationEs = applicationSearchRepository.findOne(testApplication.getId());
        assertThat(applicationEs).isEqualToComparingFieldByField(testApplication);
    }

    @Test
    @Transactional
    public void deleteApplication() throws Exception {
        // Initialize the database
        applicationService.save(application);

        int databaseSizeBeforeDelete = applicationRepository.findAll().size();

        // Get the application
        restApplicationMockMvc.perform(delete("/api/applications/{id}", application.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate ElasticSearch is empty
        boolean applicationExistsInEs = applicationSearchRepository.exists(application.getId());
        assertThat(applicationExistsInEs).isFalse();

        // Validate the database is empty
        List<Application> applications = applicationRepository.findAll();
        assertThat(applications).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void searchApplication() throws Exception {
        // Initialize the database
        applicationService.save(application);

        // Search the application
        restApplicationMockMvc.perform(get("/api/_search/applications?query=id:" + application.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(application.getId().intValue())))
            .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
            .andExpect(jsonPath("$.[*].description").value(hasItem(DEFAULT_DESCRIPTION.toString())))
            .andExpect(jsonPath("$.[*].category").value(hasItem(DEFAULT_CATEGORY.toString())))
            .andExpect(jsonPath("$.[*].type").value(hasItem(DEFAULT_TYPE.toString())))
            .andExpect(jsonPath("$.[*].sla").value(hasItem(DEFAULT_SLA.toString())))
            .andExpect(jsonPath("$.[*].holidayCalendar").value(hasItem(DEFAULT_HOLIDAY_CALENDAR.toString())))
            .andExpect(jsonPath("$.[*].documenation").value(hasItem(DEFAULT_DOCUMENATION.toString())))
            .andExpect(jsonPath("$.[*].deployedPath").value(hasItem(DEFAULT_DEPLOYED_PATH.toString())))
            .andExpect(jsonPath("$.[*].metricsPath").value(hasItem(DEFAULT_METRICS_PATH.toString())))
            .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
            .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }
}
