package com.jpmorgan.am.grt.web.rest;

import com.jpmorgan.am.grt.GrtDashboardApp;

import com.jpmorgan.am.grt.domain.BatchJobHistory;
import com.jpmorgan.am.grt.repository.BatchJobHistoryRepository;
import com.jpmorgan.am.grt.service.BatchJobHistoryService;
import com.jpmorgan.am.grt.repository.search.BatchJobHistorySearchRepository;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.time.LocalDate;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneId;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the BatchJobHistoryResource REST controller.
 *
 * @see BatchJobHistoryResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = GrtDashboardApp.class)
public class BatchJobHistoryResourceIntTest {

    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(ZoneId.of("Z"));


    private static final LocalDate DEFAULT_BUSINESS_DATE = LocalDate.ofEpochDay(0L);
    private static final LocalDate UPDATED_BUSINESS_DATE = LocalDate.now(ZoneId.systemDefault());
    private static final String DEFAULT_INITIAL_STATUS = "AAAAA";
    private static final String UPDATED_INITIAL_STATUS = "BBBBB";

    private static final ZonedDateTime DEFAULT_START_TIME = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneId.systemDefault());
    private static final ZonedDateTime UPDATED_START_TIME = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);
    private static final String DEFAULT_START_TIME_STR = dateTimeFormatter.format(DEFAULT_START_TIME);

    private static final ZonedDateTime DEFAULT_END_TIME = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneId.systemDefault());
    private static final ZonedDateTime UPDATED_END_TIME = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);
    private static final String DEFAULT_END_TIME_STR = dateTimeFormatter.format(DEFAULT_END_TIME);
    private static final String DEFAULT_FAILURE_MESSAGE = "AAAAA";
    private static final String UPDATED_FAILURE_MESSAGE = "BBBBB";
    private static final String DEFAULT_ROOT_CAUSE = "AAAAA";
    private static final String UPDATED_ROOT_CAUSE = "BBBBB";
    private static final String DEFAULT_RESOLUTION = "AAAAA";
    private static final String UPDATED_RESOLUTION = "BBBBB";
    private static final String DEFAULT_FINAL_STATUS = "AAAAA";
    private static final String UPDATED_FINAL_STATUS = "BBBBB";

    private static final ZonedDateTime DEFAULT_UPDATED_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneId.systemDefault());
    private static final ZonedDateTime UPDATED_UPDATED_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);
    private static final String DEFAULT_UPDATED_DATE_STR = dateTimeFormatter.format(DEFAULT_UPDATED_DATE);

    @Inject
    private BatchJobHistoryRepository batchJobHistoryRepository;

    @Inject
    private BatchJobHistoryService batchJobHistoryService;

    @Inject
    private BatchJobHistorySearchRepository batchJobHistorySearchRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restBatchJobHistoryMockMvc;

    private BatchJobHistory batchJobHistory;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        BatchJobHistoryResource batchJobHistoryResource = new BatchJobHistoryResource();
        ReflectionTestUtils.setField(batchJobHistoryResource, "batchJobHistoryService", batchJobHistoryService);
        this.restBatchJobHistoryMockMvc = MockMvcBuilders.standaloneSetup(batchJobHistoryResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static BatchJobHistory createEntity(EntityManager em) {
        BatchJobHistory batchJobHistory = new BatchJobHistory();
        batchJobHistory.setBusinessDate(DEFAULT_BUSINESS_DATE);
        batchJobHistory.setInitialStatus(DEFAULT_INITIAL_STATUS);
        batchJobHistory.setStartTime(DEFAULT_START_TIME);
        batchJobHistory.setEndTime(DEFAULT_END_TIME);
        batchJobHistory.setFailureMessage(DEFAULT_FAILURE_MESSAGE);
        batchJobHistory.setRootCause(DEFAULT_ROOT_CAUSE);
        batchJobHistory.setResolution(DEFAULT_RESOLUTION);
        batchJobHistory.setFinalStatus(DEFAULT_FINAL_STATUS);
        batchJobHistory.setUpdatedDate(DEFAULT_UPDATED_DATE);
        return batchJobHistory;
    }

    @Before
    public void initTest() {
        batchJobHistorySearchRepository.deleteAll();
        batchJobHistory = createEntity(em);
    }

    @Test
    @Transactional
    public void createBatchJobHistory() throws Exception {
        int databaseSizeBeforeCreate = batchJobHistoryRepository.findAll().size();

        // Create the BatchJobHistory

        restBatchJobHistoryMockMvc.perform(post("/api/batch-job-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batchJobHistory)))
                .andExpect(status().isCreated());

        // Validate the BatchJobHistory in the database
        List<BatchJobHistory> batchJobHistories = batchJobHistoryRepository.findAll();
        assertThat(batchJobHistories).hasSize(databaseSizeBeforeCreate + 1);
        BatchJobHistory testBatchJobHistory = batchJobHistories.get(batchJobHistories.size() - 1);
        assertThat(testBatchJobHistory.getBusinessDate()).isEqualTo(DEFAULT_BUSINESS_DATE);
        assertThat(testBatchJobHistory.getInitialStatus()).isEqualTo(DEFAULT_INITIAL_STATUS);
        assertThat(testBatchJobHistory.getStartTime()).isEqualTo(DEFAULT_START_TIME);
        assertThat(testBatchJobHistory.getEndTime()).isEqualTo(DEFAULT_END_TIME);
        assertThat(testBatchJobHistory.getFailureMessage()).isEqualTo(DEFAULT_FAILURE_MESSAGE);
        assertThat(testBatchJobHistory.getRootCause()).isEqualTo(DEFAULT_ROOT_CAUSE);
        assertThat(testBatchJobHistory.getResolution()).isEqualTo(DEFAULT_RESOLUTION);
        assertThat(testBatchJobHistory.getFinalStatus()).isEqualTo(DEFAULT_FINAL_STATUS);
        assertThat(testBatchJobHistory.getUpdatedDate()).isEqualTo(DEFAULT_UPDATED_DATE);

        // Validate the BatchJobHistory in ElasticSearch
        BatchJobHistory batchJobHistoryEs = batchJobHistorySearchRepository.findOne(testBatchJobHistory.getId());
        assertThat(batchJobHistoryEs).isEqualToComparingFieldByField(testBatchJobHistory);
    }

    @Test
    @Transactional
    public void checkBusinessDateIsRequired() throws Exception {
        int databaseSizeBeforeTest = batchJobHistoryRepository.findAll().size();
        // set the field null
        batchJobHistory.setBusinessDate(null);

        // Create the BatchJobHistory, which fails.

        restBatchJobHistoryMockMvc.perform(post("/api/batch-job-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batchJobHistory)))
                .andExpect(status().isBadRequest());

        List<BatchJobHistory> batchJobHistories = batchJobHistoryRepository.findAll();
        assertThat(batchJobHistories).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkInitialStatusIsRequired() throws Exception {
        int databaseSizeBeforeTest = batchJobHistoryRepository.findAll().size();
        // set the field null
        batchJobHistory.setInitialStatus(null);

        // Create the BatchJobHistory, which fails.

        restBatchJobHistoryMockMvc.perform(post("/api/batch-job-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batchJobHistory)))
                .andExpect(status().isBadRequest());

        List<BatchJobHistory> batchJobHistories = batchJobHistoryRepository.findAll();
        assertThat(batchJobHistories).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkStartTimeIsRequired() throws Exception {
        int databaseSizeBeforeTest = batchJobHistoryRepository.findAll().size();
        // set the field null
        batchJobHistory.setStartTime(null);

        // Create the BatchJobHistory, which fails.

        restBatchJobHistoryMockMvc.perform(post("/api/batch-job-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batchJobHistory)))
                .andExpect(status().isBadRequest());

        List<BatchJobHistory> batchJobHistories = batchJobHistoryRepository.findAll();
        assertThat(batchJobHistories).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkFinalStatusIsRequired() throws Exception {
        int databaseSizeBeforeTest = batchJobHistoryRepository.findAll().size();
        // set the field null
        batchJobHistory.setFinalStatus(null);

        // Create the BatchJobHistory, which fails.

        restBatchJobHistoryMockMvc.perform(post("/api/batch-job-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batchJobHistory)))
                .andExpect(status().isBadRequest());

        List<BatchJobHistory> batchJobHistories = batchJobHistoryRepository.findAll();
        assertThat(batchJobHistories).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllBatchJobHistories() throws Exception {
        // Initialize the database
        batchJobHistoryRepository.saveAndFlush(batchJobHistory);

        // Get all the batchJobHistories
        restBatchJobHistoryMockMvc.perform(get("/api/batch-job-histories?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andExpect(jsonPath("$.[*].id").value(hasItem(batchJobHistory.getId().intValue())))
                .andExpect(jsonPath("$.[*].businessDate").value(hasItem(DEFAULT_BUSINESS_DATE.toString())))
                .andExpect(jsonPath("$.[*].initialStatus").value(hasItem(DEFAULT_INITIAL_STATUS.toString())))
                .andExpect(jsonPath("$.[*].startTime").value(hasItem(DEFAULT_START_TIME_STR)))
                .andExpect(jsonPath("$.[*].endTime").value(hasItem(DEFAULT_END_TIME_STR)))
                .andExpect(jsonPath("$.[*].failureMessage").value(hasItem(DEFAULT_FAILURE_MESSAGE.toString())))
                .andExpect(jsonPath("$.[*].rootCause").value(hasItem(DEFAULT_ROOT_CAUSE.toString())))
                .andExpect(jsonPath("$.[*].resolution").value(hasItem(DEFAULT_RESOLUTION.toString())))
                .andExpect(jsonPath("$.[*].finalStatus").value(hasItem(DEFAULT_FINAL_STATUS.toString())))
                .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }

    @Test
    @Transactional
    public void getBatchJobHistory() throws Exception {
        // Initialize the database
        batchJobHistoryRepository.saveAndFlush(batchJobHistory);

        // Get the batchJobHistory
        restBatchJobHistoryMockMvc.perform(get("/api/batch-job-histories/{id}", batchJobHistory.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(batchJobHistory.getId().intValue()))
            .andExpect(jsonPath("$.businessDate").value(DEFAULT_BUSINESS_DATE.toString()))
            .andExpect(jsonPath("$.initialStatus").value(DEFAULT_INITIAL_STATUS.toString()))
            .andExpect(jsonPath("$.startTime").value(DEFAULT_START_TIME_STR))
            .andExpect(jsonPath("$.endTime").value(DEFAULT_END_TIME_STR))
            .andExpect(jsonPath("$.failureMessage").value(DEFAULT_FAILURE_MESSAGE.toString()))
            .andExpect(jsonPath("$.rootCause").value(DEFAULT_ROOT_CAUSE.toString()))
            .andExpect(jsonPath("$.resolution").value(DEFAULT_RESOLUTION.toString()))
            .andExpect(jsonPath("$.finalStatus").value(DEFAULT_FINAL_STATUS.toString()))
            .andExpect(jsonPath("$.updatedDate").value(DEFAULT_UPDATED_DATE_STR));
    }

    @Test
    @Transactional
    public void getNonExistingBatchJobHistory() throws Exception {
        // Get the batchJobHistory
        restBatchJobHistoryMockMvc.perform(get("/api/batch-job-histories/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateBatchJobHistory() throws Exception {
        // Initialize the database
        batchJobHistoryService.save(batchJobHistory);

        int databaseSizeBeforeUpdate = batchJobHistoryRepository.findAll().size();

        // Update the batchJobHistory
        BatchJobHistory updatedBatchJobHistory = batchJobHistoryRepository.findOne(batchJobHistory.getId());
        updatedBatchJobHistory.setBusinessDate(UPDATED_BUSINESS_DATE);
        updatedBatchJobHistory.setInitialStatus(UPDATED_INITIAL_STATUS);
        updatedBatchJobHistory.setStartTime(UPDATED_START_TIME);
        updatedBatchJobHistory.setEndTime(UPDATED_END_TIME);
        updatedBatchJobHistory.setFailureMessage(UPDATED_FAILURE_MESSAGE);
        updatedBatchJobHistory.setRootCause(UPDATED_ROOT_CAUSE);
        updatedBatchJobHistory.setResolution(UPDATED_RESOLUTION);
        updatedBatchJobHistory.setFinalStatus(UPDATED_FINAL_STATUS);
        updatedBatchJobHistory.setUpdatedDate(UPDATED_UPDATED_DATE);

        restBatchJobHistoryMockMvc.perform(put("/api/batch-job-histories")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(updatedBatchJobHistory)))
                .andExpect(status().isOk());

        // Validate the BatchJobHistory in the database
        List<BatchJobHistory> batchJobHistories = batchJobHistoryRepository.findAll();
        assertThat(batchJobHistories).hasSize(databaseSizeBeforeUpdate);
        BatchJobHistory testBatchJobHistory = batchJobHistories.get(batchJobHistories.size() - 1);
        assertThat(testBatchJobHistory.getBusinessDate()).isEqualTo(UPDATED_BUSINESS_DATE);
        assertThat(testBatchJobHistory.getInitialStatus()).isEqualTo(UPDATED_INITIAL_STATUS);
        assertThat(testBatchJobHistory.getStartTime()).isEqualTo(UPDATED_START_TIME);
        assertThat(testBatchJobHistory.getEndTime()).isEqualTo(UPDATED_END_TIME);
        assertThat(testBatchJobHistory.getFailureMessage()).isEqualTo(UPDATED_FAILURE_MESSAGE);
        assertThat(testBatchJobHistory.getRootCause()).isEqualTo(UPDATED_ROOT_CAUSE);
        assertThat(testBatchJobHistory.getResolution()).isEqualTo(UPDATED_RESOLUTION);
        assertThat(testBatchJobHistory.getFinalStatus()).isEqualTo(UPDATED_FINAL_STATUS);
        assertThat(testBatchJobHistory.getUpdatedDate()).isEqualTo(UPDATED_UPDATED_DATE);

        // Validate the BatchJobHistory in ElasticSearch
        BatchJobHistory batchJobHistoryEs = batchJobHistorySearchRepository.findOne(testBatchJobHistory.getId());
        assertThat(batchJobHistoryEs).isEqualToComparingFieldByField(testBatchJobHistory);
    }

    @Test
    @Transactional
    public void deleteBatchJobHistory() throws Exception {
        // Initialize the database
        batchJobHistoryService.save(batchJobHistory);

        int databaseSizeBeforeDelete = batchJobHistoryRepository.findAll().size();

        // Get the batchJobHistory
        restBatchJobHistoryMockMvc.perform(delete("/api/batch-job-histories/{id}", batchJobHistory.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate ElasticSearch is empty
        boolean batchJobHistoryExistsInEs = batchJobHistorySearchRepository.exists(batchJobHistory.getId());
        assertThat(batchJobHistoryExistsInEs).isFalse();

        // Validate the database is empty
        List<BatchJobHistory> batchJobHistories = batchJobHistoryRepository.findAll();
        assertThat(batchJobHistories).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void searchBatchJobHistory() throws Exception {
        // Initialize the database
        batchJobHistoryService.save(batchJobHistory);

        // Search the batchJobHistory
        restBatchJobHistoryMockMvc.perform(get("/api/_search/batch-job-histories?query=id:" + batchJobHistory.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(batchJobHistory.getId().intValue())))
            .andExpect(jsonPath("$.[*].businessDate").value(hasItem(DEFAULT_BUSINESS_DATE.toString())))
            .andExpect(jsonPath("$.[*].initialStatus").value(hasItem(DEFAULT_INITIAL_STATUS.toString())))
            .andExpect(jsonPath("$.[*].startTime").value(hasItem(DEFAULT_START_TIME_STR)))
            .andExpect(jsonPath("$.[*].endTime").value(hasItem(DEFAULT_END_TIME_STR)))
            .andExpect(jsonPath("$.[*].failureMessage").value(hasItem(DEFAULT_FAILURE_MESSAGE.toString())))
            .andExpect(jsonPath("$.[*].rootCause").value(hasItem(DEFAULT_ROOT_CAUSE.toString())))
            .andExpect(jsonPath("$.[*].resolution").value(hasItem(DEFAULT_RESOLUTION.toString())))
            .andExpect(jsonPath("$.[*].finalStatus").value(hasItem(DEFAULT_FINAL_STATUS.toString())))
            .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }
}
