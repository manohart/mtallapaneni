package com.jpmorgan.am.grt.web.rest;

import com.jpmorgan.am.grt.GrtDashboardApp;

import com.jpmorgan.am.grt.domain.BatchReport;
import com.jpmorgan.am.grt.repository.BatchReportRepository;
import com.jpmorgan.am.grt.service.BatchReportService;
import com.jpmorgan.am.grt.repository.search.BatchReportSearchRepository;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneId;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.jpmorgan.am.grt.domain.enumeration.ReportType;
/**
 * Test class for the BatchReportResource REST controller.
 *
 * @see BatchReportResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = GrtDashboardApp.class)
public class BatchReportResourceIntTest {

    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(ZoneId.of("Z"));

    private static final String DEFAULT_NAME = "AAAAA";
    private static final String UPDATED_NAME = "BBBBB";

    private static final ReportType DEFAULT_TYPE = ReportType.HTML;
    private static final ReportType UPDATED_TYPE = ReportType.EXCEL;
    private static final String DEFAULT_DESCRIPTION = "AAAAA";
    private static final String UPDATED_DESCRIPTION = "BBBBB";

    private static final Boolean DEFAULT_IS_ACTIVE = false;
    private static final Boolean UPDATED_IS_ACTIVE = true;

    private static final ZonedDateTime DEFAULT_UPDATED_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneId.systemDefault());
    private static final ZonedDateTime UPDATED_UPDATED_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);
    private static final String DEFAULT_UPDATED_DATE_STR = dateTimeFormatter.format(DEFAULT_UPDATED_DATE);

    @Inject
    private BatchReportRepository batchReportRepository;

    @Inject
    private BatchReportService batchReportService;

    @Inject
    private BatchReportSearchRepository batchReportSearchRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restBatchReportMockMvc;

    private BatchReport batchReport;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        BatchReportResource batchReportResource = new BatchReportResource();
        ReflectionTestUtils.setField(batchReportResource, "batchReportService", batchReportService);
        this.restBatchReportMockMvc = MockMvcBuilders.standaloneSetup(batchReportResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static BatchReport createEntity(EntityManager em) {
        BatchReport batchReport = new BatchReport();
        batchReport.setName(DEFAULT_NAME);
        batchReport.setType(DEFAULT_TYPE);
        batchReport.setDescription(DEFAULT_DESCRIPTION);
        batchReport.setIsActive(DEFAULT_IS_ACTIVE);
        batchReport.setUpdatedDate(DEFAULT_UPDATED_DATE);
        return batchReport;
    }

    @Before
    public void initTest() {
        batchReportSearchRepository.deleteAll();
        batchReport = createEntity(em);
    }

    @Test
    @Transactional
    public void createBatchReport() throws Exception {
        int databaseSizeBeforeCreate = batchReportRepository.findAll().size();

        // Create the BatchReport

        restBatchReportMockMvc.perform(post("/api/batch-reports")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batchReport)))
                .andExpect(status().isCreated());

        // Validate the BatchReport in the database
        List<BatchReport> batchReports = batchReportRepository.findAll();
        assertThat(batchReports).hasSize(databaseSizeBeforeCreate + 1);
        BatchReport testBatchReport = batchReports.get(batchReports.size() - 1);
        assertThat(testBatchReport.getName()).isEqualTo(DEFAULT_NAME);
        assertThat(testBatchReport.getType()).isEqualTo(DEFAULT_TYPE);
        assertThat(testBatchReport.getDescription()).isEqualTo(DEFAULT_DESCRIPTION);
        assertThat(testBatchReport.isIsActive()).isEqualTo(DEFAULT_IS_ACTIVE);
        assertThat(testBatchReport.getUpdatedDate()).isEqualTo(DEFAULT_UPDATED_DATE);

        // Validate the BatchReport in ElasticSearch
        BatchReport batchReportEs = batchReportSearchRepository.findOne(testBatchReport.getId());
        assertThat(batchReportEs).isEqualToComparingFieldByField(testBatchReport);
    }

    @Test
    @Transactional
    public void checkNameIsRequired() throws Exception {
        int databaseSizeBeforeTest = batchReportRepository.findAll().size();
        // set the field null
        batchReport.setName(null);

        // Create the BatchReport, which fails.

        restBatchReportMockMvc.perform(post("/api/batch-reports")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batchReport)))
                .andExpect(status().isBadRequest());

        List<BatchReport> batchReports = batchReportRepository.findAll();
        assertThat(batchReports).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkTypeIsRequired() throws Exception {
        int databaseSizeBeforeTest = batchReportRepository.findAll().size();
        // set the field null
        batchReport.setType(null);

        // Create the BatchReport, which fails.

        restBatchReportMockMvc.perform(post("/api/batch-reports")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batchReport)))
                .andExpect(status().isBadRequest());

        List<BatchReport> batchReports = batchReportRepository.findAll();
        assertThat(batchReports).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkDescriptionIsRequired() throws Exception {
        int databaseSizeBeforeTest = batchReportRepository.findAll().size();
        // set the field null
        batchReport.setDescription(null);

        // Create the BatchReport, which fails.

        restBatchReportMockMvc.perform(post("/api/batch-reports")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batchReport)))
                .andExpect(status().isBadRequest());

        List<BatchReport> batchReports = batchReportRepository.findAll();
        assertThat(batchReports).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkIsActiveIsRequired() throws Exception {
        int databaseSizeBeforeTest = batchReportRepository.findAll().size();
        // set the field null
        batchReport.setIsActive(null);

        // Create the BatchReport, which fails.

        restBatchReportMockMvc.perform(post("/api/batch-reports")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batchReport)))
                .andExpect(status().isBadRequest());

        List<BatchReport> batchReports = batchReportRepository.findAll();
        assertThat(batchReports).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllBatchReports() throws Exception {
        // Initialize the database
        batchReportRepository.saveAndFlush(batchReport);

        // Get all the batchReports
        restBatchReportMockMvc.perform(get("/api/batch-reports?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andExpect(jsonPath("$.[*].id").value(hasItem(batchReport.getId().intValue())))
                .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
                .andExpect(jsonPath("$.[*].type").value(hasItem(DEFAULT_TYPE.toString())))
                .andExpect(jsonPath("$.[*].description").value(hasItem(DEFAULT_DESCRIPTION.toString())))
                .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
                .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }

    @Test
    @Transactional
    public void getBatchReport() throws Exception {
        // Initialize the database
        batchReportRepository.saveAndFlush(batchReport);

        // Get the batchReport
        restBatchReportMockMvc.perform(get("/api/batch-reports/{id}", batchReport.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(batchReport.getId().intValue()))
            .andExpect(jsonPath("$.name").value(DEFAULT_NAME.toString()))
            .andExpect(jsonPath("$.type").value(DEFAULT_TYPE.toString()))
            .andExpect(jsonPath("$.description").value(DEFAULT_DESCRIPTION.toString()))
            .andExpect(jsonPath("$.isActive").value(DEFAULT_IS_ACTIVE.booleanValue()))
            .andExpect(jsonPath("$.updatedDate").value(DEFAULT_UPDATED_DATE_STR));
    }

    @Test
    @Transactional
    public void getNonExistingBatchReport() throws Exception {
        // Get the batchReport
        restBatchReportMockMvc.perform(get("/api/batch-reports/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateBatchReport() throws Exception {
        // Initialize the database
        batchReportService.save(batchReport);

        int databaseSizeBeforeUpdate = batchReportRepository.findAll().size();

        // Update the batchReport
        BatchReport updatedBatchReport = batchReportRepository.findOne(batchReport.getId());
        updatedBatchReport.setName(UPDATED_NAME);
        updatedBatchReport.setType(UPDATED_TYPE);
        updatedBatchReport.setDescription(UPDATED_DESCRIPTION);
        updatedBatchReport.setIsActive(UPDATED_IS_ACTIVE);
        updatedBatchReport.setUpdatedDate(UPDATED_UPDATED_DATE);

        restBatchReportMockMvc.perform(put("/api/batch-reports")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(updatedBatchReport)))
                .andExpect(status().isOk());

        // Validate the BatchReport in the database
        List<BatchReport> batchReports = batchReportRepository.findAll();
        assertThat(batchReports).hasSize(databaseSizeBeforeUpdate);
        BatchReport testBatchReport = batchReports.get(batchReports.size() - 1);
        assertThat(testBatchReport.getName()).isEqualTo(UPDATED_NAME);
        assertThat(testBatchReport.getType()).isEqualTo(UPDATED_TYPE);
        assertThat(testBatchReport.getDescription()).isEqualTo(UPDATED_DESCRIPTION);
        assertThat(testBatchReport.isIsActive()).isEqualTo(UPDATED_IS_ACTIVE);
        assertThat(testBatchReport.getUpdatedDate()).isEqualTo(UPDATED_UPDATED_DATE);

        // Validate the BatchReport in ElasticSearch
        BatchReport batchReportEs = batchReportSearchRepository.findOne(testBatchReport.getId());
        assertThat(batchReportEs).isEqualToComparingFieldByField(testBatchReport);
    }

    @Test
    @Transactional
    public void deleteBatchReport() throws Exception {
        // Initialize the database
        batchReportService.save(batchReport);

        int databaseSizeBeforeDelete = batchReportRepository.findAll().size();

        // Get the batchReport
        restBatchReportMockMvc.perform(delete("/api/batch-reports/{id}", batchReport.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate ElasticSearch is empty
        boolean batchReportExistsInEs = batchReportSearchRepository.exists(batchReport.getId());
        assertThat(batchReportExistsInEs).isFalse();

        // Validate the database is empty
        List<BatchReport> batchReports = batchReportRepository.findAll();
        assertThat(batchReports).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void searchBatchReport() throws Exception {
        // Initialize the database
        batchReportService.save(batchReport);

        // Search the batchReport
        restBatchReportMockMvc.perform(get("/api/_search/batch-reports?query=id:" + batchReport.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(batchReport.getId().intValue())))
            .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
            .andExpect(jsonPath("$.[*].type").value(hasItem(DEFAULT_TYPE.toString())))
            .andExpect(jsonPath("$.[*].description").value(hasItem(DEFAULT_DESCRIPTION.toString())))
            .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
            .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }
}
