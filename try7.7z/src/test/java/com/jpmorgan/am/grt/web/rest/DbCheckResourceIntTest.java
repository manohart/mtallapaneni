package com.jpmorgan.am.grt.web.rest;

import com.jpmorgan.am.grt.GrtDashboardApp;

import com.jpmorgan.am.grt.domain.DbCheck;
import com.jpmorgan.am.grt.repository.DbCheckRepository;
import com.jpmorgan.am.grt.service.DbCheckService;
import com.jpmorgan.am.grt.repository.search.DbCheckSearchRepository;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneId;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.jpmorgan.am.grt.domain.enumeration.DbCheckExpectation;
/**
 * Test class for the DbCheckResource REST controller.
 *
 * @see DbCheckResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = GrtDashboardApp.class)
public class DbCheckResourceIntTest {

    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(ZoneId.of("Z"));

    private static final String DEFAULT_NAME = "AAAAA";
    private static final String UPDATED_NAME = "BBBBB";
    private static final String DEFAULT_DESCRIPTION = "AAAAA";
    private static final String UPDATED_DESCRIPTION = "BBBBB";
    private static final String DEFAULT_SQL_QUERY = "AAAAA";
    private static final String UPDATED_SQL_QUERY = "BBBBB";

    private static final DbCheckExpectation DEFAULT_EXPECTATION = DbCheckExpectation.NONE;
    private static final DbCheckExpectation UPDATED_EXPECTATION = DbCheckExpectation.ISSUE_IF_RECORDS_FOUND;

    private static final Boolean DEFAULT_REPORT_ISSUES_ONLY = false;
    private static final Boolean UPDATED_REPORT_ISSUES_ONLY = true;
    private static final String DEFAULT_GROUP_COLUMNS = "AAAAA";
    private static final String UPDATED_GROUP_COLUMNS = "BBBBB";

    private static final Integer DEFAULT_SEQUENCE = 0;
    private static final Integer UPDATED_SEQUENCE = 1;

    private static final Boolean DEFAULT_IS_ACTIVE = false;
    private static final Boolean UPDATED_IS_ACTIVE = true;

    private static final ZonedDateTime DEFAULT_UPDATED_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneId.systemDefault());
    private static final ZonedDateTime UPDATED_UPDATED_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);
    private static final String DEFAULT_UPDATED_DATE_STR = dateTimeFormatter.format(DEFAULT_UPDATED_DATE);

    @Inject
    private DbCheckRepository dbCheckRepository;

    @Inject
    private DbCheckService dbCheckService;

    @Inject
    private DbCheckSearchRepository dbCheckSearchRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restDbCheckMockMvc;

    private DbCheck dbCheck;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        DbCheckResource dbCheckResource = new DbCheckResource();
        ReflectionTestUtils.setField(dbCheckResource, "dbCheckService", dbCheckService);
        this.restDbCheckMockMvc = MockMvcBuilders.standaloneSetup(dbCheckResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static DbCheck createEntity(EntityManager em) {
        DbCheck dbCheck = new DbCheck();
        dbCheck.setName(DEFAULT_NAME);
        dbCheck.setDescription(DEFAULT_DESCRIPTION);
        dbCheck.setSqlQuery(DEFAULT_SQL_QUERY);
        dbCheck.setExpectation(DEFAULT_EXPECTATION);
        dbCheck.setReportIssuesOnly(DEFAULT_REPORT_ISSUES_ONLY);
        dbCheck.setGroupColumns(DEFAULT_GROUP_COLUMNS);
        dbCheck.setSequence(DEFAULT_SEQUENCE);
        dbCheck.setIsActive(DEFAULT_IS_ACTIVE);
        dbCheck.setUpdatedDate(DEFAULT_UPDATED_DATE);
        return dbCheck;
    }

    @Before
    public void initTest() {
        dbCheckSearchRepository.deleteAll();
        dbCheck = createEntity(em);
    }

    @Test
    @Transactional
    public void createDbCheck() throws Exception {
        int databaseSizeBeforeCreate = dbCheckRepository.findAll().size();

        // Create the DbCheck

        restDbCheckMockMvc.perform(post("/api/db-checks")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(dbCheck)))
                .andExpect(status().isCreated());

        // Validate the DbCheck in the database
        List<DbCheck> dbChecks = dbCheckRepository.findAll();
        assertThat(dbChecks).hasSize(databaseSizeBeforeCreate + 1);
        DbCheck testDbCheck = dbChecks.get(dbChecks.size() - 1);
        assertThat(testDbCheck.getName()).isEqualTo(DEFAULT_NAME);
        assertThat(testDbCheck.getDescription()).isEqualTo(DEFAULT_DESCRIPTION);
        assertThat(testDbCheck.getSqlQuery()).isEqualTo(DEFAULT_SQL_QUERY);
        assertThat(testDbCheck.getExpectation()).isEqualTo(DEFAULT_EXPECTATION);
        assertThat(testDbCheck.isReportIssuesOnly()).isEqualTo(DEFAULT_REPORT_ISSUES_ONLY);
        assertThat(testDbCheck.getGroupColumns()).isEqualTo(DEFAULT_GROUP_COLUMNS);
        assertThat(testDbCheck.getSequence()).isEqualTo(DEFAULT_SEQUENCE);
        assertThat(testDbCheck.isIsActive()).isEqualTo(DEFAULT_IS_ACTIVE);
        assertThat(testDbCheck.getUpdatedDate()).isEqualTo(DEFAULT_UPDATED_DATE);

        // Validate the DbCheck in ElasticSearch
        DbCheck dbCheckEs = dbCheckSearchRepository.findOne(testDbCheck.getId());
        assertThat(dbCheckEs).isEqualToComparingFieldByField(testDbCheck);
    }

    @Test
    @Transactional
    public void checkNameIsRequired() throws Exception {
        int databaseSizeBeforeTest = dbCheckRepository.findAll().size();
        // set the field null
        dbCheck.setName(null);

        // Create the DbCheck, which fails.

        restDbCheckMockMvc.perform(post("/api/db-checks")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(dbCheck)))
                .andExpect(status().isBadRequest());

        List<DbCheck> dbChecks = dbCheckRepository.findAll();
        assertThat(dbChecks).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkDescriptionIsRequired() throws Exception {
        int databaseSizeBeforeTest = dbCheckRepository.findAll().size();
        // set the field null
        dbCheck.setDescription(null);

        // Create the DbCheck, which fails.

        restDbCheckMockMvc.perform(post("/api/db-checks")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(dbCheck)))
                .andExpect(status().isBadRequest());

        List<DbCheck> dbChecks = dbCheckRepository.findAll();
        assertThat(dbChecks).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkSqlQueryIsRequired() throws Exception {
        int databaseSizeBeforeTest = dbCheckRepository.findAll().size();
        // set the field null
        dbCheck.setSqlQuery(null);

        // Create the DbCheck, which fails.

        restDbCheckMockMvc.perform(post("/api/db-checks")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(dbCheck)))
                .andExpect(status().isBadRequest());

        List<DbCheck> dbChecks = dbCheckRepository.findAll();
        assertThat(dbChecks).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkExpectationIsRequired() throws Exception {
        int databaseSizeBeforeTest = dbCheckRepository.findAll().size();
        // set the field null
        dbCheck.setExpectation(null);

        // Create the DbCheck, which fails.

        restDbCheckMockMvc.perform(post("/api/db-checks")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(dbCheck)))
                .andExpect(status().isBadRequest());

        List<DbCheck> dbChecks = dbCheckRepository.findAll();
        assertThat(dbChecks).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkSequenceIsRequired() throws Exception {
        int databaseSizeBeforeTest = dbCheckRepository.findAll().size();
        // set the field null
        dbCheck.setSequence(null);

        // Create the DbCheck, which fails.

        restDbCheckMockMvc.perform(post("/api/db-checks")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(dbCheck)))
                .andExpect(status().isBadRequest());

        List<DbCheck> dbChecks = dbCheckRepository.findAll();
        assertThat(dbChecks).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllDbChecks() throws Exception {
        // Initialize the database
        dbCheckRepository.saveAndFlush(dbCheck);

        // Get all the dbChecks
        restDbCheckMockMvc.perform(get("/api/db-checks?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andExpect(jsonPath("$.[*].id").value(hasItem(dbCheck.getId().intValue())))
                .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
                .andExpect(jsonPath("$.[*].description").value(hasItem(DEFAULT_DESCRIPTION.toString())))
                .andExpect(jsonPath("$.[*].sqlQuery").value(hasItem(DEFAULT_SQL_QUERY.toString())))
                .andExpect(jsonPath("$.[*].expectation").value(hasItem(DEFAULT_EXPECTATION.toString())))
                .andExpect(jsonPath("$.[*].reportIssuesOnly").value(hasItem(DEFAULT_REPORT_ISSUES_ONLY.booleanValue())))
                .andExpect(jsonPath("$.[*].groupColumns").value(hasItem(DEFAULT_GROUP_COLUMNS.toString())))
                .andExpect(jsonPath("$.[*].sequence").value(hasItem(DEFAULT_SEQUENCE)))
                .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
                .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }

    @Test
    @Transactional
    public void getDbCheck() throws Exception {
        // Initialize the database
        dbCheckRepository.saveAndFlush(dbCheck);

        // Get the dbCheck
        restDbCheckMockMvc.perform(get("/api/db-checks/{id}", dbCheck.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(dbCheck.getId().intValue()))
            .andExpect(jsonPath("$.name").value(DEFAULT_NAME.toString()))
            .andExpect(jsonPath("$.description").value(DEFAULT_DESCRIPTION.toString()))
            .andExpect(jsonPath("$.sqlQuery").value(DEFAULT_SQL_QUERY.toString()))
            .andExpect(jsonPath("$.expectation").value(DEFAULT_EXPECTATION.toString()))
            .andExpect(jsonPath("$.reportIssuesOnly").value(DEFAULT_REPORT_ISSUES_ONLY.booleanValue()))
            .andExpect(jsonPath("$.groupColumns").value(DEFAULT_GROUP_COLUMNS.toString()))
            .andExpect(jsonPath("$.sequence").value(DEFAULT_SEQUENCE))
            .andExpect(jsonPath("$.isActive").value(DEFAULT_IS_ACTIVE.booleanValue()))
            .andExpect(jsonPath("$.updatedDate").value(DEFAULT_UPDATED_DATE_STR));
    }

    @Test
    @Transactional
    public void getNonExistingDbCheck() throws Exception {
        // Get the dbCheck
        restDbCheckMockMvc.perform(get("/api/db-checks/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateDbCheck() throws Exception {
        // Initialize the database
        dbCheckService.save(dbCheck);

        int databaseSizeBeforeUpdate = dbCheckRepository.findAll().size();

        // Update the dbCheck
        DbCheck updatedDbCheck = dbCheckRepository.findOne(dbCheck.getId());
        updatedDbCheck.setName(UPDATED_NAME);
        updatedDbCheck.setDescription(UPDATED_DESCRIPTION);
        updatedDbCheck.setSqlQuery(UPDATED_SQL_QUERY);
        updatedDbCheck.setExpectation(UPDATED_EXPECTATION);
        updatedDbCheck.setReportIssuesOnly(UPDATED_REPORT_ISSUES_ONLY);
        updatedDbCheck.setGroupColumns(UPDATED_GROUP_COLUMNS);
        updatedDbCheck.setSequence(UPDATED_SEQUENCE);
        updatedDbCheck.setIsActive(UPDATED_IS_ACTIVE);
        updatedDbCheck.setUpdatedDate(UPDATED_UPDATED_DATE);

        restDbCheckMockMvc.perform(put("/api/db-checks")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(updatedDbCheck)))
                .andExpect(status().isOk());

        // Validate the DbCheck in the database
        List<DbCheck> dbChecks = dbCheckRepository.findAll();
        assertThat(dbChecks).hasSize(databaseSizeBeforeUpdate);
        DbCheck testDbCheck = dbChecks.get(dbChecks.size() - 1);
        assertThat(testDbCheck.getName()).isEqualTo(UPDATED_NAME);
        assertThat(testDbCheck.getDescription()).isEqualTo(UPDATED_DESCRIPTION);
        assertThat(testDbCheck.getSqlQuery()).isEqualTo(UPDATED_SQL_QUERY);
        assertThat(testDbCheck.getExpectation()).isEqualTo(UPDATED_EXPECTATION);
        assertThat(testDbCheck.isReportIssuesOnly()).isEqualTo(UPDATED_REPORT_ISSUES_ONLY);
        assertThat(testDbCheck.getGroupColumns()).isEqualTo(UPDATED_GROUP_COLUMNS);
        assertThat(testDbCheck.getSequence()).isEqualTo(UPDATED_SEQUENCE);
        assertThat(testDbCheck.isIsActive()).isEqualTo(UPDATED_IS_ACTIVE);
        assertThat(testDbCheck.getUpdatedDate()).isEqualTo(UPDATED_UPDATED_DATE);

        // Validate the DbCheck in ElasticSearch
        DbCheck dbCheckEs = dbCheckSearchRepository.findOne(testDbCheck.getId());
        assertThat(dbCheckEs).isEqualToComparingFieldByField(testDbCheck);
    }

    @Test
    @Transactional
    public void deleteDbCheck() throws Exception {
        // Initialize the database
        dbCheckService.save(dbCheck);

        int databaseSizeBeforeDelete = dbCheckRepository.findAll().size();

        // Get the dbCheck
        restDbCheckMockMvc.perform(delete("/api/db-checks/{id}", dbCheck.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate ElasticSearch is empty
        boolean dbCheckExistsInEs = dbCheckSearchRepository.exists(dbCheck.getId());
        assertThat(dbCheckExistsInEs).isFalse();

        // Validate the database is empty
        List<DbCheck> dbChecks = dbCheckRepository.findAll();
        assertThat(dbChecks).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void searchDbCheck() throws Exception {
        // Initialize the database
        dbCheckService.save(dbCheck);

        // Search the dbCheck
        restDbCheckMockMvc.perform(get("/api/_search/db-checks?query=id:" + dbCheck.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(dbCheck.getId().intValue())))
            .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
            .andExpect(jsonPath("$.[*].description").value(hasItem(DEFAULT_DESCRIPTION.toString())))
            .andExpect(jsonPath("$.[*].sqlQuery").value(hasItem(DEFAULT_SQL_QUERY.toString())))
            .andExpect(jsonPath("$.[*].expectation").value(hasItem(DEFAULT_EXPECTATION.toString())))
            .andExpect(jsonPath("$.[*].reportIssuesOnly").value(hasItem(DEFAULT_REPORT_ISSUES_ONLY.booleanValue())))
            .andExpect(jsonPath("$.[*].groupColumns").value(hasItem(DEFAULT_GROUP_COLUMNS.toString())))
            .andExpect(jsonPath("$.[*].sequence").value(hasItem(DEFAULT_SEQUENCE)))
            .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
            .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }
}
