package com.jpmorgan.am.grt.web.rest;

import com.jpmorgan.am.grt.GrtDashboardApp;

import com.jpmorgan.am.grt.domain.DevOps;
import com.jpmorgan.am.grt.repository.DevOpsRepository;
import com.jpmorgan.am.grt.service.DevOpsService;
import com.jpmorgan.am.grt.repository.search.DevOpsSearchRepository;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneId;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the DevOpsResource REST controller.
 *
 * @see DevOpsResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = GrtDashboardApp.class)
public class DevOpsResourceIntTest {

    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(ZoneId.of("Z"));

    private static final String DEFAULT_NAME = "AAAAA";
    private static final String UPDATED_NAME = "BBBBB";

    private static final Integer DEFAULT_SEAL_ID = 1;
    private static final Integer UPDATED_SEAL_ID = 2;
    private static final String DEFAULT_CODE_REPO = "AAAAA";
    private static final String UPDATED_CODE_REPO = "BBBBB";
    private static final String DEFAULT_SCRUM_BOARD = "AAAAA";
    private static final String UPDATED_SCRUM_BOARD = "BBBBB";
    private static final String DEFAULT_CI_BUILD = "AAAAA";
    private static final String UPDATED_CI_BUILD = "BBBBB";
    private static final String DEFAULT_TECHONOLOGY_STACK = "AAAA";
    private static final String UPDATED_TECHONOLOGY_STACK = "BBBB";

    private static final Boolean DEFAULT_IS_ACTIVE = false;
    private static final Boolean UPDATED_IS_ACTIVE = true;

    private static final ZonedDateTime DEFAULT_UPDATED_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneId.systemDefault());
    private static final ZonedDateTime UPDATED_UPDATED_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);
    private static final String DEFAULT_UPDATED_DATE_STR = dateTimeFormatter.format(DEFAULT_UPDATED_DATE);

    @Inject
    private DevOpsRepository devOpsRepository;

    @Inject
    private DevOpsService devOpsService;

    @Inject
    private DevOpsSearchRepository devOpsSearchRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restDevOpsMockMvc;

    private DevOps devOps;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        DevOpsResource devOpsResource = new DevOpsResource();
        ReflectionTestUtils.setField(devOpsResource, "devOpsService", devOpsService);
        this.restDevOpsMockMvc = MockMvcBuilders.standaloneSetup(devOpsResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static DevOps createEntity(EntityManager em) {
        DevOps devOps = new DevOps();
        devOps.setName(DEFAULT_NAME);
        devOps.setSealId(DEFAULT_SEAL_ID);
        devOps.setCodeRepo(DEFAULT_CODE_REPO);
        devOps.setScrumBoard(DEFAULT_SCRUM_BOARD);
        devOps.setCiBuild(DEFAULT_CI_BUILD);
        devOps.setTechonologyStack(DEFAULT_TECHONOLOGY_STACK);
        devOps.setIsActive(DEFAULT_IS_ACTIVE);
        devOps.setUpdatedDate(DEFAULT_UPDATED_DATE);
        return devOps;
    }

    @Before
    public void initTest() {
        devOpsSearchRepository.deleteAll();
        devOps = createEntity(em);
    }

    @Test
    @Transactional
    public void createDevOps() throws Exception {
        int databaseSizeBeforeCreate = devOpsRepository.findAll().size();

        // Create the DevOps

        restDevOpsMockMvc.perform(post("/api/dev-ops")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(devOps)))
                .andExpect(status().isCreated());

        // Validate the DevOps in the database
        List<DevOps> devOps = devOpsRepository.findAll();
        assertThat(devOps).hasSize(databaseSizeBeforeCreate + 1);
        DevOps testDevOps = devOps.get(devOps.size() - 1);
        assertThat(testDevOps.getName()).isEqualTo(DEFAULT_NAME);
        assertThat(testDevOps.getSealId()).isEqualTo(DEFAULT_SEAL_ID);
        assertThat(testDevOps.getCodeRepo()).isEqualTo(DEFAULT_CODE_REPO);
        assertThat(testDevOps.getScrumBoard()).isEqualTo(DEFAULT_SCRUM_BOARD);
        assertThat(testDevOps.getCiBuild()).isEqualTo(DEFAULT_CI_BUILD);
        assertThat(testDevOps.getTechonologyStack()).isEqualTo(DEFAULT_TECHONOLOGY_STACK);
        assertThat(testDevOps.isIsActive()).isEqualTo(DEFAULT_IS_ACTIVE);
        assertThat(testDevOps.getUpdatedDate()).isEqualTo(DEFAULT_UPDATED_DATE);

        // Validate the DevOps in ElasticSearch
        DevOps devOpsEs = devOpsSearchRepository.findOne(testDevOps.getId());
        assertThat(devOpsEs).isEqualToComparingFieldByField(testDevOps);
    }

    @Test
    @Transactional
    public void checkNameIsRequired() throws Exception {
        int databaseSizeBeforeTest = devOpsRepository.findAll().size();
        // set the field null
        devOps.setName(null);

        // Create the DevOps, which fails.

        restDevOpsMockMvc.perform(post("/api/dev-ops")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(devOps)))
                .andExpect(status().isBadRequest());

        List<DevOps> devOps = devOpsRepository.findAll();
        assertThat(devOps).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkSealIdIsRequired() throws Exception {
        int databaseSizeBeforeTest = devOpsRepository.findAll().size();
        // set the field null
        devOps.setSealId(null);

        // Create the DevOps, which fails.

        restDevOpsMockMvc.perform(post("/api/dev-ops")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(devOps)))
                .andExpect(status().isBadRequest());

        List<DevOps> devOps = devOpsRepository.findAll();
        assertThat(devOps).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkCodeRepoIsRequired() throws Exception {
        int databaseSizeBeforeTest = devOpsRepository.findAll().size();
        // set the field null
        devOps.setCodeRepo(null);

        // Create the DevOps, which fails.

        restDevOpsMockMvc.perform(post("/api/dev-ops")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(devOps)))
                .andExpect(status().isBadRequest());

        List<DevOps> devOps = devOpsRepository.findAll();
        assertThat(devOps).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkScrumBoardIsRequired() throws Exception {
        int databaseSizeBeforeTest = devOpsRepository.findAll().size();
        // set the field null
        devOps.setScrumBoard(null);

        // Create the DevOps, which fails.

        restDevOpsMockMvc.perform(post("/api/dev-ops")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(devOps)))
                .andExpect(status().isBadRequest());

        List<DevOps> devOps = devOpsRepository.findAll();
        assertThat(devOps).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkCiBuildIsRequired() throws Exception {
        int databaseSizeBeforeTest = devOpsRepository.findAll().size();
        // set the field null
        devOps.setCiBuild(null);

        // Create the DevOps, which fails.

        restDevOpsMockMvc.perform(post("/api/dev-ops")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(devOps)))
                .andExpect(status().isBadRequest());

        List<DevOps> devOps = devOpsRepository.findAll();
        assertThat(devOps).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkTechonologyStackIsRequired() throws Exception {
        int databaseSizeBeforeTest = devOpsRepository.findAll().size();
        // set the field null
        devOps.setTechonologyStack(null);

        // Create the DevOps, which fails.

        restDevOpsMockMvc.perform(post("/api/dev-ops")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(devOps)))
                .andExpect(status().isBadRequest());

        List<DevOps> devOps = devOpsRepository.findAll();
        assertThat(devOps).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkIsActiveIsRequired() throws Exception {
        int databaseSizeBeforeTest = devOpsRepository.findAll().size();
        // set the field null
        devOps.setIsActive(null);

        // Create the DevOps, which fails.

        restDevOpsMockMvc.perform(post("/api/dev-ops")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(devOps)))
                .andExpect(status().isBadRequest());

        List<DevOps> devOps = devOpsRepository.findAll();
        assertThat(devOps).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllDevOps() throws Exception {
        // Initialize the database
        devOpsRepository.saveAndFlush(devOps);

        // Get all the devOps
        restDevOpsMockMvc.perform(get("/api/dev-ops?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andExpect(jsonPath("$.[*].id").value(hasItem(devOps.getId().intValue())))
                .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
                .andExpect(jsonPath("$.[*].sealId").value(hasItem(DEFAULT_SEAL_ID)))
                .andExpect(jsonPath("$.[*].codeRepo").value(hasItem(DEFAULT_CODE_REPO.toString())))
                .andExpect(jsonPath("$.[*].scrumBoard").value(hasItem(DEFAULT_SCRUM_BOARD.toString())))
                .andExpect(jsonPath("$.[*].ciBuild").value(hasItem(DEFAULT_CI_BUILD.toString())))
                .andExpect(jsonPath("$.[*].techonologyStack").value(hasItem(DEFAULT_TECHONOLOGY_STACK.toString())))
                .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
                .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }

    @Test
    @Transactional
    public void getDevOps() throws Exception {
        // Initialize the database
        devOpsRepository.saveAndFlush(devOps);

        // Get the devOps
        restDevOpsMockMvc.perform(get("/api/dev-ops/{id}", devOps.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(devOps.getId().intValue()))
            .andExpect(jsonPath("$.name").value(DEFAULT_NAME.toString()))
            .andExpect(jsonPath("$.sealId").value(DEFAULT_SEAL_ID))
            .andExpect(jsonPath("$.codeRepo").value(DEFAULT_CODE_REPO.toString()))
            .andExpect(jsonPath("$.scrumBoard").value(DEFAULT_SCRUM_BOARD.toString()))
            .andExpect(jsonPath("$.ciBuild").value(DEFAULT_CI_BUILD.toString()))
            .andExpect(jsonPath("$.techonologyStack").value(DEFAULT_TECHONOLOGY_STACK.toString()))
            .andExpect(jsonPath("$.isActive").value(DEFAULT_IS_ACTIVE.booleanValue()))
            .andExpect(jsonPath("$.updatedDate").value(DEFAULT_UPDATED_DATE_STR));
    }

    @Test
    @Transactional
    public void getNonExistingDevOps() throws Exception {
        // Get the devOps
        restDevOpsMockMvc.perform(get("/api/dev-ops/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateDevOps() throws Exception {
        // Initialize the database
        devOpsService.save(devOps);

        int databaseSizeBeforeUpdate = devOpsRepository.findAll().size();

        // Update the devOps
        DevOps updatedDevOps = devOpsRepository.findOne(devOps.getId());
        updatedDevOps.setName(UPDATED_NAME);
        updatedDevOps.setSealId(UPDATED_SEAL_ID);
        updatedDevOps.setCodeRepo(UPDATED_CODE_REPO);
        updatedDevOps.setScrumBoard(UPDATED_SCRUM_BOARD);
        updatedDevOps.setCiBuild(UPDATED_CI_BUILD);
        updatedDevOps.setTechonologyStack(UPDATED_TECHONOLOGY_STACK);
        updatedDevOps.setIsActive(UPDATED_IS_ACTIVE);
        updatedDevOps.setUpdatedDate(UPDATED_UPDATED_DATE);

        restDevOpsMockMvc.perform(put("/api/dev-ops")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(updatedDevOps)))
                .andExpect(status().isOk());

        // Validate the DevOps in the database
        List<DevOps> devOps = devOpsRepository.findAll();
        assertThat(devOps).hasSize(databaseSizeBeforeUpdate);
        DevOps testDevOps = devOps.get(devOps.size() - 1);
        assertThat(testDevOps.getName()).isEqualTo(UPDATED_NAME);
        assertThat(testDevOps.getSealId()).isEqualTo(UPDATED_SEAL_ID);
        assertThat(testDevOps.getCodeRepo()).isEqualTo(UPDATED_CODE_REPO);
        assertThat(testDevOps.getScrumBoard()).isEqualTo(UPDATED_SCRUM_BOARD);
        assertThat(testDevOps.getCiBuild()).isEqualTo(UPDATED_CI_BUILD);
        assertThat(testDevOps.getTechonologyStack()).isEqualTo(UPDATED_TECHONOLOGY_STACK);
        assertThat(testDevOps.isIsActive()).isEqualTo(UPDATED_IS_ACTIVE);
        assertThat(testDevOps.getUpdatedDate()).isEqualTo(UPDATED_UPDATED_DATE);

        // Validate the DevOps in ElasticSearch
        DevOps devOpsEs = devOpsSearchRepository.findOne(testDevOps.getId());
        assertThat(devOpsEs).isEqualToComparingFieldByField(testDevOps);
    }

    @Test
    @Transactional
    public void deleteDevOps() throws Exception {
        // Initialize the database
        devOpsService.save(devOps);

        int databaseSizeBeforeDelete = devOpsRepository.findAll().size();

        // Get the devOps
        restDevOpsMockMvc.perform(delete("/api/dev-ops/{id}", devOps.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate ElasticSearch is empty
        boolean devOpsExistsInEs = devOpsSearchRepository.exists(devOps.getId());
        assertThat(devOpsExistsInEs).isFalse();

        // Validate the database is empty
        List<DevOps> devOps = devOpsRepository.findAll();
        assertThat(devOps).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void searchDevOps() throws Exception {
        // Initialize the database
        devOpsService.save(devOps);

        // Search the devOps
        restDevOpsMockMvc.perform(get("/api/_search/dev-ops?query=id:" + devOps.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(devOps.getId().intValue())))
            .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
            .andExpect(jsonPath("$.[*].sealId").value(hasItem(DEFAULT_SEAL_ID)))
            .andExpect(jsonPath("$.[*].codeRepo").value(hasItem(DEFAULT_CODE_REPO.toString())))
            .andExpect(jsonPath("$.[*].scrumBoard").value(hasItem(DEFAULT_SCRUM_BOARD.toString())))
            .andExpect(jsonPath("$.[*].ciBuild").value(hasItem(DEFAULT_CI_BUILD.toString())))
            .andExpect(jsonPath("$.[*].techonologyStack").value(hasItem(DEFAULT_TECHONOLOGY_STACK.toString())))
            .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
            .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }
}
