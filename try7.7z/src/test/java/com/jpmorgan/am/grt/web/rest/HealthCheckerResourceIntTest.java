package com.jpmorgan.am.grt.web.rest;

import com.jpmorgan.am.grt.GrtDashboardApp;

import com.jpmorgan.am.grt.domain.HealthChecker;
import com.jpmorgan.am.grt.repository.HealthCheckerRepository;
import com.jpmorgan.am.grt.service.HealthCheckerService;
import com.jpmorgan.am.grt.repository.search.HealthCheckerSearchRepository;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneId;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the HealthCheckerResource REST controller.
 *
 * @see HealthCheckerResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = GrtDashboardApp.class)
public class HealthCheckerResourceIntTest {

    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(ZoneId.of("Z"));

    private static final String DEFAULT_NAME = "AAAAA";
    private static final String UPDATED_NAME = "BBBBB";
    private static final String DEFAULT_JAVA_CLASS = "AAAAA";
    private static final String UPDATED_JAVA_CLASS = "BBBBB";

    private static final Boolean DEFAULT_IS_ACTIVE = false;
    private static final Boolean UPDATED_IS_ACTIVE = true;

    private static final ZonedDateTime DEFAULT_UPDATED_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneId.systemDefault());
    private static final ZonedDateTime UPDATED_UPDATED_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);
    private static final String DEFAULT_UPDATED_DATE_STR = dateTimeFormatter.format(DEFAULT_UPDATED_DATE);

    @Inject
    private HealthCheckerRepository healthCheckerRepository;

    @Inject
    private HealthCheckerService healthCheckerService;

    @Inject
    private HealthCheckerSearchRepository healthCheckerSearchRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restHealthCheckerMockMvc;

    private HealthChecker healthChecker;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        HealthCheckerResource healthCheckerResource = new HealthCheckerResource();
        ReflectionTestUtils.setField(healthCheckerResource, "healthCheckerService", healthCheckerService);
        this.restHealthCheckerMockMvc = MockMvcBuilders.standaloneSetup(healthCheckerResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static HealthChecker createEntity(EntityManager em) {
        HealthChecker healthChecker = new HealthChecker();
        healthChecker.setName(DEFAULT_NAME);
        healthChecker.setJavaClass(DEFAULT_JAVA_CLASS);
        healthChecker.setIsActive(DEFAULT_IS_ACTIVE);
        healthChecker.setUpdatedDate(DEFAULT_UPDATED_DATE);
        return healthChecker;
    }

    @Before
    public void initTest() {
        healthCheckerSearchRepository.deleteAll();
        healthChecker = createEntity(em);
    }

    @Test
    @Transactional
    public void createHealthChecker() throws Exception {
        int databaseSizeBeforeCreate = healthCheckerRepository.findAll().size();

        // Create the HealthChecker

        restHealthCheckerMockMvc.perform(post("/api/health-checkers")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(healthChecker)))
                .andExpect(status().isCreated());

        // Validate the HealthChecker in the database
        List<HealthChecker> healthCheckers = healthCheckerRepository.findAll();
        assertThat(healthCheckers).hasSize(databaseSizeBeforeCreate + 1);
        HealthChecker testHealthChecker = healthCheckers.get(healthCheckers.size() - 1);
        assertThat(testHealthChecker.getName()).isEqualTo(DEFAULT_NAME);
        assertThat(testHealthChecker.getJavaClass()).isEqualTo(DEFAULT_JAVA_CLASS);
        assertThat(testHealthChecker.isIsActive()).isEqualTo(DEFAULT_IS_ACTIVE);
        assertThat(testHealthChecker.getUpdatedDate()).isEqualTo(DEFAULT_UPDATED_DATE);

        // Validate the HealthChecker in ElasticSearch
        HealthChecker healthCheckerEs = healthCheckerSearchRepository.findOne(testHealthChecker.getId());
        assertThat(healthCheckerEs).isEqualToComparingFieldByField(testHealthChecker);
    }

    @Test
    @Transactional
    public void checkNameIsRequired() throws Exception {
        int databaseSizeBeforeTest = healthCheckerRepository.findAll().size();
        // set the field null
        healthChecker.setName(null);

        // Create the HealthChecker, which fails.

        restHealthCheckerMockMvc.perform(post("/api/health-checkers")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(healthChecker)))
                .andExpect(status().isBadRequest());

        List<HealthChecker> healthCheckers = healthCheckerRepository.findAll();
        assertThat(healthCheckers).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkJavaClassIsRequired() throws Exception {
        int databaseSizeBeforeTest = healthCheckerRepository.findAll().size();
        // set the field null
        healthChecker.setJavaClass(null);

        // Create the HealthChecker, which fails.

        restHealthCheckerMockMvc.perform(post("/api/health-checkers")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(healthChecker)))
                .andExpect(status().isBadRequest());

        List<HealthChecker> healthCheckers = healthCheckerRepository.findAll();
        assertThat(healthCheckers).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkIsActiveIsRequired() throws Exception {
        int databaseSizeBeforeTest = healthCheckerRepository.findAll().size();
        // set the field null
        healthChecker.setIsActive(null);

        // Create the HealthChecker, which fails.

        restHealthCheckerMockMvc.perform(post("/api/health-checkers")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(healthChecker)))
                .andExpect(status().isBadRequest());

        List<HealthChecker> healthCheckers = healthCheckerRepository.findAll();
        assertThat(healthCheckers).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllHealthCheckers() throws Exception {
        // Initialize the database
        healthCheckerRepository.saveAndFlush(healthChecker);

        // Get all the healthCheckers
        restHealthCheckerMockMvc.perform(get("/api/health-checkers?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andExpect(jsonPath("$.[*].id").value(hasItem(healthChecker.getId().intValue())))
                .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
                .andExpect(jsonPath("$.[*].javaClass").value(hasItem(DEFAULT_JAVA_CLASS.toString())))
                .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
                .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }

    @Test
    @Transactional
    public void getHealthChecker() throws Exception {
        // Initialize the database
        healthCheckerRepository.saveAndFlush(healthChecker);

        // Get the healthChecker
        restHealthCheckerMockMvc.perform(get("/api/health-checkers/{id}", healthChecker.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(healthChecker.getId().intValue()))
            .andExpect(jsonPath("$.name").value(DEFAULT_NAME.toString()))
            .andExpect(jsonPath("$.javaClass").value(DEFAULT_JAVA_CLASS.toString()))
            .andExpect(jsonPath("$.isActive").value(DEFAULT_IS_ACTIVE.booleanValue()))
            .andExpect(jsonPath("$.updatedDate").value(DEFAULT_UPDATED_DATE_STR));
    }

    @Test
    @Transactional
    public void getNonExistingHealthChecker() throws Exception {
        // Get the healthChecker
        restHealthCheckerMockMvc.perform(get("/api/health-checkers/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateHealthChecker() throws Exception {
        // Initialize the database
        healthCheckerService.save(healthChecker);

        int databaseSizeBeforeUpdate = healthCheckerRepository.findAll().size();

        // Update the healthChecker
        HealthChecker updatedHealthChecker = healthCheckerRepository.findOne(healthChecker.getId());
        updatedHealthChecker.setName(UPDATED_NAME);
        updatedHealthChecker.setJavaClass(UPDATED_JAVA_CLASS);
        updatedHealthChecker.setIsActive(UPDATED_IS_ACTIVE);
        updatedHealthChecker.setUpdatedDate(UPDATED_UPDATED_DATE);

        restHealthCheckerMockMvc.perform(put("/api/health-checkers")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(updatedHealthChecker)))
                .andExpect(status().isOk());

        // Validate the HealthChecker in the database
        List<HealthChecker> healthCheckers = healthCheckerRepository.findAll();
        assertThat(healthCheckers).hasSize(databaseSizeBeforeUpdate);
        HealthChecker testHealthChecker = healthCheckers.get(healthCheckers.size() - 1);
        assertThat(testHealthChecker.getName()).isEqualTo(UPDATED_NAME);
        assertThat(testHealthChecker.getJavaClass()).isEqualTo(UPDATED_JAVA_CLASS);
        assertThat(testHealthChecker.isIsActive()).isEqualTo(UPDATED_IS_ACTIVE);
        assertThat(testHealthChecker.getUpdatedDate()).isEqualTo(UPDATED_UPDATED_DATE);

        // Validate the HealthChecker in ElasticSearch
        HealthChecker healthCheckerEs = healthCheckerSearchRepository.findOne(testHealthChecker.getId());
        assertThat(healthCheckerEs).isEqualToComparingFieldByField(testHealthChecker);
    }

    @Test
    @Transactional
    public void deleteHealthChecker() throws Exception {
        // Initialize the database
        healthCheckerService.save(healthChecker);

        int databaseSizeBeforeDelete = healthCheckerRepository.findAll().size();

        // Get the healthChecker
        restHealthCheckerMockMvc.perform(delete("/api/health-checkers/{id}", healthChecker.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate ElasticSearch is empty
        boolean healthCheckerExistsInEs = healthCheckerSearchRepository.exists(healthChecker.getId());
        assertThat(healthCheckerExistsInEs).isFalse();

        // Validate the database is empty
        List<HealthChecker> healthCheckers = healthCheckerRepository.findAll();
        assertThat(healthCheckers).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void searchHealthChecker() throws Exception {
        // Initialize the database
        healthCheckerService.save(healthChecker);

        // Search the healthChecker
        restHealthCheckerMockMvc.perform(get("/api/_search/health-checkers?query=id:" + healthChecker.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(healthChecker.getId().intValue())))
            .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
            .andExpect(jsonPath("$.[*].javaClass").value(hasItem(DEFAULT_JAVA_CLASS.toString())))
            .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
            .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }
}
