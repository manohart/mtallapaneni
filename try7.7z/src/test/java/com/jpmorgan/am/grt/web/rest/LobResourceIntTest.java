package com.jpmorgan.am.grt.web.rest;

import com.jpmorgan.am.grt.GrtDashboardApp;

import com.jpmorgan.am.grt.domain.Lob;
import com.jpmorgan.am.grt.repository.LobRepository;
import com.jpmorgan.am.grt.service.LobService;
import com.jpmorgan.am.grt.repository.search.LobSearchRepository;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneId;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the LobResource REST controller.
 *
 * @see LobResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = GrtDashboardApp.class)
public class LobResourceIntTest {

    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(ZoneId.of("Z"));

    private static final String DEFAULT_NAME = "AAAAA";
    private static final String UPDATED_NAME = "BBBBB";
    private static final String DEFAULT_DESCRIPTION = "AAAAA";
    private static final String UPDATED_DESCRIPTION = "BBBBB";
    private static final String DEFAULT_CTO_SID = "AAAAAAA";
    private static final String UPDATED_CTO_SID = "BBBBBBB";
    private static final String DEFAULT_OWNER_SID = "AAAAAAA";
    private static final String UPDATED_OWNER_SID = "BBBBBBB";

    private static final Boolean DEFAULT_IS_ACTIVE = false;
    private static final Boolean UPDATED_IS_ACTIVE = true;

    private static final ZonedDateTime DEFAULT_UPDATED_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneId.systemDefault());
    private static final ZonedDateTime UPDATED_UPDATED_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);
    private static final String DEFAULT_UPDATED_DATE_STR = dateTimeFormatter.format(DEFAULT_UPDATED_DATE);

    @Inject
    private LobRepository lobRepository;

    @Inject
    private LobService lobService;

    @Inject
    private LobSearchRepository lobSearchRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restLobMockMvc;

    private Lob lob;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        LobResource lobResource = new LobResource();
        ReflectionTestUtils.setField(lobResource, "lobService", lobService);
        this.restLobMockMvc = MockMvcBuilders.standaloneSetup(lobResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Lob createEntity(EntityManager em) {
        Lob lob = new Lob();
        lob.setName(DEFAULT_NAME);
        lob.setDescription(DEFAULT_DESCRIPTION);
        lob.setCtoSid(DEFAULT_CTO_SID);
        lob.setOwnerSid(DEFAULT_OWNER_SID);
        lob.setIsActive(DEFAULT_IS_ACTIVE);
        lob.setUpdatedDate(DEFAULT_UPDATED_DATE);
        return lob;
    }

    @Before
    public void initTest() {
        lobSearchRepository.deleteAll();
        lob = createEntity(em);
    }

    @Test
    @Transactional
    public void createLob() throws Exception {
        int databaseSizeBeforeCreate = lobRepository.findAll().size();

        // Create the Lob

        restLobMockMvc.perform(post("/api/lobs")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(lob)))
                .andExpect(status().isCreated());

        // Validate the Lob in the database
        List<Lob> lobs = lobRepository.findAll();
        assertThat(lobs).hasSize(databaseSizeBeforeCreate + 1);
        Lob testLob = lobs.get(lobs.size() - 1);
        assertThat(testLob.getName()).isEqualTo(DEFAULT_NAME);
        assertThat(testLob.getDescription()).isEqualTo(DEFAULT_DESCRIPTION);
        assertThat(testLob.getCtoSid()).isEqualTo(DEFAULT_CTO_SID);
        assertThat(testLob.getOwnerSid()).isEqualTo(DEFAULT_OWNER_SID);
        assertThat(testLob.isIsActive()).isEqualTo(DEFAULT_IS_ACTIVE);
        assertThat(testLob.getUpdatedDate()).isEqualTo(DEFAULT_UPDATED_DATE);

        // Validate the Lob in ElasticSearch
        Lob lobEs = lobSearchRepository.findOne(testLob.getId());
        assertThat(lobEs).isEqualToComparingFieldByField(testLob);
    }

    @Test
    @Transactional
    public void checkNameIsRequired() throws Exception {
        int databaseSizeBeforeTest = lobRepository.findAll().size();
        // set the field null
        lob.setName(null);

        // Create the Lob, which fails.

        restLobMockMvc.perform(post("/api/lobs")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(lob)))
                .andExpect(status().isBadRequest());

        List<Lob> lobs = lobRepository.findAll();
        assertThat(lobs).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkDescriptionIsRequired() throws Exception {
        int databaseSizeBeforeTest = lobRepository.findAll().size();
        // set the field null
        lob.setDescription(null);

        // Create the Lob, which fails.

        restLobMockMvc.perform(post("/api/lobs")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(lob)))
                .andExpect(status().isBadRequest());

        List<Lob> lobs = lobRepository.findAll();
        assertThat(lobs).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkCtoSidIsRequired() throws Exception {
        int databaseSizeBeforeTest = lobRepository.findAll().size();
        // set the field null
        lob.setCtoSid(null);

        // Create the Lob, which fails.

        restLobMockMvc.perform(post("/api/lobs")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(lob)))
                .andExpect(status().isBadRequest());

        List<Lob> lobs = lobRepository.findAll();
        assertThat(lobs).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkOwnerSidIsRequired() throws Exception {
        int databaseSizeBeforeTest = lobRepository.findAll().size();
        // set the field null
        lob.setOwnerSid(null);

        // Create the Lob, which fails.

        restLobMockMvc.perform(post("/api/lobs")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(lob)))
                .andExpect(status().isBadRequest());

        List<Lob> lobs = lobRepository.findAll();
        assertThat(lobs).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkIsActiveIsRequired() throws Exception {
        int databaseSizeBeforeTest = lobRepository.findAll().size();
        // set the field null
        lob.setIsActive(null);

        // Create the Lob, which fails.

        restLobMockMvc.perform(post("/api/lobs")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(lob)))
                .andExpect(status().isBadRequest());

        List<Lob> lobs = lobRepository.findAll();
        assertThat(lobs).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllLobs() throws Exception {
        // Initialize the database
        lobRepository.saveAndFlush(lob);

        // Get all the lobs
        restLobMockMvc.perform(get("/api/lobs?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andExpect(jsonPath("$.[*].id").value(hasItem(lob.getId().intValue())))
                .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
                .andExpect(jsonPath("$.[*].description").value(hasItem(DEFAULT_DESCRIPTION.toString())))
                .andExpect(jsonPath("$.[*].ctoSid").value(hasItem(DEFAULT_CTO_SID.toString())))
                .andExpect(jsonPath("$.[*].ownerSid").value(hasItem(DEFAULT_OWNER_SID.toString())))
                .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
                .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }

    @Test
    @Transactional
    public void getLob() throws Exception {
        // Initialize the database
        lobRepository.saveAndFlush(lob);

        // Get the lob
        restLobMockMvc.perform(get("/api/lobs/{id}", lob.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(lob.getId().intValue()))
            .andExpect(jsonPath("$.name").value(DEFAULT_NAME.toString()))
            .andExpect(jsonPath("$.description").value(DEFAULT_DESCRIPTION.toString()))
            .andExpect(jsonPath("$.ctoSid").value(DEFAULT_CTO_SID.toString()))
            .andExpect(jsonPath("$.ownerSid").value(DEFAULT_OWNER_SID.toString()))
            .andExpect(jsonPath("$.isActive").value(DEFAULT_IS_ACTIVE.booleanValue()))
            .andExpect(jsonPath("$.updatedDate").value(DEFAULT_UPDATED_DATE_STR));
    }

    @Test
    @Transactional
    public void getNonExistingLob() throws Exception {
        // Get the lob
        restLobMockMvc.perform(get("/api/lobs/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateLob() throws Exception {
        // Initialize the database
        lobService.save(lob);

        int databaseSizeBeforeUpdate = lobRepository.findAll().size();

        // Update the lob
        Lob updatedLob = lobRepository.findOne(lob.getId());
        updatedLob.setName(UPDATED_NAME);
        updatedLob.setDescription(UPDATED_DESCRIPTION);
        updatedLob.setCtoSid(UPDATED_CTO_SID);
        updatedLob.setOwnerSid(UPDATED_OWNER_SID);
        updatedLob.setIsActive(UPDATED_IS_ACTIVE);
        updatedLob.setUpdatedDate(UPDATED_UPDATED_DATE);

        restLobMockMvc.perform(put("/api/lobs")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(updatedLob)))
                .andExpect(status().isOk());

        // Validate the Lob in the database
        List<Lob> lobs = lobRepository.findAll();
        assertThat(lobs).hasSize(databaseSizeBeforeUpdate);
        Lob testLob = lobs.get(lobs.size() - 1);
        assertThat(testLob.getName()).isEqualTo(UPDATED_NAME);
        assertThat(testLob.getDescription()).isEqualTo(UPDATED_DESCRIPTION);
        assertThat(testLob.getCtoSid()).isEqualTo(UPDATED_CTO_SID);
        assertThat(testLob.getOwnerSid()).isEqualTo(UPDATED_OWNER_SID);
        assertThat(testLob.isIsActive()).isEqualTo(UPDATED_IS_ACTIVE);
        assertThat(testLob.getUpdatedDate()).isEqualTo(UPDATED_UPDATED_DATE);

        // Validate the Lob in ElasticSearch
        Lob lobEs = lobSearchRepository.findOne(testLob.getId());
        assertThat(lobEs).isEqualToComparingFieldByField(testLob);
    }

    @Test
    @Transactional
    public void deleteLob() throws Exception {
        // Initialize the database
        lobService.save(lob);

        int databaseSizeBeforeDelete = lobRepository.findAll().size();

        // Get the lob
        restLobMockMvc.perform(delete("/api/lobs/{id}", lob.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate ElasticSearch is empty
        boolean lobExistsInEs = lobSearchRepository.exists(lob.getId());
        assertThat(lobExistsInEs).isFalse();

        // Validate the database is empty
        List<Lob> lobs = lobRepository.findAll();
        assertThat(lobs).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void searchLob() throws Exception {
        // Initialize the database
        lobService.save(lob);

        // Search the lob
        restLobMockMvc.perform(get("/api/_search/lobs?query=id:" + lob.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(lob.getId().intValue())))
            .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
            .andExpect(jsonPath("$.[*].description").value(hasItem(DEFAULT_DESCRIPTION.toString())))
            .andExpect(jsonPath("$.[*].ctoSid").value(hasItem(DEFAULT_CTO_SID.toString())))
            .andExpect(jsonPath("$.[*].ownerSid").value(hasItem(DEFAULT_OWNER_SID.toString())))
            .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
            .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }
}
