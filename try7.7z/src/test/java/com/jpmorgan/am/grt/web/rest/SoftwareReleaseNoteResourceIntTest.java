package com.jpmorgan.am.grt.web.rest;

import com.jpmorgan.am.grt.GrtDashboardApp;

import com.jpmorgan.am.grt.domain.SoftwareReleaseNote;
import com.jpmorgan.am.grt.repository.SoftwareReleaseNoteRepository;
import com.jpmorgan.am.grt.service.SoftwareReleaseNoteService;
import com.jpmorgan.am.grt.repository.search.SoftwareReleaseNoteSearchRepository;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.time.LocalDate;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneId;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.jpmorgan.am.grt.domain.enumeration.ReleaseType;
/**
 * Test class for the SoftwareReleaseNoteResource REST controller.
 *
 * @see SoftwareReleaseNoteResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = GrtDashboardApp.class)
public class SoftwareReleaseNoteResourceIntTest {

    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(ZoneId.of("Z"));


    private static final LocalDate DEFAULT_DATE = LocalDate.ofEpochDay(0L);
    private static final LocalDate UPDATED_DATE = LocalDate.now(ZoneId.systemDefault());
    private static final String DEFAULT_VERSION = "AAAAA";
    private static final String UPDATED_VERSION = "BBBBB";

    private static final ReleaseType DEFAULT_TYPE = ReleaseType.MAJOR;
    private static final ReleaseType UPDATED_TYPE = ReleaseType.MINOR;
    private static final String DEFAULT_COMMENT = "AAAAA";
    private static final String UPDATED_COMMENT = "BBBBB";

    private static final ZonedDateTime DEFAULT_UPDATED_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneId.systemDefault());
    private static final ZonedDateTime UPDATED_UPDATED_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);
    private static final String DEFAULT_UPDATED_DATE_STR = dateTimeFormatter.format(DEFAULT_UPDATED_DATE);

    @Inject
    private SoftwareReleaseNoteRepository softwareReleaseNoteRepository;

    @Inject
    private SoftwareReleaseNoteService softwareReleaseNoteService;

    @Inject
    private SoftwareReleaseNoteSearchRepository softwareReleaseNoteSearchRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restSoftwareReleaseNoteMockMvc;

    private SoftwareReleaseNote softwareReleaseNote;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        SoftwareReleaseNoteResource softwareReleaseNoteResource = new SoftwareReleaseNoteResource();
        ReflectionTestUtils.setField(softwareReleaseNoteResource, "softwareReleaseNoteService", softwareReleaseNoteService);
        this.restSoftwareReleaseNoteMockMvc = MockMvcBuilders.standaloneSetup(softwareReleaseNoteResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static SoftwareReleaseNote createEntity(EntityManager em) {
        SoftwareReleaseNote softwareReleaseNote = new SoftwareReleaseNote();
        softwareReleaseNote.setDate(DEFAULT_DATE);
        softwareReleaseNote.setVersion(DEFAULT_VERSION);
        softwareReleaseNote.setType(DEFAULT_TYPE);
        softwareReleaseNote.setComment(DEFAULT_COMMENT);
        softwareReleaseNote.setUpdatedDate(DEFAULT_UPDATED_DATE);
        return softwareReleaseNote;
    }

    @Before
    public void initTest() {
        softwareReleaseNoteSearchRepository.deleteAll();
        softwareReleaseNote = createEntity(em);
    }

    @Test
    @Transactional
    public void createSoftwareReleaseNote() throws Exception {
        int databaseSizeBeforeCreate = softwareReleaseNoteRepository.findAll().size();

        // Create the SoftwareReleaseNote

        restSoftwareReleaseNoteMockMvc.perform(post("/api/software-release-notes")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(softwareReleaseNote)))
                .andExpect(status().isCreated());

        // Validate the SoftwareReleaseNote in the database
        List<SoftwareReleaseNote> softwareReleaseNotes = softwareReleaseNoteRepository.findAll();
        assertThat(softwareReleaseNotes).hasSize(databaseSizeBeforeCreate + 1);
        SoftwareReleaseNote testSoftwareReleaseNote = softwareReleaseNotes.get(softwareReleaseNotes.size() - 1);
        assertThat(testSoftwareReleaseNote.getDate()).isEqualTo(DEFAULT_DATE);
        assertThat(testSoftwareReleaseNote.getVersion()).isEqualTo(DEFAULT_VERSION);
        assertThat(testSoftwareReleaseNote.getType()).isEqualTo(DEFAULT_TYPE);
        assertThat(testSoftwareReleaseNote.getComment()).isEqualTo(DEFAULT_COMMENT);
        assertThat(testSoftwareReleaseNote.getUpdatedDate()).isEqualTo(DEFAULT_UPDATED_DATE);

        // Validate the SoftwareReleaseNote in ElasticSearch
        SoftwareReleaseNote softwareReleaseNoteEs = softwareReleaseNoteSearchRepository.findOne(testSoftwareReleaseNote.getId());
        assertThat(softwareReleaseNoteEs).isEqualToComparingFieldByField(testSoftwareReleaseNote);
    }

    @Test
    @Transactional
    public void checkDateIsRequired() throws Exception {
        int databaseSizeBeforeTest = softwareReleaseNoteRepository.findAll().size();
        // set the field null
        softwareReleaseNote.setDate(null);

        // Create the SoftwareReleaseNote, which fails.

        restSoftwareReleaseNoteMockMvc.perform(post("/api/software-release-notes")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(softwareReleaseNote)))
                .andExpect(status().isBadRequest());

        List<SoftwareReleaseNote> softwareReleaseNotes = softwareReleaseNoteRepository.findAll();
        assertThat(softwareReleaseNotes).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkTypeIsRequired() throws Exception {
        int databaseSizeBeforeTest = softwareReleaseNoteRepository.findAll().size();
        // set the field null
        softwareReleaseNote.setType(null);

        // Create the SoftwareReleaseNote, which fails.

        restSoftwareReleaseNoteMockMvc.perform(post("/api/software-release-notes")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(softwareReleaseNote)))
                .andExpect(status().isBadRequest());

        List<SoftwareReleaseNote> softwareReleaseNotes = softwareReleaseNoteRepository.findAll();
        assertThat(softwareReleaseNotes).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllSoftwareReleaseNotes() throws Exception {
        // Initialize the database
        softwareReleaseNoteRepository.saveAndFlush(softwareReleaseNote);

        // Get all the softwareReleaseNotes
        restSoftwareReleaseNoteMockMvc.perform(get("/api/software-release-notes?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andExpect(jsonPath("$.[*].id").value(hasItem(softwareReleaseNote.getId().intValue())))
                .andExpect(jsonPath("$.[*].date").value(hasItem(DEFAULT_DATE.toString())))
                .andExpect(jsonPath("$.[*].version").value(hasItem(DEFAULT_VERSION.toString())))
                .andExpect(jsonPath("$.[*].type").value(hasItem(DEFAULT_TYPE.toString())))
                .andExpect(jsonPath("$.[*].comment").value(hasItem(DEFAULT_COMMENT.toString())))
                .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }

    @Test
    @Transactional
    public void getSoftwareReleaseNote() throws Exception {
        // Initialize the database
        softwareReleaseNoteRepository.saveAndFlush(softwareReleaseNote);

        // Get the softwareReleaseNote
        restSoftwareReleaseNoteMockMvc.perform(get("/api/software-release-notes/{id}", softwareReleaseNote.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(softwareReleaseNote.getId().intValue()))
            .andExpect(jsonPath("$.date").value(DEFAULT_DATE.toString()))
            .andExpect(jsonPath("$.version").value(DEFAULT_VERSION.toString()))
            .andExpect(jsonPath("$.type").value(DEFAULT_TYPE.toString()))
            .andExpect(jsonPath("$.comment").value(DEFAULT_COMMENT.toString()))
            .andExpect(jsonPath("$.updatedDate").value(DEFAULT_UPDATED_DATE_STR));
    }

    @Test
    @Transactional
    public void getNonExistingSoftwareReleaseNote() throws Exception {
        // Get the softwareReleaseNote
        restSoftwareReleaseNoteMockMvc.perform(get("/api/software-release-notes/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateSoftwareReleaseNote() throws Exception {
        // Initialize the database
        softwareReleaseNoteService.save(softwareReleaseNote);

        int databaseSizeBeforeUpdate = softwareReleaseNoteRepository.findAll().size();

        // Update the softwareReleaseNote
        SoftwareReleaseNote updatedSoftwareReleaseNote = softwareReleaseNoteRepository.findOne(softwareReleaseNote.getId());
        updatedSoftwareReleaseNote.setDate(UPDATED_DATE);
        updatedSoftwareReleaseNote.setVersion(UPDATED_VERSION);
        updatedSoftwareReleaseNote.setType(UPDATED_TYPE);
        updatedSoftwareReleaseNote.setComment(UPDATED_COMMENT);
        updatedSoftwareReleaseNote.setUpdatedDate(UPDATED_UPDATED_DATE);

        restSoftwareReleaseNoteMockMvc.perform(put("/api/software-release-notes")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(updatedSoftwareReleaseNote)))
                .andExpect(status().isOk());

        // Validate the SoftwareReleaseNote in the database
        List<SoftwareReleaseNote> softwareReleaseNotes = softwareReleaseNoteRepository.findAll();
        assertThat(softwareReleaseNotes).hasSize(databaseSizeBeforeUpdate);
        SoftwareReleaseNote testSoftwareReleaseNote = softwareReleaseNotes.get(softwareReleaseNotes.size() - 1);
        assertThat(testSoftwareReleaseNote.getDate()).isEqualTo(UPDATED_DATE);
        assertThat(testSoftwareReleaseNote.getVersion()).isEqualTo(UPDATED_VERSION);
        assertThat(testSoftwareReleaseNote.getType()).isEqualTo(UPDATED_TYPE);
        assertThat(testSoftwareReleaseNote.getComment()).isEqualTo(UPDATED_COMMENT);
        assertThat(testSoftwareReleaseNote.getUpdatedDate()).isEqualTo(UPDATED_UPDATED_DATE);

        // Validate the SoftwareReleaseNote in ElasticSearch
        SoftwareReleaseNote softwareReleaseNoteEs = softwareReleaseNoteSearchRepository.findOne(testSoftwareReleaseNote.getId());
        assertThat(softwareReleaseNoteEs).isEqualToComparingFieldByField(testSoftwareReleaseNote);
    }

    @Test
    @Transactional
    public void deleteSoftwareReleaseNote() throws Exception {
        // Initialize the database
        softwareReleaseNoteService.save(softwareReleaseNote);

        int databaseSizeBeforeDelete = softwareReleaseNoteRepository.findAll().size();

        // Get the softwareReleaseNote
        restSoftwareReleaseNoteMockMvc.perform(delete("/api/software-release-notes/{id}", softwareReleaseNote.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate ElasticSearch is empty
        boolean softwareReleaseNoteExistsInEs = softwareReleaseNoteSearchRepository.exists(softwareReleaseNote.getId());
        assertThat(softwareReleaseNoteExistsInEs).isFalse();

        // Validate the database is empty
        List<SoftwareReleaseNote> softwareReleaseNotes = softwareReleaseNoteRepository.findAll();
        assertThat(softwareReleaseNotes).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void searchSoftwareReleaseNote() throws Exception {
        // Initialize the database
        softwareReleaseNoteService.save(softwareReleaseNote);

        // Search the softwareReleaseNote
        restSoftwareReleaseNoteMockMvc.perform(get("/api/_search/software-release-notes?query=id:" + softwareReleaseNote.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(softwareReleaseNote.getId().intValue())))
            .andExpect(jsonPath("$.[*].date").value(hasItem(DEFAULT_DATE.toString())))
            .andExpect(jsonPath("$.[*].version").value(hasItem(DEFAULT_VERSION.toString())))
            .andExpect(jsonPath("$.[*].type").value(hasItem(DEFAULT_TYPE.toString())))
            .andExpect(jsonPath("$.[*].comment").value(hasItem(DEFAULT_COMMENT.toString())))
            .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }
}
