package com.jpmorgan.am.grt.web.rest;

import com.jpmorgan.am.grt.GrtDashboardApp;

import com.jpmorgan.am.grt.domain.WebApp;
import com.jpmorgan.am.grt.repository.WebAppRepository;
import com.jpmorgan.am.grt.service.WebAppService;
import com.jpmorgan.am.grt.repository.search.WebAppSearchRepository;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneId;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the WebAppResource REST controller.
 *
 * @see WebAppResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = GrtDashboardApp.class)
public class WebAppResourceIntTest {

    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(ZoneId.of("Z"));

    private static final String DEFAULT_CONTAINER = "AAAAA";
    private static final String UPDATED_CONTAINER = "BBBBB";
    private static final String DEFAULT_HOSTNAME = "AAAAA";
    private static final String UPDATED_HOSTNAME = "BBBBB";

    private static final Integer DEFAULT_PORT_NUMBER = 1000;
    private static final Integer UPDATED_PORT_NUMBER = 1001;
    private static final String DEFAULT_CONTEXT = "AAAAA";
    private static final String UPDATED_CONTEXT = "BBBBB";
    private static final String DEFAULT_HEALTH_URL = "AAAAA";
    private static final String UPDATED_HEALTH_URL = "BBBBB";
    private static final String DEFAULT_HEALTH_CONTAINS = "AAAAA";
    private static final String UPDATED_HEALTH_CONTAINS = "BBBBB";

    private static final Boolean DEFAULT_IS_ACTIVE = false;
    private static final Boolean UPDATED_IS_ACTIVE = true;

    private static final ZonedDateTime DEFAULT_UPDATED_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneId.systemDefault());
    private static final ZonedDateTime UPDATED_UPDATED_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);
    private static final String DEFAULT_UPDATED_DATE_STR = dateTimeFormatter.format(DEFAULT_UPDATED_DATE);

    @Inject
    private WebAppRepository webAppRepository;

    @Inject
    private WebAppService webAppService;

    @Inject
    private WebAppSearchRepository webAppSearchRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restWebAppMockMvc;

    private WebApp webApp;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        WebAppResource webAppResource = new WebAppResource();
        ReflectionTestUtils.setField(webAppResource, "webAppService", webAppService);
        this.restWebAppMockMvc = MockMvcBuilders.standaloneSetup(webAppResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static WebApp createEntity(EntityManager em) {
        WebApp webApp = new WebApp();
        webApp.setContainer(DEFAULT_CONTAINER);
        webApp.setHostname(DEFAULT_HOSTNAME);
        webApp.setPortNumber(DEFAULT_PORT_NUMBER);
        webApp.setContext(DEFAULT_CONTEXT);
        webApp.setHealthUrl(DEFAULT_HEALTH_URL);
        webApp.setHealthContains(DEFAULT_HEALTH_CONTAINS);
        webApp.setIsActive(DEFAULT_IS_ACTIVE);
        webApp.setUpdatedDate(DEFAULT_UPDATED_DATE);
        return webApp;
    }

    @Before
    public void initTest() {
        webAppSearchRepository.deleteAll();
        webApp = createEntity(em);
    }

    @Test
    @Transactional
    public void createWebApp() throws Exception {
        int databaseSizeBeforeCreate = webAppRepository.findAll().size();

        // Create the WebApp

        restWebAppMockMvc.perform(post("/api/web-apps")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(webApp)))
                .andExpect(status().isCreated());

        // Validate the WebApp in the database
        List<WebApp> webApps = webAppRepository.findAll();
        assertThat(webApps).hasSize(databaseSizeBeforeCreate + 1);
        WebApp testWebApp = webApps.get(webApps.size() - 1);
        assertThat(testWebApp.getContainer()).isEqualTo(DEFAULT_CONTAINER);
        assertThat(testWebApp.getHostname()).isEqualTo(DEFAULT_HOSTNAME);
        assertThat(testWebApp.getPortNumber()).isEqualTo(DEFAULT_PORT_NUMBER);
        assertThat(testWebApp.getContext()).isEqualTo(DEFAULT_CONTEXT);
        assertThat(testWebApp.getHealthUrl()).isEqualTo(DEFAULT_HEALTH_URL);
        assertThat(testWebApp.getHealthContains()).isEqualTo(DEFAULT_HEALTH_CONTAINS);
        assertThat(testWebApp.isIsActive()).isEqualTo(DEFAULT_IS_ACTIVE);
        assertThat(testWebApp.getUpdatedDate()).isEqualTo(DEFAULT_UPDATED_DATE);

        // Validate the WebApp in ElasticSearch
        WebApp webAppEs = webAppSearchRepository.findOne(testWebApp.getId());
        assertThat(webAppEs).isEqualToComparingFieldByField(testWebApp);
    }

    @Test
    @Transactional
    public void checkContainerIsRequired() throws Exception {
        int databaseSizeBeforeTest = webAppRepository.findAll().size();
        // set the field null
        webApp.setContainer(null);

        // Create the WebApp, which fails.

        restWebAppMockMvc.perform(post("/api/web-apps")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(webApp)))
                .andExpect(status().isBadRequest());

        List<WebApp> webApps = webAppRepository.findAll();
        assertThat(webApps).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkHostnameIsRequired() throws Exception {
        int databaseSizeBeforeTest = webAppRepository.findAll().size();
        // set the field null
        webApp.setHostname(null);

        // Create the WebApp, which fails.

        restWebAppMockMvc.perform(post("/api/web-apps")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(webApp)))
                .andExpect(status().isBadRequest());

        List<WebApp> webApps = webAppRepository.findAll();
        assertThat(webApps).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkPortNumberIsRequired() throws Exception {
        int databaseSizeBeforeTest = webAppRepository.findAll().size();
        // set the field null
        webApp.setPortNumber(null);

        // Create the WebApp, which fails.

        restWebAppMockMvc.perform(post("/api/web-apps")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(webApp)))
                .andExpect(status().isBadRequest());

        List<WebApp> webApps = webAppRepository.findAll();
        assertThat(webApps).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkContextIsRequired() throws Exception {
        int databaseSizeBeforeTest = webAppRepository.findAll().size();
        // set the field null
        webApp.setContext(null);

        // Create the WebApp, which fails.

        restWebAppMockMvc.perform(post("/api/web-apps")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(webApp)))
                .andExpect(status().isBadRequest());

        List<WebApp> webApps = webAppRepository.findAll();
        assertThat(webApps).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkIsActiveIsRequired() throws Exception {
        int databaseSizeBeforeTest = webAppRepository.findAll().size();
        // set the field null
        webApp.setIsActive(null);

        // Create the WebApp, which fails.

        restWebAppMockMvc.perform(post("/api/web-apps")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(webApp)))
                .andExpect(status().isBadRequest());

        List<WebApp> webApps = webAppRepository.findAll();
        assertThat(webApps).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllWebApps() throws Exception {
        // Initialize the database
        webAppRepository.saveAndFlush(webApp);

        // Get all the webApps
        restWebAppMockMvc.perform(get("/api/web-apps?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andExpect(jsonPath("$.[*].id").value(hasItem(webApp.getId().intValue())))
                .andExpect(jsonPath("$.[*].container").value(hasItem(DEFAULT_CONTAINER.toString())))
                .andExpect(jsonPath("$.[*].hostname").value(hasItem(DEFAULT_HOSTNAME.toString())))
                .andExpect(jsonPath("$.[*].portNumber").value(hasItem(DEFAULT_PORT_NUMBER)))
                .andExpect(jsonPath("$.[*].context").value(hasItem(DEFAULT_CONTEXT.toString())))
                .andExpect(jsonPath("$.[*].healthUrl").value(hasItem(DEFAULT_HEALTH_URL.toString())))
                .andExpect(jsonPath("$.[*].healthContains").value(hasItem(DEFAULT_HEALTH_CONTAINS.toString())))
                .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
                .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }

    @Test
    @Transactional
    public void getWebApp() throws Exception {
        // Initialize the database
        webAppRepository.saveAndFlush(webApp);

        // Get the webApp
        restWebAppMockMvc.perform(get("/api/web-apps/{id}", webApp.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(webApp.getId().intValue()))
            .andExpect(jsonPath("$.container").value(DEFAULT_CONTAINER.toString()))
            .andExpect(jsonPath("$.hostname").value(DEFAULT_HOSTNAME.toString()))
            .andExpect(jsonPath("$.portNumber").value(DEFAULT_PORT_NUMBER))
            .andExpect(jsonPath("$.context").value(DEFAULT_CONTEXT.toString()))
            .andExpect(jsonPath("$.healthUrl").value(DEFAULT_HEALTH_URL.toString()))
            .andExpect(jsonPath("$.healthContains").value(DEFAULT_HEALTH_CONTAINS.toString()))
            .andExpect(jsonPath("$.isActive").value(DEFAULT_IS_ACTIVE.booleanValue()))
            .andExpect(jsonPath("$.updatedDate").value(DEFAULT_UPDATED_DATE_STR));
    }

    @Test
    @Transactional
    public void getNonExistingWebApp() throws Exception {
        // Get the webApp
        restWebAppMockMvc.perform(get("/api/web-apps/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateWebApp() throws Exception {
        // Initialize the database
        webAppService.save(webApp);

        int databaseSizeBeforeUpdate = webAppRepository.findAll().size();

        // Update the webApp
        WebApp updatedWebApp = webAppRepository.findOne(webApp.getId());
        updatedWebApp.setContainer(UPDATED_CONTAINER);
        updatedWebApp.setHostname(UPDATED_HOSTNAME);
        updatedWebApp.setPortNumber(UPDATED_PORT_NUMBER);
        updatedWebApp.setContext(UPDATED_CONTEXT);
        updatedWebApp.setHealthUrl(UPDATED_HEALTH_URL);
        updatedWebApp.setHealthContains(UPDATED_HEALTH_CONTAINS);
        updatedWebApp.setIsActive(UPDATED_IS_ACTIVE);
        updatedWebApp.setUpdatedDate(UPDATED_UPDATED_DATE);

        restWebAppMockMvc.perform(put("/api/web-apps")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(updatedWebApp)))
                .andExpect(status().isOk());

        // Validate the WebApp in the database
        List<WebApp> webApps = webAppRepository.findAll();
        assertThat(webApps).hasSize(databaseSizeBeforeUpdate);
        WebApp testWebApp = webApps.get(webApps.size() - 1);
        assertThat(testWebApp.getContainer()).isEqualTo(UPDATED_CONTAINER);
        assertThat(testWebApp.getHostname()).isEqualTo(UPDATED_HOSTNAME);
        assertThat(testWebApp.getPortNumber()).isEqualTo(UPDATED_PORT_NUMBER);
        assertThat(testWebApp.getContext()).isEqualTo(UPDATED_CONTEXT);
        assertThat(testWebApp.getHealthUrl()).isEqualTo(UPDATED_HEALTH_URL);
        assertThat(testWebApp.getHealthContains()).isEqualTo(UPDATED_HEALTH_CONTAINS);
        assertThat(testWebApp.isIsActive()).isEqualTo(UPDATED_IS_ACTIVE);
        assertThat(testWebApp.getUpdatedDate()).isEqualTo(UPDATED_UPDATED_DATE);

        // Validate the WebApp in ElasticSearch
        WebApp webAppEs = webAppSearchRepository.findOne(testWebApp.getId());
        assertThat(webAppEs).isEqualToComparingFieldByField(testWebApp);
    }

    @Test
    @Transactional
    public void deleteWebApp() throws Exception {
        // Initialize the database
        webAppService.save(webApp);

        int databaseSizeBeforeDelete = webAppRepository.findAll().size();

        // Get the webApp
        restWebAppMockMvc.perform(delete("/api/web-apps/{id}", webApp.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate ElasticSearch is empty
        boolean webAppExistsInEs = webAppSearchRepository.exists(webApp.getId());
        assertThat(webAppExistsInEs).isFalse();

        // Validate the database is empty
        List<WebApp> webApps = webAppRepository.findAll();
        assertThat(webApps).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void searchWebApp() throws Exception {
        // Initialize the database
        webAppService.save(webApp);

        // Search the webApp
        restWebAppMockMvc.perform(get("/api/_search/web-apps?query=id:" + webApp.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(webApp.getId().intValue())))
            .andExpect(jsonPath("$.[*].container").value(hasItem(DEFAULT_CONTAINER.toString())))
            .andExpect(jsonPath("$.[*].hostname").value(hasItem(DEFAULT_HOSTNAME.toString())))
            .andExpect(jsonPath("$.[*].portNumber").value(hasItem(DEFAULT_PORT_NUMBER)))
            .andExpect(jsonPath("$.[*].context").value(hasItem(DEFAULT_CONTEXT.toString())))
            .andExpect(jsonPath("$.[*].healthUrl").value(hasItem(DEFAULT_HEALTH_URL.toString())))
            .andExpect(jsonPath("$.[*].healthContains").value(hasItem(DEFAULT_HEALTH_CONTAINS.toString())))
            .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
            .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }
}
