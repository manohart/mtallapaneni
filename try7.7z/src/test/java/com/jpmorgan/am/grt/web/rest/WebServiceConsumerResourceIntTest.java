package com.jpmorgan.am.grt.web.rest;

import com.jpmorgan.am.grt.GrtDashboardApp;

import com.jpmorgan.am.grt.domain.WebServiceConsumer;
import com.jpmorgan.am.grt.repository.WebServiceConsumerRepository;
import com.jpmorgan.am.grt.service.WebServiceConsumerService;
import com.jpmorgan.am.grt.repository.search.WebServiceConsumerSearchRepository;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneId;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the WebServiceConsumerResource REST controller.
 *
 * @see WebServiceConsumerResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = GrtDashboardApp.class)
public class WebServiceConsumerResourceIntTest {

    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(ZoneId.of("Z"));


    private static final Boolean DEFAULT_IS_ACTIVE = false;
    private static final Boolean UPDATED_IS_ACTIVE = true;

    private static final ZonedDateTime DEFAULT_UPDATED_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneId.systemDefault());
    private static final ZonedDateTime UPDATED_UPDATED_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);
    private static final String DEFAULT_UPDATED_DATE_STR = dateTimeFormatter.format(DEFAULT_UPDATED_DATE);

    @Inject
    private WebServiceConsumerRepository webServiceConsumerRepository;

    @Inject
    private WebServiceConsumerService webServiceConsumerService;

    @Inject
    private WebServiceConsumerSearchRepository webServiceConsumerSearchRepository;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restWebServiceConsumerMockMvc;

    private WebServiceConsumer webServiceConsumer;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        WebServiceConsumerResource webServiceConsumerResource = new WebServiceConsumerResource();
        ReflectionTestUtils.setField(webServiceConsumerResource, "webServiceConsumerService", webServiceConsumerService);
        this.restWebServiceConsumerMockMvc = MockMvcBuilders.standaloneSetup(webServiceConsumerResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static WebServiceConsumer createEntity(EntityManager em) {
        WebServiceConsumer webServiceConsumer = new WebServiceConsumer();
        webServiceConsumer.setIsActive(DEFAULT_IS_ACTIVE);
        webServiceConsumer.setUpdatedDate(DEFAULT_UPDATED_DATE);
        return webServiceConsumer;
    }

    @Before
    public void initTest() {
        webServiceConsumerSearchRepository.deleteAll();
        webServiceConsumer = createEntity(em);
    }

    @Test
    @Transactional
    public void createWebServiceConsumer() throws Exception {
        int databaseSizeBeforeCreate = webServiceConsumerRepository.findAll().size();

        // Create the WebServiceConsumer

        restWebServiceConsumerMockMvc.perform(post("/api/web-service-consumers")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(webServiceConsumer)))
                .andExpect(status().isCreated());

        // Validate the WebServiceConsumer in the database
        List<WebServiceConsumer> webServiceConsumers = webServiceConsumerRepository.findAll();
        assertThat(webServiceConsumers).hasSize(databaseSizeBeforeCreate + 1);
        WebServiceConsumer testWebServiceConsumer = webServiceConsumers.get(webServiceConsumers.size() - 1);
        assertThat(testWebServiceConsumer.isIsActive()).isEqualTo(DEFAULT_IS_ACTIVE);
        assertThat(testWebServiceConsumer.getUpdatedDate()).isEqualTo(DEFAULT_UPDATED_DATE);

        // Validate the WebServiceConsumer in ElasticSearch
        WebServiceConsumer webServiceConsumerEs = webServiceConsumerSearchRepository.findOne(testWebServiceConsumer.getId());
        assertThat(webServiceConsumerEs).isEqualToComparingFieldByField(testWebServiceConsumer);
    }

    @Test
    @Transactional
    public void checkIsActiveIsRequired() throws Exception {
        int databaseSizeBeforeTest = webServiceConsumerRepository.findAll().size();
        // set the field null
        webServiceConsumer.setIsActive(null);

        // Create the WebServiceConsumer, which fails.

        restWebServiceConsumerMockMvc.perform(post("/api/web-service-consumers")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(webServiceConsumer)))
                .andExpect(status().isBadRequest());

        List<WebServiceConsumer> webServiceConsumers = webServiceConsumerRepository.findAll();
        assertThat(webServiceConsumers).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllWebServiceConsumers() throws Exception {
        // Initialize the database
        webServiceConsumerRepository.saveAndFlush(webServiceConsumer);

        // Get all the webServiceConsumers
        restWebServiceConsumerMockMvc.perform(get("/api/web-service-consumers?sort=id,desc"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andExpect(jsonPath("$.[*].id").value(hasItem(webServiceConsumer.getId().intValue())))
                .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
                .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }

    @Test
    @Transactional
    public void getWebServiceConsumer() throws Exception {
        // Initialize the database
        webServiceConsumerRepository.saveAndFlush(webServiceConsumer);

        // Get the webServiceConsumer
        restWebServiceConsumerMockMvc.perform(get("/api/web-service-consumers/{id}", webServiceConsumer.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(webServiceConsumer.getId().intValue()))
            .andExpect(jsonPath("$.isActive").value(DEFAULT_IS_ACTIVE.booleanValue()))
            .andExpect(jsonPath("$.updatedDate").value(DEFAULT_UPDATED_DATE_STR));
    }

    @Test
    @Transactional
    public void getNonExistingWebServiceConsumer() throws Exception {
        // Get the webServiceConsumer
        restWebServiceConsumerMockMvc.perform(get("/api/web-service-consumers/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateWebServiceConsumer() throws Exception {
        // Initialize the database
        webServiceConsumerService.save(webServiceConsumer);

        int databaseSizeBeforeUpdate = webServiceConsumerRepository.findAll().size();

        // Update the webServiceConsumer
        WebServiceConsumer updatedWebServiceConsumer = webServiceConsumerRepository.findOne(webServiceConsumer.getId());
        updatedWebServiceConsumer.setIsActive(UPDATED_IS_ACTIVE);
        updatedWebServiceConsumer.setUpdatedDate(UPDATED_UPDATED_DATE);

        restWebServiceConsumerMockMvc.perform(put("/api/web-service-consumers")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(updatedWebServiceConsumer)))
                .andExpect(status().isOk());

        // Validate the WebServiceConsumer in the database
        List<WebServiceConsumer> webServiceConsumers = webServiceConsumerRepository.findAll();
        assertThat(webServiceConsumers).hasSize(databaseSizeBeforeUpdate);
        WebServiceConsumer testWebServiceConsumer = webServiceConsumers.get(webServiceConsumers.size() - 1);
        assertThat(testWebServiceConsumer.isIsActive()).isEqualTo(UPDATED_IS_ACTIVE);
        assertThat(testWebServiceConsumer.getUpdatedDate()).isEqualTo(UPDATED_UPDATED_DATE);

        // Validate the WebServiceConsumer in ElasticSearch
        WebServiceConsumer webServiceConsumerEs = webServiceConsumerSearchRepository.findOne(testWebServiceConsumer.getId());
        assertThat(webServiceConsumerEs).isEqualToComparingFieldByField(testWebServiceConsumer);
    }

    @Test
    @Transactional
    public void deleteWebServiceConsumer() throws Exception {
        // Initialize the database
        webServiceConsumerService.save(webServiceConsumer);

        int databaseSizeBeforeDelete = webServiceConsumerRepository.findAll().size();

        // Get the webServiceConsumer
        restWebServiceConsumerMockMvc.perform(delete("/api/web-service-consumers/{id}", webServiceConsumer.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate ElasticSearch is empty
        boolean webServiceConsumerExistsInEs = webServiceConsumerSearchRepository.exists(webServiceConsumer.getId());
        assertThat(webServiceConsumerExistsInEs).isFalse();

        // Validate the database is empty
        List<WebServiceConsumer> webServiceConsumers = webServiceConsumerRepository.findAll();
        assertThat(webServiceConsumers).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void searchWebServiceConsumer() throws Exception {
        // Initialize the database
        webServiceConsumerService.save(webServiceConsumer);

        // Search the webServiceConsumer
        restWebServiceConsumerMockMvc.perform(get("/api/_search/web-service-consumers?query=id:" + webServiceConsumer.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(webServiceConsumer.getId().intValue())))
            .andExpect(jsonPath("$.[*].isActive").value(hasItem(DEFAULT_IS_ACTIVE.booleanValue())))
            .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(DEFAULT_UPDATED_DATE_STR)));
    }
}
