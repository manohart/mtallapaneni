'use strict';

describe('Controller Tests', function() {

    describe('AutoNotification Management Detail Controller', function() {
        var $scope, $rootScope;
        var MockEntity, MockPreviousState, MockAutoNotification, MockNotificationRule, MockLob, MockApplication;
        var createController;

        beforeEach(inject(function($injector) {
            $rootScope = $injector.get('$rootScope');
            $scope = $rootScope.$new();
            MockEntity = jasmine.createSpy('MockEntity');
            MockPreviousState = jasmine.createSpy('MockPreviousState');
            MockAutoNotification = jasmine.createSpy('MockAutoNotification');
            MockNotificationRule = jasmine.createSpy('MockNotificationRule');
            MockLob = jasmine.createSpy('MockLob');
            MockApplication = jasmine.createSpy('MockApplication');
            

            var locals = {
                '$scope': $scope,
                '$rootScope': $rootScope,
                'entity': MockEntity,
                'previousState': MockPreviousState,
                'AutoNotification': MockAutoNotification,
                'NotificationRule': MockNotificationRule,
                'Lob': MockLob,
                'Application': MockApplication
            };
            createController = function() {
                $injector.get('$controller')("AutoNotificationDetailController", locals);
            };
        }));


        describe('Root Scope Listening', function() {
            it('Unregisters root scope listener upon scope destruction', function() {
                var eventType = 'grtDashboardApp:autoNotificationUpdate';

                createController();
                expect($rootScope.$$listenerCount[eventType]).toEqual(1);

                $scope.$destroy();
                expect($rootScope.$$listenerCount[eventType]).toBeUndefined();
            });
        });
    });

});
