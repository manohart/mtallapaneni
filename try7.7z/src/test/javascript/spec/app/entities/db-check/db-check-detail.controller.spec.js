'use strict';

describe('Controller Tests', function() {

    describe('DbCheck Management Detail Controller', function() {
        var $scope, $rootScope;
        var MockEntity, MockPreviousState, MockDbCheck, MockHealthCheckConfig, MockWebService, MockHealthChecker, MockBatchReport;
        var createController;

        beforeEach(inject(function($injector) {
            $rootScope = $injector.get('$rootScope');
            $scope = $rootScope.$new();
            MockEntity = jasmine.createSpy('MockEntity');
            MockPreviousState = jasmine.createSpy('MockPreviousState');
            MockDbCheck = jasmine.createSpy('MockDbCheck');
            MockHealthCheckConfig = jasmine.createSpy('MockHealthCheckConfig');
            MockWebService = jasmine.createSpy('MockWebService');
            MockHealthChecker = jasmine.createSpy('MockHealthChecker');
            MockBatchReport = jasmine.createSpy('MockBatchReport');
            

            var locals = {
                '$scope': $scope,
                '$rootScope': $rootScope,
                'entity': MockEntity,
                'previousState': MockPreviousState,
                'DbCheck': MockDbCheck,
                'HealthCheckConfig': MockHealthCheckConfig,
                'WebService': MockWebService,
                'HealthChecker': MockHealthChecker,
                'BatchReport': MockBatchReport
            };
            createController = function() {
                $injector.get('$controller')("DbCheckDetailController", locals);
            };
        }));


        describe('Root Scope Listening', function() {
            it('Unregisters root scope listener upon scope destruction', function() {
                var eventType = 'grtDashboardApp:dbCheckUpdate';

                createController();
                expect($rootScope.$$listenerCount[eventType]).toEqual(1);

                $scope.$destroy();
                expect($rootScope.$$listenerCount[eventType]).toBeUndefined();
            });
        });
    });

});
