'use strict';

describe('Controller Tests', function() {

    describe('Lob Management Detail Controller', function() {
        var $scope, $rootScope;
        var MockEntity, MockPreviousState, MockLob, MockApplication, MockArchiveLocation, MockAutoNotification, MockDevOps, MockTemplate, MockTeam;
        var createController;

        beforeEach(inject(function($injector) {
            $rootScope = $injector.get('$rootScope');
            $scope = $rootScope.$new();
            MockEntity = jasmine.createSpy('MockEntity');
            MockPreviousState = jasmine.createSpy('MockPreviousState');
            MockLob = jasmine.createSpy('MockLob');
            MockApplication = jasmine.createSpy('MockApplication');
            MockArchiveLocation = jasmine.createSpy('MockArchiveLocation');
            MockAutoNotification = jasmine.createSpy('MockAutoNotification');
            MockDevOps = jasmine.createSpy('MockDevOps');
            MockTemplate = jasmine.createSpy('MockTemplate');
            MockTeam = jasmine.createSpy('MockTeam');
            

            var locals = {
                '$scope': $scope,
                '$rootScope': $rootScope,
                'entity': MockEntity,
                'previousState': MockPreviousState,
                'Lob': MockLob,
                'Application': MockApplication,
                'ArchiveLocation': MockArchiveLocation,
                'AutoNotification': MockAutoNotification,
                'DevOps': MockDevOps,
                'Template': MockTemplate,
                'Team': MockTeam
            };
            createController = function() {
                $injector.get('$controller')("LobDetailController", locals);
            };
        }));


        describe('Root Scope Listening', function() {
            it('Unregisters root scope listener upon scope destruction', function() {
                var eventType = 'grtDashboardApp:lobUpdate';

                createController();
                expect($rootScope.$$listenerCount[eventType]).toEqual(1);

                $scope.$destroy();
                expect($rootScope.$$listenerCount[eventType]).toBeUndefined();
            });
        });
    });

});
